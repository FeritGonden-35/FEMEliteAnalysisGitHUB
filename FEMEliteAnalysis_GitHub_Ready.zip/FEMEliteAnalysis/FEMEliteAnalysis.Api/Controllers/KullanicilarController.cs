using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace FEMEliteAnalysis.Api.Controllers;

[ApiController]
[Route("api/kullanicilar")]
public class KullanicilarController : ControllerBase
{
    private readonly IKullaniciService _kullaniciService;

    public KullanicilarController(IKullaniciService kullaniciService)
    {
        _kullaniciService = kullaniciService;
    }

    [HttpGet("telegram/{telegramKullaniciId:long}")]
    public async Task<IActionResult> TelegramIdIleGetir(
        long telegramKullaniciId,
        CancellationToken cancellationToken)
    {
        var kullanici = await _kullaniciService.TelegramIdIleGetirAsync(
            telegramKullaniciId,
            cancellationToken);

        return kullanici is null ? NotFound() : Ok(kullanici);
    }
}
