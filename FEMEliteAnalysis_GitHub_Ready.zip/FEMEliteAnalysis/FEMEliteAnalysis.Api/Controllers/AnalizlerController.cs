using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace FEMEliteAnalysis.Api.Controllers;

[ApiController]
[Route("api/analizler")]
public class AnalizlerController : ControllerBase
{
    private readonly IAnalizService _analizService;

    public AnalizlerController(IAnalizService analizService)
    {
        _analizService = analizService;
    }

    [HttpPost]
    public async Task<IActionResult> Olustur(
        AnalizOlusturRequest request,
        CancellationToken cancellationToken)
    {
        var sonuc = await _analizService.AnalizOlusturAsync(
            request,
            cancellationToken);

        return sonuc.Basarili
            ? Ok(sonuc)
            : BadRequest(sonuc);
    }
}
