using System.Globalization;
using System.Text.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.VeriToplama;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Providers.SofaScore;

public class SofaScoreVeriSaglayici : IVeriSaglayici
{
    private readonly HttpClient _httpClient;
    private readonly FemDbContext _dbContext;
    private readonly SofaScoreOptions _options;
    private readonly ILogger<SofaScoreVeriSaglayici> _logger;

    public SofaScoreVeriSaglayici(
        HttpClient httpClient,
        FemDbContext dbContext,
        IOptions<SofaScoreOptions> options,
        ILogger<SofaScoreVeriSaglayici> logger)
    {
        _httpClient = httpClient;
        _dbContext = dbContext;
        _options = options.Value;
        _logger = logger;
    }

    public VeriSaglayiciTuru Tur => VeriSaglayiciTuru.Crawler;
    public string Ad => "SofaScore Crawler";
    public bool AktifMi => _options.Aktif;

    public async Task<ServiceResult<bool>> BaglantiTestiAsync(
        CancellationToken cancellationToken)
    {
        if (!AktifMi)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "SofaScore sağlayıcısı aktif değil.");
        }

        var tarih = DateOnly.FromDateTime(
            TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                DateTime.UtcNow,
                "Turkey Standard Time"));

        try
        {
            using var response = await _httpClient.GetAsync(
                TarihEndpointi(tarih),
                cancellationToken);

            return response.IsSuccessStatusCode
                ? ServiceResult<bool>.BasariliSonuc(
                    true,
                    "SofaScore bağlantısı başarılı.")
                : ServiceResult<bool>.BasarisizSonuc(
                    $"SofaScore bağlantısı başarısız: " +
                    $"{(int)response.StatusCode}");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "SofaScore bağlantı testi başarısız.");

            return ServiceResult<bool>.BasarisizSonuc(
                "SofaScore bağlantı testi sırasında hata oluştu.");
        }
    }

    public async Task<ServiceResult<VeriToplamaSonucDto>> VeriToplaAsync(
        VeriToplamaIstekDto istek,
        CancellationToken cancellationToken)
    {
        var baslama = DateTime.UtcNow;

        if (!AktifMi)
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "SofaScore sağlayıcısı aktif değil.");
        }

        if (istek.BitisTarihi < istek.BaslangicTarihi)
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "Bitiş tarihi başlangıç tarihinden küçük olamaz.");
        }

        var gunSayisi =
            istek.BitisTarihi.DayNumber -
            istek.BaslangicTarihi.DayNumber + 1;

        var maksimumGun = Math.Max(
            1,
            _options.MaksimumGunSayisi);

        if (gunSayisi > maksimumGun)
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                $"Tek işlemde en fazla {maksimumGun} gün çekilebilir.");
        }

        var sonuc = new VeriToplamaSonucDto
        {
            SaglayiciTuru = Tur,
            BaslamaZamani = baslama
        };

        var ligIdleri = new HashSet<int>();
        var takimIdleri = new HashSet<int>();

        try
        {
            for (var tarih = istek.BaslangicTarihi;
                 tarih <= istek.BitisTarihi;
                 tarih = tarih.AddDays(1))
            {
                cancellationToken.ThrowIfCancellationRequested();

                var gunSonucu = await TarihVerisiniIsleAsync(
                    tarih,
                    istek,
                    ligIdleri,
                    takimIdleri,
                    cancellationToken);

                sonuc.GelenMacSayisi += gunSonucu.GelenMac;
                sonuc.EklenenKayitSayisi += gunSonucu.Eklenen;
                sonuc.GuncellenenKayitSayisi += gunSonucu.Guncellenen;
                sonuc.AtlananKayitSayisi += gunSonucu.Atlanan;
                sonuc.Uyarilar.AddRange(gunSonucu.Uyarilar);

                if (tarih < istek.BitisTarihi)
                {
                    await Task.Delay(
                        Math.Max(200, _options.IsteklerArasiBeklemeMs),
                        cancellationToken);
                }
            }

            sonuc.GelenLigSayisi = ligIdleri.Count;
            sonuc.GelenTakimSayisi = takimIdleri.Count;
            sonuc.BitisZamani = DateTime.UtcNow;
            sonuc.Basarili = true;
            sonuc.Mesaj =
                $"{sonuc.GelenMacSayisi} maç işlendi; " +
                $"{sonuc.EklenenKayitSayisi} kayıt eklendi, " +
                $"{sonuc.GuncellenenKayitSayisi} kayıt güncellendi.";

            return ServiceResult<VeriToplamaSonucDto>.BasariliSonuc(
                sonuc,
                sonuc.Mesaj);
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            sonuc.BitisZamani = DateTime.UtcNow;
            sonuc.Basarili = false;
            sonuc.Mesaj = "Veri toplama iptal edildi.";

            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                sonuc.Mesaj);
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "SofaScore veri toplama işlemi başarısız.");

            sonuc.BitisZamani = DateTime.UtcNow;
            sonuc.Basarili = false;
            sonuc.Mesaj =
                "SofaScore verileri işlenirken hata oluştu.";

            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                sonuc.Mesaj);
        }
    }

    private async Task<GunIslemeSonucu> TarihVerisiniIsleAsync(
        DateOnly tarih,
        VeriToplamaIstekDto istek,
        HashSet<int> ligIdleri,
        HashSet<int> takimIdleri,
        CancellationToken cancellationToken)
    {
        using var response = await _httpClient.GetAsync(
            TarihEndpointi(tarih),
            cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            return new GunIslemeSonucu
            {
                Uyarilar =
                {
                    $"{tarih:dd.MM.yyyy}: HTTP " +
                    $"{(int)response.StatusCode}"
                }
            };
        }

        await using var stream =
            await response.Content.ReadAsStreamAsync(
                cancellationToken);

        using var document = await JsonDocument.ParseAsync(
            stream,
            cancellationToken: cancellationToken);

        if (!document.RootElement.TryGetProperty(
                "events",
                out var events) ||
            events.ValueKind != JsonValueKind.Array)
        {
            return new GunIslemeSonucu
            {
                Uyarilar =
                {
                    $"{tarih:dd.MM.yyyy}: events alanı bulunamadı."
                }
            };
        }

        var gunSonucu = new GunIslemeSonucu();

        foreach (var eventElement in events.EnumerateArray())
        {
            gunSonucu.GelenMac++;

            try
            {
                var parsed = ParseEvent(eventElement);

                if (parsed is null)
                {
                    gunSonucu.Atlanan++;
                    continue;
                }

                if (istek.LigIdleri.Count > 0 &&
                    !istek.LigIdleri.Contains(parsed.TournamentId))
                {
                    gunSonucu.Atlanan++;
                    continue;
                }

                ligIdleri.Add(parsed.TournamentId);
                takimIdleri.Add(parsed.HomeTeamId);
                takimIdleri.Add(parsed.AwayTeamId);

                var islem = await MacKaydetVeyaGuncelleAsync(
                    parsed,
                    cancellationToken);

                if (islem == KayitIslemi.Eklendi)
                    gunSonucu.Eklenen++;
                else if (islem == KayitIslemi.Guncellendi)
                    gunSonucu.Guncellenen++;
                else
                    gunSonucu.Atlanan++;
            }
            catch (Exception ex)
            {
                gunSonucu.Atlanan++;

                _logger.LogWarning(
                    ex,
                    "SofaScore event kaydı atlandı. Tarih: {Tarih}",
                    tarih);
            }
        }

        return gunSonucu;
    }

    private async Task<KayitIslemi> MacKaydetVeyaGuncelleAsync(
        SofaScoreMac parsed,
        CancellationToken cancellationToken)
    {
        var lig = await LigGetirVeyaOlusturAsync(
            parsed,
            cancellationToken);

        var evSahibi = await TakimGetirVeyaOlusturAsync(
            parsed.HomeTeamId,
            parsed.HomeTeamName,
            lig.Id,
            parsed.Country,
            cancellationToken);

        var deplasman = await TakimGetirVeyaOlusturAsync(
            parsed.AwayTeamId,
            parsed.AwayTeamName,
            lig.Id,
            parsed.Country,
            cancellationToken);

        var hariciId = HariciMacIdOlustur(parsed.EventId);

        var mac = await _dbContext.Maclar
            .FirstOrDefaultAsync(
                x => x.HariciMacId == hariciId,
                cancellationToken);

        var yeniMi = mac is null;

        if (mac is null)
        {
            mac = new Mac
            {
                HariciMacId = hariciId,
                OlusturmaTarihi = DateTime.UtcNow
            };

            _dbContext.Maclar.Add(mac);
        }

        mac.LigId = lig.Id;
        mac.EvSahibiTakimId = evSahibi.Id;
        mac.DeplasmanTakimId = deplasman.Id;
        mac.MacTarihi = parsed.StartTimeUtc;
        mac.Durum = parsed.Status;
        mac.EvSahibiSkor = parsed.HomeScore;
        mac.DeplasmanSkor = parsed.AwayScore;
        mac.IlkYariEvSahibiSkor = parsed.HalfTimeHomeScore;
        mac.IlkYariDeplasmanSkor = parsed.HalfTimeAwayScore;
        mac.Stadyum = parsed.Venue;
        mac.GuncellemeTarihi = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return yeniMi
            ? KayitIslemi.Eklendi
            : KayitIslemi.Guncellendi;
    }

    private async Task<Lig> LigGetirVeyaOlusturAsync(
        SofaScoreMac parsed,
        CancellationToken cancellationToken)
    {
        var hariciLigId =
            HariciLigIdOlustur(parsed.TournamentId);

        var sezon = parsed.SeasonName
            ?? parsed.StartTimeUtc.Year.ToString(
                CultureInfo.InvariantCulture);

        var lig = await _dbContext.Ligler
            .FirstOrDefaultAsync(
                x => x.HariciLigId == hariciLigId &&
                     x.Sezon == sezon,
                cancellationToken);

        if (lig is not null)
            return lig;

        lig = new Lig
        {
            HariciLigId = hariciLigId,
            Ad = parsed.TournamentName,
            Ulke = parsed.Country,
            Sezon = sezon,
            AktifMi = true
        };

        _dbContext.Ligler.Add(lig);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return lig;
    }

    private async Task<Takim> TakimGetirVeyaOlusturAsync(
        int sourceTeamId,
        string name,
        int ligId,
        string? country,
        CancellationToken cancellationToken)
    {
        var hariciTakimId =
            HariciTakimIdOlustur(sourceTeamId);

        var takim = await _dbContext.Takimlar
            .FirstOrDefaultAsync(
                x => x.HariciTakimId == hariciTakimId,
                cancellationToken);

        if (takim is not null)
        {
            takim.Ad = name;
            takim.LigId = ligId;
            takim.Ulke = country;
            return takim;
        }

        takim = new Takim
        {
            HariciTakimId = hariciTakimId,
            LigId = ligId,
            Ad = name,
            Ulke = country,
            AktifMi = true
        };

        _dbContext.Takimlar.Add(takim);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return takim;
    }

    private static SofaScoreMac? ParseEvent(
        JsonElement item)
    {
        if (!TryGetInt(item, "id", out var eventId) ||
            !TryGetLong(item, "startTimestamp", out var startTimestamp))
        {
            return null;
        }

        if (!item.TryGetProperty("homeTeam", out var homeTeam) ||
            !item.TryGetProperty("awayTeam", out var awayTeam) ||
            !item.TryGetProperty(
                "tournament",
                out var tournament))
        {
            return null;
        }

        if (!TryGetInt(homeTeam, "id", out var homeTeamId) ||
            !TryGetInt(awayTeam, "id", out var awayTeamId) ||
            !TryGetInt(tournament, "id", out var tournamentId))
        {
            return null;
        }

        var parsed = new SofaScoreMac
        {
            EventId = eventId,
            StartTimeUtc =
                DateTimeOffset.FromUnixTimeSeconds(
                    startTimestamp).UtcDateTime,
            HomeTeamId = homeTeamId,
            HomeTeamName = GetString(homeTeam, "name") ??
                           "Bilinmeyen Ev Sahibi",
            AwayTeamId = awayTeamId,
            AwayTeamName = GetString(awayTeam, "name") ??
                           "Bilinmeyen Deplasman",
            TournamentId = tournamentId,
            TournamentName =
                GetString(tournament, "name") ??
                "Bilinmeyen Lig",
            Status = StatusOku(item),
            HomeScore = ScoreOku(item, "homeScore", "current"),
            AwayScore = ScoreOku(item, "awayScore", "current"),
            HalfTimeHomeScore =
                ScoreOku(item, "homeScore", "period1"),
            HalfTimeAwayScore =
                ScoreOku(item, "awayScore", "period1")
        };

        if (tournament.TryGetProperty(
                "category",
                out var category))
        {
            parsed.Country =
                GetString(category, "name");
        }

        if (item.TryGetProperty(
                "season",
                out var season))
        {
            parsed.SeasonName =
                GetString(season, "name");
        }

        if (item.TryGetProperty(
                "venue",
                out var venue))
        {
            parsed.Venue =
                GetString(venue, "name");
        }

        return parsed;
    }

    private string TarihEndpointi(DateOnly tarih)
    {
        return
            $"sport/football/scheduled-events/" +
            $"{tarih:yyyy-MM-dd}";
    }

    private static string StatusOku(
        JsonElement item)
    {
        if (item.TryGetProperty(
                "status",
                out var status))
        {
            return GetString(status, "type") ??
                   GetString(status, "description") ??
                   "scheduled";
        }

        return "scheduled";
    }

    private static int? ScoreOku(
        JsonElement item,
        string scoreProperty,
        string valueProperty)
    {
        if (!item.TryGetProperty(
                scoreProperty,
                out var score))
        {
            return null;
        }

        return TryGetInt(
            score,
            valueProperty,
            out var value)
            ? value
            : null;
    }

    private static string? GetString(
        JsonElement element,
        string property)
    {
        return element.TryGetProperty(
                   property,
                   out var value) &&
               value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;
    }

    private static bool TryGetInt(
        JsonElement element,
        string property,
        out int value)
    {
        value = 0;

        return element.TryGetProperty(
                   property,
                   out var result) &&
               result.TryGetInt32(out value);
    }

    private static bool TryGetLong(
        JsonElement element,
        string property,
        out long value)
    {
        value = 0;

        return element.TryGetProperty(
                   property,
                   out var result) &&
               result.TryGetInt64(out value);
    }

    // SofaScore ve API-Football ID alanlarının çakışmaması için
    // ayrı negatif ID alanı kullanılır.
    private static int HariciMacIdOlustur(int sourceId)
    {
        return sourceId > 0
            ? -sourceId
            : sourceId;
    }

    private static int HariciLigIdOlustur(int sourceId)
    {
        return sourceId > 0
            ? -sourceId
            : sourceId;
    }

    private static int HariciTakimIdOlustur(int sourceId)
    {
        return sourceId > 0
            ? -sourceId
            : sourceId;
    }

    private enum KayitIslemi
    {
        Atlandi = 0,
        Eklendi = 1,
        Guncellendi = 2
    }

    private sealed class GunIslemeSonucu
    {
        public int GelenMac { get; set; }
        public int Eklenen { get; set; }
        public int Guncellenen { get; set; }
        public int Atlanan { get; set; }

        public List<string> Uyarilar { get; set; } = new();
    }

    private sealed class SofaScoreMac
    {
        public int EventId { get; set; }
        public DateTime StartTimeUtc { get; set; }

        public int TournamentId { get; set; }
        public string TournamentName { get; set; } = string.Empty;
        public string? Country { get; set; }
        public string? SeasonName { get; set; }

        public int HomeTeamId { get; set; }
        public string HomeTeamName { get; set; } = string.Empty;

        public int AwayTeamId { get; set; }
        public string AwayTeamName { get; set; } = string.Empty;

        public string Status { get; set; } = "scheduled";

        public int? HomeScore { get; set; }
        public int? AwayScore { get; set; }

        public int? HalfTimeHomeScore { get; set; }
        public int? HalfTimeAwayScore { get; set; }

        public string? Venue { get; set; }
    }
}
