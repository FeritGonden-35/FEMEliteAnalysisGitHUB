using System.Globalization;
using System.Text;
using System.Net.Http.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.TheSportsDb;
using FEMEliteAnalysis.Api.Dtos.VeriToplama;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Providers.TheSportsDb;

public class TheSportsDbVeriSaglayici : IVeriSaglayici
{
    private const int KaynakIdCarpani = -10;

    private readonly HttpClient _httpClient;
    private readonly FemDbContext _dbContext;
    private readonly TheSportsDbOptions _options;
    private readonly ILogger<TheSportsDbVeriSaglayici> _logger;
    private readonly TheSportsDbV2Client _v2Client;

    public TheSportsDbVeriSaglayici(
        HttpClient httpClient,
        FemDbContext dbContext,
        IOptions<TheSportsDbOptions> options,
        TheSportsDbV2Client v2Client,
        ILogger<TheSportsDbVeriSaglayici> logger)
    {
        _httpClient = httpClient;
        _dbContext = dbContext;
        _options = options.Value;
        _v2Client = v2Client;
        _logger = logger;
    }

    public VeriSaglayiciTuru Tur => VeriSaglayiciTuru.TheSportsDb;
    public string Ad => "TheSportsDB";
    public bool AktifMi => _options.Aktif;

    public async Task<ServiceResult<bool>> BaglantiTestiAsync(
        CancellationToken cancellationToken)
    {
        if (!AktifMi)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "TheSportsDB sağlayıcısı aktif değil.");
        }

        if (string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "TheSportsDB API anahtarı tanımlanmamış.");
        }

        try
        {
            using var response = await _httpClient.GetAsync(
                "all_sports.php",
                cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                return ServiceResult<bool>.BasarisizSonuc(
                    $"TheSportsDB V1 bağlantısı başarısız: " +
                    $"{(int)response.StatusCode}");
            }

            if (_v2Client.Kullanilabilir)
            {
                var v2Basarili = await _v2Client.BaglantiTestiAsync(
                    cancellationToken);

                return v2Basarili
                    ? ServiceResult<bool>.BasariliSonuc(
                        true,
                        "TheSportsDB V1 + V2 bağlantısı başarılı.")
                    : ServiceResult<bool>.BasarisizSonuc(
                        "TheSportsDB V1 başarılı ancak V2 bağlantısı başarısız.");
            }

            return ServiceResult<bool>.BasariliSonuc(
                true,
                "TheSportsDB V1 bağlantısı başarılı. V2 anahtarı tanımlı değil.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "TheSportsDB bağlantı testi başarısız.");

            return ServiceResult<bool>.BasarisizSonuc(
                "TheSportsDB bağlantı testi sırasında hata oluştu.");
        }
    }

    public async Task<ServiceResult<VeriToplamaSonucDto>> VeriToplaAsync(
        VeriToplamaIstekDto istek,
        CancellationToken cancellationToken)
    {
        if (!AktifMi)
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "TheSportsDB sağlayıcısı aktif değil.");
        }

        var ligIdleri = istek.LigIdleri.Count > 0
            ? istek.LigIdleri.Distinct().ToList()
            : _options.SeciliLigIdleri.Distinct().ToList();

        if (ligIdleri.Count == 0)
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "TheSportsDB için seçili lig ID değeri bulunmuyor.");
        }

        var sonuc = new VeriToplamaSonucDto
        {
            SaglayiciTuru = Tur,
            BaslamaZamani = DateTime.UtcNow
        };

        var takimlar = new HashSet<int>();
        var kaynakTakimIdleri = new HashSet<int>();
        var islenenKaynakMacIdleri = new HashSet<int>();

        try
        {
            foreach (var ligId in ligIdleri)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var ligSonucu = await LigMaclariniGetirAsync(
                    ligId,
                    cancellationToken);

                if (!ligSonucu.Basarili || ligSonucu.Veri is null)
                {
                    sonuc.Uyarilar.Add(
                        $"Lig {ligId}: {ligSonucu.Mesaj}");
                    continue;
                }

                sonuc.GelenLigSayisi++;

                var tumLigMaclari = new Dictionary<string, TheSportsDbEventDto>();
                foreach (var x in ligSonucu.Veri)
                {
                    if (!string.IsNullOrWhiteSpace(x.EventId))
                        tumLigMaclari[x.EventId] = x;
                }

                if (_options.LigSezonGecmisiAktif &&
                    istek.GecmisFormuGetir)
                {
                    foreach (var sezon in _options.Sezonlar
                                 .Where(x => !string.IsNullOrWhiteSpace(x))
                                 .Distinct(StringComparer.OrdinalIgnoreCase))
                    {
                        await EndpointMaclariniEkleAsync(
                            $"eventsseason.php?id={ligId}&s={Uri.EscapeDataString(sezon)}",
                            tumLigMaclari,
                            cancellationToken);
                    }
                }

                // Normal senkronizasyonda endpointlerin döndürdüğü kayıtlar
                // istenen tarih penceresiyle sınırlandırılır. Böylece geçmiş
                // sezonlar ve uzak fikstürler yeniden işlenmez.
                var pencereBaslangic = istek.BaslangicTarihi
                    .ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);
                var pencereBitis = istek.BitisTarihi
                    .AddDays(1)
                    .ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);

                var islenecekMaclar = tumLigMaclari.Values
                    .Where(x =>
                    {
                        var tarih = MacTarihiniOku(x);
                        return tarih.HasValue &&
                               tarih.Value >= pencereBaslangic &&
                               tarih.Value < pencereBitis;
                    })
                    .ToList();

                sonuc.GelenMacSayisi += islenecekMaclar.Count;

                foreach (var eventDto in islenecekMaclar)
                {
                    KaynakTakimIdleriniEkle(
                        eventDto,
                        kaynakTakimIdleri);

                    if (TryParsePositiveInt(
                            eventDto.EventId,
                            out var kaynakMacId))
                    {
                        islenenKaynakMacIdleri.Add(kaynakMacId);
                    }

                    var kayitSonucu = await MacKaydetVeyaGuncelleAsync(
                        eventDto,
                        takimlar,
                        cancellationToken);

                    switch (kayitSonucu)
                    {
                        case KayitSonucu.Eklendi:
                            sonuc.EklenenKayitSayisi++;
                            break;

                        case KayitSonucu.Guncellendi:
                            sonuc.GuncellenenKayitSayisi++;
                            break;

                        default:
                            sonuc.AtlananKayitSayisi++;
                            break;
                    }
                }

                await Task.Delay(
                    Math.Max(200, _options.IsteklerArasiBeklemeMs),
                    cancellationToken);
            }

            if (_options.TakimGecmisiAktif &&
                istek.GecmisFormuGetir &&
                kaynakTakimIdleri.Count > 0)
            {
                var gecmisSonucu = await TakimGecmisleriniGetirAsync(
                    kaynakTakimIdleri,
                    takimlar,
                    islenenKaynakMacIdleri,
                    cancellationToken);

                sonuc.GelenMacSayisi += gecmisSonucu.GelenMac;
                sonuc.EklenenKayitSayisi += gecmisSonucu.Eklenen;
                sonuc.GuncellenenKayitSayisi += gecmisSonucu.Guncellenen;
                sonuc.AtlananKayitSayisi += gecmisSonucu.Atlanan;
                sonuc.Uyarilar.AddRange(gecmisSonucu.Uyarilar);
            }

            sonuc.GelenTakimSayisi = takimlar.Count;
            sonuc.BitisZamani = DateTime.UtcNow;
            sonuc.Basarili = sonuc.GelenLigSayisi > 0;
            sonuc.Mesaj = sonuc.Basarili
                ? $"{sonuc.GelenMacSayisi} TheSportsDB maçı işlendi."
                : "TheSportsDB üzerinden işlenebilir maç alınamadı.";

            return sonuc.Basarili
                ? ServiceResult<VeriToplamaSonucDto>.BasariliSonuc(
                    sonuc,
                    sonuc.Mesaj)
                : ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                    sonuc.Mesaj);
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "TheSportsDB veri toplama işlemi iptal edildi.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "TheSportsDB veri toplama işlemi başarısız.");

            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "TheSportsDB verileri işlenirken hata oluştu.");
        }
    }

    private async Task<ServiceResult<List<TheSportsDbEventDto>>>
        LigMaclariniGetirAsync(
            int ligId,
            CancellationToken cancellationToken)
    {
        var maclar = new Dictionary<string, TheSportsDbEventDto>();

        // Yaklaşan lig maçları.
        await EndpointMaclariniEkleAsync(
            $"eventsnextleague.php?id={ligId}",
            maclar,
            cancellationToken);

        // Son tamamlanan lig maçları.
        await EndpointMaclariniEkleAsync(
            $"eventspastleague.php?id={ligId}",
            maclar,
            cancellationToken);

        return ServiceResult<List<TheSportsDbEventDto>>.BasariliSonuc(
            maclar.Values.ToList(),
            $"{maclar.Count} maç getirildi.");
    }

    private async Task EndpointMaclariniEkleAsync(
        string endpoint,
        Dictionary<string, TheSportsDbEventDto> maclar,
        CancellationToken cancellationToken)
    {
        try
        {
            var response =
                await _httpClient.GetFromJsonAsync<TheSportsDbEventsResponse>(
                    endpoint,
                    cancellationToken);

            var gelenMaclar = response?.Events ?? response?.Results;

            if (gelenMaclar is null)
                return;

            foreach (var eventDto in gelenMaclar)
            {
                if (string.IsNullOrWhiteSpace(eventDto.EventId))
                    continue;

                maclar[eventDto.EventId] = eventDto;
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "TheSportsDB endpoint okunamadı. Endpoint: {Endpoint}",
                endpoint);
        }
    }

    private async Task<GecmisSenkronizasyonSonucu>
        TakimGecmisleriniGetirAsync(
            IReadOnlyCollection<int> kaynakTakimIdleri,
            HashSet<int> takimlar,
            HashSet<int> islenenKaynakMacIdleri,
            CancellationToken cancellationToken)
    {
        var sonuc = new GecmisSenkronizasyonSonucu();

        foreach (var kaynakTakimId in kaynakTakimIdleri)
        {
            cancellationToken.ThrowIfCancellationRequested();

            try
            {
                var response = await _httpClient
                    .GetFromJsonAsync<TheSportsDbEventsResponse>(
                        $"eventslast.php?id={kaynakTakimId}",
                        cancellationToken);

                var maclar = response?.Results ?? response?.Events;

                if (maclar is null || maclar.Count == 0)
                {
                    sonuc.Uyarilar.Add(
                        $"Takım {kaynakTakimId}: geçmiş maç dönmedi.");
                    continue;
                }

                foreach (var eventDto in maclar)
                {
                    if (!TryParsePositiveInt(
                            eventDto.EventId,
                            out var kaynakMacId))
                    {
                        sonuc.Atlanan++;
                        continue;
                    }

                    // Lig akışında aynı maç işlendi ise yeniden saymayalım.
                    if (!islenenKaynakMacIdleri.Add(kaynakMacId))
                        continue;

                    sonuc.GelenMac++;

                    var kayitSonucu = await MacKaydetVeyaGuncelleAsync(
                        eventDto,
                        takimlar,
                        cancellationToken);

                    switch (kayitSonucu)
                    {
                        case KayitSonucu.Eklendi:
                            sonuc.Eklenen++;
                            break;

                        case KayitSonucu.Guncellendi:
                            sonuc.Guncellenen++;
                            break;

                        default:
                            sonuc.Atlanan++;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(
                    ex,
                    "TheSportsDB takım geçmişi alınamadı. Takım ID: {TakimId}",
                    kaynakTakimId);

                sonuc.Uyarilar.Add(
                    $"Takım {kaynakTakimId}: geçmiş maç isteği başarısız.");
            }

            await Task.Delay(
                Math.Max(200, _options.IsteklerArasiBeklemeMs),
                cancellationToken);
        }

        return sonuc;
    }

    private static void KaynakTakimIdleriniEkle(
        TheSportsDbEventDto eventDto,
        HashSet<int> kaynakTakimIdleri)
    {
        if (TryParsePositiveInt(
                eventDto.HomeTeamId,
                out var evTakimId))
        {
            kaynakTakimIdleri.Add(evTakimId);
        }

        if (TryParsePositiveInt(
                eventDto.AwayTeamId,
                out var depTakimId))
        {
            kaynakTakimIdleri.Add(depTakimId);
        }
    }

    private async Task<KayitSonucu> MacKaydetVeyaGuncelleAsync(
        TheSportsDbEventDto eventDto,
        HashSet<int> takimlar,
        CancellationToken cancellationToken)
    {
        if (!TryParsePositiveInt(eventDto.EventId, out var sourceEventId) ||
            !TryParsePositiveInt(eventDto.LeagueId, out var sourceLeagueId) ||
            !TryParsePositiveInt(eventDto.HomeTeamId, out var sourceHomeTeamId) ||
            !TryParsePositiveInt(eventDto.AwayTeamId, out var sourceAwayTeamId))
        {
            return KayitSonucu.Atlandi;
        }

        var macTarihi = MacTarihiniOku(eventDto);

        if (!macTarihi.HasValue)
            return KayitSonucu.Atlandi;

        var lig = await LigGetirVeyaOlusturAsync(
            sourceLeagueId,
            eventDto,
            cancellationToken);

        var evSahibi = await TakimGetirVeyaOlusturAsync(
            sourceHomeTeamId,
            eventDto.HomeTeamName,
            lig.Id,
            eventDto.Country,
            cancellationToken);

        var deplasman = await TakimGetirVeyaOlusturAsync(
            sourceAwayTeamId,
            eventDto.AwayTeamName,
            lig.Id,
            eventDto.Country,
            cancellationToken);

        takimlar.Add(evSahibi.Id);
        takimlar.Add(deplasman.Id);

        var hariciMacId = KaynakIdOlustur(sourceEventId);

        var mac = await _dbContext.Maclar
            .FirstOrDefaultAsync(
                x => x.HariciMacId == hariciMacId,
                cancellationToken);

        var yeniMi = mac is null;

        if (mac is null)
        {
            mac = new Mac
            {
                HariciMacId = hariciMacId,
                OlusturmaTarihi = DateTime.UtcNow
            };

            _dbContext.Maclar.Add(mac);
        }

        mac.LigId = lig.Id;
        mac.EvSahibiTakimId = evSahibi.Id;
        mac.DeplasmanTakimId = deplasman.Id;
        mac.MacTarihi = macTarihi.Value;
        mac.Durum = DurumOku(eventDto);
        mac.EvSahibiSkor = ParseNullableInt(eventDto.HomeScore);
        mac.DeplasmanSkor = ParseNullableInt(eventDto.AwayScore);
        mac.IlkYariEvSahibiSkor =
            ParseNullableInt(eventDto.HomeHalfTimeScore);
        mac.IlkYariDeplasmanSkor =
            ParseNullableInt(eventDto.AwayHalfTimeScore);
        mac.Stadyum = eventDto.Venue;
        mac.GuncellemeTarihi = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return yeniMi
            ? KayitSonucu.Eklendi
            : KayitSonucu.Guncellendi;
    }

    private async Task<Lig> LigGetirVeyaOlusturAsync(
        int sourceLeagueId,
        TheSportsDbEventDto eventDto,
        CancellationToken cancellationToken)
    {
        var hariciLigId = KaynakIdOlustur(sourceLeagueId);
        var sezon = string.IsNullOrWhiteSpace(eventDto.Season)
            ? _options.VarsayilanSezon
            : eventDto.Season.Trim();

        var lig = await _dbContext.Ligler
            .FirstOrDefaultAsync(
                x => x.HariciLigId == hariciLigId &&
                     x.Sezon == sezon,
                cancellationToken);

        if (lig is not null)
            return lig;

        lig = new Lig
        {
            HariciLigId = hariciLigId,
            Ad = string.IsNullOrWhiteSpace(eventDto.LeagueName)
                ? $"TheSportsDB Lig {sourceLeagueId}"
                : eventDto.LeagueName.Trim(),
            Ulke = eventDto.Country,
            Sezon = sezon,
            AktifMi = true
        };

        _dbContext.Ligler.Add(lig);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return lig;
    }

    private async Task<Takim> TakimGetirVeyaOlusturAsync(
        int sourceTeamId,
        string? teamName,
        int ligId,
        string? country,
        CancellationToken cancellationToken)
    {
        var hariciTakimId = KaynakIdOlustur(sourceTeamId);

        var takim = await _dbContext.Takimlar
            .FirstOrDefaultAsync(
                x => x.TheSportsDbTakimId == sourceTeamId || x.HariciTakimId == hariciTakimId,
                cancellationToken);

        var v2Bilgi = await _v2Client.TakimAraAsync(
    teamName ?? string.Empty,
    0,
    cancellationToken);

        var dogrulanmisAd = !string.IsNullOrWhiteSpace(v2Bilgi?.Ad)
            ? v2Bilgi.Ad.Trim()
            : !string.IsNullOrWhiteSpace(teamName)
                ? teamName.Trim()
                : $"TheSportsDB Takım {sourceTeamId}";

        var dogrulanmisUlke = !string.IsNullOrWhiteSpace(v2Bilgi?.Ulke)
            ? v2Bilgi.Ulke
            : country;

        if (takim is null && _options.OtomatikTakimBirlestirmeAktif)
        {
            takim = await CanonicalTakimBulAsync(
                dogrulanmisAd,
                dogrulanmisUlke,
                cancellationToken);

            if (takim is not null)
            {
                takim.HariciTakimId = hariciTakimId;
                takim.TheSportsDbTakimId = sourceTeamId;
                takim.AktifMi = true;
            }
        }

        if (takim is null)
        {
            takim = new Takim
            {
                HariciTakimId = hariciTakimId,
                TheSportsDbTakimId = sourceTeamId,
                LigId = ligId,
                Ad = dogrulanmisAd,
                Ulke = dogrulanmisUlke,
                LogoUrl = v2Bilgi?.LogoUrl,
                AktifMi = true
            };

            _dbContext.Takimlar.Add(takim);
            await _dbContext.SaveChangesAsync(cancellationToken);
        }
        else
        {
            takim.HariciTakimId = hariciTakimId;
            takim.TheSportsDbTakimId = sourceTeamId;
            takim.LigId = ligId;
            takim.Ad = dogrulanmisAd;
            takim.Ulke = dogrulanmisUlke;
            takim.AktifMi = true;

            if (!string.IsNullOrWhiteSpace(v2Bilgi?.LogoUrl))
                takim.LogoUrl = v2Bilgi.LogoUrl;

            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        if (_options.OtomatikTakimBirlestirmeAktif)
        {
            await AyniCanonicalTakimlariBirlestirAsync(
                takim,
                cancellationToken);
        }

        return takim;
    }

    private async Task<Takim?> CanonicalTakimBulAsync(
        string takimAdi,
        string? ulke,
        CancellationToken ct)
    {
        var anahtar = TakimAnahtariOlustur(takimAdi);
        if (string.IsNullOrWhiteSpace(anahtar))
            return null;

        var adaylar = await _dbContext.Takimlar
            .Where(x => x.AktifMi)
            .Where(x => ulke == null || x.Ulke == null || x.Ulke == ulke)
            .ToListAsync(ct);

        var eslesenler = adaylar
            .Where(x => TakimAnahtariOlustur(x.Ad) == anahtar)
            .ToList();

        if (eslesenler.Count == 0)
            return null;

        var ids = eslesenler.Select(x => x.Id).ToList();
        var evSayilari = await _dbContext.Maclar
            .Where(x => ids.Contains(x.EvSahibiTakimId))
            .GroupBy(x => x.EvSahibiTakimId)
            .Select(g => new { Id = g.Key, Sayi = g.Count() })
            .ToListAsync(ct);
        var depSayilari = await _dbContext.Maclar
            .Where(x => ids.Contains(x.DeplasmanTakimId))
            .GroupBy(x => x.DeplasmanTakimId)
            .Select(g => new { Id = g.Key, Sayi = g.Count() })
            .ToListAsync(ct);
        var sayilar = evSayilari.Concat(depSayilari)
            .GroupBy(x => x.Id)
            .ToDictionary(g => g.Key, g => g.Sum(x => x.Sayi));

        return eslesenler
            .OrderByDescending(x => x.HariciTakimId.HasValue)
            .ThenByDescending(x => sayilar.GetValueOrDefault(x.Id))
            .ThenBy(x => x.Id)
            .First();
    }

    private async Task AyniCanonicalTakimlariBirlestirAsync(
        Takim anaTakim,
        CancellationToken ct)
    {
        var anahtar = TakimAnahtariOlustur(anaTakim.Ad);
        if (string.IsNullOrWhiteSpace(anahtar))
            return;

        var adaylar = await _dbContext.Takimlar
            .Where(x => x.Id != anaTakim.Id && x.AktifMi)
            .Where(x => anaTakim.Ulke == null || x.Ulke == null || x.Ulke == anaTakim.Ulke)
            .ToListAsync(ct);

        var birlesecekler = adaylar
            .Where(x => TakimAnahtariOlustur(x.Ad) == anahtar)
            .ToList();

        foreach (var kaynak in birlesecekler)
        {
            await _dbContext.MacIstatistikleri
                .Where(x => x.TakimId == kaynak.Id &&
                            _dbContext.MacIstatistikleri.Any(y =>
                                y.MacId == x.MacId &&
                                y.TakimId == anaTakim.Id))
                .ExecuteDeleteAsync(ct);

            await _dbContext.MacIstatistikleri
                .Where(x => x.TakimId == kaynak.Id)
                .ExecuteUpdateAsync(
                    setters => setters.SetProperty(
                        x => x.TakimId,
                        anaTakim.Id),
                    ct);

            await _dbContext.TakimFormlari
                .Where(x => x.TakimId == kaynak.Id)
                .ExecuteUpdateAsync(
                    setters => setters.SetProperty(
                        x => x.TakimId,
                        anaTakim.Id),
                    ct);

            await _dbContext.Maclar
                .Where(x => x.EvSahibiTakimId == kaynak.Id)
                .ExecuteUpdateAsync(
                    setters => setters.SetProperty(
                        x => x.EvSahibiTakimId,
                        anaTakim.Id),
                    ct);

            await _dbContext.Maclar
                .Where(x => x.DeplasmanTakimId == kaynak.Id)
                .ExecuteUpdateAsync(
                    setters => setters.SetProperty(
                        x => x.DeplasmanTakimId,
                        anaTakim.Id),
                    ct);

            kaynak.AktifMi = false;
        }

        if (birlesecekler.Count > 0)
            await _dbContext.SaveChangesAsync(ct);
    }

    private static string TakimAnahtariOlustur(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var normalized = value.Trim().ToLowerInvariant()
            .Normalize(NormalizationForm.FormD);
        var builder = new StringBuilder(normalized.Length);

        foreach (var ch in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(ch) ==
                UnicodeCategory.NonSpacingMark)
                continue;
            if (char.IsLetterOrDigit(ch) || char.IsWhiteSpace(ch))
                builder.Append(ch);
        }

        var words = builder.ToString()
            .Normalize(NormalizationForm.FormC)
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Where(x => !TakimEkleri.Contains(x))
            .ToList();

        return string.Concat(words);
    }

    private static readonly HashSet<string> TakimEkleri = new(
        StringComparer.OrdinalIgnoreCase)
    {
        "fc", "cf", "sc", "sk", "as", "aş", "fk", "club",
        "football", "futbol", "spor", "kulubu", "kulübü",
        "istanbul", "belediye", "belediyesi"
    };

    private static DateTime? MacTarihiniOku(
        TheSportsDbEventDto eventDto)
    {
        if (!string.IsNullOrWhiteSpace(eventDto.Timestamp) &&
            DateTimeOffset.TryParse(
                eventDto.Timestamp,
                CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeUniversal |
                DateTimeStyles.AdjustToUniversal,
                out var timestamp))
        {
            return timestamp.UtcDateTime;
        }

        var dateText = eventDto.DateEvent?.Trim();
        var timeText = eventDto.Time?.Trim();

        if (string.IsNullOrWhiteSpace(dateText))
            return null;

        var combined = string.IsNullOrWhiteSpace(timeText)
            ? $"{dateText} 00:00:00"
            : $"{dateText} {timeText}";

        return DateTime.TryParse(
            combined,
            CultureInfo.InvariantCulture,
            DateTimeStyles.AssumeUniversal |
            DateTimeStyles.AdjustToUniversal,
            out var parsed)
            ? parsed
            : null;
    }

    private static string DurumOku(
        TheSportsDbEventDto eventDto)
    {
        if (eventDto.Postponed == "yes")
            return "postponed";

        if (!string.IsNullOrWhiteSpace(eventDto.Status))
            return eventDto.Status.Trim();

        var home = ParseNullableInt(eventDto.HomeScore);
        var away = ParseNullableInt(eventDto.AwayScore);

        return home.HasValue && away.HasValue
            ? "finished"
            : "scheduled";
    }

    private static int KaynakIdOlustur(int sourceId)
    {
        checked
        {
            return sourceId * KaynakIdCarpani;
        }
    }

    private static bool TryParsePositiveInt(
        string? value,
        out int parsed)
    {
        return int.TryParse(
                   value,
                   NumberStyles.Integer,
                   CultureInfo.InvariantCulture,
                   out parsed) &&
               parsed > 0;
    }

    private static int? ParseNullableInt(string? value)
    {
        return int.TryParse(
            value,
            NumberStyles.Integer,
            CultureInfo.InvariantCulture,
            out var parsed)
            ? parsed
            : null;
    }

    private sealed class GecmisSenkronizasyonSonucu
    {
        public int GelenMac { get; set; }
        public int Eklenen { get; set; }
        public int Guncellenen { get; set; }
        public int Atlanan { get; set; }
        public List<string> Uyarilar { get; set; } = new();
    }

    private enum KayitSonucu
    {
        Atlandi = 0,
        Eklendi = 1,
        Guncellendi = 2
    }
}
