using System.Text.Json;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Providers.TheSportsDb;

public sealed class TheSportsDbV2Client
{
    private readonly HttpClient _httpClient;
    private readonly TheSportsDbOptions _options;
    private readonly ILogger<TheSportsDbV2Client> _logger;

    public TheSportsDbV2Client(
        HttpClient httpClient,
        IOptions<TheSportsDbOptions> options,
        ILogger<TheSportsDbV2Client> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
    }

    public bool Kullanilabilir =>
        _options.V2TakimDogrulamaAktif &&
        !string.IsNullOrWhiteSpace(_options.V2ApiKey);

    public async Task<bool> BaglantiTestiAsync(CancellationToken ct)
    {
        if (!Kullanilabilir)
            return false;

        using var response = await _httpClient.GetAsync(
            "search/team/manchester_united",
            ct);

        return response.IsSuccessStatusCode;
    }

    public async Task<V2TakimBilgisi?> TakimAraAsync(
        string takimAdi,
        int beklenenTheSportsDbTakimId,
        CancellationToken ct)
    {
        if (!Kullanilabilir || string.IsNullOrWhiteSpace(takimAdi))
            return null;

        var slug = Uri.EscapeDataString(
            takimAdi.Trim().Replace(' ', '_'));

        try
        {
            using var response = await _httpClient.GetAsync(
                $"search/team/{slug}",
                ct);

            if (!response.IsSuccessStatusCode)
                return null;

            await using var stream = await response.Content
                .ReadAsStreamAsync(ct);
            using var document = await JsonDocument.ParseAsync(
                stream,
                cancellationToken: ct);

            foreach (var item in EnumerateTeamObjects(document.RootElement))
            {
                var sport = GetString(item, "strSport", "sport");
                if (!string.IsNullOrWhiteSpace(sport) &&
                    !sport.Equals("Soccer", StringComparison.OrdinalIgnoreCase) &&
                    !sport.Equals("Football", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                var idText = GetString(item, "idTeam", "id");
                if (!int.TryParse(idText, out var id))
                    continue;

                if (beklenenTheSportsDbTakimId > 0 &&
    id != beklenenTheSportsDbTakimId)
{
    continue;
}
                int? apiFootballId = null;
                var apiFootballText = GetString(item, "idAPIfootball");
                if (int.TryParse(apiFootballText, out var parsedApiFootballId) &&
                    parsedApiFootballId > 0)
                {
                    apiFootballId = parsedApiFootballId;
                }

                return new V2TakimBilgisi
                {
                    Id = id,
                    ApiFootballId = apiFootballId,
                    Ad = GetString(item, "strTeam", "name") ?? takimAdi,
                    Ulke = GetString(item, "strCountry", "country"),
                    LogoUrl = GetString(
                        item,
                        "strBadge",
                        "strTeamBadge",
                        "badge")
                };
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "TheSportsDB V2 takım araması başarısız. Takım: {Takim}",
                takimAdi);
        }

        return null;
    }

    private static IEnumerable<JsonElement> EnumerateTeamObjects(
    JsonElement root)
{
    if (root.ValueKind == JsonValueKind.Array)
    {
        foreach (var item in root.EnumerateArray())
        {
            if (item.ValueKind == JsonValueKind.Object)
                yield return item;
        }

        yield break;
    }

    if (root.ValueKind != JsonValueKind.Object)
        yield break;

    foreach (var propertyName in new[]
    {
        "search",
        "teams",
        "team",
        "data",
        "results"
    })
    {
        if (!root.TryGetProperty(propertyName, out var value))
            continue;

        if (value.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in value.EnumerateArray())
            {
                if (item.ValueKind == JsonValueKind.Object)
                    yield return item;
            }
        }
        else if (value.ValueKind == JsonValueKind.Object)
        {
            yield return value;
        }
    }
}

    private static string? GetString(
        JsonElement element,
        params string[] names)
    {
        foreach (var name in names)
        {
            if (!element.TryGetProperty(name, out var value))
                continue;

            if (value.ValueKind == JsonValueKind.String)
                return value.GetString();

            if (value.ValueKind == JsonValueKind.Number)
                return value.GetRawText();
        }

        return null;
    }
}

public sealed class V2TakimBilgisi
{
    public int Id { get; init; }
    public int? ApiFootballId { get; init; }
    public string Ad { get; init; } = string.Empty;
    public string? Ulke { get; init; }
    public string? LogoUrl { get; init; }
}
