namespace FEMEliteAnalysis.Api.Bot.Moderation;

public class ModerasyonKarari
{
    public bool IhlalVarMi { get; set; }
    public ModerasyonIhlalTuru Tur { get; set; }
    public string Sebep { get; set; } = string.Empty;
}
