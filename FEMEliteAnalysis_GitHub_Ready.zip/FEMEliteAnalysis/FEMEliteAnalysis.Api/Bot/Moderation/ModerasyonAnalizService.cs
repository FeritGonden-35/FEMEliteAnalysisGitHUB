using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Bot.Moderation;

public class ModerasyonAnalizService
{
    private static readonly Regex LinkRegex = new(
        @"(?i)(https?://|www\.|t\.me/|telegram\.me/|discord\.gg/|wa\.me/)",
        RegexOptions.Compiled);

    private static readonly Regex TekrarKarakterRegex = new(
        @"(.)\1{7,}",
        RegexOptions.Compiled | RegexOptions.Singleline);

    private readonly ModerasyonOptions _options;

    public ModerasyonAnalizService(IOptions<ModerasyonOptions> options)
    {
        _options = options.Value;
    }

    public ModerasyonKarari AnalizEt(string metin)
    {
        if (string.IsNullOrWhiteSpace(metin))
            return Temiz();

        var normalize = NormalizeEt(metin);

        foreach (var kelime in _options.YasakliKelimeler)
        {
            var hedef = NormalizeEt(kelime);
            if (hedef.Length >= 2 && normalize.Contains(hedef, StringComparison.Ordinal))
            {
                return Ihlal(ModerasyonIhlalTuru.Kufur, "Küfür veya hakaret");
            }
        }

        var linkSayisi = LinkRegex.Matches(metin).Count;
        if (linkSayisi > 0)
        {
            var izinli = _options.IzinliAlanAdlari.Any(x =>
                metin.Contains(x, StringComparison.OrdinalIgnoreCase));

            if (!izinli || linkSayisi > _options.TekMesajLinkLimiti)
                return Ihlal(ModerasyonIhlalTuru.ReklamLinki, "İzinsiz reklam veya bağlantı");
        }

        if (TekrarKarakterRegex.IsMatch(metin) ||
            UnlemSoruSpami(metin) >= _options.TekrarKarakterLimiti)
        {
            return Ihlal(ModerasyonIhlalTuru.KarakterSpami, "Tekrarlanan karakter spamı");
        }

        var harfler = metin.Where(char.IsLetter).ToArray();
        if (harfler.Length >= _options.BuyukHarfMinimumHarf)
        {
            var buyuk = harfler.Count(char.IsUpper);
            var oran = buyuk * 100 / harfler.Length;
            if (oran >= _options.BuyukHarfYuzdesi)
                return Ihlal(ModerasyonIhlalTuru.BuyukHarf, "Aşırı büyük harf kullanımı");
        }

        return Temiz();
    }

    public string TekrarKontrolMetni(string metin)
        => NormalizeEt(metin);

    private static int UnlemSoruSpami(string metin)
        => metin.Count(x => x is '!' or '?');

    private static string NormalizeEt(string metin)
    {
        var lower = metin.ToLowerInvariant()
            .Replace('0', 'o')
            .Replace('1', 'i')
            .Replace('3', 'e')
            .Replace('4', 'a')
            .Replace('5', 's')
            .Replace('7', 't')
            .Replace('@', 'a')
            .Replace('$', 's');

        var normalized = lower.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();

        foreach (var c in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark)
                continue;

            if (char.IsLetterOrDigit(c))
                sb.Append(c);
        }

        return sb.ToString();
    }

    private static ModerasyonKarari Temiz()
        => new() { IhlalVarMi = false, Tur = ModerasyonIhlalTuru.Yok };

    private static ModerasyonKarari Ihlal(ModerasyonIhlalTuru tur, string sebep)
        => new() { IhlalVarMi = true, Tur = tur, Sebep = sebep };
}
