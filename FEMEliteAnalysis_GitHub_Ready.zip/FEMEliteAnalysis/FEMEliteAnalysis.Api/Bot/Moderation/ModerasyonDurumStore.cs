using System.Collections.Concurrent;

namespace FEMEliteAnalysis.Api.Bot.Moderation;

public class ModerasyonDurumStore
{
    private readonly ConcurrentDictionary<long, bool> _grupDurumlari = new();
    private readonly ConcurrentDictionary<string, KullaniciModerasyonDurumu> _kullanicilar = new();

    public bool GrupAktifMi(long chatId, bool varsayilan)
        => _grupDurumlari.TryGetValue(chatId, out var aktif) ? aktif : varsayilan;

    public void GrupDurumunuAyarla(long chatId, bool aktif)
        => _grupDurumlari[chatId] = aktif;

    public KullaniciModerasyonDurumu KullaniciGetir(long chatId, long userId)
        => _kullanicilar.GetOrAdd($"{chatId}:{userId}", _ => new KullaniciModerasyonDurumu());
}

public class KullaniciModerasyonDurumu
{
    public object Kilit { get; } = new();
    public int ToplamIhlal { get; set; }
    public List<DateTime> MesajZamanlari { get; } = new();
    public List<(DateTime Zaman, string Metin)> SonMesajlar { get; } = new();
}
