namespace FEMEliteAnalysis.Api.Bot.Moderation;

public enum ModerasyonIhlalTuru
{
    Yok = 0,
    Kufur = 1,
    Spam = 2,
    TekrarMesaj = 3,
    ReklamLinki = 4,
    BuyukHarf = 5,
    KarakterSpami = 6
}
