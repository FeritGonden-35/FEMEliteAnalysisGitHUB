using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Commands;

public sealed class CommandContext
{
    public IServiceProvider Services { get; }
    public ITelegramBotClient BotClient { get; }

    public CommandContext(
        IServiceProvider services,
        ITelegramBotClient botClient)
    {
        Services = services;
        BotClient = botClient;
    }

    public T GetService<T>() where T : notnull
    {
        return Services.GetRequiredService<T>();
    }
}