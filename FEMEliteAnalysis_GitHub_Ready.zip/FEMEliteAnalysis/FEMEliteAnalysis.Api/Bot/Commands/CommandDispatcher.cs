using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Commands;

public sealed class CommandDispatcher
{
    private readonly Dictionary<string, ICommand> _commands;

    public CommandDispatcher(IEnumerable<ICommand> commands)
    {
        _commands = commands.ToDictionary(
            x => x.Name.ToLowerInvariant(),
            x => x);
    }

    public async Task DispatchAsync(
        string command,
        CommandContext context,
        Update update)
    {
        command = command.ToLowerInvariant();

        if (_commands.TryGetValue(command, out var selectedCommand))
        {
            await selectedCommand.ExecuteAsync(context, update);
            return;
        }

        if (_commands.TryGetValue("unknown", out var unknownCommand))
        {
            await unknownCommand.ExecuteAsync(context, update);
        }
    }
}