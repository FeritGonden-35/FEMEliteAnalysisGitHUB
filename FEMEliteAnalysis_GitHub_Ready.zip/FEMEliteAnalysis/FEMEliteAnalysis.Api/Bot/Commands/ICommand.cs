using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Commands;

public interface ICommand
{
    string Name { get; }

    Task ExecuteAsync(
        CommandContext context,
        Update update);
}