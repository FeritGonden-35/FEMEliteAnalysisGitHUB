using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AdminStatsKeyboard
{
    public static InlineKeyboardMarkup Menu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("👥 Kullanıcı", "stats_users"),
                InlineKeyboardButton.WithCallbackData("💎 VIP", "stats_vip")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🎯 Analiz & Kupon", "stats_analysis"),
                InlineKeyboardButton.WithCallbackData("🗄 Veri", "stats_data")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🔄 Yenile", "admin_stats")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⬅️ Admin Menüsüne Dön", "admin_main")
            }
        });
    }

    public static InlineKeyboardMarkup GeriDon()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⬅️ İstatistiklere Dön", "admin_stats")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🏠 Admin Menüsü", "admin_main")
            }
        });
    }
}
