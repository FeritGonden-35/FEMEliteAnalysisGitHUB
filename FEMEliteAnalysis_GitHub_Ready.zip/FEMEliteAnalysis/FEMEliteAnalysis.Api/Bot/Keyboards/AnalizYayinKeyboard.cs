using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AnalizYayinKeyboard
{
    public static InlineKeyboardMarkup OnayMenu(int analizId)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "👁 Ön İzleme",
                    $"analysis_preview:{analizId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📢 VIP Kanalına Yayınla",
                    $"analysis_publish:{analizId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "❌ Vazgeç",
                    "match_date_menu")
            }
        });
    }

    public static InlineKeyboardMarkup Yayinlandi()
    {
        return new InlineKeyboardMarkup(
            InlineKeyboardButton.WithCallbackData(
                "⬅️ Match Center",
                "match_date_menu"));
    }
}
