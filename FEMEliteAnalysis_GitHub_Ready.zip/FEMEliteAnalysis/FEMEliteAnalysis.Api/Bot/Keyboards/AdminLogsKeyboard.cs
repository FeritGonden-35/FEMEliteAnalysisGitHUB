using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AdminLogsKeyboard
{
    public static InlineKeyboardMarkup Menu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("📋 Son Kayıtlar", "logs_recent:0"),
                InlineKeyboardButton.WithCallbackData("❌ Hatalar", "logs_errors:0")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🔄 Yenile", "admin_logs")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⬅️ Admin Menüsüne Dön", "admin_main")
            }
        });
    }

    public static InlineKeyboardMarkup Liste(int sayfa, bool oncekiVar, bool sonrakiVar, bool hatalar)
    {
        var satirlar = new List<InlineKeyboardButton[]>();
        var sayfalama = new List<InlineKeyboardButton>();
        var prefix = hatalar ? "logs_errors:" : "logs_recent:";

        if (oncekiVar)
            sayfalama.Add(InlineKeyboardButton.WithCallbackData("⬅️ Önceki", $"{prefix}{sayfa - 1}"));

        if (sonrakiVar)
            sayfalama.Add(InlineKeyboardButton.WithCallbackData("Sonraki ➡️", $"{prefix}{sayfa + 1}"));

        if (sayfalama.Count > 0)
            satirlar.Add(sayfalama.ToArray());

        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("⬅️ Log Menüsü", "admin_logs")
        });

        return new InlineKeyboardMarkup(satirlar);
    }
}
