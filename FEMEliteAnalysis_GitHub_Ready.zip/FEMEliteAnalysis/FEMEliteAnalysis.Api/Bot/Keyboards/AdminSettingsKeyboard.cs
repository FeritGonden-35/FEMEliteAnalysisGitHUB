using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AdminSettingsKeyboard
{
    public static InlineKeyboardMarkup Menu(IReadOnlyList<(int Id, string Etiket)> ayarlar)
    {
        var satirlar = ayarlar
            .Select(x => new[]
            {
                InlineKeyboardButton.WithCallbackData(x.Etiket, $"setting_detail:{x.Id}")
            })
            .ToList();

        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("🔄 Yenile", "admin_settings")
        });
        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("⬅️ Admin Menüsüne Dön", "admin_main")
        });

        return new InlineKeyboardMarkup(satirlar);
    }

    public static InlineKeyboardMarkup Detay()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⬅️ Ayarlara Dön", "admin_settings")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🏠 Admin Menüsü", "admin_main")
            }
        });
    }
}
