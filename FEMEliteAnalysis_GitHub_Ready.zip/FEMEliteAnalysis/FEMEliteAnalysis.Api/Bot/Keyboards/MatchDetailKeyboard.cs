using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class MatchDetailKeyboard
{
    public static InlineKeyboardMarkup Menu(int macId, DateOnly tarih)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📊 Analiz Oluştur", $"analysis_generate:{macId}"),
                InlineKeyboardButton.WithCallbackData(
                    "📋 Kayıtlı Analiz", $"analysis_show:{macId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "🔄 Bu Maçı Güncelle", $"match_refresh:{macId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Maç Listesi", $"match_page:{tarih:yyyyMMdd}:0"),
                InlineKeyboardButton.WithCallbackData(
                    "📅 Tarih Menüsü", "match_date_menu")
            }
        });
    }
}
