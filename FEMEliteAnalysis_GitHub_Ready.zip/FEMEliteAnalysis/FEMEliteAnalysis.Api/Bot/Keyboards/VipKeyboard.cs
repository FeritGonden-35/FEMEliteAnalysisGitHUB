using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class VipKeyboard
{
    public static InlineKeyboardMarkup Menu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📋 Aktif VIP Üyeler",
                    "vip_active_members")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "🔎 Üye Bilgisi",
                    "vip_member_info"),
                InlineKeyboardButton.WithCallbackData(
                    "➕ Üye Ekle / Uzat",
                    "vip_add_extend")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "❌ Üyelik İptal",
                    "vip_cancel")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Admin Menüsüne Dön",
                    "admin_main")
            }
        });
    }
}
