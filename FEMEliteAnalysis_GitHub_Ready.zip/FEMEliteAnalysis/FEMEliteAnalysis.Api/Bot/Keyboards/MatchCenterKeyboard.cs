using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class MatchCenterKeyboard
{
    public static InlineKeyboardMarkup Liste(
        DateOnly tarih,
        int sayfa,
        int toplamSayfa,
        IReadOnlyCollection<(int Id, string Baslik)> maclar)
    {
        var satirlar = new List<InlineKeyboardButton[]>();

        foreach (var mac in maclar)
        {
            satirlar.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    mac.Baslik.Length > 55 ? mac.Baslik[..55] : mac.Baslik,
                    $"match_detail:{mac.Id}")
            });
        }

        var gezinti = new List<InlineKeyboardButton>();
        if (sayfa > 0)
        {
            gezinti.Add(InlineKeyboardButton.WithCallbackData(
                "⬅️ Önceki", $"match_page:{tarih:yyyyMMdd}:{sayfa - 1}"));
        }

        gezinti.Add(InlineKeyboardButton.WithCallbackData(
            $"📄 {sayfa + 1}/{Math.Max(1, toplamSayfa)}", "match_noop"));

        if (sayfa + 1 < toplamSayfa)
        {
            gezinti.Add(InlineKeyboardButton.WithCallbackData(
                "Sonraki ➡️", $"match_page:{tarih:yyyyMMdd}:{sayfa + 1}"));
        }

        satirlar.Add(gezinti.ToArray());
        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("📅 Tarih Menüsü", "match_date_menu"),
            InlineKeyboardButton.WithCallbackData("👑 Admin", "admin_main")
        });

        return new InlineKeyboardMarkup(satirlar);
    }

    public static InlineKeyboardMarkup YediGun(DateOnly baslangic)
    {
        var satirlar = Enumerable.Range(0, 7)
            .Select(i =>
            {
                var tarih = baslangic.AddDays(i);
                return new[]
                {
                    InlineKeyboardButton.WithCallbackData(
                        $"📅 {tarih:dd.MM ddd}",
                        $"match_leagues:{tarih:yyyyMMdd}")
                };
            })
            .ToList();

        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("⬅️ Tarih Menüsü", "match_date_menu")
        });

        return new InlineKeyboardMarkup(satirlar);
    }

    public static InlineKeyboardMarkup LigSecimi(
        DateOnly tarih,
        IReadOnlyCollection<(int Id, string Ad, int Sayi)> onemliLigler,
        IReadOnlyCollection<(int Id, string Ad, int Sayi)> digerLigler)
    {
        var satirlar = new List<InlineKeyboardButton[]>();

        if (onemliLigler.Count > 0)
        {
            satirlar.Add(new[] { InlineKeyboardButton.WithCallbackData("🔥 ÖNEMLİ LİGLER", "match_noop") });
            foreach (var lig in onemliLigler)
                satirlar.Add(new[] { InlineKeyboardButton.WithCallbackData(
                    $"⭐ {Kisalt(lig.Ad, 42)} ({lig.Sayi})",
                    $"match_league:{tarih:yyyyMMdd}:{lig.Id}:0") });
        }

        if (digerLigler.Count > 0)
        {
            satirlar.Add(new[] { InlineKeyboardButton.WithCallbackData("🌍 DİĞER LİGLER", "match_noop") });
            foreach (var lig in digerLigler)
                satirlar.Add(new[] { InlineKeyboardButton.WithCallbackData(
                    $"{Kisalt(lig.Ad, 44)} ({lig.Sayi})",
                    $"match_league:{tarih:yyyyMMdd}:{lig.Id}:0") });
        }

        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("📅 Tarih Menüsü", "match_date_menu"),
            InlineKeyboardButton.WithCallbackData("👑 Admin", "admin_main")
        });
        return new InlineKeyboardMarkup(satirlar);
    }

    public static InlineKeyboardMarkup LigMaclari(
        DateOnly tarih, int ligId, int sayfa, int toplamSayfa,
        IReadOnlyCollection<(int Id, string Baslik)> maclar)
    {
        var satirlar = maclar.Select(mac => new[]
        {
            InlineKeyboardButton.WithCallbackData(
                Kisalt(mac.Baslik, 55), $"match_detail:{mac.Id}")
        }).ToList();

        var nav = new List<InlineKeyboardButton>();
        if (sayfa > 0) nav.Add(InlineKeyboardButton.WithCallbackData(
            "⬅️", $"match_league:{tarih:yyyyMMdd}:{ligId}:{sayfa - 1}"));
        nav.Add(InlineKeyboardButton.WithCallbackData(
            $"{sayfa + 1}/{Math.Max(1, toplamSayfa)}", "match_noop"));
        if (sayfa + 1 < toplamSayfa) nav.Add(InlineKeyboardButton.WithCallbackData(
            "➡️", $"match_league:{tarih:yyyyMMdd}:{ligId}:{sayfa + 1}"));
        satirlar.Add(nav.ToArray());
        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("⬅️ Ligler", $"match_leagues:{tarih:yyyyMMdd}"),
            InlineKeyboardButton.WithCallbackData("📅 Tarihler", "match_date_menu")
        });
        return new InlineKeyboardMarkup(satirlar);
    }

    private static string Kisalt(string text, int max) =>
        text.Length <= max ? text : text[..(max - 1)] + "…";
}
