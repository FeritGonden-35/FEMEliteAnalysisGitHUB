using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AnalizDuzenlemeKeyboard
{
    public static InlineKeyboardMarkup TaslakMenu(int analizId)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "✍️ Tahmin Ekleme Komutu",
                    $"analysis_prediction_help:{analizId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "👁 Yayın Ön İzlemesi",
                    $"analysis_preview:{analizId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📢 VIP Kanalına Yayınla",
                    $"analysis_publish:{analizId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Match Center",
                    "match_date_menu")
            }
        });
    }
}
