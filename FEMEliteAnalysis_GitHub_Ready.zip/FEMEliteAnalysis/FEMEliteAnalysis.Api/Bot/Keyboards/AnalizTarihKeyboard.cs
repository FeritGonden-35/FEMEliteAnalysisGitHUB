using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AnalizTarihKeyboard
{
    public static InlineKeyboardMarkup Menu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📅 Bugün",
                    "match_today"),
                InlineKeyboardButton.WithCallbackData(
                    "⏭️ Yarın",
                    "match_tomorrow")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📆 Bugün + Yarın",
                    "match_today_tomorrow"),
                InlineKeyboardButton.WithCallbackData(
                    "🗓 7 Gün",
                    "match_7days")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🔎 Maç Ara", "match_search_help"),
                InlineKeyboardButton.WithCallbackData("👤 Takım Ara", "team_search_help")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🏆 Lig Ara", "league_search_help")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Admin Menüsüne Dön",
                    "admin_main")
            }
        });
    }
}
