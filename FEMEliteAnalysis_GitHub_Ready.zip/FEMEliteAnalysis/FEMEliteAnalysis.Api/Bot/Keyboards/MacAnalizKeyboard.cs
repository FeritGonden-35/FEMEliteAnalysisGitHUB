using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class MacAnalizKeyboard
{
    public static InlineKeyboardMarkup SecilenMac(int macId)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "🤖 AI Analizi Oluştur",
                    $"analysis_generate:{macId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📋 Kayıtlı Analizi Göster",
                    $"analysis_show:{macId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Tarih Menüsüne Dön",
                    "match_date_menu")
            }
        });
    }

    public static InlineKeyboardMarkup AnalizSonucu(
        int macId,
        int analizId)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "🔄 Yeniden Analiz",
                    $"analysis_regenerate:{macId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "📢 VIP Kanalına Gönder",
                    $"analysis_publish:{analizId}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Match Center",
                    "match_date_menu")
            }
        });
    }
}
