using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AdminKeyboard
{
    public static InlineKeyboardMarkup Menu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("👥 Kullanıcılar","admin_users"),
                InlineKeyboardButton.WithCallbackData("💎 VIP","admin_vip")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⚽ Analiz","admin_analysis"),
                InlineKeyboardButton.WithCallbackData("📊 İstatistik","admin_stats")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⚙ Ayarlar","admin_settings"),
                InlineKeyboardButton.WithCallbackData("📜 Loglar","admin_logs")
            }
        });
    }
}