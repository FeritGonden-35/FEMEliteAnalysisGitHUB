using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Keyboards;

public static class AdminUsersKeyboard
{
    public static InlineKeyboardMarkup Menu()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("👥 Son Kullanıcılar", "users_page:0"),
                InlineKeyboardButton.WithCallbackData("🚫 Engellenenler", "users_blocked:0")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🔄 Yenile", "admin_users")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⬅️ Admin Menüsüne Dön", "admin_main")
            }
        });
    }

    public static InlineKeyboardMarkup Liste(
        IReadOnlyList<(int Id, string Etiket)> kullanicilar,
        int sayfa,
        bool oncekiVar,
        bool sonrakiVar,
        bool engellenenler)
    {
        var satirlar = new List<InlineKeyboardButton[]>();

        foreach (var kullanici in kullanicilar)
        {
            satirlar.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    kullanici.Etiket,
                    $"user_detail:{kullanici.Id}:{sayfa}:{(engellenenler ? 1 : 0)}")
            });
        }

        var sayfalama = new List<InlineKeyboardButton>();
        var prefix = engellenenler ? "users_blocked:" : "users_page:";

        if (oncekiVar)
            sayfalama.Add(InlineKeyboardButton.WithCallbackData("⬅️ Önceki", $"{prefix}{sayfa - 1}"));

        if (sonrakiVar)
            sayfalama.Add(InlineKeyboardButton.WithCallbackData("Sonraki ➡️", $"{prefix}{sayfa + 1}"));

        if (sayfalama.Count > 0)
            satirlar.Add(sayfalama.ToArray());

        satirlar.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("⬅️ Kullanıcı Yönetimi", "admin_users")
        });

        return new InlineKeyboardMarkup(satirlar);
    }

    public static InlineKeyboardMarkup Detay(
        int kullaniciId,
        bool engellendiMi,
        int sayfa,
        bool engellenenler)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    engellendiMi ? "✅ Engeli Kaldır" : "🚫 Kullanıcıyı Engelle",
                    $"user_toggle_block:{kullaniciId}:{sayfa}:{(engellenenler ? 1 : 0)}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Listeye Dön",
                    $"{(engellenenler ? "users_blocked:" : "users_page:")}{sayfa}")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🏠 Kullanıcı Yönetimi", "admin_users")
            }
        });
    }
}
