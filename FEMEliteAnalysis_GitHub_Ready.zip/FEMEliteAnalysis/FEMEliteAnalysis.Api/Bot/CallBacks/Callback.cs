using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Callbacks;

public interface ICallback
{
    string Name { get; }

    Task ExecuteAsync(CallbackQuery callback, CancellationToken cancellationToken);
}