using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Callbacks.Admin;

public class AdminUsersCallback
{
    public Task ExecuteAsync(
        CallbackQuery callback,
        CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }
}