namespace FEMEliteAnalysis.Api.Bot.Context;

public sealed class BotContext
{
    public IServiceProvider Services { get; }

    public BotContext(IServiceProvider services)
    {
        Services = services;
    }
}