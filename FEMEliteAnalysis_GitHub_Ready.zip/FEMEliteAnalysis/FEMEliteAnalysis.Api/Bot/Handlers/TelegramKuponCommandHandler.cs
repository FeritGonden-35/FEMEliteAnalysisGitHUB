using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramKuponCommandHandler
{
    public async Task<bool> TryHandleAsync(ITelegramBotClient botClient, Message message, string text,
        long adminTelegramId, IServiceProvider serviceProvider, bool adminMi, CancellationToken cancellationToken)
    {
        var komutMu = KomutMu(text, BotKomutlari.KuponaEkle) || KomutMu(text, BotKomutlari.Kuponum) ||
                      KomutMu(text, BotKomutlari.KupondanCikar) || KomutMu(text, BotKomutlari.KuponuTemizle) ||
                      KomutMu(text, BotKomutlari.KuponuKaydet) || KomutMu(text, BotKomutlari.Kuponlar) ||
                      KomutMu(text, BotKomutlari.KuponHazir) ||
                      KomutMu(text, BotKomutlari.KuponOptimize) || KomutMu(text, BotKomutlari.KuponOtomatik) || KomutMu(text, BotKomutlari.OtomatikKupon) || KomutMu(text, BotKomutlari.Kupon) || KomutMu(text, BotKomutlari.KuponAnaliz) ||
                      KomutMu(text, BotKomutlari.KuponAlternatif) || KomutMu(text, BotKomutlari.KuponKritik) ||
                      KomutMu(text, BotKomutlari.KuponOnizle) || KomutMu(text, BotKomutlari.KuponYayinla) ||
                      KomutMu(text, BotKomutlari.TwitterMetni) || KomutMu(text, BotKomutlari.Performans) ||
                      KomutMu(text, BotKomutlari.KuponSonuclari) || KomutMu(text, BotKomutlari.MarketPerformans) ||
                      KomutMu(text, BotKomutlari.KilitMaclar) || KomutMu(text, BotKomutlari.YuksekDeger) || KomutMu(text, BotKomutlari.OranAnaliz);
        if (!komutMu) return false;

        if (!adminMi)
        {
            await botClient.SendMessage(message.Chat.Id, "⛔ Bu kupon komutunu kullanma yetkiniz yok.", cancellationToken: cancellationToken);
            return true;
        }

        var service = serviceProvider.GetRequiredService<CokluKuponTelegramService>();
        var optimizasyonService = serviceProvider.GetRequiredService<KuponOptimizasyonTelegramService>();
        var yayinService = serviceProvider.GetRequiredService<KuponYayinTelegramService>();
        var performansService = serviceProvider.GetRequiredService<KuponPerformansTelegramService>();


        if (KomutMu(text, BotKomutlari.KilitMaclar) || KomutMu(text, BotKomutlari.YuksekDeger))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var adet = 4;
            if (p.Length >= 2 && int.TryParse(p[1], out var parsed)) adet = Math.Clamp(parsed, 1, 10);
            var yuksek = KomutMu(text, BotKomutlari.YuksekDeger);
            await botClient.SendMessage(message.Chat.Id, yuksek
                ? "🚀 FEM V5.1 yüksek-değer taraması çalışıyor...\nGerçek oran + model + market performansı + oran patterni birlikte değerlendirilecek."
                : "🔐 FEM V5.1 kilit maç taraması çalışıyor...\nZayıf maçlar elenecek; yalnız gerçek oranı ve edge'i bulunan seçimler dönecek.", cancellationToken: cancellationToken);
            var ks = serviceProvider.GetRequiredService<FEMEliteAnalysis.Api.Interfaces.IKilitMacService>();
            var r = await ks.GetirAsync(adet, yuksek, cancellationToken);
            if (!r.Basarili || r.Veri is null)
            {
                await botClient.SendMessage(message.Chat.Id, $"❌ {r.Mesaj}", cancellationToken: cancellationToken);
                return true;
            }
            var sb = new System.Text.StringBuilder();
            sb.AppendLine(yuksek ? "🚀 FEM ELITE — YÜKSEK DEĞER" : "🔐 FEM ELITE — KİLİT MAÇLAR");
            sb.AppendLine($"🔎 İncelenen: {r.Veri.IncelenenMac} | Shortlist: {r.Veri.Shortlist} | API: {r.Veri.ApiIstek}");
            sb.AppendLine();
            var i = 1;
            foreach (var x in r.Veri.Secimler)
            {
                sb.AppendLine($"{i}️⃣ {x.EvSahibi} - {x.Deplasman}");
                sb.AppendLine($"🎯 {x.Market} @ {x.Oran:0.00}");
                sb.AppendLine($"🧠 Kalibre güven: %{x.ModelGuven} | Edge: %{x.Edge:0.0} | FEM: {x.FinalSkor:0.0}/100+");
                if (x.GecmisMarketOrneklem > 0) sb.AppendLine($"📚 Market geçmişi: %{x.GecmisMarketBasari:0.0} ({x.GecmisMarketOrneklem} seçim)");
                if (!string.IsNullOrWhiteSpace(x.PatternBilgisi)) sb.AppendLine($"💹 Pattern: {x.PatternBilgisi}");
                sb.AppendLine($"➡️ /analiz {x.MacId}");
                sb.AppendLine(); i++;
            }
            sb.AppendLine("⚠️ V5.1 zayıf seçimle liste doldurmaz; bahis finansal risk içerir.");
            await botClient.SendMessage(message.Chat.Id, sb.ToString().Trim(), cancellationToken: cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.OranAnaliz))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var macId))
            {
                await Kullanim(botClient, message.Chat.Id, "/orananaliz MAC_ID", cancellationToken);
                return true;
            }
            var pe = serviceProvider.GetRequiredService<FEMEliteAnalysis.Api.Interfaces.IOddsPatternEngine>();
            var r = await pe.AnalizEtAsync(macId, cancellationToken);
            if (!r.Basarili || r.Veri is null)
            {
                await botClient.SendMessage(message.Chat.Id, $"❌ {r.Mesaj}", cancellationToken: cancellationToken);
                return true;
            }
            var x=r.Veri; var sb=new System.Text.StringBuilder();
            sb.AppendLine("💹 FEM V5.1 ORAN PATTERN ANALİZİ");
            sb.AppendLine($"Pattern #{x.PatternNo} | Referans: {x.Referans}");
            sb.AppendLine($"Benzerlik: %{x.Benzerlik:0.0} | Geçmiş örneklem: {x.Orneklem}");
            sb.AppendLine($"Durum: {x.Durum}");
            sb.AppendLine();
            foreach(var kv in x.BasariOranlari.OrderByDescending(z=>z.Value)) sb.AppendLine($"• {kv.Key}: %{kv.Value:0.0}");
            sb.AppendLine(); sb.AppendLine($"🔥 En güçlü tarihsel sinyal: {x.EnGucluSinyal} %{x.EnGucluSinyalYuzdesi:0.0}");
            sb.AppendLine("ℹ️ Bu bir manipülasyon/şike tespiti değildir; geçmiş benzer oran profillerinin istatistiksel sonucudur.");
            await botClient.SendMessage(message.Chat.Id, sb.ToString().Trim(), cancellationToken: cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.Performans) || KomutMu(text, BotKomutlari.KuponSonuclari) || KomutMu(text, BotKomutlari.MarketPerformans))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var gun = 30;
            if (p.Length >= 2 && int.TryParse(p[1], out var g)) gun = Math.Clamp(g, 1, 3650);
            var mod = KomutMu(text, BotKomutlari.MarketPerformans) ? "market" : KomutMu(text, BotKomutlari.KuponSonuclari) ? "sonuc" : "genel";
            await performansService.GonderAsync(botClient, message.Chat.Id, adminTelegramId, gun, mod, cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.KuponOnizle) ||
            KomutMu(text, BotKomutlari.KuponYayinla) ||
            KomutMu(text, BotKomutlari.TwitterMetni))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var kuponId))
            {
                var kullanim = KomutMu(text, BotKomutlari.KuponOnizle)
                    ? "/kupononizle KUPON_ID"
                    : KomutMu(text, BotKomutlari.KuponYayinla)
                        ? "/kuponyayinla KUPON_ID"
                        : "/twittermetni KUPON_ID";

                await Kullanim(botClient, message.Chat.Id, kullanim, cancellationToken);
                return true;
            }

            if (KomutMu(text, BotKomutlari.KuponOnizle))
            {
                await yayinService.OnizlemeGonderAsync(
                    botClient,
                    message.Chat.Id,
                    adminTelegramId,
                    kuponId,
                    cancellationToken);
            }
            else if (KomutMu(text, BotKomutlari.KuponYayinla))
            {
                await yayinService.YayinlaAsync(
                    botClient,
                    message.Chat.Id,
                    adminTelegramId,
                    kuponId,
                    cancellationToken);
            }
            else
            {
                await yayinService.TwitterMetniGonderAsync(
                    botClient,
                    message.Chat.Id,
                    adminTelegramId,
                    kuponId,
                    cancellationToken);
            }

            return true;
        }

        if (KomutMu(text, BotKomutlari.OtomatikKupon))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 3 || !int.TryParse(p[2], out var adet) || adet < 1 || adet > 20)
            {
                await Kullanim(botClient, message.Chat.Id, "/otomatikkupon dusuk|orta|yuksek ADET\nÖrnek: /otomatikkupon orta 3", cancellationToken);
                return true;
            }

            await botClient.SendMessage(message.Chat.Id,
                $"🤖 Otomatik {p[1].ToUpperInvariant()} kupon motoru çalışıyor...\n📊 Maçlar yerel veride daraltılacak, yalnız shortlist için gerçek oran çekilecek.",
                cancellationToken: cancellationToken);

            var auto = serviceProvider.GetRequiredService<FEMEliteAnalysis.Api.Interfaces.IOtomatikKuponService>();
            var r = await auto.OlusturAsync(adminTelegramId, p[1], adet, cancellationToken);
            if (!r.Basarili || r.Veri is null)
            {
                await botClient.SendMessage(message.Chat.Id, $"❌ {r.Mesaj}", cancellationToken: cancellationToken);
                return true;
            }

            var x = r.Veri;
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"✅ FEM OTOMATİK KUPON — {x.Mod.ToUpperInvariant()}");
            sb.AppendLine($"🎫 İstenen: {x.IstenenAdet} | Oluşan: {x.UretilenAdet}");
            sb.AppendLine($"🔎 DB maç: {x.IncelenenMac} | Shortlist: {x.ShortlistMac}");
            sb.AppendLine($"💰 Gerçek oranlı maç: {x.GercekOranliMac} | API istek: {x.OddsApiIstek}");
            sb.AppendLine();
            foreach (var k in x.Kuponlar)
            {
                sb.AppendLine($"🎟 #{k.KuponId} — {k.Baslik}");
                sb.AppendLine($"Oran: {k.ToplamOran:0.00} | Seçim: {k.SecimSayisi} | Güven: %{k.OrtalamaGuven}");
                sb.AppendLine($"Görüntüle: /kupon {k.KuponId}");
                sb.AppendLine();
            }
            if (x.UretilenAdet < x.IstenenAdet) sb.AppendLine("ℹ️ Adet doldurmak için zayıf veya tekrar kupon üretilmedi.");
            await botClient.SendMessage(message.Chat.Id, sb.ToString().Trim(), cancellationToken: cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.KuponAnaliz))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var id))
            {
                await Kullanim(botClient, message.Chat.Id, "/kuponanaliz KUPON_ID", cancellationToken);
                return true;
            }
            var db = serviceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
            var k = await db.Kuponlar.AsNoTracking().Include(x => x.Maclar)
                .FirstOrDefaultAsync(x => x.Id == id && x.AdminTelegramId == adminTelegramId, cancellationToken);
            if (k is null)
            {
                await botClient.SendMessage(message.Chat.Id, "❌ Kupon bulunamadı.", cancellationToken: cancellationToken);
                return true;
            }
            var sb = new System.Text.StringBuilder($"🧠 {k.Baslik} — ANALİZLER\n\n");
            foreach (var m in k.Maclar.OrderBy(x => x.Sira))
                sb.AppendLine($"⚽ {m.EvSahibi} - {m.Deplasman}\n🎯 {m.SecilenMarket} @{m.Oran:0.00}\n➡️ /analiz {m.MacId}\n");
            await botClient.SendMessage(message.Chat.Id, sb.ToString().Trim(), cancellationToken: cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.Kupon))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var id))
            {
                await Kullanim(botClient, message.Chat.Id, "/kupon KUPON_ID", cancellationToken);
                return true;
            }
            await service.HazirMetniGonderAsync(botClient, message.Chat.Id, adminTelegramId, id, cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.KuponOptimize))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            int? hedef = null;
            if (p.Length == 2 && int.TryParse(p[1], out var parsed)) hedef = parsed;
            await optimizasyonService.OptimizeGonderAsync(botClient, message.Chat.Id, adminTelegramId, hedef, cancellationToken);
            return true;
        }
        if (KomutMu(text, BotKomutlari.KuponOtomatik))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var adet))
            {
                await Kullanim(botClient, message.Chat.Id, "/kuponotomatik 1-5", cancellationToken);
                return true;
            }
            await optimizasyonService.OtomatikUygulaAsync(botClient, message.Chat.Id, adminTelegramId, adet, cancellationToken);
            return true;
        }
        if (KomutMu(text, BotKomutlari.KuponAlternatif))
        {
            await optimizasyonService.AlternatifGonderAsync(botClient, message.Chat.Id, adminTelegramId, cancellationToken);
            return true;
        }
        if (KomutMu(text, BotKomutlari.KuponKritik))
        {
            await optimizasyonService.KritikGonderAsync(botClient, message.Chat.Id, adminTelegramId, cancellationToken);
            return true;
        }
        if (KomutMu(text, BotKomutlari.Kuponum)) { await service.KuponuGonderAsync(botClient, message.Chat.Id, adminTelegramId, cancellationToken); return true; }
        if (KomutMu(text, BotKomutlari.KuponuTemizle)) { await service.KuponuTemizleAsync(botClient, message.Chat.Id, adminTelegramId, cancellationToken); return true; }
        if (KomutMu(text, BotKomutlari.Kuponlar)) { await service.KuponlariListeleAsync(botClient, message.Chat.Id, adminTelegramId, cancellationToken); return true; }
        if (KomutMu(text, BotKomutlari.KuponuKaydet))
        {
            var baslik = text.Length > BotKomutlari.KuponuKaydet.Length ? text[BotKomutlari.KuponuKaydet.Length..].Trim() : null;
            await service.KuponuKaydetAsync(botClient, message.Chat.Id, adminTelegramId, baslik, cancellationToken); return true;
        }
        if (KomutMu(text, BotKomutlari.KuponHazir))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var id)) { await Kullanim(botClient, message.Chat.Id, "/kuponhazir KUPON_ID", cancellationToken); return true; }
            await service.HazirMetniGonderAsync(botClient, message.Chat.Id, adminTelegramId, id, cancellationToken); return true;
        }
        if (KomutMu(text, BotKomutlari.KupondanCikar))
        {
            var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (p.Length != 2 || !int.TryParse(p[1], out var id)) { await Kullanim(botClient, message.Chat.Id, "/kupondancikar ANALIZ_ID", cancellationToken); return true; }
            await service.KupondanCikarAsync(botClient, message.Chat.Id, adminTelegramId, id, cancellationToken); return true;
        }

        var e = text.Split(' ', 3, StringSplitOptions.RemoveEmptyEntries);
        if (e.Length != 3 || !int.TryParse(e[1], out var analizId))
        { await Kullanim(botClient, message.Chat.Id, "/kuponaekle ANALIZ_ID MARKET\nÖrnek: /kuponaekle 7 1X + 1.5 ÜST", cancellationToken); return true; }
        await service.KuponaEkleAsync(botClient, message.Chat.Id, adminTelegramId, analizId, e[2], cancellationToken);
        return true;
    }

    private static bool KomutMu(string text, string komut) => text.Equals(komut, StringComparison.OrdinalIgnoreCase) || text.StartsWith(komut + " ", StringComparison.OrdinalIgnoreCase);
    private static Task Kullanim(ITelegramBotClient bot, long chatId, string metin, CancellationToken ct) => bot.SendMessage(chatId, $"Kullanım:\n{metin}", cancellationToken: ct);
}
