using System.Text;
using FEMEliteAnalysis.Api.Bot.Keyboards;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Services;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public sealed class TelegramCallbackHandler
{
    private const int TelegramMesajLimiti = 3900;
    private const int MatchCenterSayfaBoyutu = 10;
    private const int KullaniciSayfaBoyutu = 8;
    private const int LogSayfaBoyutu = 10;

    private readonly IServiceScopeFactory _scopeFactory;
    private readonly TelegramOptions _telegramOptions;
    private readonly ILogger<TelegramCallbackHandler> _logger;

    public TelegramCallbackHandler(
        IServiceScopeFactory scopeFactory,
        IOptions<TelegramOptions> telegramOptions,
        ILogger<TelegramCallbackHandler> logger)
    {
        _scopeFactory = scopeFactory;
        _telegramOptions = telegramOptions.Value;
        _logger = logger;
    }

    public async Task HandleAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        if (callbackQuery.Message is null ||
            string.IsNullOrWhiteSpace(callbackQuery.Data))
        {
            return;
        }

        if (!AdminMi(callbackQuery.From.Id))
        {
            await botClient.AnswerCallbackQuery(
                callbackQuery.Id,
                text: "Bu işlem için yetkiniz bulunmuyor.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        var chatId = callbackQuery.Message.Chat.Id;
        var messageId = callbackQuery.Message.MessageId;
        var callbackData = callbackQuery.Data;

        _logger.LogInformation(
            "Admin callback çalıştırıldı. UserId: {UserId}, Callback: {Callback}",
            callbackQuery.From.Id,
            callbackData);

        await CallbackLoguKaydetAsync(
            callbackQuery.From.Id,
            callbackData,
            cancellationToken);

        try
        {
            if (callbackData.StartsWith("joinannounce:", StringComparison.Ordinal))
            {
                await HandleJoinAnnouncementCallbackAsync(botClient, callbackQuery, callbackData, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("joinapprove:", StringComparison.Ordinal) ||
                callbackData.StartsWith("joinreject:", StringComparison.Ordinal) ||
                callbackData.StartsWith("joinresubmit:", StringComparison.Ordinal))
            {
                await HandleJoinVerificationCallbackAsync(
                    botClient,
                    callbackQuery,
                    callbackData,
                    cancellationToken);
                return;
            }

            if (callbackData == "match_noop")
            {
                await botClient.AnswerCallbackQuery(callbackQuery.Id, cancellationToken: cancellationToken);
                return;
            }

            if (callbackData.StartsWith("match_detail:", StringComparison.Ordinal))
            {
                await MacDetayiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("match_refresh:", StringComparison.Ordinal))
            {
                await TekMaciGuncelleAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("match_page:", StringComparison.Ordinal))
            {
                await MatchSayfasiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("match_leagues:", StringComparison.Ordinal))
            {
                await LigSecimMenusuGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("match_league:", StringComparison.Ordinal))
            {
                await LigMaclariniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("analysis_prediction_help:", StringComparison.Ordinal))
            {
                await AnalizTahminYardimiGosterAsync(botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("analysis_generate:", StringComparison.Ordinal) ||
                callbackData.StartsWith("analysis_regenerate:", StringComparison.Ordinal))
            {
                await AnalizOlusturButonuAsync(botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("analysis_show:", StringComparison.Ordinal))
            {
                await KayitliAnaliziGosterAsync(botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith(
                    "analysis_preview:",
                    StringComparison.Ordinal))
            {
                await AnalizOnizlemesiGosterAsync(
                    botClient,
                    chatId,
                    messageId,
                    callbackData,
                    cancellationToken);

                await CallbackCevaplaAsync(
                    botClient,
                    callbackQuery.Id,
                    cancellationToken);
                return;
            }

            if (callbackData.StartsWith(
                    "analysis_publish:",
                    StringComparison.Ordinal))
            {
                await AnaliziYayinlaAsync(
                    botClient,
                    chatId,
                    messageId,
                    callbackData,
                    cancellationToken);

                await CallbackCevaplaAsync(
                    botClient,
                    callbackQuery.Id,
                    cancellationToken);
                return;
            }

            if (callbackData == "admin_users")
            {
                await KullaniciYonetimMenusuGosterAsync(
                    botClient, chatId, messageId, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("users_page:", StringComparison.Ordinal) ||
                callbackData.StartsWith("users_blocked:", StringComparison.Ordinal))
            {
                await KullaniciListesiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("user_detail:", StringComparison.Ordinal))
            {
                await KullaniciDetayiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("user_toggle_block:", StringComparison.Ordinal))
            {
                await KullaniciEngeliniDegistirAsync(
                    botClient,
                    chatId,
                    messageId,
                    callbackQuery.From.Id,
                    callbackData,
                    cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData == "admin_settings")
            {
                await AyarlarMenusuGosterAsync(
                    botClient, chatId, messageId, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData == "admin_stats")
            {
                await IstatistikMenusuGosterAsync(
                    botClient, chatId, messageId, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData is "stats_users" or "stats_vip" or "stats_analysis" or "stats_data")
            {
                await IstatistikDetayiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("setting_detail:", StringComparison.Ordinal))
            {
                await AyarDetayiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData == "admin_logs")
            {
                await LogMenusuGosterAsync(
                    botClient, chatId, messageId, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            if (callbackData.StartsWith("logs_recent:", StringComparison.Ordinal) ||
                callbackData.StartsWith("logs_errors:", StringComparison.Ordinal))
            {
                await LogListesiniGosterAsync(
                    botClient, chatId, messageId, callbackData, cancellationToken);
                await CallbackCevaplaAsync(botClient, callbackQuery.Id, cancellationToken);
                return;
            }

            switch (callbackData)
            {
                case "admin_users":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "👥 KULLANICI YÖNETİMİ\n\n" +
                        "Kullanıcı işlemleri sonraki feature içinde aktif edilecek.",
                        AdminGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "admin_vip":
                    await botClient.EditMessageText(
                        chatId: chatId,
                        messageId: messageId,
                        text:
                            "💎 VIP YÖNETİMİ\n\n" +
                            "Yapmak istediğiniz işlemi seçin.",
                        replyMarkup: VipKeyboard.Menu(),
                        cancellationToken: cancellationToken);
                    break;

                case "vip_active_members":
                    await AktifVipUyeleriGosterAsync(
                        botClient,
                        chatId,
                        messageId,
                        cancellationToken);
                    break;

                case "vip_member_info":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "🔎 ÜYE BİLGİSİ\n\n" +
                        "Komut:\n/uyebilgi TELEGRAM_ID\n\n" +
                        "Örnek:\n/uyebilgi 123456789",
                        VipGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "vip_add_extend":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "➕ ÜYE EKLE / UZAT\n\n" +
                        "Komut:\n/uyeekle TELEGRAM_ID GUN\n\n" +
                        "Örnek:\n/uyeekle 123456789 30",
                        VipGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "vip_cancel":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "❌ ÜYELİK İPTAL\n\n" +
                        "Komut:\n/uyesil TELEGRAM_ID\n\n" +
                        "Örnek:\n/uyesil 123456789",
                        VipGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "vip_main":
                    await botClient.EditMessageText(
                        chatId: chatId,
                        messageId: messageId,
                        text:
                            "💎 VIP YÖNETİMİ\n\n" +
                            "Yapmak istediğiniz işlemi seçin.",
                        replyMarkup: VipKeyboard.Menu(),
                        cancellationToken: cancellationToken);
                    break;

                case "admin_analysis":
                    await botClient.EditMessageText(
                        chatId: chatId,
                        messageId: messageId,
                        text:
                            "⚽ MATCH CENTER\n\n" +
                            "Analiz etmek istediğiniz maçların tarihini seçin.",
                        replyMarkup: AnalizTarihKeyboard.Menu(),
                        cancellationToken: cancellationToken);
                    break;

                case "match_today":
                    await LigSecimMenusuGosterAsync(
                        botClient, chatId, messageId,
                        $"match_leagues:{BugununTarihi():yyyyMMdd}", cancellationToken);
                    break;

                case "match_tomorrow":
                    await LigSecimMenusuGosterAsync(
                        botClient, chatId, messageId,
                        $"match_leagues:{BugununTarihi().AddDays(1):yyyyMMdd}", cancellationToken);
                    break;

                case "match_today_tomorrow":
                    await BugunVeYariniGosterAsync(
                        botClient, chatId, messageId, cancellationToken);
                    break;

                case "match_7days":
                    await botClient.EditMessageText(
                        chatId, messageId,
                        "🗓 ÖNÜMÜZDEKİ 7 GÜN\n\nGörüntülemek istediğiniz tarihi seçin.",
                        replyMarkup: MatchCenterKeyboard.YediGun(BugununTarihi()),
                        cancellationToken: cancellationToken);
                    break;

                case "match_date_menu":
                    await botClient.EditMessageText(
                        chatId: chatId,
                        messageId: messageId,
                        text:
                            "⚽ MATCH CENTER\n\n" +
                            "Analiz etmek istediğiniz maçların tarihini seçin.",
                        replyMarkup: AnalizTarihKeyboard.Menu(),
                        cancellationToken: cancellationToken);
                    break;

                case "match_search_help":
                    await MenuyuGuncelleAsync(
                        botClient, chatId, messageId,
                        "🔎 MAÇ ARA\n\n" +
                        "Komut:\n/macara TAKIM_VEYA_LİG\n\n" +
                        "Örnek:\n/macara Galatasaray\n/macara Süper Lig\n\n" +
                        "Sonuçlarda maç ID ve doğrudan maç detay butonu görünür.",
                        MacTarihGeriDonKeyboard(), cancellationToken);
                    break;

                case "team_search_help":
                    await MenuyuGuncelleAsync(
                        botClient, chatId, messageId,
                        "👤 TAKIM ARA\n\n" +
                        "Komut:\n/takim TAKIM_ADI\n\n" +
                        "Örnek:\n/takim Galatasaray\n\n" +
                        "Takım profili, son 20 formu ve yaklaşan maç ID'leri gösterilir.",
                        MacTarihGeriDonKeyboard(), cancellationToken);
                    break;

                case "league_search_help":
                    await MenuyuGuncelleAsync(
                        botClient, chatId, messageId,
                        "🏆 LİG ARA\n\n" +
                        "Komut:\n/lig LİG_ADI\n\n" +
                        "Örnek:\n/lig Süper Lig\n\n" +
                        "Lig özeti ve yaklaşan maçlara doğrudan erişim gösterilir.",
                        MacTarihGeriDonKeyboard(), cancellationToken);
                    break;

                case "admin_stats":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "📊 İSTATİSTİKLER\n\n" +
                        "Analiz ve üyelik istatistikleri burada gösterilecek.",
                        AdminGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "admin_settings":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "⚙ AYARLAR\n\n" +
                        "Bot, kanal ve API ayarları burada yönetilecek.",
                        AdminGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "admin_logs":
                    await MenuyuGuncelleAsync(
                        botClient,
                        chatId,
                        messageId,
                        "📜 SİSTEM LOGLARI\n\n" +
                        "Son sistem kayıtları burada gösterilecek.",
                        AdminGeriDonKeyboard(),
                        cancellationToken);
                    break;

                case "admin_main":
                    await botClient.EditMessageText(
                        chatId: chatId,
                        messageId: messageId,
                        text:
                            "👑 FEM ELITE ANALYSIS\n\n" +
                            "Admin paneline hoş geldiniz.\n" +
                            "Yapmak istediğiniz işlemi seçin.",
                        replyMarkup: AdminKeyboard.Menu(),
                        cancellationToken: cancellationToken);
                    break;

                default:
                    await botClient.AnswerCallbackQuery(
                        callbackQuery.Id,
                        text: "Bilinmeyen işlem.",
                        cancellationToken: cancellationToken);
                    return;
            }

            await CallbackCevaplaAsync(
                botClient,
                callbackQuery.Id,
                cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Callback işlenirken hata oluştu. Callback: {Callback}",
                callbackData);

            await botClient.AnswerCallbackQuery(
                callbackQuery.Id,
                text: "İşlem sırasında bir hata oluştu.",
                showAlert: true,
                cancellationToken: cancellationToken);
        }
    }

    private async Task AnalizOnizlemesiGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!CallbackIdOku(
                callbackData,
                "analysis_preview:",
                out var analizId))
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                "❌ Geçersiz analiz ID değeri.",
                AdminGeriDonKeyboard(),
                cancellationToken);
            return;
        }

        using var scope = _scopeFactory.CreateScope();

        var yayinService =
            scope.ServiceProvider.GetRequiredService<IAnalizYayinService>();

        var sonuc = await yayinService.YayinOnizlemesiOlusturAsync(
            analizId,
            cancellationToken);

        if (!sonuc.Basarili || string.IsNullOrWhiteSpace(sonuc.Veri))
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                $"❌ {sonuc.Mesaj}",
                AdminGeriDonKeyboard(),
                cancellationToken);
            return;
        }

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            "👁 YAYIN ÖN İZLEMESİ\n\n" + sonuc.Veri,
            AnalizYayinKeyboard.OnayMenu(analizId),
            cancellationToken);
    }

    private async Task AnaliziYayinlaAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!CallbackIdOku(
                callbackData,
                "analysis_publish:",
                out var analizId))
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                "❌ Geçersiz analiz ID değeri.",
                AdminGeriDonKeyboard(),
                cancellationToken);
            return;
        }

        await botClient.EditMessageText(
            chatId: chatId,
            messageId: messageId,
            text: "⏳ Analiz VIP kanalına gönderiliyor...",
            cancellationToken: cancellationToken);

        using var scope = _scopeFactory.CreateScope();

        var yayinService =
            scope.ServiceProvider.GetRequiredService<IAnalizYayinService>();

        var sonuc = await yayinService.VipKanalinaYayinlaAsync(
            analizId,
            cancellationToken);

        if (!sonuc.Basarili)
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                $"❌ {sonuc.Mesaj}",
                AnalizYayinKeyboard.OnayMenu(analizId),
                cancellationToken);
            return;
        }

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            "✅ ANALİZ YAYINLANDI\n\n" +
            $"{sonuc.Mesaj}\n" +
            $"Telegram mesaj ID: {sonuc.Veri}",
            AnalizYayinKeyboard.Yayinlandi(),
            cancellationToken);
    }

    private static readonly string[] OncelikliLigKelimeleri =
    [
        "Süper Lig", "Super Lig", "Premier League", "La Liga",
        "Serie A", "Bundesliga", "Ligue 1", "Eredivisie",
        "Primeira Liga", "Pro League", "Swiss Super League",
        "Champions League", "Europa League", "Conference League"
    ];

    private async Task LigSecimMenusuGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var parcalar = callbackData.Split(':');
        if (parcalar.Length != 2 ||
            !DateOnly.TryParseExact(parcalar[1], "yyyyMMdd", out var tarih))
        {
            await MenuyuGuncelleAsync(botClient, chatId, messageId,
                "❌ Geçersiz tarih.", MacTarihGeriDonKeyboard(), cancellationToken);
            return;
        }

        var tz = TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time");
        var baslangicUtc = TimeZoneInfo.ConvertTimeToUtc(tarih.ToDateTime(TimeOnly.MinValue), tz);
        var bitisUtc = TimeZoneInfo.ConvertTimeToUtc(tarih.AddDays(1).ToDateTime(TimeOnly.MinValue), tz);

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();

        var ligler = await db.Maclar.AsNoTracking()
            .Where(x => x.MacTarihi >= baslangicUtc && x.MacTarihi < bitisUtc && x.LigId.HasValue)
            .GroupBy(x => new { Id = x.LigId!.Value, Ad = x.Lig != null ? x.Lig.Ad : "Bilinmeyen Lig" })
            .Select(g => new { g.Key.Id, g.Key.Ad, Sayi = g.Count() })
            .ToListAsync(cancellationToken);

        var sirali = ligler
            .OrderBy(x => LigOnemPuani(x.Ad))
            .ThenByDescending(x => x.Sayi)
            .ThenBy(x => x.Ad)
            .ToList();

        var onemli = sirali.Where(x => LigOnemPuani(x.Ad) < 100).Take(20).ToList();
        var diger = sirali.Where(x => LigOnemPuani(x.Ad) >= 100).Take(25).ToList();

        var mesaj = new StringBuilder();
        mesaj.AppendLine("🏟 MATCH CENTER");
        mesaj.AppendLine($"📅 {tarih:dd.MM.yyyy}");
        mesaj.AppendLine();
        mesaj.AppendLine("Önce ligi seçin. Önemli ligler en üstte gösterilir.");
        mesaj.AppendLine($"Toplam fikstür: {ligler.Sum(x => x.Sayi)} maç • {ligler.Count} lig");

        await botClient.EditMessageText(
            chatId, messageId, mesaj.ToString(),
            replyMarkup: MatchCenterKeyboard.LigSecimi(tarih,
                onemli.Select(x => (x.Id, x.Ad, x.Sayi)).ToList(),
                diger.Select(x => (x.Id, x.Ad, x.Sayi)).ToList()),
            cancellationToken: cancellationToken);
    }

    private async Task LigMaclariniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var p = callbackData.Split(':');
        if (p.Length != 4 ||
            !DateOnly.TryParseExact(p[1], "yyyyMMdd", out var tarih) ||
            !int.TryParse(p[2], out var ligId) ||
            !int.TryParse(p[3], out var sayfa))
        {
            await MenuyuGuncelleAsync(botClient, chatId, messageId,
                "❌ Geçersiz lig/sayfa bilgisi.", MacTarihGeriDonKeyboard(), cancellationToken);
            return;
        }

        var tz = TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time");
        var baslangicUtc = TimeZoneInfo.ConvertTimeToUtc(tarih.ToDateTime(TimeOnly.MinValue), tz);
        var bitisUtc = TimeZoneInfo.ConvertTimeToUtc(tarih.AddDays(1).ToDateTime(TimeOnly.MinValue), tz);

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();

        var maclar = await db.Maclar.AsNoTracking()
            .Include(x => x.Lig).Include(x => x.EvSahibiTakim).Include(x => x.DeplasmanTakim)
            .Where(x => x.LigId == ligId && x.MacTarihi >= baslangicUtc && x.MacTarihi < bitisUtc)
            .OrderBy(x => x.MacTarihi)
            .Select(x => new MacDetayDto
            {
                Id = x.Id, Lig = x.Lig != null ? x.Lig.Ad : "Bilinmeyen Lig",
                EvSahibi = x.EvSahibiTakim.Ad, Deplasman = x.DeplasmanTakim.Ad,
                MacTarihi = x.MacTarihi, Durum = x.Durum
            })
            .ToListAsync(cancellationToken);

        var toplamSayfa = Math.Max(1, (int)Math.Ceiling(maclar.Count / (double)MatchCenterSayfaBoyutu));
        sayfa = Math.Clamp(sayfa, 0, toplamSayfa - 1);
        var sayfaMaclari = maclar.Skip(sayfa * MatchCenterSayfaBoyutu).Take(MatchCenterSayfaBoyutu).ToList();
        var ligAdi = maclar.FirstOrDefault()?.Lig ?? "Lig";

        var formService = scope.ServiceProvider.GetRequiredService<ISqlTakimFormService>();
        var kaliteMap = new Dictionary<int, (int Puan, string Etiket, string Yildiz)>();
        foreach (var mac in sayfaMaclari)
        {
            var kalite = await formService.MacKuponVerisiOlusturAsync(mac.Id, cancellationToken);
            var puan = kalite.Basarili && kalite.Veri is not null
                ? kalite.Veri.VeriKalitesiPuani
                : 0;
            kaliteMap[mac.Id] = (puan, KaliteEtiketi(puan), YildizMetni(puan));
        }

        var butonlar = sayfaMaclari.Select(x =>
        {
            var q = kaliteMap[x.Id];
            return (x.Id, $"{q.Yildiz} %{q.Puan} • {IstanbulSaati(x.MacTarihi):HH:mm} • {x.EvSahibi} - {x.Deplasman}");
        }).ToList();

        var metin = new StringBuilder();
        metin.AppendLine($"🏆 {ligAdi}");
        metin.AppendLine($"📅 {tarih:dd.MM.yyyy} • Sayfa {sayfa + 1}/{toplamSayfa}");
        metin.AppendLine();
        foreach (var mac in sayfaMaclari)
        {
            var q = kaliteMap[mac.Id];
            metin.AppendLine($"{q.Yildiz} %{q.Puan} — {q.Etiket}");
            metin.AppendLine($"{IstanbulSaati(mac.MacTarihi):HH:mm}  {mac.EvSahibi} — {mac.Deplasman}");
            metin.AppendLine();
        }
        metin.AppendLine($"Toplam {maclar.Count} maç. Detay için butona dokunun.");

        await botClient.EditMessageText(
            chatId, messageId, MesajiSinirla(metin.ToString()),
            replyMarkup: MatchCenterKeyboard.LigMaclari(tarih, ligId, sayfa, toplamSayfa, butonlar),
            cancellationToken: cancellationToken);
    }

    private static string YildizMetni(int puan)
    {
        var adet = puan >= 90 ? 5 : puan >= 75 ? 4 : puan >= 60 ? 3 : puan >= 40 ? 2 : 1;
        return new string('⭐', adet) + new string('☆', 5 - adet);
    }

    private static string KaliteEtiketi(int puan) => puan switch
    {
        >= 90 => "Mükemmel",
        >= 75 => "Çok iyi",
        >= 60 => "İyi",
        >= 40 => "Orta",
        _ => "Zayıf"
    };

    private static int LigOnemPuani(string ligAdi)
    {
        for (var i = 0; i < OncelikliLigKelimeleri.Length; i++)
        {
            if (ligAdi.Contains(OncelikliLigKelimeleri[i], StringComparison.OrdinalIgnoreCase))
                return i;
        }
        return 100;
    }

    private async Task TariheGoreMaclariGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        DateOnly tarih,
        string baslik,
        CancellationToken cancellationToken,
        int sayfa = 0)
    {
        await botClient.EditMessageText(
            chatId, messageId, "⏳ Maçlar getiriliyor...",
            cancellationToken: cancellationToken);

        using var scope = _scopeFactory.CreateScope();
        var macService = scope.ServiceProvider
            .GetRequiredService<IMacSenkronizasyonService>();

        var sonuc = await macService.TariheGoreMaclariGetirAsync(
            tarih, cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await MenuyuGuncelleAsync(
                botClient, chatId, messageId, $"❌ {sonuc.Mesaj}",
                MacTarihGeriDonKeyboard(), cancellationToken);
            return;
        }

        var sirali = sonuc.Veri
            .OrderBy(x => x.Lig)
            .ThenBy(x => x.MacTarihi)
            .ToList();

        var toplamSayfa = Math.Max(1,
            (int)Math.Ceiling(sirali.Count / (double)MatchCenterSayfaBoyutu));
        sayfa = Math.Clamp(sayfa, 0, toplamSayfa - 1);

        var sayfaMaclari = sirali
            .Skip(sayfa * MatchCenterSayfaBoyutu)
            .Take(MatchCenterSayfaBoyutu)
            .ToList();

        var mesaj = MacListesiOlustur(
            baslik, tarih, sayfaMaclari, sayfa, toplamSayfa, sirali.Count);

        var butonlar = sayfaMaclari
            .Select(x => (
                x.Id,
                $"{IstanbulSaati(x.MacTarihi):HH:mm} • {x.EvSahibi} - {x.Deplasman}"))
            .ToList();

        await botClient.EditMessageText(
            chatId, messageId, mesaj,
            replyMarkup: MatchCenterKeyboard.Liste(
                tarih, sayfa, toplamSayfa, butonlar),
            cancellationToken: cancellationToken);
    }

    private async Task MatchSayfasiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var parcalar = callbackData.Split(':');
        if (parcalar.Length != 3 ||
            !DateOnly.TryParseExact(parcalar[1], "yyyyMMdd", out var tarih) ||
            !int.TryParse(parcalar[2], out var sayfa))
        {
            await MenuyuGuncelleAsync(
                botClient, chatId, messageId, "❌ Geçersiz sayfa bilgisi.",
                MacTarihGeriDonKeyboard(), cancellationToken);
            return;
        }

        await TariheGoreMaclariGosterAsync(
            botClient, chatId, messageId, tarih,
            tarih == BugununTarihi() ? "BUGÜNÜN MAÇLARI" : "MAÇ MERKEZİ",
            cancellationToken, sayfa);
    }

    private async Task BugunVeYariniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        CancellationToken cancellationToken)
    {
        var bugun = BugununTarihi();
        var keyboard = new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    $"📅 Bugün • {bugun:dd.MM}", $"match_page:{bugun:yyyyMMdd}:0")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    $"⏭️ Yarın • {bugun.AddDays(1):dd.MM}",
                    $"match_page:{bugun.AddDays(1):yyyyMMdd}:0")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("⬅️ Tarih Menüsü", "match_date_menu")
            }
        });

        await botClient.EditMessageText(
            chatId, messageId,
            "📆 BUGÜN + YARIN\n\nTelegram mesaj sınırına takılmaması için günler ayrı ve sayfalı gösterilir.",
            replyMarkup: keyboard,
            cancellationToken: cancellationToken);
    }

    private static string MacListesiOlustur(
        string baslik,
        DateOnly tarih,
        IReadOnlyCollection<MacDetayDto> maclar,
        int sayfa = 0,
        int toplamSayfa = 1,
        int toplamMac = 0)
    {
        var metin = new StringBuilder();
        metin.AppendLine($"⚽ {baslik}");
        metin.AppendLine($"📅 {tarih:dd.MM.yyyy}");
        metin.AppendLine($"📄 Sayfa {sayfa + 1}/{Math.Max(1, toplamSayfa)} • Toplam {toplamMac} maç");
        metin.AppendLine();

        if (maclar.Count == 0)
        {
            metin.AppendLine("Bu tarih için maç bulunamadı.");
            return metin.ToString();
        }

        foreach (var lig in maclar.GroupBy(x => x.Lig).OrderBy(x => x.Key))
        {
            metin.AppendLine($"🏆 {lig.Key}");
            foreach (var mac in lig.OrderBy(x => x.MacTarihi))
            {
                metin.AppendLine(
                    $"{IstanbulSaati(mac.MacTarihi):HH:mm}  " +
                    $"{mac.EvSahibi} — {mac.Deplasman}");
                metin.AppendLine($"   🆔 {mac.Id}");
            }
            metin.AppendLine();
        }

        metin.AppendLine("Maç detayını açmak için aşağıdaki butona dokunun.");
        return MesajiSinirla(metin.ToString());
    }

    private async Task MacDetayiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!CallbackIdOku(callbackData, "match_detail:", out var macId))
            return;

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();

        var mac = await db.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(x => x.Id == macId, cancellationToken);

        if (mac is null)
        {
            await MenuyuGuncelleAsync(
                botClient, chatId, messageId, "❌ Maç bulunamadı.",
                MacTarihGeriDonKeyboard(), cancellationToken);
            return;
        }

        var tarih = IstanbulTarihi(mac.MacTarihi);
        var metin = new StringBuilder();
        metin.AppendLine("⚽ MAÇ DETAYI");
        metin.AppendLine();
        metin.AppendLine($"🏠 {mac.EvSahibiTakim?.Ad ?? "Bilinmeyen"}");
        metin.AppendLine($"✈️ {mac.DeplasmanTakim?.Ad ?? "Bilinmeyen"}");
        metin.AppendLine();
        metin.AppendLine($"🏆 {mac.Lig?.Ad ?? "Bilinmeyen Lig"}");
        metin.AppendLine($"📅 {IstanbulSaati(mac.MacTarihi):dd.MM.yyyy HH:mm}");
        metin.AppendLine($"🆔 Maç ID: {mac.Id}");
        metin.AppendLine($"📡 Durum: {mac.Durum ?? "Planlandı"}");
        metin.AppendLine();
        metin.AppendLine("İşlem seçin:");

        await botClient.EditMessageText(
            chatId, messageId, metin.ToString(),
            replyMarkup: MatchDetailKeyboard.Menu(mac.Id, tarih),
            cancellationToken: cancellationToken);
    }

    private async Task TekMaciGuncelleAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!CallbackIdOku(callbackData, "match_refresh:", out var macId))
            return;

        await botClient.EditMessageText(
            chatId, messageId,
            "⏳ Yalnızca seçilen maçın iki takımı ve H2H verisi güncelleniyor...",
            cancellationToken: cancellationToken);

        using var scope = _scopeFactory.CreateScope();
        var service = scope.ServiceProvider.GetRequiredService<IUygunMacService>();
        var sonuc = await service.SeciliMacVerisiniCekAsync(macId, cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await MenuyuGuncelleAsync(
                botClient, chatId, messageId, $"❌ {sonuc.Mesaj}",
                MacAnalizKeyboard.SecilenMac(macId), cancellationToken);
            return;
        }

        var x = sonuc.Veri;
        var bilgi = x.Bilgiler.Count == 0
            ? ""
            : "\n\n🔎 Derin veri:\n" + string.Join("\n", x.Bilgiler.Select(u => $"• {u}"));
        var uyari = x.Uyarilar.Count == 0
            ? ""
            : "\n\n⚠️ Uyarılar:\n" + string.Join("\n", x.Uyarilar.Select(u => $"• {u}"));

        var metin =
            $"✅ SEÇİLİ MAÇ GÜNCELLENDİ\n\n" +
            $"⚽ {x.MacAdi}\n" +
            $"📥 API kaydı: {x.ApiKayitSayisi}\n" +
            $"➕ Eklenen: {x.EklenenMacSayisi}\n" +
            $"🔄 Güncellenen: {x.GuncellenenMacSayisi}\n" +
            $"📦 Veri kalitesi: %{x.VeriKalitesiOnce} → %{x.VeriKalitesiSonra}" +
            bilgi + uyari;

        await MenuyuGuncelleAsync(
            botClient, chatId, messageId, metin,
            MacAnalizKeyboard.SecilenMac(macId), cancellationToken);
    }

    private async Task AktifVipUyeleriGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();

        var vipService =
            scope.ServiceProvider.GetRequiredService<IVipYonetimService>();

        var sonuc = await vipService.AktifUyeleriGetirAsync(
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                $"❌ {sonuc.Mesaj}",
                VipGeriDonKeyboard(),
                cancellationToken);
            return;
        }

        if (sonuc.Veri.Count == 0)
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                "📋 AKTİF VIP ÜYELER\n\nAktif VIP üye bulunmuyor.",
                VipGeriDonKeyboard(),
                cancellationToken);
            return;
        }

        var metin = new StringBuilder();

        metin.AppendLine("📋 AKTİF VIP ÜYELER");
        metin.AppendLine();

        foreach (var uye in sonuc.Veri.Take(30))
        {
            var ad = string.IsNullOrWhiteSpace(uye.AdSoyad)
                ? "İsimsiz kullanıcı"
                : uye.AdSoyad;

            metin.AppendLine($"👤 {ad}");
            metin.AppendLine($"🆔 {uye.TelegramKullaniciId}");

            if (!string.IsNullOrWhiteSpace(uye.KullaniciAdi))
            {
                metin.AppendLine($"🔗 @{uye.KullaniciAdi}");
            }

            metin.AppendLine(
                $"📅 Bitiş: {uye.BitisTarihi.ToLocalTime():dd.MM.yyyy HH:mm}");

            metin.AppendLine($"⏳ Kalan: {uye.KalanGun} gün");
            metin.AppendLine("────────────");
        }

        if (sonuc.Veri.Count > 30)
        {
            metin.AppendLine();
            metin.AppendLine(
                $"İlk 30 üye gösteriliyor. Toplam: {sonuc.Veri.Count}");
        }

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin.ToString(),
            VipGeriDonKeyboard(),
            cancellationToken);
    }

    private async Task IstatistikMenusuGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var simdi = DateTime.UtcNow;
        var sonYediGun = simdi.AddDays(-7);

        var kullanici = await db.Kullanicilar.CountAsync(cancellationToken);
        var aktifVip = await db.Uyelikler
            .Where(x =>
                x.Durum == FEMEliteAnalysis.Api.Enums.UyelikDurumu.Aktif &&
                x.BitisTarihi > simdi)
            .Select(x => x.KullaniciId)
            .Distinct()
            .CountAsync(cancellationToken);
        var mac = await db.Maclar.CountAsync(cancellationToken);
        var analiz = await db.Analizler.CountAsync(cancellationToken);
        var sonHaftaAnaliz = await db.Analizler.CountAsync(
            x => x.OlusturmaTarihi >= sonYediGun, cancellationToken);
        var kupon = await db.Kuponlar.CountAsync(cancellationToken);

        var sonuclanan = await db.Analizler.CountAsync(
            x => x.Sonuc == FEMEliteAnalysis.Api.Enums.AnalizSonucu.Basarili ||
                 x.Sonuc == FEMEliteAnalysis.Api.Enums.AnalizSonucu.Basarisiz,
            cancellationToken);
        var basarili = await db.Analizler.CountAsync(
            x => x.Sonuc == FEMEliteAnalysis.Api.Enums.AnalizSonucu.Basarili,
            cancellationToken);
        var basariOrani = sonuclanan == 0 ? 0 : basarili * 100.0 / sonuclanan;

        var metin =
            "📊 İSTATİSTİKLER\n\n" +
            $"Kullanıcı: {kullanici:N0}\n" +
            $"Aktif VIP: {aktifVip:N0}\n" +
            $"Maç: {mac:N0}\n" +
            $"Analiz: {analiz:N0}\n" +
            $"Son 7 gün analiz: {sonHaftaAnaliz:N0}\n" +
            $"Kupon: {kupon:N0}\n" +
            $"Sonuçlanan analiz başarısı: %{basariOrani:F1}\n\n" +
            "Ayrıntılı istatistik için bir kategori seçin.";

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminStatsKeyboard.Menu(),
            cancellationToken);
    }

    private async Task IstatistikDetayiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string kategori,
        CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();

        var metin = kategori switch
        {
            "stats_users" => await KullaniciIstatistikMetniAsync(db, cancellationToken),
            "stats_vip" => await VipIstatistikMetniAsync(db, cancellationToken),
            "stats_analysis" => await AnalizIstatistikMetniAsync(db, cancellationToken),
            "stats_data" => await VeriIstatistikMetniAsync(db, cancellationToken),
            _ => "İstatistik kategorisi bulunamadı."
        };

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminStatsKeyboard.GeriDon(),
            cancellationToken);
    }

    private static async Task<string> KullaniciIstatistikMetniAsync(
        FEMEliteAnalysis.Api.Data.FemDbContext db,
        CancellationToken cancellationToken)
    {
        var simdi = DateTime.UtcNow;
        var bugun = simdi.Date;
        var sonYediGun = simdi.AddDays(-7);
        var sonOtuzGun = simdi.AddDays(-30);

        var toplam = await db.Kullanicilar.CountAsync(cancellationToken);
        var bugunKayit = await db.Kullanicilar.CountAsync(
            x => x.KayitTarihi >= bugun, cancellationToken);
        var yediGunKayit = await db.Kullanicilar.CountAsync(
            x => x.KayitTarihi >= sonYediGun, cancellationToken);
        var otuzGunKayit = await db.Kullanicilar.CountAsync(
            x => x.KayitTarihi >= sonOtuzGun, cancellationToken);
        var yediGunAktif = await db.Kullanicilar.CountAsync(
            x => x.SonGorulmeTarihi >= sonYediGun, cancellationToken);
        var otuzGunAktif = await db.Kullanicilar.CountAsync(
            x => x.SonGorulmeTarihi >= sonOtuzGun, cancellationToken);
        var engellenen = await db.Kullanicilar.CountAsync(
            x => x.EngellendiMi, cancellationToken);

        return
            "👥 KULLANICI İSTATİSTİKLERİ\n\n" +
            $"Toplam: {toplam:N0}\n" +
            $"Bugün kayıt: {bugunKayit:N0}\n" +
            $"Son 7 gün kayıt: {yediGunKayit:N0}\n" +
            $"Son 30 gün kayıt: {otuzGunKayit:N0}\n\n" +
            $"Son 7 gün aktif: {yediGunAktif:N0}\n" +
            $"Son 30 gün aktif: {otuzGunAktif:N0}\n" +
            $"Engellenen: {engellenen:N0}";
    }

    private static async Task<string> VipIstatistikMetniAsync(
        FEMEliteAnalysis.Api.Data.FemDbContext db,
        CancellationToken cancellationToken)
    {
        var simdi = DateTime.UtcNow;
        var yediGunSonra = simdi.AddDays(7);
        var sonOtuzGun = simdi.AddDays(-30);
        var aktifDurum = FEMEliteAnalysis.Api.Enums.UyelikDurumu.Aktif;

        var aktif = await db.Uyelikler
            .Where(x => x.Durum == aktifDurum && x.BitisTarihi > simdi)
            .Select(x => x.KullaniciId)
            .Distinct()
            .CountAsync(cancellationToken);
        var yediGundeBitecek = await db.Uyelikler.CountAsync(
            x => x.Durum == aktifDurum &&
                 x.BitisTarihi > simdi &&
                 x.BitisTarihi <= yediGunSonra,
            cancellationToken);
        var sonOtuzGunEklenen = await db.Uyelikler.CountAsync(
            x => x.OlusturmaTarihi >= sonOtuzGun, cancellationToken);
        var suresiDolan = await db.Uyelikler.CountAsync(
            x => x.Durum == FEMEliteAnalysis.Api.Enums.UyelikDurumu.SuresiDoldu,
            cancellationToken);
        var iptal = await db.Uyelikler.CountAsync(
            x => x.Durum == FEMEliteAnalysis.Api.Enums.UyelikDurumu.IptalEdildi,
            cancellationToken);
        var toplamKullanici = await db.Kullanicilar.CountAsync(cancellationToken);
        var donusum = toplamKullanici == 0 ? 0 : aktif * 100.0 / toplamKullanici;

        return
            "💎 VIP İSTATİSTİKLERİ\n\n" +
            $"Aktif VIP: {aktif:N0}\n" +
            $"VIP dönüşüm oranı: %{donusum:F1}\n" +
            $"7 gün içinde bitecek: {yediGundeBitecek:N0}\n" +
            $"Son 30 gün eklenen üyelik: {sonOtuzGunEklenen:N0}\n" +
            $"Süresi dolan: {suresiDolan:N0}\n" +
            $"İptal edilen: {iptal:N0}";
    }

    private static async Task<string> AnalizIstatistikMetniAsync(
        FEMEliteAnalysis.Api.Data.FemDbContext db,
        CancellationToken cancellationToken)
    {
        var sonYediGun = DateTime.UtcNow.AddDays(-7);
        var toplam = await db.Analizler.CountAsync(cancellationToken);
        var sonYediGunToplam = await db.Analizler.CountAsync(
            x => x.OlusturmaTarihi >= sonYediGun, cancellationToken);
        var yayinlanan = await db.Analizler.CountAsync(
            x => x.Durum == FEMEliteAnalysis.Api.Enums.AnalizDurumu.Yayinlandi ||
                 x.Durum == FEMEliteAnalysis.Api.Enums.AnalizDurumu.Sonuclandi,
            cancellationToken);
        var basarili = await db.Analizler.CountAsync(
            x => x.Sonuc == FEMEliteAnalysis.Api.Enums.AnalizSonucu.Basarili,
            cancellationToken);
        var basarisiz = await db.Analizler.CountAsync(
            x => x.Sonuc == FEMEliteAnalysis.Api.Enums.AnalizSonucu.Basarisiz,
            cancellationToken);
        var ortalamaGuven = await db.Analizler
            .Select(x => (double?)x.GuvenPuani)
            .AverageAsync(cancellationToken) ?? 0;
        var kupon = await db.Kuponlar.CountAsync(cancellationToken);
        var yayinlananKupon = await db.Kuponlar.CountAsync(
            x => x.YayinlanmaTarihi.HasValue, cancellationToken);
        var sonuclanan = basarili + basarisiz;
        var basariOrani = sonuclanan == 0 ? 0 : basarili * 100.0 / sonuclanan;

        return
            "🎯 ANALİZ & KUPON İSTATİSTİKLERİ\n\n" +
            $"Toplam analiz: {toplam:N0}\n" +
            $"Son 7 gün analiz: {sonYediGunToplam:N0}\n" +
            $"Yayınlanan/sonuçlanan: {yayinlanan:N0}\n" +
            $"Ortalama güven: %{ortalamaGuven:F1}\n\n" +
            $"Başarılı: {basarili:N0}\n" +
            $"Başarısız: {basarisiz:N0}\n" +
            $"Başarı oranı: %{basariOrani:F1}\n\n" +
            $"Toplam kupon: {kupon:N0}\n" +
            $"Yayınlanan kupon: {yayinlananKupon:N0}";
    }

    private static async Task<string> VeriIstatistikMetniAsync(
        FEMEliteAnalysis.Api.Data.FemDbContext db,
        CancellationToken cancellationToken)
    {
        var simdi = DateTime.UtcNow;
        var sonYediGun = simdi.AddDays(-7);

        var lig = await db.Ligler.CountAsync(cancellationToken);
        var takim = await db.Takimlar.CountAsync(cancellationToken);
        var mac = await db.Maclar.CountAsync(cancellationToken);
        var gelecekMac = await db.Maclar.CountAsync(
            x => x.MacTarihi >= simdi, cancellationToken);
        var istatistik = await db.MacIstatistikleri.CountAsync(cancellationToken);
        var sonYediGunSync = await db.ApiSenkronizasyonLoglari.CountAsync(
            x => x.BaslangicTarihi >= sonYediGun, cancellationToken);
        var basarisizSync = await db.ApiSenkronizasyonLoglari.CountAsync(
            x => x.BaslangicTarihi >= sonYediGun && !x.BasariliMi,
            cancellationToken);
        var sonSync = await db.ApiSenkronizasyonLoglari
            .AsNoTracking()
            .OrderByDescending(x => x.BitisTarihi)
            .Select(x => new { x.Kaynak, x.BasariliMi, x.BitisTarihi })
            .FirstOrDefaultAsync(cancellationToken);

        var sonSyncMetni = sonSync is null
            ? "Kayıt yok"
            : $"{sonSync.Kaynak} · {(sonSync.BasariliMi ? "Başarılı" : "Hatalı")} · {sonSync.BitisTarihi.ToLocalTime():dd.MM HH:mm}";

        return
            "🗄 VERİ İSTATİSTİKLERİ\n\n" +
            $"Lig: {lig:N0}\n" +
            $"Takım: {takim:N0}\n" +
            $"Toplam maç: {mac:N0}\n" +
            $"Gelecek maç: {gelecekMac:N0}\n" +
            $"Maç istatistik kaydı: {istatistik:N0}\n\n" +
            $"Son 7 gün senkronizasyon: {sonYediGunSync:N0}\n" +
            $"Son 7 gün hatalı senkronizasyon: {basarisizSync:N0}\n" +
            $"Son senkronizasyon: {sonSyncMetni}";
    }

    private async Task AyarlarMenusuGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var ayarlar = await db.Ayarlar
            .AsNoTracking()
            .OrderBy(x => x.Id)
            .ToListAsync(cancellationToken);

        var telegramDurumu = string.IsNullOrWhiteSpace(_telegramOptions.BotToken)
            ? "❌ Token yok"
            : "✅ Bağlı";
        var kanalDurumu = _telegramOptions.VipChannelId.HasValue ||
                          _telegramOptions.FreeChannelId.HasValue
            ? "✅ Tanımlı"
            : "➖ Tanımlı değil";

        var metin =
            "⚙️ AYARLAR\n\n" +
            $"Telegram botu: {telegramDurumu}\n" +
            $"Kanal ayarı: {kanalDurumu}\n" +
            $"Global admin sayısı: {_telegramOptions.AdminUserIds.Count + (_telegramOptions.AdminUserId > 0 ? 1 : 0)}\n" +
            $"Veritabanı ayarı: {ayarlar.Count}\n\n" +
            "Detayını görmek veya düzenleme komutunu almak için bir ayar seçin.";

        var tuslar = ayarlar
            .Select(x => (x.Id, Etiket: AyarEtiketi(x.Anahtar)))
            .ToList();

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminSettingsKeyboard.Menu(tuslar),
            cancellationToken);
    }

    private async Task AyarDetayiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!int.TryParse(callbackData["setting_detail:".Length..], out var ayarId))
            return;

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var ayar = await db.Ayarlar
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == ayarId, cancellationToken);

        if (ayar is null)
        {
            await AyarlarMenusuGosterAsync(
                botClient, chatId, messageId, cancellationToken);
            return;
        }

        var metin =
            $"⚙️ {AyarEtiketi(ayar.Anahtar)}\n\n" +
            $"Anahtar: {ayar.Anahtar}\n" +
            $"Mevcut değer: {ayar.Deger}\n" +
            $"Açıklama: {ayar.Aciklama ?? "Yok"}\n" +
            $"Son güncelleme: {ayar.GuncellemeTarihi.ToLocalTime():dd.MM.yyyy HH:mm}\n\n" +
            "Değiştirmek için:\n" +
            $"/ayarla {ayar.Anahtar} YENİ_DEĞER";

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminSettingsKeyboard.Detay(),
            cancellationToken);
    }

    private async Task LogMenusuGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var son24Saat = DateTime.UtcNow.AddHours(-24);

        var toplam = await db.BotLoglari.CountAsync(cancellationToken);
        var bugun = await db.BotLoglari.CountAsync(
            x => x.KayitTarihi >= son24Saat, cancellationToken);
        var hatalar = await db.BotLoglari.CountAsync(
            x => x.LogSeviyesi == "Error", cancellationToken);
        var benzersizKullanici = await db.BotLoglari
            .Where(x => x.KayitTarihi >= son24Saat && x.TelegramKullaniciId.HasValue)
            .Select(x => x.TelegramKullaniciId)
            .Distinct()
            .CountAsync(cancellationToken);

        var metin =
            "📜 SİSTEM LOGLARI\n\n" +
            $"Toplam kayıt: {toplam}\n" +
            $"Son 24 saat: {bugun}\n" +
            $"Son 24 saat kullanıcı: {benzersizKullanici}\n" +
            $"Toplam hata: {hatalar}\n\n" +
            "Görüntülemek istediğiniz kayıt türünü seçin.";

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminLogsKeyboard.Menu(),
            cancellationToken);
    }

    private async Task LogListesiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var hatalar = callbackData.StartsWith("logs_errors:", StringComparison.Ordinal);
        var prefix = hatalar ? "logs_errors:" : "logs_recent:";

        if (!int.TryParse(callbackData[prefix.Length..], out var sayfa) || sayfa < 0)
            sayfa = 0;

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var sorgu = db.BotLoglari.AsNoTracking();

        if (hatalar)
            sorgu = sorgu.Where(x => x.LogSeviyesi == "Error");

        var toplam = await sorgu.CountAsync(cancellationToken);
        var toplamSayfa = Math.Max(1, (int)Math.Ceiling(toplam / (double)LogSayfaBoyutu));
        sayfa = Math.Min(sayfa, toplamSayfa - 1);

        var loglar = await sorgu
            .OrderByDescending(x => x.KayitTarihi)
            .Skip(sayfa * LogSayfaBoyutu)
            .Take(LogSayfaBoyutu)
            .ToListAsync(cancellationToken);

        var metin = new StringBuilder()
            .AppendLine(hatalar ? "❌ HATA KAYITLARI" : "📋 SON SİSTEM KAYITLARI")
            .AppendLine()
            .AppendLine($"Toplam: {toplam} | Sayfa: {sayfa + 1}/{toplamSayfa}")
            .AppendLine();

        if (loglar.Count == 0)
        {
            metin.AppendLine("Kayıt bulunamadı.");
        }
        else
        {
            foreach (var log in loglar)
            {
                var seviye = log.LogSeviyesi == "Error" ? "❌" : "ℹ️";
                var kimlik = log.TelegramKullaniciId?.ToString() ?? "Sistem";
                var detay = (log.Detay ?? string.Empty)
                    .Replace("\r", " ")
                    .Replace("\n", " ");

                if (detay.Length > 140)
                    detay = detay[..140] + "…";

                metin
                    .AppendLine($"{seviye} {log.KayitTarihi.ToLocalTime():dd.MM HH:mm:ss}")
                    .AppendLine($"Kullanıcı: {kimlik}")
                    .AppendLine($"İşlem: {log.Komut ?? "-"}")
                    .AppendLine($"Detay: {(string.IsNullOrWhiteSpace(detay) ? "-" : detay)}")
                    .AppendLine("──────────");
            }
        }

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin.ToString(),
            AdminLogsKeyboard.Liste(
                sayfa,
                sayfa > 0,
                sayfa + 1 < toplamSayfa,
                hatalar),
            cancellationToken);
    }

    private async Task CallbackLoguKaydetAsync(
        long telegramKullaniciId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
            var kullaniciId = await db.Kullanicilar
                .Where(x => x.TelegramKullaniciId == telegramKullaniciId)
                .Select(x => (int?)x.Id)
                .FirstOrDefaultAsync(cancellationToken);

            db.BotLoglari.Add(new FEMEliteAnalysis.Api.Models.BotLogu
            {
                KullaniciId = kullaniciId,
                TelegramKullaniciId = telegramKullaniciId,
                Komut = "CALLBACK",
                Detay = callbackData.Length > 1000 ? callbackData[..1000] : callbackData,
                LogSeviyesi = "Information",
                KayitTarihi = DateTime.UtcNow
            });

            await db.SaveChangesAsync(cancellationToken);
        }
        catch (Exception exception)
        {
            _logger.LogWarning(
                exception,
                "Callback veritabanı logu yazılamadı.");
        }
    }

    private static string AyarEtiketi(string anahtar)
    {
        return anahtar switch
        {
            "UygulamaAdi" => "🏷 Uygulama Adı",
            "VarsayilanUyelikGunu" => "📅 Varsayılan Üyelik Günü",
            "AnalizUyarisi" => "⚠️ Analiz Uyarısı",
            "VarsayilanDil" => "🌐 Varsayılan Dil",
            _ => $"⚙️ {anahtar}"
        };
    }

    private async Task KullaniciYonetimMenusuGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var simdi = DateTime.UtcNow;
        var sonYediGun = simdi.AddDays(-7);

        var toplam = await db.Kullanicilar.CountAsync(cancellationToken);
        var aktif = await db.Kullanicilar.CountAsync(
            x => x.SonGorulmeTarihi >= sonYediGun, cancellationToken);
        var engellenen = await db.Kullanicilar.CountAsync(
            x => x.EngellendiMi, cancellationToken);
        var vip = await db.Uyelikler
            .Where(x =>
                x.Durum == FEMEliteAnalysis.Api.Enums.UyelikDurumu.Aktif &&
                x.BitisTarihi > simdi)
            .Select(x => x.KullaniciId)
            .Distinct()
            .CountAsync(cancellationToken);

        var metin =
            "👥 KULLANICI YÖNETİMİ\n\n" +
            $"Toplam kullanıcı: {toplam}\n" +
            $"Son 7 günde aktif: {aktif}\n" +
            $"Aktif VIP: {vip}\n" +
            $"Engellenen: {engellenen}\n\n" +
            "Bir işlem seçin.";

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminUsersKeyboard.Menu(),
            cancellationToken);
    }

    private async Task KullaniciListesiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var engellenenler = callbackData.StartsWith("users_blocked:", StringComparison.Ordinal);
        var prefix = engellenenler ? "users_blocked:" : "users_page:";

        if (!int.TryParse(callbackData[prefix.Length..], out var sayfa) || sayfa < 0)
            sayfa = 0;

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var sorgu = db.Kullanicilar.AsNoTracking();

        if (engellenenler)
            sorgu = sorgu.Where(x => x.EngellendiMi);

        var toplam = await sorgu.CountAsync(cancellationToken);
        var toplamSayfa = Math.Max(1, (int)Math.Ceiling(toplam / (double)KullaniciSayfaBoyutu));
        sayfa = Math.Min(sayfa, toplamSayfa - 1);

        var kullanicilar = await sorgu
            .OrderByDescending(x => x.SonGorulmeTarihi ?? x.KayitTarihi)
            .Skip(sayfa * KullaniciSayfaBoyutu)
            .Take(KullaniciSayfaBoyutu)
            .Select(x => new
            {
                x.Id,
                x.KullaniciAdi,
                x.Ad,
                x.Soyad,
                x.TelegramKullaniciId,
                x.EngellendiMi
            })
            .ToListAsync(cancellationToken);

        var tuslar = kullanicilar
            .Select(x =>
            {
                var ad = $"{x.Ad} {x.Soyad}".Trim();
                var etiket = !string.IsNullOrWhiteSpace(x.KullaniciAdi)
                    ? $"@{x.KullaniciAdi}"
                    : !string.IsNullOrWhiteSpace(ad)
                        ? ad
                        : x.TelegramKullaniciId.ToString();

                if (x.EngellendiMi)
                    etiket = $"🚫 {etiket}";

                return (x.Id, Etiket: etiket.Length > 40 ? etiket[..40] : etiket);
            })
            .ToList();

        var baslik = engellenenler ? "🚫 ENGELLENEN KULLANICILAR" : "👥 SON KULLANICILAR";
        var metin = toplam == 0
            ? $"{baslik}\n\nKayıt bulunamadı."
            : $"{baslik}\n\nToplam: {toplam}\nSayfa: {sayfa + 1}/{toplamSayfa}\n\nDetay için kullanıcı seçin.";

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminUsersKeyboard.Liste(
                tuslar,
                sayfa,
                sayfa > 0,
                sayfa + 1 < toplamSayfa,
                engellenenler),
            cancellationToken);
    }

    private async Task KullaniciDetayiniGosterAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!KullaniciCallbackVerisiniOku(
                callbackData, "user_detail:", out var kullaniciId, out var sayfa, out var engellenenler))
            return;

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var kullanici = await db.Kullanicilar
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == kullaniciId, cancellationToken);

        if (kullanici is null)
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                "Kullanıcı bulunamadı.",
                AdminUsersKeyboard.Menu(),
                cancellationToken);
            return;
        }

        var simdi = DateTime.UtcNow;
        var vipBitis = await db.Uyelikler
            .AsNoTracking()
            .Where(x =>
                x.KullaniciId == kullanici.Id &&
                x.Durum == FEMEliteAnalysis.Api.Enums.UyelikDurumu.Aktif &&
                x.BitisTarihi > simdi)
            .OrderByDescending(x => x.BitisTarihi)
            .Select(x => (DateTime?)x.BitisTarihi)
            .FirstOrDefaultAsync(cancellationToken);

        var adSoyad = $"{kullanici.Ad} {kullanici.Soyad}".Trim();
        var kullaniciAdi = string.IsNullOrWhiteSpace(kullanici.KullaniciAdi)
            ? "Yok"
            : $"@{kullanici.KullaniciAdi}";

        var metin = new StringBuilder()
            .AppendLine("👤 KULLANICI DETAYI")
            .AppendLine()
            .AppendLine($"Ad soyad: {(string.IsNullOrWhiteSpace(adSoyad) ? "Yok" : adSoyad)}")
            .AppendLine($"Kullanıcı adı: {kullaniciAdi}")
            .AppendLine($"Telegram ID: {kullanici.TelegramKullaniciId}")
            .AppendLine($"Kayıt: {kullanici.KayitTarihi.ToLocalTime():dd.MM.yyyy HH:mm}")
            .AppendLine($"Son görülme: {(kullanici.SonGorulmeTarihi.HasValue ? kullanici.SonGorulmeTarihi.Value.ToLocalTime().ToString("dd.MM.yyyy HH:mm") : "Yok")}")
            .AppendLine($"VIP: {(vipBitis.HasValue ? $"Aktif ({vipBitis.Value.ToLocalTime():dd.MM.yyyy HH:mm})" : "Aktif değil")}")
            .AppendLine($"Global admin: {(AdminMi(kullanici.TelegramKullaniciId) ? "Evet" : "Hayır")}")
            .AppendLine($"Durum: {(kullanici.EngellendiMi ? "🚫 Engelli" : "✅ Aktif")}")
            .ToString();

        await MenuyuGuncelleAsync(
            botClient,
            chatId,
            messageId,
            metin,
            AdminUsersKeyboard.Detay(kullanici.Id, kullanici.EngellendiMi, sayfa, engellenenler),
            cancellationToken);
    }

    private async Task KullaniciEngeliniDegistirAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        long islemiYapanTelegramId,
        string callbackData,
        CancellationToken cancellationToken)
    {
        if (!KullaniciCallbackVerisiniOku(
                callbackData, "user_toggle_block:", out var kullaniciId, out var sayfa, out var engellenenler))
            return;

        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var kullanici = await db.Kullanicilar
            .FirstOrDefaultAsync(x => x.Id == kullaniciId, cancellationToken);

        if (kullanici is null)
            return;

        if (kullanici.TelegramKullaniciId == islemiYapanTelegramId ||
            AdminMi(kullanici.TelegramKullaniciId))
        {
            await MenuyuGuncelleAsync(
                botClient,
                chatId,
                messageId,
                "⛔ Admin kullanıcılar engellenemez.",
                AdminUsersKeyboard.Detay(kullanici.Id, kullanici.EngellendiMi, sayfa, engellenenler),
                cancellationToken);
            return;
        }

        kullanici.EngellendiMi = !kullanici.EngellendiMi;
        await db.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Kullanıcı engel durumu değiştirildi. KullaniciId: {KullaniciId}, EngellendiMi: {EngellendiMi}, AdminId: {AdminId}",
            kullanici.Id,
            kullanici.EngellendiMi,
            islemiYapanTelegramId);

        await KullaniciDetayiniGosterAsync(
            botClient,
            chatId,
            messageId,
            $"user_detail:{kullanici.Id}:{sayfa}:{(engellenenler ? 1 : 0)}",
            cancellationToken);
    }

    private static bool KullaniciCallbackVerisiniOku(
        string callbackData,
        string prefix,
        out int kullaniciId,
        out int sayfa,
        out bool engellenenler)
    {
        kullaniciId = 0;
        sayfa = 0;
        engellenenler = false;

        if (!callbackData.StartsWith(prefix, StringComparison.Ordinal))
            return false;

        var parcalar = callbackData[prefix.Length..].Split(':');

        if (parcalar.Length != 3 ||
            !int.TryParse(parcalar[0], out kullaniciId) ||
            !int.TryParse(parcalar[1], out sayfa) ||
            !int.TryParse(parcalar[2], out var engelliListe) ||
            engelliListe is < 0 or > 1)
        {
            return false;
        }

        engellenenler = engelliListe == 1;
        return true;
    }

    private async Task HandleJoinVerificationCallbackAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var parts = callbackData.Split(':', 2, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 2 || !long.TryParse(parts[1], out var verificationId))
        {
            await botClient.AnswerCallbackQuery(
                callbackQuery.Id,
                text: "Geçersiz doğrulama isteği.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        using var scope = _scopeFactory.CreateScope();
        var service = scope.ServiceProvider.GetRequiredService<TelegramJoinVerificationService>();

        string result;
        if (parts[0].Equals("joinapprove", StringComparison.Ordinal))
        {
            result = await service.ApproveAsync(botClient, verificationId, callbackQuery.From.Id, cancellationToken);
        }
        else if (parts[0].Equals("joinreject", StringComparison.Ordinal))
        {
            result = await service.RejectAsync(botClient, verificationId, callbackQuery.From.Id, cancellationToken);
        }
        else
        {
            result = await service.RequestNewScreenshotAsync(botClient, verificationId, callbackQuery.From.Id, cancellationToken);
        }

        if (callbackQuery.Message is not null)
        {
            await botClient.EditMessageText(
                chatId: callbackQuery.Message.Chat.Id,
                messageId: callbackQuery.Message.MessageId,
                text: result,
                replyMarkup: null,
                cancellationToken: cancellationToken);
        }

        await botClient.AnswerCallbackQuery(
            callbackQuery.Id,
            text: "İşlem tamamlandı.",
            cancellationToken: cancellationToken);
    }

    private async Task HandleJoinAnnouncementCallbackAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        string callbackData,
        CancellationToken cancellationToken)
    {
        var target = callbackData.Split(':', 2).ElementAtOrDefault(1)?.ToLowerInvariant();
        ChatId? targetChatId = target switch
        {
            "free" when _telegramOptions.FreeChannelId.HasValue => new ChatId(_telegramOptions.FreeChannelId.Value),
            "vip" when _telegramOptions.VipChannelId.HasValue => new ChatId(_telegramOptions.VipChannelId.Value),
            "bayi" when !string.IsNullOrWhiteSpace(_telegramOptions.BayiChannelUsername) => new ChatId(_telegramOptions.BayiChannelUsername),
            _ => null
        };

        var targetName = target switch
        {
            "vip" => "VIP Kanal",
            "bayi" => "Bayi / Katılım Kanalı",
            _ => "Ücretsiz Kanal"
        };
        if (targetChatId is null)
        {
            await botClient.AnswerCallbackQuery(callbackQuery.Id, text: "Seçilen kanal ayarlarda tanımlı değil.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        const string announcement =
            "🔐 FEM ELITE ÜCRETSİZ GRUP KATILIMI\n\n" +
            "FEM Elite topluluğunda günlük futbol analizleri ve istatistiksel maç değerlendirmeleri paylaşılır.\n\n" +
            "✅ Üyelik ücreti yoktur.\n" +
            "📌 Katılım şartı: 303037 bayi doğrulaması.\n\n" +
            "Bayi geçişini tamamladıktan sonra aşağıdaki butondan doğrulamayı başlat. Doğrulama onaylandığında bot sana özel grup davet bağlantını gönderir.\n\n" +
            "⚠️ Bahis finansal risk içerir. Analizler kesin sonuç veya kazanç garantisi değildir.";

        var keyboard = new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithUrl("🤖 DOĞRULAMAYI BAŞLAT", "https://t.me/FEMEliteAnalysisBot?start=katilim") }
        });

        try
        {
            await botClient.SendMessage(chatId: targetChatId, text: announcement, replyMarkup: keyboard, cancellationToken: cancellationToken);
            await botClient.AnswerCallbackQuery(callbackQuery.Id, text: $"Duyuru {targetName} kanalına gönderildi.", cancellationToken: cancellationToken);

            if (callbackQuery.Message is not null)
            {
                await botClient.EditMessageText(
                    chatId: callbackQuery.Message.Chat.Id,
                    messageId: callbackQuery.Message.MessageId,
                    text: $"✅ Katılım duyurusu gönderildi.\n📍 Hedef: {targetName}\n🆔 Hedef: {targetChatId}",
                    cancellationToken: cancellationToken);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Katılım duyurusu gönderilemedi. Hedef: {TargetChatId}", targetChatId);
            await botClient.AnswerCallbackQuery(callbackQuery.Id, text: "Duyuru gönderilemedi. Botun hedef kanalda admin olduğundan emin ol.", showAlert: true, cancellationToken: cancellationToken);
        }
    }

    private bool AdminMi(long userId)
    {
        return (_telegramOptions.AdminUserId > 0 && _telegramOptions.AdminUserId == userId) ||
               _telegramOptions.AdminUserIds.Contains(userId);
    }

    private async Task AnalizTahminYardimiGosterAsync(ITelegramBotClient bot,long chatId,int messageId,string data,CancellationToken ct)
    {
        if(!CallbackIdOku(data,"analysis_prediction_help:",out var id)) return;
        await MenuyuGuncelleAsync(bot,chatId,messageId,$"✍️ TAHMİN EKLEME\n\nKomut:\n/tahmin {id} TAHMIN_METNI\n\nÖrnek:\n/tahmin {id} MS1 + 1.5 ÜST",AnalizDuzenlemeKeyboard.TaslakMenu(id),ct);
    }

    private async Task AnalizOlusturButonuAsync(ITelegramBotClient bot,long chatId,int messageId,string data,CancellationToken ct)
    {
        var prefix=data.StartsWith("analysis_generate:",StringComparison.Ordinal)?"analysis_generate:":"analysis_regenerate:";
        if(!CallbackIdOku(data,prefix,out var macId)) return;
        await bot.EditMessageText(chatId,messageId,"⏳ 20 maçlık geniş analiz hazırlanıyor...",cancellationToken:ct);
        using var scope=_scopeFactory.CreateScope();
        var svc=scope.ServiceProvider.GetRequiredService<IAnalizService>();
        var r=await svc.AnalizOlusturAsync(new FEMEliteAnalysis.Api.Dtos.Analiz.AnalizOlusturRequest{MacId=macId,AnalizTuru="FEM Geniş Analiz",KullaniciTahmini=string.Empty},ct);
        if(!r.Basarili){await MenuyuGuncelleAsync(bot,chatId,messageId,"❌ "+r.Mesaj,MacAnalizKeyboard.SecilenMac(macId),ct);return;}
        await KayitliAnaliziGosterAsync(bot,chatId,messageId,$"analysis_show:{macId}",ct);
    }

    private async Task KayitliAnaliziGosterAsync(ITelegramBotClient bot,long chatId,int messageId,string data,CancellationToken ct)
    {
        if(!CallbackIdOku(data,"analysis_show:",out var macId)) return;
        using var scope=_scopeFactory.CreateScope();
        var db=scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Data.FemDbContext>();
        var a=await Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.FirstOrDefaultAsync(
            db.Analizler.AsNoTracking().Where(x=>x.MacId==macId).OrderByDescending(x=>x.OlusturmaTarihi),ct);
        if(a is null){await MenuyuGuncelleAsync(bot,chatId,messageId,"Bu maç için kayıtlı analiz bulunamadı.",MacAnalizKeyboard.SecilenMac(macId),ct);return;}
        await MenuyuGuncelleAsync(bot,chatId,messageId,"🤖 KAYITLI ANALİZ\n\n"+a.YapayZekaAnalizi,MacAnalizKeyboard.AnalizSonucu(macId,a.Id),ct);
    }

    private static bool CallbackIdOku(
        string callbackData,
        string prefix,
        out int id)
    {
        id = 0;

        return callbackData.StartsWith(
                   prefix,
                   StringComparison.Ordinal) &&
               int.TryParse(
                   callbackData[prefix.Length..],
                   out id);
    }

    private static Task CallbackCevaplaAsync(
        ITelegramBotClient botClient,
        string callbackId,
        CancellationToken cancellationToken)
    {
        return botClient.AnswerCallbackQuery(
            callbackId,
            cancellationToken: cancellationToken);
    }

    private static Task MenuyuGuncelleAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId,
        string text,
        InlineKeyboardMarkup keyboard,
        CancellationToken cancellationToken)
    {
        return botClient.EditMessageText(
            chatId: chatId,
            messageId: messageId,
            text: MesajiSinirla(text),
            replyMarkup: keyboard,
            cancellationToken: cancellationToken);
    }

    private static InlineKeyboardMarkup AdminGeriDonKeyboard()
    {
        return new InlineKeyboardMarkup(
            InlineKeyboardButton.WithCallbackData(
                "⬅️ Admin Menüsüne Dön",
                "admin_main"));
    }

    private static InlineKeyboardMarkup VipGeriDonKeyboard()
    {
        return new InlineKeyboardMarkup(
            InlineKeyboardButton.WithCallbackData(
                "⬅️ VIP Menüsüne Dön",
                "vip_main"));
    }

    private static InlineKeyboardMarkup MacTarihGeriDonKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "🔄 Yenile",
                    "match_today_tomorrow")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "⬅️ Tarih Menüsüne Dön",
                    "match_date_menu")
            }
        });
    }

    private static DateOnly BugununTarihi()
    {
        return DateOnly.FromDateTime(
            TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                DateTime.UtcNow,
                "Turkey Standard Time"));
    }

    private static DateOnly IstanbulTarihi(DateTime utcTarih)
    {
        return DateOnly.FromDateTime(IstanbulSaati(utcTarih));
    }

    private static DateTime IstanbulSaati(DateTime utcTarih)
    {
        var tarih = utcTarih.Kind == DateTimeKind.Utc
            ? utcTarih
            : DateTime.SpecifyKind(utcTarih, DateTimeKind.Utc);

        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
            tarih,
            "Turkey Standard Time");
    }

    private static string MesajiSinirla(string text)
    {
        if (text.Length <= TelegramMesajLimiti)
            return text;

        return text[..(TelegramMesajLimiti - 50)] +
               "\n\n⚠️ Mesaj uzun olduğu için kısaltıldı.";
    }
}
