using FEMEliteAnalysis.Api.Common.Constants;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public sealed class TelegramLigCommandHandler
{
    public async Task<bool> TryHandleAsync(ITelegramBotClient botClient, Message message, string text, IServiceProvider services, bool adminMi, CancellationToken cancellationToken)
    {
        if (!text.StartsWith(BotKomutlari.LigAra, StringComparison.OrdinalIgnoreCase) &&
            !text.StartsWith(BotKomutlari.SyncLig, StringComparison.OrdinalIgnoreCase))
            return false;

        if (!adminMi)
        {
            await botClient.SendMessage(message.Chat.Id, "⛔ Bu komut yalnızca adminler içindir.", cancellationToken: cancellationToken);
            return true;
        }

        var service = services.GetRequiredService<ILigYonetimService>();
        var parts = text.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        if (text.StartsWith(BotKomutlari.LigAra, StringComparison.OrdinalIgnoreCase))
        {
            if (parts.Length < 2)
            {
                await botClient.SendMessage(message.Chat.Id, "Kullanım: /ligara Premier League", cancellationToken: cancellationToken);
                return true;
            }

            var result = await service.LigAraAsync(string.Join(' ', parts.Skip(1)), cancellationToken);
            if (!result.Basarili || result.Veri is null)
            {
                await botClient.SendMessage(message.Chat.Id, $"❌ {result.Mesaj}", cancellationToken: cancellationToken);
                return true;
            }

            var lines = result.Veri.Take(15).Select(x =>
                $"• {x.Ad} ({x.Ulke})\n  ID: {x.LigId} | {x.Tur}\n  Son sezonlar: {string.Join(", ", x.Sezonlar.Take(5))}");
            await botClient.SendMessage(message.Chat.Id, "🔎 LİG SONUÇLARI\n\n" + string.Join("\n\n", lines), cancellationToken: cancellationToken);
            return true;
        }

        if (parts.Length < 2 || !int.TryParse(parts[1], out var ligId))
        {
            await botClient.SendMessage(message.Chat.Id, "Kullanım: /synclig LIG_ID [sezon_sayisi]\nÖrnek: /synclig 4328 3", cancellationToken: cancellationToken);
            return true;
        }

        var seasonCount = parts.Length >= 3 && int.TryParse(parts[2], out var parsed) ? parsed : 3;
        await botClient.SendMessage(message.Chat.Id, $"⏳ TheSportsDB lig {ligId} için son {Math.Clamp(seasonCount, 1, 5)} sezon senkronize ediliyor...", cancellationToken: cancellationToken);
        var sync = await service.LigSenkronizeEtAsync(ligId, seasonCount, cancellationToken);
        if (!sync.Basarili || sync.Veri is null)
        {
            await botClient.SendMessage(message.Chat.Id, $"❌ {sync.Mesaj}", cancellationToken: cancellationToken);
            return true;
        }

        var x = sync.Veri;
        await botClient.SendMessage(message.Chat.Id,
            $"✅ LİG SENKRONİZASYONU TAMAMLANDI\n\n" +
            $"Lig: {x.LigAdi} ({x.LigId})\n" +
            $"Sezonlar: {string.Join(", ", x.Sezonlar)}\n" +
            $"Gelen maç: {x.GelenMacSayisi}\n" +
            $"Eklenen maç: {x.EklenenMacSayisi}\n" +
            $"Güncellenen maç: {x.GuncellenenMacSayisi}\n" +
            $"Eklenen takım: {x.EklenenTakimSayisi}",
            cancellationToken: cancellationToken);
        return true;
    }
}
