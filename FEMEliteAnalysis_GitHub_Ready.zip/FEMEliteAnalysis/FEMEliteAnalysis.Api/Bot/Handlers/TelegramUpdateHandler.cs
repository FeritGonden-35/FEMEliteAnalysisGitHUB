using System.Text.Json;
using FEMEliteAnalysis.Api.Bot.Keyboards;
using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Uyelik;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramUpdateHandler
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly TelegramCallbackHandler _callbackHandler;
    private readonly TelegramOptions _telegramOptions;
    private readonly ILogger<TelegramUpdateHandler> _logger;
    private readonly TelegramDebugCommandHandler _debugCommandHandler;
    private readonly TelegramKuponCommandHandler _kuponCommandHandler;
    private readonly TelegramModerasyonCommandHandler _moderasyonCommandHandler;
    private readonly TelegramUygunMacCommandHandler _uygunMacCommandHandler;
    private readonly TelegramHistoricalCommandHandler _historicalCommandHandler;
    private readonly TelegramTeamRepairCommandHandler _teamRepairCommandHandler;
    private readonly TelegramFootballDataCommandHandler _footballDataCommandHandler;
    private readonly TelegramSearchCommandHandler _searchCommandHandler;
    private readonly TelegramLigCommandHandler _ligCommandHandler;

    public TelegramUpdateHandler(
        IServiceScopeFactory scopeFactory,
        TelegramCallbackHandler callbackHandler,
        TelegramDebugCommandHandler debugCommandHandler,
        TelegramKuponCommandHandler kuponCommandHandler,
        TelegramModerasyonCommandHandler moderasyonCommandHandler,
        TelegramUygunMacCommandHandler uygunMacCommandHandler,
        TelegramHistoricalCommandHandler historicalCommandHandler,
        TelegramTeamRepairCommandHandler teamRepairCommandHandler,
        TelegramFootballDataCommandHandler footballDataCommandHandler,
        TelegramSearchCommandHandler searchCommandHandler,
        TelegramLigCommandHandler ligCommandHandler,
        IOptions<TelegramOptions> telegramOptions,
        ILogger<TelegramUpdateHandler> logger)
    {
        _scopeFactory = scopeFactory;
        _callbackHandler = callbackHandler;
        _debugCommandHandler = debugCommandHandler;
        _kuponCommandHandler = kuponCommandHandler;
        _moderasyonCommandHandler = moderasyonCommandHandler;
        _uygunMacCommandHandler = uygunMacCommandHandler;
        _historicalCommandHandler = historicalCommandHandler;
        _teamRepairCommandHandler = teamRepairCommandHandler;
        _footballDataCommandHandler = footballDataCommandHandler;
        _searchCommandHandler = searchCommandHandler;
        _ligCommandHandler = ligCommandHandler;
        _telegramOptions = telegramOptions.Value;
        _logger = logger;
    }

    public async Task HandleUpdateAsync(
        ITelegramBotClient botClient,
        Update update,
        CancellationToken cancellationToken)
    {
        if (update.ChatJoinRequest is not null)
        {
            using var joinScope = _scopeFactory.CreateScope();
            var joinVerificationService = joinScope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Services.TelegramJoinVerificationService>();
            await joinVerificationService.HandleJoinRequestAsync(
                botClient,
                update.ChatJoinRequest,
                cancellationToken);
            return;
        }

        if (update.Type == UpdateType.CallbackQuery &&
            update.CallbackQuery is not null)
        {
            await _callbackHandler.HandleAsync(
                botClient,
                update.CallbackQuery,
                cancellationToken);
            return;
        }

        if (update.Type != UpdateType.Message ||
            update.Message is null ||
            update.Message.From is null)
        {
            return;
        }

        var message = update.Message;
        var user = message.From;
        var text = (message.Text ?? message.Caption ?? string.Empty).Trim();

        var ozelSohbetMi =
            message.Chat.Type == ChatType.Private;

        var komutMu =
            text.StartsWith(
                "/",
                StringComparison.Ordinal);

        using var scope = _scopeFactory.CreateScope();

        var moderasyonService =
            scope.ServiceProvider.GetRequiredService<ModerasyonTelegramService>();

        if (await moderasyonService.MesajiDenetleAsync(
                botClient,
                message,
                cancellationToken))
        {
            return;
        }

        if (ozelSohbetMi && komutMu)
        {
            var commandParts = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var commandName = commandParts.Length > 0
                ? commandParts[0].Split('@', 2, StringSplitOptions.RemoveEmptyEntries)[0]
                : string.Empty;

            var startParameter = commandParts.Length > 1 ? commandParts[1].Trim() : string.Empty;
            if (commandName.Equals("/katil", StringComparison.OrdinalIgnoreCase))
                startParameter = "katilim";

            if ((commandName.Equals("/start", StringComparison.OrdinalIgnoreCase) &&
                 (startParameter.Equals("katilim", StringComparison.OrdinalIgnoreCase) ||
                  startParameter.Equals("join", StringComparison.OrdinalIgnoreCase))) ||
                commandName.Equals("/katil", StringComparison.OrdinalIgnoreCase))
            {
                var joinVerificationService =
                    scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Services.TelegramJoinVerificationService>();

                if (await joinVerificationService.HandleStartAsync(
                        botClient,
                        message,
                        startParameter,
                        cancellationToken))
                {
                    return;
                }
            }
        }

        if (ozelSohbetMi && message.Photo is { Length: > 0 })
        {
            var joinVerificationService =
                scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Services.TelegramJoinVerificationService>();

            if (await joinVerificationService.HandleScreenshotAsync(
                    botClient,
                    message,
                    cancellationToken))
            {
                return;
            }
        }

        if (ozelSohbetMi)
        {
            var joinVerificationService =
                scope.ServiceProvider.GetRequiredService<FEMEliteAnalysis.Api.Services.TelegramJoinVerificationService>();

            if (await joinVerificationService.HandleProfileInputAsync(
                    botClient,
                    message,
                    cancellationToken))
            {
                return;
            }
        }

        if (string.IsNullOrWhiteSpace(text))
        {
            return;
        }

        // Grup ve süper gruplarda bot yalnızca moderasyon yapar.
        // Normal mesajlara cevap vermez ve komutları çalıştırmaz.
        if (!ozelSohbetMi)
        {
            return;
        }

        // Özel sohbette yalnızca Telegram komutlarını işler.
        // Kullanıcı normal metin yazarsa bot sessiz kalır.
        if (!komutMu)
        {
            return;
        }

        var kullaniciService =
            scope.ServiceProvider.GetRequiredService<IKullaniciService>();

        var kullanici = await kullaniciService.KaydetVeyaGuncelleAsync(
            user,
            cancellationToken);

        scope.ServiceProvider.GetRequiredService<FemDbContext>().BotLoglari.Add(
            new BotLogu
            {
                KullaniciId = kullanici.Id,
                TelegramKullaniciId = user.Id,
                Komut = text.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault(),
                Detay = text.Length > 1000 ? text[..1000] : text,
                LogSeviyesi = "Information",
                KayitTarihi = DateTime.UtcNow
            });
        await scope.ServiceProvider.GetRequiredService<FemDbContext>()
            .SaveChangesAsync(cancellationToken);

        if (kullanici.EngellendiMi && !AdminMi(user.Id))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "⛔ Botu kullanma erişiminiz engellenmiştir.",
                cancellationToken: cancellationToken);
            return;
        }

        // /hedefkupon yalnızca üç mod kabul eder. Sayısal hedef oran girişi tamamen kaldırıldı.
        var komutParcalari = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var anaKomut = komutParcalari.Length > 0
            ? komutParcalari[0].Split('@', 2, StringSplitOptions.RemoveEmptyEntries)[0]
            : string.Empty;

        if (anaKomut.Equals("/katilimduyuru", StringComparison.OrdinalIgnoreCase))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(botClient, message.Chat.Id, cancellationToken);
                return;
            }

            var rows = new List<InlineKeyboardButton[]>();
            if (_telegramOptions.FreeChannelId.HasValue)
                rows.Add([InlineKeyboardButton.WithCallbackData("📢 Ücretsiz Kanal", "joinannounce:free")]);
            if (_telegramOptions.VipChannelId.HasValue)
                rows.Add([InlineKeyboardButton.WithCallbackData("🔒 VIP Kanal", "joinannounce:vip")]);
            if (!string.IsNullOrWhiteSpace(_telegramOptions.BayiChannelUsername))
                rows.Add([InlineKeyboardButton.WithCallbackData("🤝 Bayi / Katılım Kanalı", "joinannounce:bayi")]);

            if (rows.Count == 0)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "❌ Gönderim yapılacak kanal tanımlı değil. Telegram kanal ayarlarını kontrol et.",
                    cancellationToken: cancellationToken);
                return;
            }

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "📣 Katılım duyurusunu hangi kanala göndereyim?",
                replyMarkup: new InlineKeyboardMarkup(rows),
                cancellationToken: cancellationToken);
            return;
        }

        if (anaKomut.Equals(BotKomutlari.HedefKupon, StringComparison.OrdinalIgnoreCase))
        {
            if (!AdminMi(user.Id))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "⛔ Bu kupon komutunu kullanma yetkiniz yok.",
                    cancellationToken: cancellationToken);
                return;
            }

            if (komutParcalari.Length != 2)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Kullanım:\n/hedefkupon dusuk\n/hedefkupon orta\n/hedefkupon yuksek",
                    cancellationToken: cancellationToken);
                return;
            }

            var mod = komutParcalari[1].Trim().ToLowerInvariant();
            var hedefKuponService = scope.ServiceProvider.GetRequiredService<HedefKuponTelegramService>();

            if (mod is "dusuk" or "düşük")
            {
                await hedefKuponService.DusukOlusturAsync(
                    botClient, message.Chat.Id, user.Id, cancellationToken);
                return;
            }

            if (mod == "orta")
            {
                await hedefKuponService.OrtaOlusturAsync(
                    botClient, message.Chat.Id, user.Id, cancellationToken);
                return;
            }

            if (mod is "yuksek" or "yüksek")
            {
                await hedefKuponService.YuksekOlusturAsync(
                    botClient, message.Chat.Id, cancellationToken);
                return;
            }

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "❌ Geçersiz mod.\n\nKullanım:\n/hedefkupon dusuk\n/hedefkupon orta\n/hedefkupon yuksek",
                cancellationToken: cancellationToken);
            return;
        }


        // Gerçek oran havuzu: yalnız admin, en fazla 5 maç.
        if (anaKomut.Equals(BotKomutlari.OranEkle, StringComparison.OrdinalIgnoreCase) ||
            anaKomut.Equals(BotKomutlari.OranHavuzu, StringComparison.OrdinalIgnoreCase) ||
            anaKomut.Equals(BotKomutlari.OranCikar, StringComparison.OrdinalIgnoreCase) ||
            anaKomut.Equals(BotKomutlari.OranTemizle, StringComparison.OrdinalIgnoreCase) ||
            anaKomut.Equals(BotKomutlari.OranlariCek, StringComparison.OrdinalIgnoreCase))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(botClient, message.Chat.Id, cancellationToken);
                return;
            }

            var havuz = scope.ServiceProvider.GetRequiredService<IOranHavuzuService>();
            var db = scope.ServiceProvider.GetRequiredService<FemDbContext>();

            if (anaKomut.Equals(BotKomutlari.OranEkle, StringComparison.OrdinalIgnoreCase))
            {
                if (komutParcalari.Length != 2 || !int.TryParse(komutParcalari[1], out var oranMacId))
                {
                    await botClient.SendMessage(message.Chat.Id, "Kullanım: /oranekle MAC_ID", cancellationToken: cancellationToken);
                    return;
                }
                var mac = await db.Maclar.AsNoTracking().Include(x => x.EvSahibiTakim).Include(x => x.DeplasmanTakim)
                    .FirstOrDefaultAsync(x => x.Id == oranMacId, cancellationToken);
                if (mac is null)
                {
                    await botClient.SendMessage(message.Chat.Id, "❌ Maç bulunamadı.", cancellationToken: cancellationToken);
                    return;
                }
                var eklendi = havuz.Ekle(user.Id, new FEMEliteAnalysis.Api.Dtos.Oran.OranHavuzuMacDto
                {
                    MacId = mac.Id,
                    EvSahibi = mac.EvSahibiTakim.Ad,
                    Deplasman = mac.DeplasmanTakim.Ad,
                    MacTarihi = mac.MacTarihi
                }, out var havuzMesaj);
                await botClient.SendMessage(message.Chat.Id,
                    $"{(eklendi ? "✅" : "ℹ️")} {havuzMesaj}\n⚽ {mac.EvSahibiTakim.Ad} - {mac.DeplasmanTakim.Ad}\n📦 Havuz: {havuz.Listele(user.Id).Count}/5",
                    cancellationToken: cancellationToken);
                return;
            }

            if (anaKomut.Equals(BotKomutlari.OranCikar, StringComparison.OrdinalIgnoreCase))
            {
                if (komutParcalari.Length != 2 || !int.TryParse(komutParcalari[1], out var silMacId))
                {
                    await botClient.SendMessage(message.Chat.Id, "Kullanım: /orancikar MAC_ID", cancellationToken: cancellationToken);
                    return;
                }
                var silindi = havuz.Cikar(user.Id, silMacId);
                await botClient.SendMessage(message.Chat.Id, silindi ? "✅ Maç oran havuzundan çıkarıldı." : "ℹ️ Maç havuzda yok.", cancellationToken: cancellationToken);
                return;
            }

            if (anaKomut.Equals(BotKomutlari.OranTemizle, StringComparison.OrdinalIgnoreCase))
            {
                havuz.Temizle(user.Id);
                await botClient.SendMessage(message.Chat.Id, "🧹 Oran havuzu temizlendi.", cancellationToken: cancellationToken);
                return;
            }

            if (anaKomut.Equals(BotKomutlari.OranHavuzu, StringComparison.OrdinalIgnoreCase))
            {
                var liste = havuz.Listele(user.Id);
                var txt = liste.Count == 0
                    ? "📦 ORAN HAVUZU boş.\n\n/oranekle MAC_ID ile en fazla 5 maç ekleyebilirsin."
                    : "📦 ORAN HAVUZU\n\n" + string.Join("\n", liste.Select((x, i) => $"{i + 1}️⃣ {x.EvSahibi} - {x.Deplasman} | ID {x.MacId}")) + "\n\n💰 Oranları çek: /oranlaricek";
                await botClient.SendMessage(message.Chat.Id, txt, cancellationToken: cancellationToken);
                return;
            }

            if (anaKomut.Equals(BotKomutlari.OranlariCek, StringComparison.OrdinalIgnoreCase))
            {
                var liste = havuz.Listele(user.Id);
                if (liste.Count == 0)
                {
                    await botClient.SendMessage(message.Chat.Id, "📦 Oran havuzu boş. Önce /oranekle MAC_ID kullan.", cancellationToken: cancellationToken);
                    return;
                }
                await botClient.SendMessage(message.Chat.Id, $"💰 Gerçek pre-match oranları çekiliyor... ({liste.Count} maç)", cancellationToken: cancellationToken);
                var odds = scope.ServiceProvider.GetRequiredService<IOddsApiService>();
                var sync = await odds.HavuzOranlariniCekAsync(liste.Select(x => x.MacId), cancellationToken);
                var totalReq = sync.Sum(x => x.ApiIstekSayisi);
                var metin = "💰 ORAN SYNC SONUCU\n\n" + string.Join("\n\n", sync.Select(x =>
                    $"⚽ {x.MacAdi}\n{(x.EslesmeBulundu ? "✅" : "❌")} {x.Mesaj}\n📊 Kaydedilen market: {x.KaydedilenOran}")) +
                    $"\n\n🔌 Bu işlemde API isteği: {totalReq}\n➡️ Şimdi /analiz MAC_ID kullanabilirsin.";
                await botClient.SendMessage(message.Chat.Id, metin, cancellationToken: cancellationToken);
                return;
            }
        }

        if (await _moderasyonCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _debugCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _kuponCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                user.Id,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _uygunMacCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _teamRepairCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _historicalCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _footballDataCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _searchCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }

        if (await _ligCommandHandler.TryHandleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                AdminMi(user.Id),
                cancellationToken))
        {
            return;
        }


        if (KomutMu(text, BotKomutlari.Start))
        {
            var uyelikMetni = kullanici.AktifVipMi
                ? $"✅ VIP aktif\n📅 Bitiş: " +
                  $"{kullanici.UyelikBitisTarihi?.ToLocalTime():dd.MM.yyyy HH:mm}"
                : "❌ Aktif VIP üyeliğiniz bulunmuyor.";

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "⚽ FEM ELITE ANALYSIS\n\n" +
                    $"Hoş geldiniz, {user.FirstName}.\n\n" +
                    $"{uyelikMetni}\n\n" +
                    $"{BotKomutlari.Uyeligim} - Üyeliğim\n" +
                    $"{BotKomutlari.Id} - Telegram ID",
                cancellationToken: cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Id))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"Telegram ID: {user.Id}",
                cancellationToken: cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Uyeligim))
        {
            var cevap = kullanici.AktifVipMi
                ? $"✅ VIP aktif.\nBitiş: " +
                  $"{kullanici.UyelikBitisTarihi?.ToLocalTime():dd.MM.yyyy HH:mm}"
                : "❌ Aktif VIP üyeliğiniz bulunmuyor.";

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: cevap,
                cancellationToken: cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Admin))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "👑 FEM ELITE ANALYSIS\n\n" +
                    "Admin paneline hoş geldiniz.\n" +
                    "Yapmak istediğiniz işlemi seçin.",
                replyMarkup: AdminKeyboard.Menu(),
                cancellationToken: cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Sync) ||
            KomutMu(text, BotKomutlari.SyncDurum) ||
            KomutMu(text, BotKomutlari.SyncBaglanti) ||
            KomutMu(text, BotKomutlari.Sync3Sezon) ||
            KomutMu(text, BotKomutlari.SyncGenis) ||
            KomutMu(text, BotKomutlari.SyncIstatistik) ||
            KomutMu(text, BotKomutlari.SyncIstatistikDurum))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            var syncService =
                scope.ServiceProvider
                    .GetRequiredService<VeriToplamaTelegramService>();

            if (KomutMu(text, BotKomutlari.Sync))
            {
                await syncService.SyncCalistirAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }
            else if (KomutMu(text, BotKomutlari.SyncDurum))
            {
                await syncService.DurumGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }
            else if (KomutMu(text, BotKomutlari.Sync3Sezon))
            {
                await syncService.Sync3SezonCalistirAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }
            else if (KomutMu(text, BotKomutlari.SyncGenis))
            {
                await syncService.SyncGenisCalistirAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }
            else if (KomutMu(text, BotKomutlari.SyncIstatistik))
            {
                await syncService.SyncIstatistikBaslatAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }
            else if (KomutMu(text, BotKomutlari.SyncIstatistikDurum))
            {
                await syncService.SyncIstatistikDurumGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }
            else
            {
                await syncService.BaglantiTestiAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
            }

            return;
        }

        if (KomutMu(text, BotKomutlari.Analiz))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await AnalizOlusturAsync(
                botClient,
                message,
                text,
                user.Id,
                scope.ServiceProvider,
                cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Tahmin))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await TahminGuncelleAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.UyeEkle) ||
            KomutMu(text, BotKomutlari.UyeUzat))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await UyeEkleVeyaUzatAsync(
                botClient,
                message,
                text,
                user.Id,
                scope.ServiceProvider,
                cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.UyeBilgi))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await UyeBilgisiGonderAsync(
                botClient,
                message,
                text,
                scope.ServiceProvider,
                cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.AktifUyeler))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await AktifUyeleriGonderAsync(
                botClient,
                message.Chat.Id,
                scope.ServiceProvider,
                cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.UyeSil))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(
                    botClient,
                    message.Chat.Id,
                    cancellationToken);
                return;
            }

            await UyelikIptalEtAsync(
                botClient,
                message,
                text,
                user.Id,
                scope.ServiceProvider,
                cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Ayarlar))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(botClient, message.Chat.Id, cancellationToken);
                return;
            }

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "⚙️ Ayarlar için /admin menüsündeki Ayarlar düğmesini kullanın.\n\nDüzenleme:\n/ayarla ANAHTAR DEĞER",
                cancellationToken: cancellationToken);
            return;
        }

        if (KomutMu(text, "/ayarla"))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(botClient, message.Chat.Id, cancellationToken);
                return;
            }

            await AyarGuncelleAsync(
                botClient, message.Chat.Id, text, scope.ServiceProvider, cancellationToken);
            return;
        }

        if (KomutMu(text, BotKomutlari.Loglar))
        {
            if (!AdminMi(user.Id))
            {
                await YetkisizMesajiGonderAsync(botClient, message.Chat.Id, cancellationToken);
                return;
            }

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "📜 Loglar için /admin menüsündeki Loglar düğmesini kullanın.",
                cancellationToken: cancellationToken);
            return;
        }

        if (ozelSohbetMi)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "Komut bulunamadı.\n\n" +
                    "/start yazarak ana menüyü açabilirsiniz.",
                cancellationToken: cancellationToken);
        }
    }

    public async Task HandleErrorAsync(
        ITelegramBotClient botClient,
        Exception exception,
        CancellationToken cancellationToken)
    {
        _logger.LogError(
            exception,
            "Telegram botunda beklenmeyen hata oluştu.");

        try
        {
            using var scope = _scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<FemDbContext>();
            db.BotLoglari.Add(new BotLogu
            {
                Komut = "SYSTEM_ERROR",
                Detay = exception.ToString().Length > 3500
                    ? exception.ToString()[..3500]
                    : exception.ToString(),
                LogSeviyesi = "Error",
                KayitTarihi = DateTime.UtcNow
            });
            await db.SaveChangesAsync(cancellationToken);
        }
        catch (Exception logException)
        {
            _logger.LogError(logException, "Hata kaydı veritabanına yazılamadı.");
        }
    }

    private static async Task TahminGuncelleAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var parcalar = text.Split(
            ' ',
            3,
            StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 3 ||
            !int.TryParse(parcalar[1], out var analizId))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "Kullanım:\n" +
                    "/tahmin ANALIZ_ID TAHMIN_METNI\n\n" +
                    "Örnek:\n" +
                    "/tahmin 1 KG VAR + 1.5 ÜST",
                cancellationToken: cancellationToken);
            return;
        }

        var duzenlemeService =
            serviceProvider.GetRequiredService<IAnalizDuzenlemeService>();

        var sonuc = await duzenlemeService.TahminGuncelleAsync(
            analizId,
            parcalar[2],
            cancellationToken);

        if (!sonuc.Basarili)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text:
                $"✅ {sonuc.Mesaj}\n\n" +
                $"🎯 Tahmin: {parcalar[2]}\n" +
                $"Analiz ID: {analizId}",
            replyMarkup: AnalizDuzenlemeKeyboard.TaslakMenu(analizId),
            cancellationToken: cancellationToken);
    }

    private static async Task AnalizOlusturAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        long telegramId,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var parcalar = text.Split(
            ' ',
            StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 2 ||
            !int.TryParse(parcalar[1], out var macId))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "Kullanım:\n/analiz MAC_ID\n\n" +
                    "Örnek:\n/analiz 25",
                cancellationToken: cancellationToken);
            return;
        }

        var havuz = serviceProvider.GetRequiredService<IOranHavuzuService>();
        var oddsService = serviceProvider.GetRequiredService<IOddsApiService>();
        if (havuz.Iceriyor(telegramId, macId))
        {
            if (!await oddsService.GuncelOranVarMiAsync(macId, cancellationToken))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "💰 Önce gerçek pre-match oranları çekiyorum...",
                    cancellationToken: cancellationToken);
                var oddsSonuc = await oddsService.MacOraniniCekAsync(macId, cacheKullan: true, ct: cancellationToken);
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: $"{(oddsSonuc.EslesmeBulundu ? "✅" : "⚠️")} {oddsSonuc.Mesaj}\n📊 Kaydedilen market: {oddsSonuc.KaydedilenOran}",
                    cancellationToken: cancellationToken);
            }
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text:
                "🤖 FEM maç analizi hazırlanıyor...\n" +
                (havuz.Iceriyor(telegramId, macId) ? "Gerçek piyasa oranları analizle birlikte değerlendirilecek." : "Not: Bu maç oran havuzunda değil; analiz oran datası olmadan çalışabilir."),
            cancellationToken: cancellationToken);

        var analizService =
            serviceProvider.GetRequiredService<IAnalizService>();

        var sonuc = await analizService.AnalizOlusturAsync(
            new AnalizOlusturRequest
            {
                MacId = macId,
                AnalizTuru = "FEM İstatistiksel Maç Analizi",
                KullaniciTahmini = string.Empty
            },
            cancellationToken);

        if (!sonuc.Basarili)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var dbContext =
            serviceProvider.GetRequiredService<FemDbContext>();

        var analiz = await dbContext.Analizler
            .AsNoTracking()
            .Include(x => x.Mac)
                .ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac)
                .ThenInclude(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == sonuc.Veri,
                cancellationToken);

        if (analiz is null)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    $"✅ {sonuc.Mesaj}\n" +
                    $"Analiz ID: {sonuc.Veri}",
                cancellationToken: cancellationToken);
            return;
        }

        List<string> faktorler;

        try
        {
            faktorler =
                JsonSerializer.Deserialize<List<string>>(
                    analiz.AnaFaktorlerJson ?? "[]")
                ?? new List<string>();
        }
        catch
        {
            faktorler = new List<string>();
        }

        var faktorMetni = faktorler.Count == 0
            ? "• Veri bulunamadı"
            : string.Join(
                "\n",
                faktorler.Select(x => $"• {x}"));

        var analizMesaji =
            "🤖 FEM ANALİZ TASLAĞI\n\n" +
            $"⚽ {analiz.Mac.EvSahibiTakim.Ad} - " +
            $"{analiz.Mac.DeplasmanTakim.Ad}\n\n" +
            $"📝 {analiz.YapayZekaAnalizi}\n\n" +
            $"📊 Ev sahibi: %{analiz.EvSahibiKazanmaOlasiligi:0.##}\n" +
            $"📊 Beraberlik: %{analiz.BeraberlikOlasiligi:0.##}\n" +
            $"📊 Deplasman: %{analiz.DeplasmanKazanmaOlasiligi:0.##}\n\n" +
            $"🎯 Güven puanı: {analiz.GuvenPuani}/100\n" +
            $"⚠️ Risk: {analiz.RiskSeviyesi}\n\n" +
            $"Ana faktörler:\n{faktorMetni}\n\n" +
            $"Analiz ID: {analiz.Id}\n" +
            "Durum: Taslak\n\n" +
            $"Tahmin eklemek için:\n" +
            $"/tahmin {analiz.Id} TAHMIN_METNI";

        const int telegramParca = 3800;
        var parcalarMesaj = Enumerable.Range(0, (analizMesaji.Length + telegramParca - 1) / telegramParca)
            .Select(i => analizMesaji.Substring(i * telegramParca, Math.Min(telegramParca, analizMesaji.Length - i * telegramParca)))
            .ToList();

        for (var i = 0; i < parcalarMesaj.Count; i++)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: parcalarMesaj[i],
                replyMarkup: i == parcalarMesaj.Count - 1 ? AnalizDuzenlemeKeyboard.TaslakMenu(analiz.Id) : null,
                cancellationToken: cancellationToken);
        }
    }

    private static async Task UyeEkleVeyaUzatAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        long adminTelegramId,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var parcalar = text.Split(
            ' ',
            StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 3 ||
            !long.TryParse(parcalar[1], out var telegramId) ||
            !int.TryParse(parcalar[2], out var gun))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "Kullanım:\n" +
                    "/uyeekle TELEGRAM_ID GUN",
                cancellationToken: cancellationToken);
            return;
        }

        var uyelikService =
            serviceProvider.GetRequiredService<IUyelikService>();

        var sonuc = await uyelikService.UyeEkleVeyaUzatAsync(
            new UyelikEkleRequest
            {
                TelegramKullaniciId = telegramId,
                Gun = gun
            },
            adminTelegramId,
            cancellationToken);

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: sonuc.Basarili
                ? $"✅ {sonuc.Mesaj}\n" +
                  $"Bitiş: {sonuc.Veri.ToLocalTime():dd.MM.yyyy HH:mm}"
                : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    private static async Task UyeBilgisiGonderAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var parcalar = text.Split(
            ' ',
            StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 2 ||
            !long.TryParse(parcalar[1], out var telegramId))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "Kullanım:\n/uyebilgi TELEGRAM_ID",
                cancellationToken: cancellationToken);
            return;
        }

        var vipService =
            serviceProvider.GetRequiredService<IVipYonetimService>();

        var sonuc = await vipService.UyeBilgisiGetirAsync(
            telegramId,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var uye = sonuc.Veri;

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text:
                "💎 VIP ÜYE BİLGİSİ\n\n" +
                $"👤 {uye.AdSoyad}\n" +
                $"🆔 {uye.TelegramKullaniciId}\n" +
                $"📅 Bitiş: " +
                $"{uye.BitisTarihi.ToLocalTime():dd.MM.yyyy HH:mm}\n" +
                $"⏳ Kalan: {uye.KalanGun} gün",
            cancellationToken: cancellationToken);
    }

    private static async Task AktifUyeleriGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var vipService =
            serviceProvider.GetRequiredService<IVipYonetimService>();

        var sonuc = await vipService.AktifUyeleriGetirAsync(
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var mesaj = sonuc.Veri.Count == 0
            ? "Aktif VIP üye bulunmuyor."
            : string.Join(
                "\n\n",
                sonuc.Veri.Take(30).Select(x =>
                    $"👤 {x.AdSoyad}\n" +
                    $"🆔 {x.TelegramKullaniciId}\n" +
                    $"📅 {x.BitisTarihi.ToLocalTime():dd.MM.yyyy HH:mm}\n" +
                    $"⏳ {x.KalanGun} gün"));

        await botClient.SendMessage(
            chatId: chatId,
            text:
                $"📋 AKTİF VIP ÜYELER ({sonuc.Veri.Count})\n\n" +
                mesaj,
            cancellationToken: cancellationToken);
    }

    private static async Task UyelikIptalEtAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        long adminTelegramId,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var parcalar = text.Split(
            ' ',
            StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 2 ||
            !long.TryParse(parcalar[1], out var telegramId))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text:
                    "Kullanım:\n/uyesil TELEGRAM_ID",
                cancellationToken: cancellationToken);
            return;
        }

        var vipService =
            serviceProvider.GetRequiredService<IVipYonetimService>();

        var sonuc = await vipService.UyelikIptalEtAsync(
            telegramId,
            adminTelegramId,
            cancellationToken);

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: sonuc.Basarili
                ? $"✅ {sonuc.Mesaj}"
                : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    private static async Task AyarGuncelleAsync(
        ITelegramBotClient botClient,
        long chatId,
        string text,
        IServiceProvider serviceProvider,
        CancellationToken cancellationToken)
    {
        var parcalar = text.Split(' ', 3, StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 3)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text:
                    "Kullanım:\n/ayarla ANAHTAR YENİ_DEĞER\n\n" +
                    "Geçerli anahtarlar:\n" +
                    "UygulamaAdi\nVarsayilanUyelikGunu\nAnalizUyarisi\nVarsayilanDil",
                cancellationToken: cancellationToken);
            return;
        }

        var anahtar = parcalar[1];
        var yeniDeger = parcalar[2].Trim();
        var db = serviceProvider.GetRequiredService<FemDbContext>();
        var ayar = await db.Ayarlar.FirstOrDefaultAsync(
            x => x.Anahtar == anahtar, cancellationToken);

        if (ayar is null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "❌ Ayar bulunamadı. Anahtarı Ayarlar menüsündeki biçimiyle yazın.",
                cancellationToken: cancellationToken);
            return;
        }

        if (ayar.Anahtar == "VarsayilanUyelikGunu" &&
            (!int.TryParse(yeniDeger, out var gun) || gun is < 1 or > 3650))
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "❌ Üyelik günü 1 ile 3650 arasında bir sayı olmalıdır.",
                cancellationToken: cancellationToken);
            return;
        }

        if (yeniDeger.Length > 2000)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "❌ Ayar değeri en fazla 2000 karakter olabilir.",
                cancellationToken: cancellationToken);
            return;
        }

        ayar.Deger = yeniDeger;
        ayar.GuncellemeTarihi = DateTime.UtcNow;
        await db.SaveChangesAsync(cancellationToken);

        await botClient.SendMessage(
            chatId: chatId,
            text: $"✅ {ayar.Anahtar} güncellendi.\n\nYeni değer:\n{ayar.Deger}",
            cancellationToken: cancellationToken);
    }

    private static bool KomutMu(string text, string komut)
    {
        return text.Equals(
                   komut,
                   StringComparison.OrdinalIgnoreCase) ||
               text.StartsWith(
                   komut + " ",
                   StringComparison.OrdinalIgnoreCase);
    }

    private bool AdminMi(long telegramKullaniciId)
    {
        // Eski AdminUserId değeri çalışmaya devam eder.
        if (_telegramOptions.AdminUserId > 0 &&
            telegramKullaniciId == _telegramOptions.AdminUserId)
        {
            return true;
        }

        // Yeni çoklu admin listesi.
        return _telegramOptions.AdminUserIds.Contains(
            telegramKullaniciId);
    }

    private static Task YetkisizMesajiGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        return botClient.SendMessage(
            chatId: chatId,
            text: "⛔ Bu işlemi kullanma yetkiniz bulunmuyor.",
            cancellationToken: cancellationToken);
    }
}
