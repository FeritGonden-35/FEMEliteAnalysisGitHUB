using FEMEliteAnalysis.Api.Bot.Services;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramModerasyonCommandHandler
{
    public async Task<bool> TryHandleAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        bool globalAdminMi,
        CancellationToken cancellationToken)
    {
        var komut = text.Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault()?.ToLowerInvariant();

        if (komut is not "/moddurum" and not "/modac" and not "/modkapat")
            return false;

        if (message.Chat.Type is not ChatType.Group and not ChatType.Supergroup)
        {
            await botClient.SendMessage(message.Chat.Id,
                "Bu komut yalnızca sohbet grubunda kullanılabilir.",
                cancellationToken: cancellationToken);
            return true;
        }

        var grupAdminMi = globalAdminMi || await GrupAdminMiAsync(
            botClient, message.Chat.Id, message.From!.Id, cancellationToken);

        if (!grupAdminMi)
        {
            await botClient.SendMessage(message.Chat.Id,
                "⛔ Bu komutu yalnızca grup yöneticileri kullanabilir.",
                cancellationToken: cancellationToken);
            return true;
        }

        var service = serviceProvider.GetRequiredService<ModerasyonTelegramService>();

        if (komut == "/modac")
        {
            service.GrupDurumunuAyarla(message.Chat.Id, true);
            await botClient.SendMessage(message.Chat.Id,
                "✅ Sohbet moderasyonu açıldı.",
                cancellationToken: cancellationToken);
        }
        else if (komut == "/modkapat")
        {
            service.GrupDurumunuAyarla(message.Chat.Id, false);
            await botClient.SendMessage(message.Chat.Id,
                "⏸️ Sohbet moderasyonu kapatıldı.",
                cancellationToken: cancellationToken);
        }
        else
        {
            var aktif = service.GrupAktifMi(message.Chat.Id);
            await botClient.SendMessage(message.Chat.Id,
                "👮 MODERASYON DURUMU\n\n" +
                $"Durum: {(aktif ? "🟢 Açık" : "🔴 Kapalı")}\n" +
                "Koruma: Küfür, reklam, flood, tekrar mesaj, caps ve karakter spamı\n" +
                "Ceza: Uyarı → 10 dk → 1 saat → 24 saat → Ban",
                cancellationToken: cancellationToken);
        }

        return true;
    }

    private static async Task<bool> GrupAdminMiAsync(
        ITelegramBotClient botClient,
        long chatId,
        long userId,
        CancellationToken cancellationToken)
    {
        try
        {
            var member = await botClient.GetChatMember(chatId, userId, cancellationToken);
            return member.Status is ChatMemberStatus.Administrator or ChatMemberStatus.Creator;
        }
        catch
        {
            return false;
        }
    }
}
