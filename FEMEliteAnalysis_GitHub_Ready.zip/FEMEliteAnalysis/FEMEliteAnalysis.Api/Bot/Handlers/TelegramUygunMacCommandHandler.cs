using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramUygunMacCommandHandler
{
    public async Task<bool> TryHandleAsync(ITelegramBotClient bot, Message message, string text, IServiceProvider sp, bool adminMi, CancellationToken ct)
    {
        var uygun = KomutMu(text, BotKomutlari.UygunMaclar);
        var veri = KomutMu(text, BotKomutlari.MacVeriCek);
        if (!uygun && !veri) return false;
        if (!adminMi) { await bot.SendMessage(message.Chat.Id, "⛔ Yetkiniz yok.", cancellationToken: ct); return true; }
        var service = sp.GetRequiredService<UygunMacTelegramService>();
        var p = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (uygun)
        {
            var gun = p.Length > 1 && int.TryParse(p[1], out var g) ? Math.Clamp(g, 1, 14) : 3;
            await service.ListeGonderAsync(bot, message.Chat.Id, gun, ct); return true;
        }
        if (p.Length != 2 || !int.TryParse(p[1], out var id))
        { await bot.SendMessage(message.Chat.Id, "Kullanım: /macvericek MAC_ID", cancellationToken: ct); return true; }
        await service.VeriCekAsync(bot, message.Chat.Id, id, ct); return true;
    }
    private static bool KomutMu(string t, string k) => t.Equals(k, StringComparison.OrdinalIgnoreCase) || t.StartsWith(k + " ", StringComparison.OrdinalIgnoreCase);
}

