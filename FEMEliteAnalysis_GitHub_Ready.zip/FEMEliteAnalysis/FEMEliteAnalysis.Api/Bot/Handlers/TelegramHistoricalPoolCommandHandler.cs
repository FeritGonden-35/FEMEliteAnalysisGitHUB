using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramHistoricalPoolCommandHandler
{
    public async Task<bool> TryHandleAsync(
        ITelegramBotClient bot,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        bool adminMi,
        CancellationToken cancellationToken)
    {
        var komutMu = KomutMu(text, BotKomutlari.HavuzImport) ||
                      KomutMu(text, BotKomutlari.HavuzDurum) ||
                      KomutMu(text, BotKomutlari.HavuzLigler) ||
                      KomutMu(text, BotKomutlari.VeriSayisi);
        if (!komutMu) return false;

        if (!adminMi)
        {
            await bot.SendMessage(message.Chat.Id, "⛔ Bu komutu kullanma yetkiniz yok.", cancellationToken: cancellationToken);
            return true;
        }

        var service = serviceProvider.GetRequiredService<HistoricalPoolTelegramService>();
        if (KomutMu(text, BotKomutlari.HavuzDurum))
        {
            await service.DurumAsync(bot, message.Chat.Id, cancellationToken);
            return true;
        }
        if (KomutMu(text, BotKomutlari.VeriSayisi))
        {
            await service.VeriSayisiAsync(bot, message.Chat.Id, cancellationToken);
            return true;
        }
        if (KomutMu(text, BotKomutlari.HavuzLigler))
        {
            await service.LiglerAsync(bot, message.Chat.Id, cancellationToken);
            return true;
        }

        var parts = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 3)
        {
            await bot.SendMessage(message.Chat.Id,
                "Kullanım: /havuzimport BASLANGIC BITIS\nÖrnek: /havuzimport 9394 2526\n\nÖnce küçük test: /havuzimport 2425 2526",
                cancellationToken: cancellationToken);
            return true;
        }

        await service.BaslatAsync(bot, message.Chat.Id, parts[1], parts[2], cancellationToken);
        return true;
    }

    private static bool KomutMu(string text, string komut) =>
        text.Equals(komut, StringComparison.OrdinalIgnoreCase) ||
        text.StartsWith(komut + " ", StringComparison.OrdinalIgnoreCase);
}
