using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramFootballDataCommandHandler
{
    public async Task<bool> TryHandleAsync(
        ITelegramBotClient bot,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        bool adminMi,
        CancellationToken cancellationToken)
    {
        var komutMu = KomutMu(text, BotKomutlari.FdLigler) ||
                      KomutMu(text, BotKomutlari.FdIndir) ||
                      KomutMu(text, BotKomutlari.FdToplu);
        if (!komutMu) return false;

        if (!adminMi)
        {
            await bot.SendMessage(message.Chat.Id,
                "⛔ Bu komutu kullanma yetkiniz yok.",
                cancellationToken: cancellationToken);
            return true;
        }

        var service = serviceProvider.GetRequiredService<FootballDataTelegramService>();
        if (KomutMu(text, BotKomutlari.FdLigler))
        {
            await service.LigleriGonderAsync(bot, message.Chat.Id, cancellationToken);
            return true;
        }

        var parts = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (KomutMu(text, BotKomutlari.FdIndir))
        {
            if (parts.Length != 3)
            {
                await bot.SendMessage(message.Chat.Id,
                    "Kullanım: /fdindir LIG_KODU SEZON\nÖrnek: /fdindir E0 2526",
                    cancellationToken: cancellationToken);
                return true;
            }
            await service.IndirAsync(bot, message.Chat.Id, parts[1], parts[2], cancellationToken);
            return true;
        }

        if (parts.Length < 3)
        {
            await bot.SendMessage(message.Chat.Id,
                "Kullanım: /fdtoplu SEZON E0,E1,D1,SP1,I1,F1\n" +
                "Örnek: /fdtoplu 2526 E0,D1,SP1,I1,F1",
                cancellationToken: cancellationToken);
            return true;
        }

        var ligler = string.Join("", parts.Skip(2))
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        await service.TopluIndirAsync(bot, message.Chat.Id, parts[1], ligler, cancellationToken);
        return true;
    }

    private static bool KomutMu(string text, string komut) =>
        text.Equals(komut, StringComparison.OrdinalIgnoreCase) ||
        text.StartsWith(komut + " ", StringComparison.OrdinalIgnoreCase);
}
