using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramHistoricalCommandHandler
{
    public async Task<bool> TryHandleAsync(
        ITelegramBotClient bot,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        bool adminMi,
        CancellationToken cancellationToken)
    {
        var komutMu =
            KomutMu(text, BotKomutlari.HistorikImport) ||
            KomutMu(text, BotKomutlari.HistorikDurum) ||
            KomutMu(text, BotKomutlari.HistorikDosyalar);

        if (!komutMu)
            return false;

        if (!adminMi)
        {
            await bot.SendMessage(
                chatId: message.Chat.Id,
                text: "⛔ Bu komutu kullanma yetkiniz yok.",
                cancellationToken: cancellationToken);

            return true;
        }

        var service =
            serviceProvider.GetRequiredService<
                HistoricalImportTelegramService>();

        if (KomutMu(text, BotKomutlari.HistorikImport))
        {
            await service.ImportAsync(
                bot,
                message.Chat.Id,
                cancellationToken);
        }
        else if (KomutMu(text, BotKomutlari.HistorikDurum))
        {
            await service.DurumAsync(
                bot,
                message.Chat.Id,
                cancellationToken);
        }
        else
        {
            await service.DosyalarAsync(
                bot,
                message.Chat.Id,
                cancellationToken);
        }

        return true;
    }

    private static bool KomutMu(
        string text,
        string komut)
    {
        return text.Equals(
                   komut,
                   StringComparison.OrdinalIgnoreCase) ||
               text.StartsWith(
                   komut + " ",
                   StringComparison.OrdinalIgnoreCase);
    }
}