using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public class TelegramDebugCommandHandler
{
    public async Task<bool> TryHandleAsync(
        ITelegramBotClient botClient,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        bool adminMi,
        CancellationToken cancellationToken)
    {
        var debugKomutuMu =
            KomutMu(text, BotKomutlari.Debug) ||
            KomutMu(text, BotKomutlari.DebugTakim) ||
            KomutMu(text, BotKomutlari.DebugH2H) ||
            KomutMu(text, BotKomutlari.DebugMarket);

        if (!debugKomutuMu)
            return false;

        if (!adminMi)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "⛔ Bu debug komutunu kullanma yetkiniz yok.",
                cancellationToken: cancellationToken);
            return true;
        }

        var service =
            serviceProvider.GetRequiredService<DebugTelegramService>();

        if (KomutMu(text, BotKomutlari.DebugTakim))
        {
            var takimAdi = ParametreMetni(
                text,
                BotKomutlari.DebugTakim);

            if (string.IsNullOrWhiteSpace(takimAdi))
            {
                await KullanimGonderAsync(
                    botClient,
                    message.Chat.Id,
                    "/debugtakim TAKIM_ADI",
                    cancellationToken);
                return true;
            }

            await service.TakimDebugGonderAsync(
                botClient,
                message.Chat.Id,
                takimAdi,
                cancellationToken);
            return true;
        }

        var parcalar = text.Split(
            ' ',
            StringSplitOptions.RemoveEmptyEntries);

        if (parcalar.Length != 2 ||
            !int.TryParse(parcalar[1], out var macId))
        {
            var kullanim = KomutMu(text, BotKomutlari.DebugH2H)
                ? "/debugh2h MAC_ID"
                : KomutMu(text, BotKomutlari.DebugMarket)
                    ? "/debugmarket MAC_ID"
                    : "/debug MAC_ID";

            await KullanimGonderAsync(
                botClient,
                message.Chat.Id,
                kullanim,
                cancellationToken);
            return true;
        }

        if (KomutMu(text, BotKomutlari.DebugH2H))
        {
            await service.H2HDebugGonderAsync(
                botClient,
                message.Chat.Id,
                macId,
                cancellationToken);
        }
        else if (KomutMu(text, BotKomutlari.DebugMarket))
        {
            await service.MarketDebugGonderAsync(
                botClient,
                message.Chat.Id,
                macId,
                cancellationToken);
        }
        else
        {
            await service.MacDebugGonderAsync(
                botClient,
                message.Chat.Id,
                macId,
                cancellationToken);
        }

        return true;
    }

    private static bool KomutMu(
        string text,
        string komut)
    {
        return text.Equals(
                   komut,
                   StringComparison.OrdinalIgnoreCase) ||
               text.StartsWith(
                   komut + " ",
                   StringComparison.OrdinalIgnoreCase);
    }

    private static string ParametreMetni(
        string text,
        string komut)
    {
        return text.Length <= komut.Length
            ? string.Empty
            : text[komut.Length..].Trim();
    }

    private static Task KullanimGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        string kullanim,
        CancellationToken cancellationToken)
    {
        return botClient.SendMessage(
            chatId: chatId,
            text: $"Kullanım: {kullanim}",
            cancellationToken: cancellationToken);
    }
}
