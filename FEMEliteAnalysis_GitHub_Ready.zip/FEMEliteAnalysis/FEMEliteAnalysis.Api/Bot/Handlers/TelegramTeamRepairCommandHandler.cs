using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Common.Constants;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public sealed class TelegramTeamRepairCommandHandler
{
    public async Task<bool> TryHandleAsync(ITelegramBotClient bot,Message message,string text,IServiceProvider sp,bool adminMi,CancellationToken ct)
    {
        var komut=KomutMu(text,BotKomutlari.TakimTarama)||KomutMu(text,BotKomutlari.BirlestirmeOnizle)||KomutMu(text,BotKomutlari.TakimBirlestir)||KomutMu(text,BotKomutlari.BirlestirmeDurum);
        if(!komut)return false;
        if(!adminMi){await bot.SendMessage(message.Chat.Id,"⛔ Yetkiniz yok.",cancellationToken:ct);return true;}
        var s=sp.GetRequiredService<TeamRepairTelegramService>();
        if(KomutMu(text,BotKomutlari.TakimTarama)) await s.TaraAsync(bot,message.Chat.Id,ct);
        else if(KomutMu(text,BotKomutlari.BirlestirmeOnizle)) await s.OnizleAsync(bot,message.Chat.Id,ct);
        else if(KomutMu(text,BotKomutlari.TakimBirlestir)) await s.UygulaAsync(bot,message.Chat.Id,ct);
        else await s.DurumAsync(bot,message.Chat.Id,ct);
        return true;
    }
    private static bool KomutMu(string text,string komut)=>text.Equals(komut,StringComparison.OrdinalIgnoreCase)||text.StartsWith(komut+" ",StringComparison.OrdinalIgnoreCase);
}
