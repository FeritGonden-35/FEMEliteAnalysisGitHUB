using System.Globalization;
using System.Text;
using FEMEliteAnalysis.Api.Bot.Keyboards;
using FEMEliteAnalysis.Api.Common.Constants;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Bot.Handlers;

public sealed class TelegramSearchCommandHandler
{
    public async Task<bool> TryHandleAsync(
        ITelegramBotClient bot,
        Message message,
        string text,
        IServiceProvider serviceProvider,
        bool adminMi,
        CancellationToken ct)
    {
        var takimMi = KomutMu(text, BotKomutlari.Takim);
        var ligMi = KomutMu(text, BotKomutlari.Lig);
        var macMi = KomutMu(text, BotKomutlari.MacAra);

        if (!takimMi && !ligMi && !macMi)
            return false;

        if (!adminMi)
        {
            await bot.SendMessage(message.Chat.Id,
                "⛔ Bu komutu kullanma yetkiniz yok.", cancellationToken: ct);
            return true;
        }

        var arama = KomutParametresi(text);
        if (string.IsNullOrWhiteSpace(arama))
        {
            var kullanim = takimMi
                ? "/takim Galatasaray"
                : ligMi
                    ? "/lig Süper Lig"
                    : "/macara Galatasaray";

            await bot.SendMessage(message.Chat.Id,
                $"🔎 Arama metni eksik.\n\nÖrnek:\n{kullanim}",
                cancellationToken: ct);
            return true;
        }

        var db = serviceProvider.GetRequiredService<FemDbContext>();

        if (takimMi)
        {
            var kimlikService = serviceProvider
                .GetRequiredService<ITakimSaglayiciKimlikService>();
            await TakimProfiliAsync(
                bot,
                message.Chat.Id,
                db,
                kimlikService,
                arama,
                ct);
        }
        else if (ligMi)
            await LigProfiliAsync(bot, message.Chat.Id, db, arama, ct);
        else
            await MacAraAsync(bot, message.Chat.Id, db, arama, ct);

        return true;
    }

    private static async Task TakimProfiliAsync(
        ITelegramBotClient bot,
        long chatId,
        FemDbContext db,
        ITakimSaglayiciKimlikService kimlikService,
        string arama,
        CancellationToken ct)
    {
        var norm = Normalize(arama);
        var adaylar = await db.Takimlar.AsNoTracking()
            .Where(x => x.AktifMi)
            .Select(x => new { x.Id, x.Ad, x.HariciTakimId, x.LigId, x.Ulke })
            .ToListAsync(ct);

        var takim = adaylar
            .Where(x => Normalize(x.Ad).Contains(norm, StringComparison.Ordinal))
            .OrderByDescending(x => x.HariciTakimId.HasValue && x.HariciTakimId.Value > 0)
            .ThenBy(x => Normalize(x.Ad) == norm ? 0 : 1)
            .ThenBy(x => x.Ad.Length)
            .FirstOrDefault();

        if (takim is null)
        {
            await bot.SendMessage(chatId,
                $"❌ '{arama}' için takım bulunamadı.", cancellationToken: ct);
            return;
        }

        // Aynı kulübün farklı kaynaklardan oluşmuş mükerrer kayıtlarını birlikte değerlendir.
        var esTakimIdleri = adaylar
            .Where(x => Normalize(x.Ad) == Normalize(takim.Ad))
            .Select(x => x.Id)
            .Distinct()
            .ToList();

        if (!esTakimIdleri.Contains(takim.Id))
            esTakimIdleri.Add(takim.Id);

        var kimlikler = await kimlikService.TumKimlikleriGetirAsync(
            takim.Id,
            ct);

        var simdi = DateTime.UtcNow;
        var maclar = await db.Maclar.AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x => esTakimIdleri.Contains(x.EvSahibiTakimId) ||
                        esTakimIdleri.Contains(x.DeplasmanTakimId))
            .OrderByDescending(x => x.MacTarihi)
            .Take(120)
            .ToListAsync(ct);

        var tamamlanan = maclar
            .Where(x => x.MacTarihi < simdi && x.EvSahibiSkor.HasValue && x.DeplasmanSkor.HasValue)
            .OrderByDescending(x => x.MacTarihi)
            .Take(20)
            .ToList();

        var galibiyet = 0; var beraberlik = 0; var maglubiyet = 0; var attigi = 0; var yedigi = 0;
        foreach (var m in tamamlanan)
        {
            var evMi = esTakimIdleri.Contains(m.EvSahibiTakimId);
            var a = evMi ? m.EvSahibiSkor!.Value : m.DeplasmanSkor!.Value;
            var y = evMi ? m.DeplasmanSkor!.Value : m.EvSahibiSkor!.Value;
            attigi += a; yedigi += y;
            if (a > y) galibiyet++; else if (a == y) beraberlik++; else maglubiyet++;
        }

        var gelecek = await db.Maclar.AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x => x.MacTarihi >= simdi &&
                        (esTakimIdleri.Contains(x.EvSahibiTakimId) ||
                         esTakimIdleri.Contains(x.DeplasmanTakimId)))
            .OrderBy(x => x.MacTarihi)
            .Take(5)
            .ToListAsync(ct);

        var metin = new StringBuilder();
        metin.AppendLine($"👤 {takim.Ad.ToUpperInvariant()}");
        metin.AppendLine();
        metin.AppendLine($"🆔 Takım ID: {takim.Id}");
        metin.AppendLine($"🌐 TheSportsDB ID: {kimlikler.TheSportsDbId?.ToString() ?? "-"}");
        metin.AppendLine($"🔗 API-Football ID: {kimlikler.ApiFootballId?.ToString() ?? "-"}");
        if (esTakimIdleri.Count > 1)
            metin.AppendLine($"🔄 Birleştirilen takım kaydı: {esTakimIdleri.Count}");
        if (!string.IsNullOrWhiteSpace(takim.Ulke)) metin.AppendLine($"🌍 Ülke: {takim.Ulke}");
        metin.AppendLine();
        metin.AppendLine("📈 SON 20 MAÇ");
        metin.AppendLine($"✅ {galibiyet}G  ➖ {beraberlik}B  ❌ {maglubiyet}M");
        if (tamamlanan.Count > 0)
        {
            metin.AppendLine($"⚽ Gol: {attigi} attı / {yedigi} yedi");
            metin.AppendLine($"📊 Maç başı gol: {(attigi / (decimal)tamamlanan.Count):0.00}");
        }

        metin.AppendLine();
        metin.AppendLine("📅 YAKLAŞAN MAÇLAR");
        if (gelecek.Count == 0)
            metin.AppendLine("Yaklaşan maç bulunamadı.");
        else
            foreach (var m in gelecek)
                metin.AppendLine($"• 🆔 {m.Id} | {Istanbul(m.MacTarihi):dd.MM HH:mm} | {m.EvSahibiTakim.Ad} - {m.DeplasmanTakim.Ad}");

        var butonlar = gelecek.Select(m => new[]
        {
            InlineKeyboardButton.WithCallbackData(
                $"⚽ {Kisalt(m.EvSahibiTakim.Ad + " - " + m.DeplasmanTakim.Ad, 45)}",
                $"match_detail:{m.Id}")
        }).ToList();
        butonlar.Add(new[] { InlineKeyboardButton.WithCallbackData("⬅️ Match Center", "match_date_menu") });

        await bot.SendMessage(chatId, metin.ToString(),
            replyMarkup: new InlineKeyboardMarkup(butonlar), cancellationToken: ct);
    }

    private static async Task LigProfiliAsync(
        ITelegramBotClient bot,
        long chatId,
        FemDbContext db,
        string arama,
        CancellationToken ct)
    {
        var norm = Normalize(arama);
        var ligler = await db.Ligler.AsNoTracking().Where(x => x.AktifMi).ToListAsync(ct);
        var lig = ligler
            .Where(x => Normalize(x.Ad).Contains(norm, StringComparison.Ordinal))
            .OrderBy(x => Normalize(x.Ad) == norm ? 0 : 1)
            .ThenByDescending(x => x.Sezon)
            .FirstOrDefault();

        if (lig is null)
        {
            await bot.SendMessage(chatId, $"❌ '{arama}' için lig bulunamadı.", cancellationToken: ct);
            return;
        }

        var simdi = DateTime.UtcNow;
        var sonMaclar = await db.Maclar.AsNoTracking()
            .Where(x => x.LigId == lig.Id && x.MacTarihi < simdi &&
                        x.EvSahibiSkor.HasValue && x.DeplasmanSkor.HasValue)
            .OrderByDescending(x => x.MacTarihi)
            .Take(100)
            .ToListAsync(ct);

        var gelecek = await db.Maclar.AsNoTracking()
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x => x.LigId == lig.Id && x.MacTarihi >= simdi)
            .OrderBy(x => x.MacTarihi)
            .Take(20)
            .ToListAsync(ct);

        var toplamGol = sonMaclar.Sum(x => x.EvSahibiSkor!.Value + x.DeplasmanSkor!.Value);
        var kg = sonMaclar.Count(x => x.EvSahibiSkor > 0 && x.DeplasmanSkor > 0);
        var ust25 = sonMaclar.Count(x => x.EvSahibiSkor + x.DeplasmanSkor > 2);
        var ev = sonMaclar.Count(x => x.EvSahibiSkor > x.DeplasmanSkor);
        var ber = sonMaclar.Count(x => x.EvSahibiSkor == x.DeplasmanSkor);
        var dep = sonMaclar.Count(x => x.EvSahibiSkor < x.DeplasmanSkor);

        var metin = new StringBuilder();
        metin.AppendLine($"🏆 {lig.Ad.ToUpperInvariant()}");
        metin.AppendLine($"🌍 {lig.Ulke ?? "-"}  |  Sezon: {lig.Sezon ?? "-"}");
        metin.AppendLine();
        metin.AppendLine($"📊 Örneklem: Son {sonMaclar.Count} maç");
        if (sonMaclar.Count > 0)
        {
            metin.AppendLine($"⚽ Gol ortalaması: {(toplamGol / (decimal)sonMaclar.Count):0.00}");
            metin.AppendLine($"🥅 KG Var: %{Yuzde(kg, sonMaclar.Count)}");
            metin.AppendLine($"⬆️ 2.5 Üst: %{Yuzde(ust25, sonMaclar.Count)}");
            metin.AppendLine($"🏠 Ev / ➖ X / ✈️ Dep: %{Yuzde(ev, sonMaclar.Count)} / %{Yuzde(ber, sonMaclar.Count)} / %{Yuzde(dep, sonMaclar.Count)}");
        }
        metin.AppendLine();
        metin.AppendLine("📅 YAKLAŞAN MAÇLAR");
        foreach (var m in gelecek.Take(10))
            metin.AppendLine($"• 🆔 {m.Id} | {Istanbul(m.MacTarihi):dd.MM HH:mm} | {m.EvSahibiTakim.Ad} - {m.DeplasmanTakim.Ad}");
        if (gelecek.Count == 0) metin.AppendLine("Yaklaşan maç bulunamadı.");

        var buttons = gelecek.Take(10).Select(m => new[]
        {
            InlineKeyboardButton.WithCallbackData(
                $"⚽ {Kisalt(m.EvSahibiTakim.Ad + " - " + m.DeplasmanTakim.Ad, 45)}",
                $"match_detail:{m.Id}")
        }).ToList();
        buttons.Add(new[] { InlineKeyboardButton.WithCallbackData("⬅️ Match Center", "match_date_menu") });

        await bot.SendMessage(chatId, metin.ToString(),
            replyMarkup: new InlineKeyboardMarkup(buttons), cancellationToken: ct);
    }

    private static async Task MacAraAsync(
        ITelegramBotClient bot,
        long chatId,
        FemDbContext db,
        string arama,
        CancellationToken ct)
    {
        var norm = Normalize(arama);
        var simdi = DateTime.UtcNow;
        var adaylar = await db.Maclar.AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x => x.MacTarihi >= simdi.AddDays(-1) && x.MacTarihi < simdi.AddDays(30))
            .OrderBy(x => x.MacTarihi)
            .Take(2500)
            .ToListAsync(ct);

        var bulunan = adaylar
            .Where(x => Normalize(x.EvSahibiTakim.Ad + " " + x.DeplasmanTakim.Ad + " " + (x.Lig?.Ad ?? ""))
                .Contains(norm, StringComparison.Ordinal))
            .Take(20)
            .ToList();

        if (bulunan.Count == 0)
        {
            await bot.SendMessage(chatId,
                $"❌ '{arama}' için önümüzdeki 30 günde maç bulunamadı.", cancellationToken: ct);
            return;
        }

        var metin = new StringBuilder("🔎 MAÇ ARAMA SONUÇLARI\n\n");
        foreach (var m in bulunan)
            metin.AppendLine($"🆔 {m.Id} | {Istanbul(m.MacTarihi):dd.MM HH:mm}\n{m.EvSahibiTakim.Ad} - {m.DeplasmanTakim.Ad}\n🏆 {m.Lig?.Ad ?? "-"}\n");

        var buttons = bulunan.Select(m => new[]
        {
            InlineKeyboardButton.WithCallbackData(
                $"🆔 {m.Id} • {Kisalt(m.EvSahibiTakim.Ad + " - " + m.DeplasmanTakim.Ad, 38)}",
                $"match_detail:{m.Id}")
        }).ToList();
        buttons.Add(new[] { InlineKeyboardButton.WithCallbackData("⬅️ Match Center", "match_date_menu") });

        await bot.SendMessage(chatId, metin.ToString(),
            replyMarkup: new InlineKeyboardMarkup(buttons), cancellationToken: ct);
    }

    private static bool KomutMu(string text, string komut) =>
        text.Equals(komut, StringComparison.OrdinalIgnoreCase) ||
        text.StartsWith(komut + " ", StringComparison.OrdinalIgnoreCase);

    private static string KomutParametresi(string text)
    {
        var index = text.IndexOf(' ');
        return index < 0 ? string.Empty : text[(index + 1)..].Trim();
    }

    private static string Normalize(string value)
    {
        var text = value.Trim().ToLower(new CultureInfo("tr-TR"));
        var sb = new StringBuilder(text.Length);
        foreach (var c in text.Normalize(NormalizationForm.FormD))
        {
            var category = CharUnicodeInfo.GetUnicodeCategory(c);
            if (category == UnicodeCategory.NonSpacingMark) continue;
            if (char.IsLetterOrDigit(c)) sb.Append(c == 'ı' ? 'i' : c);
        }
        return sb.ToString().Normalize(NormalizationForm.FormC);
    }

    private static DateTime Istanbul(DateTime utc)
    {
        var value = utc.Kind == DateTimeKind.Utc ? utc : DateTime.SpecifyKind(utc, DateTimeKind.Utc);
        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(value, "Turkey Standard Time");
    }

    private static int Yuzde(int sayi, int toplam) => toplam <= 0 ? 0 : (int)Math.Round(sayi * 100m / toplam);
    private static string Kisalt(string text, int max) => text.Length <= max ? text : text[..(max - 1)] + "…";
}
