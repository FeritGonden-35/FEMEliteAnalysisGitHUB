using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class TelegramMesajService
{
    private readonly ITelegramBotClient _botClient;

    public TelegramMesajService(ITelegramBotClient botClient)
    {
        _botClient = botClient;
    }

    public Task MesajGonderAsync(
        long chatId,
        string mesaj,
        CancellationToken cancellationToken)
    {
        return _botClient.SendMessage(
            chatId: chatId,
            text: mesaj,
            cancellationToken: cancellationToken);
    }
}
