using System.Text;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class CokluKuponTelegramService
{
    private readonly ICokluKuponTaslakService _taslakService;
    private readonly IKuponKaliciService _kaliciService;
    private readonly FemDbContext _dbContext;

    public CokluKuponTelegramService(
        ICokluKuponTaslakService taslakService,
        IKuponKaliciService kaliciService,
        FemDbContext dbContext)
    {
        _taslakService = taslakService;
        _kaliciService = kaliciService;
        _dbContext = dbContext;
    }

    public async Task KuponaEkleAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        int analizId, string market, CancellationToken cancellationToken)
    {
        var analiz = await _dbContext.Analizler.AsNoTracking()
            .Include(x => x.Mac).ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac).ThenInclude(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(x => x.Id == analizId, cancellationToken);

        if (analiz is null)
        {
            await botClient.SendMessage(chatId, "❌ Analiz bulunamadı.", cancellationToken: cancellationToken);
            return;
        }

        var sonuc = _taslakService.MacEkle(adminTelegramId, new CokluKuponMacSecimiDto
        {
            AnalizId = analiz.Id,
            MacId = analiz.MacId,
            EvSahibi = analiz.Mac.EvSahibiTakim.Ad,
            Deplasman = analiz.Mac.DeplasmanTakim.Ad,
            SecilenMarket = market,
            GuvenPuani = analiz.GuvenPuani
        });

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(chatId, $"❌ {sonuc.Mesaj}", cancellationToken: cancellationToken);
            return;
        }

        var uyari = analiz.GuvenPuani < 50
            ? "\n⚠️ Bu analizin güven puanı düşük. Kuponu kaydetmeden önce tekrar değerlendir."
            : string.Empty;

        await botClient.SendMessage(chatId,
            $"✅ {sonuc.Mesaj}\n\n⚽ {analiz.Mac.EvSahibiTakim.Ad} - {analiz.Mac.DeplasmanTakim.Ad}\n" +
            $"🎯 Market: {market}\n📊 Güven: %{analiz.GuvenPuani}\n\n" +
            $"Kupondaki maç: {sonuc.Veri.Maclar.Count}/5{uyari}\n\nKuponu görmek: /kuponum",
            cancellationToken: cancellationToken);
    }

    public Task KuponuGonderAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var sonuc = _taslakService.TaslagiGetir(adminTelegramId);
        if (!sonuc.Basarili || sonuc.Veri is null || sonuc.Veri.Maclar.Count == 0)
            return botClient.SendMessage(chatId, "📭 Kupon taslağı boş.\n\n/kuponaekle ANALIZ_ID MARKET",
                cancellationToken: cancellationToken);

        return botClient.SendMessage(chatId, TaslakMetni(sonuc.Veri, false), cancellationToken: cancellationToken);
    }

    public async Task KuponuKaydetAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        string? baslik, CancellationToken cancellationToken)
    {
        var taslakSonucu = _taslakService.TaslagiGetir(adminTelegramId);
        if (!taslakSonucu.Basarili || taslakSonucu.Veri is null || taslakSonucu.Veri.Maclar.Count == 0)
        {
            await botClient.SendMessage(chatId, "❌ Kaydedilecek kupon taslağı bulunmuyor.", cancellationToken: cancellationToken);
            return;
        }

        var dusukler = taslakSonucu.Veri.Maclar.Where(x => x.GuvenPuani < 50).ToList();
        var sonuc = await _kaliciService.KaydetAsync(adminTelegramId, taslakSonucu.Veri, baslik, cancellationToken);
        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(chatId, $"❌ {sonuc.Mesaj}", cancellationToken: cancellationToken);
            return;
        }

        _taslakService.Temizle(adminTelegramId);
        var uyari = dusukler.Count > 0 ? $"\n⚠️ {dusukler.Count} seçim %50 altında güven puanına sahip." : string.Empty;
        await botClient.SendMessage(chatId,
            $"✅ Kupon SQL'e kaydedildi.\nKupon ID: {sonuc.Veri.Id}\nMaç: {sonuc.Veri.Maclar.Count}\n" +
            $"Ortalama güven: %{sonuc.Veri.OrtalamaGuvenPuani}\nRisk: {sonuc.Veri.RiskSeviyesi}{uyari}\n\n" +
            $"Önizleme: /kupononizle {sonuc.Veri.Id}\n" +
            $"VIP yayın: /kuponyayinla {sonuc.Veri.Id}", cancellationToken: cancellationToken);
    }

    public async Task KuponlariListeleAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _kaliciService.ListeleAsync(adminTelegramId, cancellationToken);
        if (!sonuc.Basarili || sonuc.Veri is null || sonuc.Veri.Count == 0)
        {
            await botClient.SendMessage(chatId, "📭 Kayıtlı kupon bulunmuyor.", cancellationToken: cancellationToken);
            return;
        }

        var sb = new StringBuilder("📚 KAYITLI KUPONLAR\n\n");
        foreach (var k in sonuc.Veri)
            sb.AppendLine($"🎫 #{k.Id} — {k.Baslik}\n{k.Maclar.Count} maç | Güven %{k.OrtalamaGuvenPuani} | {k.RiskSeviyesi}\n/kuponhazir {k.Id}\n");
        await botClient.SendMessage(chatId, sb.ToString(), cancellationToken: cancellationToken);
    }

    public async Task HazirMetniGonderAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        int kuponId, CancellationToken cancellationToken)
    {
        var sonuc = await _kaliciService.GetirAsync(kuponId, adminTelegramId, cancellationToken);
        await botClient.SendMessage(chatId,
            sonuc.Basarili && sonuc.Veri is not null ? sonuc.Veri.YayinMetni ?? "Yayın metni bulunamadı." : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    public async Task KupondanCikarAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        int analizId, CancellationToken cancellationToken)
    {
        var sonuc = _taslakService.MacCikar(adminTelegramId, analizId);
        await botClient.SendMessage(chatId,
            sonuc.Basarili ? $"✅ {sonuc.Mesaj}\nKalan maç: {sonuc.Veri?.Maclar.Count ?? 0}" : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    public Task KuponuTemizleAsync(ITelegramBotClient botClient, long chatId, long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var sonuc = _taslakService.Temizle(adminTelegramId);
        return botClient.SendMessage(chatId, sonuc.Basarili ? "✅ Kupon taslağı tamamen temizlendi." : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    private static string TaslakMetni(CokluKuponTaslakDto taslak, bool yayin)
    {
        var sb = new StringBuilder(yayin ? "🎫 FEM ELITE KUPONU\n\n" : "🎫 FEM ELITE KUPON TASLAĞI\n\n");
        var sira = 1;
        foreach (var mac in taslak.Maclar)
        {
            sb.AppendLine($"{sira++}️⃣ {mac.EvSahibi} - {mac.Deplasman}");
            sb.AppendLine($"🎯 {mac.SecilenMarket}");
            sb.AppendLine($"📊 Güven: %{mac.GuvenPuani}\n");
        }
        sb.AppendLine($"📦 Maç sayısı: {taslak.Maclar.Count}/5");
        sb.AppendLine($"🎯 Ortalama güven: %{taslak.OrtalamaGuvenPuani}");
        sb.AppendLine($"🛡️ Kupon riski: {taslak.RiskSeviyesi}");
        sb.AppendLine("\nKaydetmek: /kuponukaydet [BAŞLIK]\nÇıkarmak: /kupondancikar ANALIZ_ID\nTemizlemek: /kuponutemizle");
        return sb.ToString();
    }
}
