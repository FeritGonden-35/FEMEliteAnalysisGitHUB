using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class KuponPerformansTelegramService
{
    private readonly IKuponPerformansService _service;
    public KuponPerformansTelegramService(IKuponPerformansService service) => _service = service;

    public async Task GonderAsync(ITelegramBotClient bot, long chatId, long adminTelegramId, int gun, string mod, CancellationToken ct)
    {
        var sonuc = await _service.GetirAsync(adminTelegramId, gun, ct);
        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await bot.SendMessage(chatId, $"❌ {sonuc.Mesaj}", cancellationToken: ct); return;
        }
        var x = sonuc.Veri;
        var sb = new StringBuilder();
        if (mod == "market")
        {
            sb.AppendLine($"🎯 MARKET PERFORMANSI — SON {gun} GÜN\n");
            foreach (var m in x.Marketler.Take(15))
                sb.AppendLine($"• {m.Market}: {m.Kazanan}/{m.Toplam} ✅ %{m.BasariYuzdesi:0.0}");
        }
        else if (mod == "sonuc")
        {
            sb.AppendLine($"🎫 KUPON SONUÇLARI — SON {gun} GÜN\n");
            sb.AppendLine($"✅ Kazanan: {x.KazananKupon}");
            sb.AppendLine($"❌ Kaybeden: {x.KaybedenKupon}");
            sb.AppendLine($"⏳ Bekleyen: {x.BekleyenKupon}");
            sb.AppendLine($"📈 Sonuçlanan başarı: %{x.KuponBasariYuzdesi:0.0}\n");
            foreach (var b in x.OranBantlari)
                sb.AppendLine($"• {b.Bant} oran: {b.Kazanan}/{b.Toplam} — %{b.BasariYuzdesi:0.0}");
            sb.AppendLine("\n🧾 SON KUPONLAR");
            foreach (var k in x.SonKuponlar.Take(10))
                sb.AppendLine($"#{k.KuponId} {(k.ToplamOran.HasValue ? k.ToplamOran.Value.ToString("0.00") + " oran" : "oran -")} | {k.Sonuc} | ✅{k.KazananSecim} ❌{k.KaybedenSecim} ⏳{k.BekleyenSecim}");
        }
        else
        {
            sb.AppendLine($"📊 FEM ELITE PERFORMANS — SON {gun} GÜN\n");
            sb.AppendLine($"🎫 Kupon: {x.ToplamKupon} | ✅ {x.KazananKupon} | ❌ {x.KaybedenKupon} | ⏳ {x.BekleyenKupon}");
            sb.AppendLine($"🏆 Kupon başarı: %{x.KuponBasariYuzdesi:0.0}");
            sb.AppendLine($"🎯 Seçim: {x.ToplamSecim} | ✅ {x.KazananSecim} | ❌ {x.KaybedenSecim} | ⏳ {x.BekleyenSecim}");
            sb.AppendLine($"📈 Seçim başarı: %{x.SecimBasariYuzdesi:0.0}\n");
            sb.AppendLine("🔥 EN ÇOK OYNANAN MARKETLER");
            foreach (var m in x.Marketler.Take(8))
                sb.AppendLine($"• {m.Market}: {m.Kazanan}/{m.Toplam} — %{m.BasariYuzdesi:0.0}");
        }
        await bot.SendMessage(chatId, sb.ToString().Trim(), cancellationToken: ct);
    }
}
