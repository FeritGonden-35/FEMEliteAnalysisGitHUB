using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class HistoricalImportTelegramService
{
    private const int TelegramGuvenliLimit = 3500;

    private readonly IHistoricalImportService _service;

    public HistoricalImportTelegramService(
        IHistoricalImportService service)
    {
        _service = service;
    }

    public async Task ImportAsync(
        ITelegramBotClient bot,
        long chatId,
        CancellationToken cancellationToken)
    {
        await bot.SendMessage(
            chatId: chatId,
            text:
                "⏳ Geçmiş CSV aktarımı başladı.\n" +
                "Dosya miktarına göre birkaç dakika sürebilir.",
            cancellationToken: cancellationToken);

        var sonuc = await _service.InboxAktarAsync(
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await bot.SendMessage(
                chatId: chatId,
                text: $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);

            return;
        }

        var dosyalar = sonuc.Veri;

        var ozet = new StringBuilder();

        ozet.AppendLine("✅ GEÇMİŞ VERİ AKTARIMI TAMAMLANDI");
        ozet.AppendLine();
        ozet.AppendLine($"Toplam dosya: {dosyalar.Count}");
        ozet.AppendLine($"Başarılı: {dosyalar.Count(x => x.Basarili)}");
        ozet.AppendLine($"Başarısız: {dosyalar.Count(x => !x.Basarili)}");
        ozet.AppendLine($"Okunan satır: {dosyalar.Sum(x => x.OkunanSatir)}");
        ozet.AppendLine($"Eklenen maç: {dosyalar.Sum(x => x.EklenenMac)}");
        ozet.AppendLine($"Güncellenen maç: {dosyalar.Sum(x => x.GuncellenenMac)}");
        ozet.AppendLine($"Yeni takım: {dosyalar.Sum(x => x.YeniTakim)}");
        ozet.AppendLine($"Yeni lig: {dosyalar.Sum(x => x.YeniLig)}");
        ozet.AppendLine($"Alias eşleşmesi: {dosyalar.Sum(x => x.AliasEslesmesi)}");
        ozet.AppendLine($"Atlanan satır: {dosyalar.Sum(x => x.AtlananSatir)}");

        await bot.SendMessage(
            chatId: chatId,
            text: ozet.ToString(),
            cancellationToken: cancellationToken);

        var detaySatirlari = new List<string>();

        foreach (var x in dosyalar)
        {
            var durum = x.Basarili
                ? "✅"
                : $"❌ {x.Mesaj}";

            detaySatirlari.Add(
                $"📄 {x.DosyaAdi}\n" +
                $"Okunan: {x.OkunanSatir} | " +
                $"Eklenen: {x.EklenenMac} | " +
                $"Güncellenen: {x.GuncellenenMac}\n" +
                $"Yeni takım: {x.YeniTakim} | " +
                $"Yeni lig: {x.YeniLig} | " +
                $"Atlanan: {x.AtlananSatir}\n" +
                $"Durum: {durum}\n" +
                "────────────\n");
        }

        await ParcalariGonderAsync(
            bot,
            chatId,
            "📋 DOSYA DETAYLARI",
            detaySatirlari,
            cancellationToken);
    }

    public async Task DurumAsync(
        ITelegramBotClient bot,
        long chatId,
        CancellationToken cancellationToken)
    {
        var x = _service.DurumGetir();

        var metin =
            "📚 HISTORICAL DATA DURUMU\n\n" +
            $"Durum: {(x.CalisiyorMu ? "🟡 Çalışıyor" : "🟢 Beklemede")}\n" +
            $"Son başlangıç: {Tarih(x.SonBaslama)}\n" +
            $"Son bitiş: {Tarih(x.SonBitis)}\n" +
            $"Son mesaj: {x.SonMesaj}";

        await bot.SendMessage(
            chatId: chatId,
            text: metin,
            cancellationToken: cancellationToken);
    }

    public async Task DosyalarAsync(
        ITelegramBotClient bot,
        long chatId,
        CancellationToken cancellationToken)
    {
        var dosyalar = _service
            .BekleyenDosyalariGetir();

        if (dosyalar.Count == 0)
        {
            await bot.SendMessage(
                chatId: chatId,
                text:
                    "📂 HistoricalData/Inbox klasöründe " +
                    "bekleyen CSV dosyası bulunamadı.",
                cancellationToken: cancellationToken);

            return;
        }

        var satirlar = dosyalar
            .Select(x => $"• {x}\n")
            .ToList();

        await ParcalariGonderAsync(
            bot,
            chatId,
            $"📂 BEKLEYEN HISTORICAL CSV DOSYALARI\nToplam: {dosyalar.Count}",
            satirlar,
            cancellationToken,
            "Aktarımı başlatmak için: /historikimport");
    }

    private static async Task ParcalariGonderAsync(
        ITelegramBotClient bot,
        long chatId,
        string anaBaslik,
        IReadOnlyCollection<string> satirlar,
        CancellationToken cancellationToken,
        string? altBilgi = null)
    {
        var parcalar = new List<string>();
        var mevcut = new StringBuilder();

        mevcut.AppendLine(anaBaslik);
        mevcut.AppendLine();

        foreach (var satir in satirlar)
        {
            if (mevcut.Length + satir.Length >
                TelegramGuvenliLimit)
            {
                parcalar.Add(
                    mevcut.ToString().Trim());

                mevcut.Clear();
                mevcut.AppendLine($"{anaBaslik} — DEVAM");
                mevcut.AppendLine();
            }

            mevcut.Append(satir);
        }

        if (!string.IsNullOrWhiteSpace(altBilgi))
        {
            if (mevcut.Length + altBilgi.Length + 4 >
                TelegramGuvenliLimit)
            {
                parcalar.Add(
                    mevcut.ToString().Trim());

                mevcut.Clear();
                mevcut.AppendLine($"{anaBaslik} — SON");
                mevcut.AppendLine();
            }

            mevcut.AppendLine();
            mevcut.AppendLine(altBilgi);
        }

        if (mevcut.Length > 0)
        {
            parcalar.Add(
                mevcut.ToString().Trim());
        }

        for (var i = 0; i < parcalar.Count; i++)
        {
            var sayfaBasligi =
                $"Sayfa {i + 1}/{parcalar.Count}\n\n";

            await bot.SendMessage(
                chatId: chatId,
                text: sayfaBasligi + parcalar[i],
                cancellationToken: cancellationToken);

            await Task.Delay(
                200,
                cancellationToken);
        }
    }

    private static string Tarih(
        DateTime? value)
    {
        return value.HasValue
            ? value.Value
                .ToLocalTime()
                .ToString("dd.MM.yyyy HH:mm:ss")
            : "-";
    }
}