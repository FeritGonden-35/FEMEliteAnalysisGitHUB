using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class KuponYayinTelegramService
{
    private readonly IKuponYayinService _yayinService;
    private readonly TelegramOptions _options;
    private readonly ILogger<KuponYayinTelegramService> _logger;

    public KuponYayinTelegramService(
        IKuponYayinService yayinService,
        IOptions<TelegramOptions> options,
        ILogger<KuponYayinTelegramService> logger)
    {
        _yayinService = yayinService;
        _options = options.Value;
        _logger = logger;
    }

    public async Task OnizlemeGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        int kuponId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _yayinService.OnizlemeGetirAsync(
            kuponId,
            adminTelegramId,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await HataGonderAsync(
                botClient,
                chatId,
                sonuc.Mesaj,
                cancellationToken);
            return;
        }

        var veri = sonuc.Veri;
        var durum = veri.DahaOnceYayinlandiMi
            ? $"\n\n⚠️ Bu kupon daha önce yayınlandı: {TarihYaz(veri.YayinlanmaTarihi)}"
            : string.Empty;

        await botClient.SendMessage(
            chatId: chatId,
            text:
                "👁️ VIP YAYIN ÖNİZLEMESİ\n\n" +
                veri.VipMetni +
                durum +
                $"\n\nYayınlamak için:\n/kuponyayinla {kuponId}",
            cancellationToken: cancellationToken);
    }

    public async Task TwitterMetniGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        int kuponId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _yayinService.OnizlemeGetirAsync(
            kuponId,
            adminTelegramId,
            cancellationToken);

        await botClient.SendMessage(
            chatId: chatId,
            text: sonuc.Basarili && sonuc.Veri is not null
                ? "🐦 X / TWITTER METNİ\n\n" + sonuc.Veri.TwitterMetni
                : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    public async Task YayinlaAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        int kuponId,
        CancellationToken cancellationToken)
    {
        if (!_options.VipChannelId.HasValue)
        {
            await HataGonderAsync(
                botClient,
                chatId,
                "Telegram:VipChannelId ayarı bulunmuyor.",
                cancellationToken);
            return;
        }

        var onizlemeSonucu = await _yayinService.OnizlemeGetirAsync(
            kuponId,
            adminTelegramId,
            cancellationToken);

        if (!onizlemeSonucu.Basarili || onizlemeSonucu.Veri is null)
        {
            await HataGonderAsync(
                botClient,
                chatId,
                onizlemeSonucu.Mesaj,
                cancellationToken);
            return;
        }

        if (onizlemeSonucu.Veri.DahaOnceYayinlandiMi)
        {
            await HataGonderAsync(
                botClient,
                chatId,
                $"Bu kupon daha önce yayınlandı: {TarihYaz(onizlemeSonucu.Veri.YayinlanmaTarihi)}",
                cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: "⏳ Kupon VIP kanalına yayınlanıyor...",
            cancellationToken: cancellationToken);

        try
        {
            await botClient.SendMessage(
                chatId: _options.VipChannelId.Value,
                text: onizlemeSonucu.Veri.VipMetni,
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Kupon VIP kanalına gönderilemedi. KuponId: {KuponId}",
                kuponId);

            await HataGonderAsync(
                botClient,
                chatId,
                "Kupon VIP kanalına gönderilemedi. Botun kanalda admin olduğundan ve kanal ID'sinin doğru olduğundan emin olun.",
                cancellationToken);
            return;
        }

        var ucretsizDurumu = "Ücretsiz kanal ayarlanmadığı için duyuru gönderilmedi.";

        if (_options.FreeChannelId.HasValue)
        {
            try
            {
                await botClient.SendMessage(
                    chatId: _options.FreeChannelId.Value,
                    text: onizlemeSonucu.Veri.UcretsizKanalMetni,
                    cancellationToken: cancellationToken);

                ucretsizDurumu = "Ücretsiz kanala kısa duyuru gönderildi.";
            }
            catch (Exception ex)
            {
                _logger.LogWarning(
                    ex,
                    "Ücretsiz kanal duyurusu gönderilemedi. KuponId: {KuponId}",
                    kuponId);

                ucretsizDurumu = "VIP yayını başarılı; ücretsiz kanal duyurusu gönderilemedi.";
            }
        }

        var isaretSonucu = await _yayinService.YayinlandiOlarakIsaretleAsync(
            kuponId,
            adminTelegramId,
            cancellationToken);

        if (!isaretSonucu.Basarili)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text:
                    "⚠️ Kupon kanala gönderildi fakat veritabanında yayınlandı olarak işaretlenemedi.\n" +
                    isaretSonucu.Mesaj,
                cancellationToken: cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId: chatId,
            text:
                "✅ KUPON YAYINLANDI\n\n" +
                $"Kupon ID: {kuponId}\n" +
                "VIP kanalı: Başarılı\n" +
                $"Ücretsiz kanal: {ucretsizDurumu}\n\n" +
                $"X/Twitter metni için:\n/twittermetni {kuponId}",
            cancellationToken: cancellationToken);
    }

    private static string TarihYaz(DateTime? tarih)
    {
        if (!tarih.HasValue)
            return "Bilinmiyor";

        var utc = tarih.Value.Kind == DateTimeKind.Utc
            ? tarih.Value
            : DateTime.SpecifyKind(tarih.Value, DateTimeKind.Utc);

        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                utc,
                "Turkey Standard Time")
            .ToString("dd.MM.yyyy HH:mm");
    }

    private static Task HataGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        string mesaj,
        CancellationToken cancellationToken)
    {
        return botClient.SendMessage(
            chatId: chatId,
            text: $"❌ {mesaj}",
            cancellationToken: cancellationToken);
    }
}
