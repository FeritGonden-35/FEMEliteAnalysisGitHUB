using FEMEliteAnalysis.Api.Bot.Moderation;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class ModerasyonTelegramService
{
    private readonly ModerasyonOptions _options;
    private readonly ModerasyonDurumStore _store;
    private readonly ModerasyonAnalizService _analiz;
    private readonly ILogger<ModerasyonTelegramService> _logger;

    public ModerasyonTelegramService(
        IOptions<ModerasyonOptions> options,
        ModerasyonDurumStore store,
        ModerasyonAnalizService analiz,
        ILogger<ModerasyonTelegramService> logger)
    {
        _options = options.Value;
        _store = store;
        _analiz = analiz;
        _logger = logger;
    }

    public async Task<bool> MesajiDenetleAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        if (message.Chat.Type is not ChatType.Group and not ChatType.Supergroup)
            return false;

        if (!_options.TumGruplardaCalis && !_options.GrupIdleri.Contains(message.Chat.Id))
            return false;

        if (!_store.GrupAktifMi(message.Chat.Id, _options.Aktif))
            return false;

        if (message.From is null || message.From.IsBot)
            return false;

        if (await AdminMiAsync(botClient, message.Chat.Id, message.From.Id, cancellationToken))
            return false;

        var metin = (message.Text ?? message.Caption ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(metin))
            return false;

        var durum = _store.KullaniciGetir(message.Chat.Id, message.From.Id);
        ModerasyonKarari karar;

        lock (durum.Kilit)
        {
            var simdi = DateTime.UtcNow;
            durum.MesajZamanlari.RemoveAll(x => x < simdi.AddSeconds(-_options.SpamPencereSaniye));
            durum.MesajZamanlari.Add(simdi);

            if (durum.MesajZamanlari.Count >= _options.SpamMesajLimiti)
            {
                karar = new ModerasyonKarari
                {
                    IhlalVarMi = true,
                    Tur = ModerasyonIhlalTuru.Spam,
                    Sebep = "Kısa sürede çok fazla mesaj"
                };
            }
            else
            {
                var normalizeMetin = _analiz.TekrarKontrolMetni(metin);
                durum.SonMesajlar.RemoveAll(x => x.Zaman < simdi.AddSeconds(-_options.TekrarPencereSaniye));
                durum.SonMesajlar.Add((simdi, normalizeMetin));

                var tekrar = durum.SonMesajlar.Count(x => x.Metin == normalizeMetin);
                karar = tekrar >= _options.AyniMesajLimiti
                    ? new ModerasyonKarari
                    {
                        IhlalVarMi = true,
                        Tur = ModerasyonIhlalTuru.TekrarMesaj,
                        Sebep = "Aynı mesajın tekrarlanması"
                    }
                    : _analiz.AnalizEt(metin);
            }

            if (karar.IhlalVarMi)
                durum.ToplamIhlal++;
        }

        if (!karar.IhlalVarMi)
            return false;

        await GuvenliMesajSilAsync(botClient, message, cancellationToken);
        await CezaUygulaAsync(botClient, message, karar, durum.ToplamIhlal, cancellationToken);
        return true;
    }

    public bool GrupAktifMi(long chatId)
        => _store.GrupAktifMi(chatId, _options.Aktif);

    public void GrupDurumunuAyarla(long chatId, bool aktif)
        => _store.GrupDurumunuAyarla(chatId, aktif);

    private async Task CezaUygulaAsync(
        ITelegramBotClient botClient,
        Message message,
        ModerasyonKarari karar,
        int ihlalSayisi,
        CancellationToken cancellationToken)
    {
        var userId = message.From!.Id;
        var ad = KullaniciAdi(message.From);
        string islem;

        try
        {
            if (ihlalSayisi >= 5)
            {
                await botClient.BanChatMember(
                    chatId: message.Chat.Id,
                    userId: userId,
                    revokeMessages: true,
                    cancellationToken: cancellationToken);
                islem = "Gruptan yasaklandı";
            }
            else if (ihlalSayisi >= 2)
            {
                var dakika = ihlalSayisi switch
                {
                    2 => 10,
                    3 => 60,
                    _ => 1440
                };

                var permissions = new ChatPermissions
                {
                    CanSendMessages = false,
                    CanSendAudios = false,
                    CanSendDocuments = false,
                    CanSendPhotos = false,
                    CanSendVideos = false,
                    CanSendVideoNotes = false,
                    CanSendVoiceNotes = false,
                    CanSendPolls = false,
                    CanSendOtherMessages = false,
                    CanAddWebPagePreviews = false,
                    CanChangeInfo = false,
                    CanInviteUsers = false,
                    CanPinMessages = false,
                    CanManageTopics = false
                };

                await botClient.RestrictChatMember(
                    chatId: message.Chat.Id,
                    userId: userId,
                    permissions: permissions,
                    untilDate: DateTime.UtcNow.AddMinutes(dakika),
                    cancellationToken: cancellationToken);

                islem = $"{dakika} dakika susturuldu";
            }
            else
            {
                islem = "Uyarıldı";
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Telegram moderasyon cezası uygulanamadı.");
            islem = "Mesaj silindi; ceza uygulanamadı (bot yetkilerini kontrol edin)";
        }

        var uyari =
            $"⚠️ {ad}\n" +
            $"Sebep: {karar.Sebep}\n" +
            $"İhlal: {ihlalSayisi}/5\n" +
            $"İşlem: {islem}";

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: uyari,
            cancellationToken: cancellationToken);

        if (_options.LogChatId.HasValue && _options.LogChatId.Value != message.Chat.Id)
        {
            await botClient.SendMessage(
                chatId: _options.LogChatId.Value,
                text:
                    "🚨 MODERASYON LOGU\n\n" +
                    $"Grup: {message.Chat.Title ?? message.Chat.Id.ToString()}\n" +
                    $"Kullanıcı: {ad} ({userId})\n" +
                    $"Sebep: {karar.Sebep}\n" +
                    $"İşlem: {islem}",
                cancellationToken: cancellationToken);
        }
    }

    private static async Task<bool> AdminMiAsync(
        ITelegramBotClient botClient,
        long chatId,
        long userId,
        CancellationToken cancellationToken)
    {
        try
        {
            var member = await botClient.GetChatMember(chatId, userId, cancellationToken);
            return member.Status is ChatMemberStatus.Administrator or ChatMemberStatus.Creator;
        }
        catch
        {
            return false;
        }
    }

    private static async Task GuvenliMesajSilAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        try
        {
            await botClient.DeleteMessage(message.Chat.Id, message.Id, cancellationToken);
        }
        catch
        {
            // Botun silme yetkisi yoksa ceza/uyarı akışı yine devam eder.
        }
    }

    private static string KullaniciAdi(User user)
        => string.IsNullOrWhiteSpace(user.Username)
            ? user.FirstName
            : $"@{user.Username}";
}
