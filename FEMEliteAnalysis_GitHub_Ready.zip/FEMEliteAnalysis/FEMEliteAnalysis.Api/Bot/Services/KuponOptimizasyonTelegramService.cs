using System.Text;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class KuponOptimizasyonTelegramService
{
    private readonly IKuponOptimizasyonService _service;

    public KuponOptimizasyonTelegramService(
        IKuponOptimizasyonService service)
    {
        _service = service;
    }

    public async Task OptimizeGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        int? hedefMacSayisi,
        CancellationToken cancellationToken)
    {
        var sonuc = await _service.OptimizeEtAsync(
            adminTelegramId,
            hedefMacSayisi,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId,
                $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId,
            OptimizasyonMetni(sonuc.Veri),
            cancellationToken: cancellationToken);
    }

    public async Task OtomatikUygulaAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        int hedefMacSayisi,
        CancellationToken cancellationToken)
    {
        if (hedefMacSayisi is < 1 or > 5)
        {
            await botClient.SendMessage(
                chatId,
                "Kullanım: /kuponotomatik 1-5",
                cancellationToken: cancellationToken);
            return;
        }

        var sonuc = await _service.OnerilenKuponuUygulaAsync(
            adminTelegramId,
            hedefMacSayisi,
            cancellationToken);

        await botClient.SendMessage(
            chatId,
            sonuc.Basarili
                ? $"✅ {sonuc.Mesaj}\n\nYeni taslağı görmek: /kuponum"
                : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    public async Task KritikGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _service.OptimizeEtAsync(
            adminTelegramId,
            null,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId,
                $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var sb = new StringBuilder("🧪 KUPON ELEŞTİRİ MOTORU\n\n");
        if (sonuc.Veri.Kritikler.Count == 0)
        {
            sb.AppendLine("✅ Belirgin kritik risk bulunmadı.");
        }
        else
        {
            foreach (var kritik in sonuc.Veri.Kritikler)
                sb.AppendLine($"• {kritik}");
        }

        await botClient.SendMessage(
            chatId,
            sb.ToString(),
            cancellationToken: cancellationToken);
    }

    public async Task AlternatifGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _service.OptimizeEtAsync(
            adminTelegramId,
            null,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId,
                $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var sb = new StringBuilder("🔀 ALTERNATİF KUPONLAR\n\n");
        var list = new List<KuponKombinasyonDto>();
        if (sonuc.Veri.OnerilenKupon is not null)
            list.Add(sonuc.Veri.OnerilenKupon);
        list.AddRange(sonuc.Veri.Alternatifler);

        foreach (var kombinasyon in list.Take(4))
        {
            sb.AppendLine($"#{kombinasyon.Sira} — {kombinasyon.Maclar.Count} maç");
            sb.AppendLine($"Optimizasyon: %{kombinasyon.OptimizasyonPuani} | Risk: {kombinasyon.RiskSeviyesi}");
            foreach (var mac in kombinasyon.Maclar)
                sb.AppendLine($"• {mac.EvSahibi} - {mac.Deplasman}: {mac.Market}");
            sb.AppendLine();
        }

        await botClient.SendMessage(
            chatId,
            sb.ToString(),
            cancellationToken: cancellationToken);
    }

    private static string OptimizasyonMetni(
        KuponOptimizasyonSonucDto sonuc)
    {
        var sb = new StringBuilder("🧠 KUPON OPTİMİZASYON MOTORU\n\n");
        sb.AppendLine("MEVCUT KUPON");
        sb.AppendLine($"Maç: {sonuc.MevcutMacSayisi}");
        sb.AppendLine($"Ortalama güven: %{sonuc.MevcutOrtalamaGuven}");
        sb.AppendLine($"Optimizasyon puanı: %{sonuc.MevcutOptimizasyonPuani}");
        sb.AppendLine($"Risk: {sonuc.MevcutRiskSeviyesi}");
        sb.AppendLine();

        if (sonuc.OnerilenKupon is not null)
        {
            sb.AppendLine("⭐ ÖNERİLEN KOMBİNASYON");
            sb.AppendLine($"Maç: {sonuc.OnerilenKupon.Maclar.Count}");
            sb.AppendLine($"Optimizasyon: %{sonuc.OnerilenKupon.OptimizasyonPuani}");
            sb.AppendLine($"Risk: {sonuc.OnerilenKupon.RiskSeviyesi}");

            foreach (var mac in sonuc.OnerilenKupon.Maclar)
            {
                sb.AppendLine(
                    $"• {mac.EvSahibi} - {mac.Deplasman}\n" +
                    $"  {mac.Market} | Ham %{mac.HamGuvenPuani} | Düzeltilmiş %{mac.DuzenlenmisGuvenPuani}");
            }
        }

        if (sonuc.EnZayifSecim is not null)
        {
            sb.AppendLine();
            sb.AppendLine("⚠️ EN ZAYIF SEÇİM");
            sb.AppendLine(
                $"{sonuc.EnZayifSecim.EvSahibi} - {sonuc.EnZayifSecim.Deplasman}: " +
                $"{sonuc.EnZayifSecim.Market} (%{sonuc.EnZayifSecim.DuzenlenmisGuvenPuani})");
        }

        sb.AppendLine();
        sb.AppendLine("Uygulamak: /kuponotomatik MAÇ_SAYISI");
        sb.AppendLine("Alternatifler: /kuponalternatif");
        sb.AppendLine("Eleştiri: /kuponkritik");
        return sb.ToString();
    }
}
