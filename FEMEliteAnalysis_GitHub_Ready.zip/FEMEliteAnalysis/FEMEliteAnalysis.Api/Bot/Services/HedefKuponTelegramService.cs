using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class HedefKuponTelegramService
{
    private readonly IHedefKuponService _service;
    public HedefKuponTelegramService(IHedefKuponService service) => _service = service;

    public Task DusukOlusturAsync(ITelegramBotClient bot,long chatId,long adminTelegramId,CancellationToken ct)
        => Gonder(bot,chatId,adminTelegramId,"dusuk","🟢 DÜŞÜK ORAN KUPONU","2.00 - 4.00",ct);
    public Task OrtaOlusturAsync(ITelegramBotClient bot,long chatId,long adminTelegramId,CancellationToken ct)
        => Gonder(bot,chatId,adminTelegramId,"orta","🟠 ORTA ORAN KUPONU","4.00 - 12.00",ct);
    public Task YuksekOlusturAsync(ITelegramBotClient bot,long chatId,CancellationToken ct)
        => Gonder(bot,chatId,0,"yuksek","🔴 YÜKSEK ORAN KUPONU","12.00 - 500.00",ct,false);

    private async Task Gonder(ITelegramBotClient bot,long chatId,long adminTelegramId,string mod,string baslik,string aralik,CancellationToken ct,bool taslak=true)
    {
        var r = mod=="dusuk" ? await _service.DusukOlusturAsync(adminTelegramId,ct) : mod=="orta" ? await _service.OrtaOlusturAsync(adminTelegramId,ct) : await _service.YuksekOlusturAsync(adminTelegramId,ct);
        if(!r.Basarili||r.Veri is null){await bot.SendMessage(chatId,$"❌ {r.Mesaj}",cancellationToken:ct);return;}
        var k=r.Veri; var sb=new StringBuilder();
        sb.AppendLine(baslik); sb.AppendLine($"🎯 Oran aralığı: {aralik}"); sb.AppendLine($"🎫 Gerçek toplam oran: {k.ToplamOran:0.00}"); sb.AppendLine($"📊 Ortalama güven: %{k.OrtalamaGuven}"); sb.AppendLine();
        var i=1; foreach(var x in k.Secimler){sb.AppendLine($"{i++}️⃣ {x.EvSahibi} - {x.Deplasman}");sb.AppendLine($"🎯 {x.Market} @{x.Oran:0.00}");sb.AppendLine($"📊 Güven %{x.Guven} | Veri %{x.VeriKalitesi}");sb.AppendLine();}
        if(taslak && adminTelegramId>0){var u=await _service.TaslagaUygulaAsync(adminTelegramId,k);sb.AppendLine(u.Basarili?"✅ Kupon taslağına uygulandı. /kuponum":"⚠️ Kupon üretildi ancak taslağa uygulanamadı.");}
        else sb.AppendLine("✅ Kupon yalnız gerçek bookmaker oranlarıyla hesaplandı.");
        await bot.SendMessage(chatId,sb.ToString().Trim(),cancellationToken:ct);
    }
}
