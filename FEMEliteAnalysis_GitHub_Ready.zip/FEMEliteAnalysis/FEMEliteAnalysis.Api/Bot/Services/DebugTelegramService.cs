using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class DebugTelegramService
{
    private readonly IDebugService _debugService;

    public DebugTelegramService(
        IDebugService debugService)
    {
        _debugService = debugService;
    }

    public async Task MacDebugGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        int macId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _debugService.MacDebugGetirAsync(
            macId,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await HataGonderAsync(
                botClient,
                chatId,
                sonuc.Mesaj,
                cancellationToken);
            return;
        }

        var x = sonuc.Veri;

        var uyarilar = x.Uyarilar.Count == 0
            ? "Yok"
            : string.Join(
                "\n",
                x.Uyarilar.Select(u => $"• {u}"));

        var metin =
            $"🔍 FEM DEBUG\n\n" +
            $"Maç ID: {x.MacId}\n" +
            $"Maç: {x.MacAdi}\n" +
            $"Tarih: {x.MacTarihi.ToLocalTime():dd.MM.yyyy HH:mm}\n\n" +

            $"🏠 EV SAHİBİ\n" +
            $"Takım ID: {x.EvTakimId}\n" +
            $"Harici ID: {x.EvHariciTakimId?.ToString() ?? "NULL"}\n" +
            $"Genel form maçı: {x.EvGenelMacSayisi}\n" +
            $"İç saha maçı: {x.EvIcSahaMacSayisi}\n" +
            $"Son maç: " +
            $"{TarihYaz(x.EvSonMacTarihi)}\n\n" +

            $"✈️ DEPLASMAN\n" +
            $"Takım ID: {x.DepTakimId}\n" +
            $"Harici ID: {x.DepHariciTakimId?.ToString() ?? "NULL"}\n" +
            $"Genel form maçı: {x.DepGenelMacSayisi}\n" +
            $"Dış saha maçı: {x.DepDisSahaMacSayisi}\n" +
            $"Son maç: " +
            $"{TarihYaz(x.DepSonMacTarihi)}\n\n" +

            $"🤝 H2H: {x.H2HMacSayisi} maç\n" +
            $"📦 Veri kalitesi: %{x.VeriKalitesiPuani}\n\n" +
            $"⚠️ Uyarılar\n{uyarilar}";

        await botClient.SendMessage(
            chatId: chatId,
            text: metin,
            cancellationToken: cancellationToken);
    }

    public async Task TakimDebugGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        string takimAdi,
        CancellationToken cancellationToken)
    {
        var sonuc = await _debugService.TakimDebugGetirAsync(
            takimAdi,
            cancellationToken);

        await botClient.SendMessage(
            chatId: chatId,
            text: sonuc.Basarili && sonuc.Veri is not null
                ? $"🔍 TAKIM DEBUG\n\n{sonuc.Veri}"
                : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    public async Task H2HDebugGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        int macId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _debugService.H2HDebugGetirAsync(
            macId,
            cancellationToken);

        await botClient.SendMessage(
            chatId: chatId,
            text: sonuc.Basarili && sonuc.Veri is not null
                ? sonuc.Veri
                : $"❌ {sonuc.Mesaj}",
            cancellationToken: cancellationToken);
    }

    public async Task MarketDebugGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        int macId,
        CancellationToken cancellationToken)
    {
        var sonuc = await _debugService.MarketDebugGetirAsync(
            macId,
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await HataGonderAsync(
                botClient,
                chatId,
                sonuc.Mesaj,
                cancellationToken);
            return;
        }

        var analiz = sonuc.Veri;
        var metin = new StringBuilder();

        metin.AppendLine("📊 MARKET DEBUG");
        metin.AppendLine();
        metin.AppendLine(
            $"{analiz.EvSahibi} - {analiz.Deplasman}");
        metin.AppendLine(
            $"Veri kalitesi: %{analiz.VeriKalitesiPuani}");
        metin.AppendLine(
            $"Genel güven: %{analiz.GenelGuvenPuani}");
        metin.AppendLine(
            $"Risk: {analiz.GenelRiskSeviyesi}");
        metin.AppendLine();

        foreach (var market in analiz.Marketler
                     .OrderByDescending(x => x.GuvenPuani))
        {
            metin.AppendLine(
                $"{market.Kod}: %{market.GuvenPuani} " +
                $"({market.RiskSeviyesi})");
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: metin.ToString(),
            cancellationToken: cancellationToken);
    }

    private static string TarihYaz(DateTime? tarih)
    {
        return tarih.HasValue
            ? tarih.Value.ToLocalTime()
                .ToString("dd.MM.yyyy HH:mm")
            : "Bulunamadı";
    }

    private static Task HataGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        string mesaj,
        CancellationToken cancellationToken)
    {
        return botClient.SendMessage(
            chatId: chatId,
            text: $"❌ {mesaj}",
            cancellationToken: cancellationToken);
    }
}
