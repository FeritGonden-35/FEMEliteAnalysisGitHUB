using System.Text;
using FEMEliteAnalysis.Api.BackgroundServices;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Services;
using Microsoft.EntityFrameworkCore;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class HistoricalPoolTelegramService
{
    public static readonly string[] VarsayilanLigler =
    [
        "E0", "E1", "E2", "E3",
        "SC0", "SC1", "SC2", "SC3",
        "D1", "D2", "SP1", "SP2",
        "I1", "I2", "F1", "F2",
        "N1", "P1", "B1", "T1", "G1"
    ];

    private readonly HistoricalPoolQueue _queue;
    private readonly HistoricalPoolStatusStore _status;
    private readonly FemDbContext _db;

    public HistoricalPoolTelegramService(
        HistoricalPoolQueue queue,
        HistoricalPoolStatusStore status,
        FemDbContext db)
    {
        _queue = queue;
        _status = status;
        _db = db;
    }

    public async Task BaslatAsync(
        ITelegramBotClient bot,
        long chatId,
        string baslangic,
        string bitis,
        CancellationToken cancellationToken)
    {
        List<string> sezonlar;
        try
        {
            sezonlar = HistoricalPoolBackgroundService.SezonAraligi(baslangic, bitis);
        }
        catch (Exception ex)
        {
            await bot.SendMessage(chatId, $"❌ {ex.Message}", cancellationToken: cancellationToken);
            return;
        }

        var durum = _status.Getir();
        if (durum.CalisiyorMu)
        {
            await bot.SendMessage(chatId, "⚠️ Bir veri havuzu aktarımı zaten çalışıyor.", cancellationToken: cancellationToken);
            return;
        }

        if (!_status.Baslat(sezonlar.First(), sezonlar.Last(), sezonlar.Count, VarsayilanLigler.Length))
        {
            await bot.SendMessage(chatId, "⚠️ Aktarım başlatılamadı; başka işlem çalışıyor.", cancellationToken: cancellationToken);
            return;
        }

        if (!_queue.Ekle(new HistoricalPoolRequest(sezonlar.First(), sezonlar.Last(), VarsayilanLigler)))
        {
            _status.Bitir("Aktarım kuyruğa eklenemedi.", "Kuyruk dolu.");
            await bot.SendMessage(chatId, "❌ Aktarım kuyruğu dolu.", cancellationToken: cancellationToken);
            return;
        }

        await bot.SendMessage(
            chatId,
            "🚀 TARİHSEL VERİ HAVUZU BAŞLATILDI\n\n" +
            $"Sezon: {sezonlar.First()} - {sezonlar.Last()}\n" +
            $"Toplam sezon: {sezonlar.Count}\n" +
            $"Lig sayısı: {VarsayilanLigler.Length}\n\n" +
            "İşlem arka planda çalışır. Durum: /havuzdurum",
            cancellationToken: cancellationToken);
    }

    public Task DurumAsync(ITelegramBotClient bot, long chatId, CancellationToken cancellationToken)
    {
        var x = _status.Getir();
        var yuzde = x.ToplamSezon == 0 ? 0 : Math.Round(x.IslenenSezon * 100d / x.ToplamSezon, 1);
        var metin =
            "📦 TARİHSEL VERİ HAVUZU DURUMU\n\n" +
            $"Durum: {(x.CalisiyorMu ? "🟡 Çalışıyor" : "🟢 Beklemede")}\n" +
            $"İlerleme: %{yuzde} ({x.IslenenSezon}/{x.ToplamSezon} sezon)\n" +
            $"Lig: {x.ToplamLig}\n" +
            $"Başarılı aktarım: {x.BasariliAktarim}\n" +
            $"Başarısız aktarım: {x.BasarisizAktarim}\n" +
            $"Eklenen maç: {x.EklenenMac}\n" +
            $"Güncellenen maç: {x.GuncellenenMac}\n" +
            $"Son işlem: {x.SonIslem}" +
            (string.IsNullOrWhiteSpace(x.SonHata) ? "" : $"\nSon uyarı: {x.SonHata}");
        return bot.SendMessage(chatId, metin, cancellationToken: cancellationToken);
    }

    public async Task VeriSayisiAsync(ITelegramBotClient bot, long chatId, CancellationToken cancellationToken)
    {
        var mac = await _db.Maclar.LongCountAsync(cancellationToken);
        var skorlu = await _db.Maclar.LongCountAsync(x => x.EvSahibiSkor != null && x.DeplasmanSkor != null, cancellationToken);
        var takim = await _db.Takimlar.LongCountAsync(cancellationToken);
        var lig = await _db.Ligler.LongCountAsync(cancellationToken);
        var ilk = await _db.Maclar.MinAsync(x => (DateTime?)x.MacTarihi, cancellationToken);
        var son = await _db.Maclar.MaxAsync(x => (DateTime?)x.MacTarihi, cancellationToken);

        await bot.SendMessage(chatId,
            "📊 FEM VERİTABANI SAYILARI\n\n" +
            $"Toplam maç: {mac:N0}\n" +
            $"Skorlu maç: {skorlu:N0}\n" +
            $"Takım: {takim:N0}\n" +
            $"Lig/sezon: {lig:N0}\n" +
            $"Tarih aralığı: {(ilk.HasValue ? ilk.Value.ToLocalTime().ToString("dd.MM.yyyy") : "-")} - {(son.HasValue ? son.Value.ToLocalTime().ToString("dd.MM.yyyy") : "-")}",
            cancellationToken: cancellationToken);
    }

    public Task LiglerAsync(ITelegramBotClient bot, long chatId, CancellationToken cancellationToken)
    {
        return bot.SendMessage(chatId,
            "🌍 HAVUZ LİGLERİ\n\n" + string.Join(", ", VarsayilanLigler) +
            "\n\nBaşlatma örneği:\n/havuzimport 9394 2526",
            cancellationToken: cancellationToken);
    }
}
