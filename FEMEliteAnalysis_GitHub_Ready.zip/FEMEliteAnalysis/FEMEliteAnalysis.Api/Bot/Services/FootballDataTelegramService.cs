using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class FootballDataTelegramService
{
    private readonly IFootballDataCoUkImportService _service;

    public FootballDataTelegramService(IFootballDataCoUkImportService service)
    {
        _service = service;
    }

    public Task LigleriGonderAsync(
        ITelegramBotClient bot,
        long chatId,
        CancellationToken cancellationToken)
    {
        var ligler = _service.LigleriGetir();
        var metin = new StringBuilder("📚 FOOTBALL-DATA.CO.UK LİGLERİ\n\n");
        foreach (var grup in ligler.GroupBy(x => x.Ulke))
        {
            metin.AppendLine($"🌍 {grup.Key}");
            foreach (var lig in grup)
                metin.AppendLine($"• {lig.Kod} — {lig.Ad}");
            metin.AppendLine();
        }
        metin.AppendLine("Örnek: /fdindir E0 2526");
        return bot.SendMessage(chatId, metin.ToString(), cancellationToken: cancellationToken);
    }

    public async Task IndirAsync(
        ITelegramBotClient bot,
        long chatId,
        string lig,
        string sezon,
        CancellationToken cancellationToken)
    {
        await bot.SendMessage(chatId,
            $"⏳ {lig} / {sezon} geçmiş verisi indiriliyor...",
            cancellationToken: cancellationToken);
        var sonuc = await _service.LigSezonAktarAsync(lig, sezon, cancellationToken);
        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await bot.SendMessage(chatId, $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var x = sonuc.Veri;
        await bot.SendMessage(chatId,
            "✅ FOOTBALL-DATA AKTARIMI\n\n" +
            $"Lig: {x.LigAdi} ({x.LigKodu})\n" +
            $"Sezon: {x.Sezon}\n" +
            $"Kaynak maç: {x.KaynaktanGelenMac}\n" +
            $"Eklenen: {x.EklenenMac}\n" +
            $"Güncellenen: {x.GuncellenenMac}\n" +
            $"Yeni takım: {x.YeniTakim}\n" +
            $"İstatistik eklendi: {x.EklenenIstatistik}\n" +
            $"İstatistik güncellendi: {x.GuncellenenIstatistik}",
            cancellationToken: cancellationToken);
    }

    public async Task TopluIndirAsync(
        ITelegramBotClient bot,
        long chatId,
        string sezon,
        IReadOnlyCollection<string> ligler,
        CancellationToken cancellationToken)
    {
        await bot.SendMessage(chatId,
            $"⏳ {ligler.Count} lig için {sezon} sezonu indiriliyor...",
            cancellationToken: cancellationToken);
        var sonuc = await _service.TopluAktarAsync(ligler, sezon, cancellationToken);
        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await bot.SendMessage(chatId, $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var metin = new StringBuilder("✅ TOPLU FOOTBALL-DATA AKTARIMI\n\n");
        foreach (var x in sonuc.Veri)
        {
            metin.AppendLine(
                $"{(x.Basarili ? "✅" : "❌")} {x.LigKodu} {x.Sezon}: " +
                $"{x.KaynaktanGelenMac} maç, +{x.EklenenMac}, ↻{x.GuncellenenMac}");
            if (!x.Basarili) metin.AppendLine($"   {x.Mesaj}");
        }
        await bot.SendMessage(chatId, metin.ToString(), cancellationToken: cancellationToken);
    }
}
