using System.Text;
using FEMEliteAnalysis.Api.Dtos.VeriToplama;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Services;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class VeriToplamaTelegramService
{
    private readonly IVeriToplamaService _veriToplamaService;
    private readonly IVeriToplamaDurumStore _durumStore;
    private readonly IVeriSaglayiciFactory _factory;
    private readonly ILigYonetimService _ligYonetimService;
    private readonly IstatistikSyncDurumStore _istatistikDurum;

    public VeriToplamaTelegramService(
        IVeriToplamaService veriToplamaService,
        IVeriToplamaDurumStore durumStore,
        IVeriSaglayiciFactory factory,
        ILigYonetimService ligYonetimService,
        IstatistikSyncDurumStore istatistikDurum)
    {
        _veriToplamaService = veriToplamaService;
        _durumStore = durumStore;
        _factory = factory;
        _ligYonetimService = ligYonetimService;
        _istatistikDurum = istatistikDurum;
    }

    public async Task SyncCalistirAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        var saglayicilar =
            _factory.AktifSaglayicilariGetir();

        if (saglayicilar.Count == 0)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text:
                    "❌ Aktif veri sağlayıcısı bulunmuyor.\n\n" +
                    "appsettings.json içinde:\n" +
                    "SofaScore:Aktif = true\n" +
                    "olmalıdır.",
                cancellationToken: cancellationToken);
            return;
        }

        var bugun = DateOnly.FromDateTime(
            TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                DateTime.UtcNow,
                "Turkey Standard Time"));

        // Günlük /sync artık geçmiş sezonları tekrar indirmez.
        // Son 7 günün sonuçları ile önümüzdeki 7 günlük fikstürü günceller.
        var baslangic = bugun.AddDays(-7);
        var bitis = bugun.AddDays(7);

        await botClient.SendMessage(
            chatId: chatId,
            text:
                "⏳ Veri senkronizasyonu başladı.\n\n" +
                $"Tarih aralığı: {baslangic:dd.MM.yyyy} - " +
                $"{bitis:dd.MM.yyyy}\n" +
                "Yalnızca son 7 gün ve gelecek 7 gün güncellenir.\n" +
                "Geçmiş 3 sezon yeniden indirilmez.",
            cancellationToken: cancellationToken);

        var sonuc =
            await _veriToplamaService
                .TumAktifSaglayicilariCalistirAsync(
                    baslangic,
                    bitis,
                    cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: $"❌ {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var metin = new StringBuilder();

        metin.AppendLine("✅ VERİ SENKRONİZASYONU TAMAMLANDI");
        metin.AppendLine();

        foreach (var item in sonuc.Veri)
        {
            metin.AppendLine($"Kaynak: {item.SaglayiciTuru}");
            metin.AppendLine($"Başarılı: {(item.Basarili ? "Evet" : "Hayır")}");
            metin.AppendLine($"Lig: {item.GelenLigSayisi}");
            metin.AppendLine($"Takım: {item.GelenTakimSayisi}");
            metin.AppendLine($"Maç: {item.GelenMacSayisi}");
            metin.AppendLine($"Eklenen: {item.EklenenKayitSayisi}");
            metin.AppendLine($"Güncellenen: {item.GuncellenenKayitSayisi}");
            metin.AppendLine($"Atlanan: {item.AtlananKayitSayisi}");

            if (item.Uyarilar.Count > 0)
            {
                metin.AppendLine(
                    $"Uyarı: {item.Uyarilar.First()}");
            }

            metin.AppendLine("────────────");
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: metin.ToString(),
            cancellationToken: cancellationToken);
    }

    public async Task SyncGenisCalistirAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        const int hedefLig = 90;
        await botClient.SendMessage(
            chatId,
            "🌍 Geniş lig havuzu hazırlanıyor...\n\nHedef: yaklaşık 90 güçlü futbol ligi.\nBu işlem ilk çalıştırmada birkaç dakika sürebilir.",
            cancellationToken: cancellationToken);

        var havuz = await _ligYonetimService.GenisLigHavuzuGetirAsync(hedefLig, cancellationToken);
        if (!havuz.Basarili || havuz.Veri is null || havuz.Veri.Count == 0)
        {
            await botClient.SendMessage(chatId, $"❌ {havuz.Mesaj}", cancellationToken: cancellationToken);
            return;
        }

        var basarili = 0;
        var hatali = 0;
        var gelenMac = 0;
        var eklenenMac = 0;
        var guncellenenMac = 0;
        var ilkHatalar = new List<string>();

        for (var i = 0; i < havuz.Veri.Count; i++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var lig = havuz.Veri[i];
            var sync = await _ligYonetimService.LigSenkronizeEtAsync(lig.LigId, 2, cancellationToken);
            if (sync.Basarili && sync.Veri is not null)
            {
                basarili++;
                gelenMac += sync.Veri.GelenMacSayisi;
                eklenenMac += sync.Veri.EklenenMacSayisi;
                guncellenenMac += sync.Veri.GuncellenenMacSayisi;
            }
            else
            {
                hatali++;
                if (ilkHatalar.Count < 5)
                    ilkHatalar.Add($"{lig.Ad}: {sync.Mesaj}");
            }

            if ((i + 1) % 15 == 0)
            {
                await botClient.SendMessage(
                    chatId,
                    $"⏳ Geniş sync: {i + 1}/{havuz.Veri.Count} lig işlendi | ✅ {basarili} | ❌ {hatali}",
                    cancellationToken: cancellationToken);
            }
        }

        var hataMetni = ilkHatalar.Count == 0
            ? "Yok"
            : string.Join("\n", ilkHatalar.Select(x => $"• {x}"));

        await botClient.SendMessage(
            chatId,
            "✅ GENİŞ LİG SENKRONİZASYONU TAMAMLANDI\n\n" +
            $"🌍 Hedef lig: {havuz.Veri.Count}\n" +
            $"✅ Başarılı lig: {basarili}\n" +
            $"❌ Hatalı lig: {hatali}\n" +
            $"📥 Gelen maç: {gelenMac}\n" +
            $"➕ Eklenen maç: {eklenenMac}\n" +
            $"🔄 Güncellenen maç: {guncellenenMac}\n\n" +
            $"İlk hatalar:\n{hataMetni}\n\n" +
            "Bundan sonra /uygunmaclar veritabanındaki tüm aktif ligleri tarar; appsettings'teki 20 ligle sınırlı değildir.",
            cancellationToken: cancellationToken);
    }

    public async Task Sync3SezonCalistirAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        var bugun = DateOnly.FromDateTime(
            TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                DateTime.UtcNow,
                "Turkey Standard Time"));

        // Bir defalık arşiv onarımı. appsettings içindeki Sezonlar listesi
        // provider tarafından okunur; geniş tarih aralığı sezon maçlarının
        // filtreye takılmadan işlenmesini sağlar.
        var baslangic = new DateOnly(2024, 7, 1);
        var bitis = bugun.AddDays(7);

        await botClient.SendMessage(
            chatId: chatId,
            text:
                "⏳ 3 sezonluk onarım senkronizasyonu başladı.\n\n" +
                $"Tarih aralığı: {baslangic:dd.MM.yyyy} - {bitis:dd.MM.yyyy}\n" +
                "Bu komutu yalnızca bir kez çalıştırın. İşlem uzun sürebilir.",
            cancellationToken: cancellationToken);

        var sonuc = await _veriToplamaService.CalistirAsync(
            new VeriToplamaIstekDto
            {
                SaglayiciTuru = VeriSaglayiciTuru.TheSportsDb,
                BaslangicTarihi = baslangic,
                BitisTarihi = bitis,
                MaclariGetir = true,
                TakimlariGetir = true,
                SonuclariGuncelle = true,
                GecmisFormuGetir = true
            },
            cancellationToken);

        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: $"❌ 3 sezon senkronizasyonu başarısız: {sonuc.Mesaj}",
                cancellationToken: cancellationToken);
            return;
        }

        var item = sonuc.Veri;
        await botClient.SendMessage(
            chatId: chatId,
            text:
                "✅ 3 SEZON SENKRONİZASYONU TAMAMLANDI\n\n" +
                $"Lig: {item.GelenLigSayisi}\n" +
                $"Takım: {item.GelenTakimSayisi}\n" +
                $"Maç: {item.GelenMacSayisi}\n" +
                $"Eklenen: {item.EklenenKayitSayisi}\n" +
                $"Güncellenen: {item.GuncellenenKayitSayisi}\n" +
                $"Atlanan: {item.AtlananKayitSayisi}",
            cancellationToken: cancellationToken);
    }

    public async Task SyncIstatistikBaslatAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        if (!_istatistikDurum.Baslat(chatId))
        {
            await botClient.SendMessage(
                chatId,
                "⏳ İstatistik senkronizasyonu zaten çalışıyor veya sırada.\n\n/syncistatistikdurum ile durumu görebilirsin.",
                cancellationToken: cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId,
            "📊 3 sezonluk KORNER / KART / ŞUT senkronizasyonu arka planda başlatıldı.\n\n" +
            "🌍 Tüm aktif ligler taranır.\n" +
            "🚩 Korner, 🟨 kart, 🎯 şut, isabetli şut, faul ve ofsayt stats verileri kaydedilir.\n" +
            "♻️ Daha önce dolu olan maçlar tekrar API'den çekilmez.\n" +
            "💾 İşlem yarıda kalırsa cursor sayesinde sonraki çalıştırmada kaldığı yerden devam eder.\n\n" +
            "Bot bu sırada diğer komutlara cevap vermeye devam eder. /syncistatistikdurum ile ilerlemeyi kontrol edebilirsin.",
            cancellationToken: cancellationToken);
    }

    public async Task SyncIstatistikDurumGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        var durum = _istatistikDurum.CalisiyorMu ? "🟡 Çalışıyor" : "🟢 Beklemede";
        await botClient.SendMessage(
            chatId,
            $"📊 İSTATİSTİK SYNC DURUMU\n\n" +
            $"Durum: {durum}\n" +
            $"🎯 Hedef maç: {_istatistikDurum.ToplamHedef}\n" +
            $"⚽ Kontrol edilen: {_istatistikDurum.KontrolEdilen}/{_istatistikDurum.ToplamHedef}\n" +
            $"🚩 Korner bulunan: {_istatistikDurum.KornerBulunan}\n" +
            $"🟨 Kart bulunan: {_istatistikDurum.KartBulunan}\n" +
            $"⏭ Zaten kayıtlı: {_istatistikDurum.ZatenDolu}\n" +
            $"❔ Stats bulunamayan: {_istatistikDurum.StatsBulunamayan}\n" +
            $"❌ API/DB hata: {_istatistikDurum.Hata}\n\n" +
            _istatistikDurum.SonMesaj,
            cancellationToken: cancellationToken);
    }

    public async Task DurumGonderAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        var durum = _durumStore.CalisiyorMu
            ? "🟡 Çalışıyor"
            : "🟢 Beklemede";

        var baslangic = _durumStore.SonBaslamaZamani.HasValue
            ? IstanbulSaati(
                _durumStore.SonBaslamaZamani.Value)
                .ToString("dd.MM.yyyy HH:mm:ss")
            : "Henüz çalışmadı";

        var bitis = _durumStore.SonBitisZamani.HasValue
            ? IstanbulSaati(
                _durumStore.SonBitisZamani.Value)
                .ToString("dd.MM.yyyy HH:mm:ss")
            : "-";

        await botClient.SendMessage(
            chatId: chatId,
            text:
                "📡 VERİ TOPLAMA DURUMU\n\n" +
                $"Durum: {durum}\n" +
                $"Son başlangıç: {baslangic}\n" +
                $"Son bitiş: {bitis}\n" +
                $"Son mesaj: {_durumStore.SonMesaj ?? "-"}",
            cancellationToken: cancellationToken);
    }

    public async Task BaglantiTestiAsync(
        ITelegramBotClient botClient,
        long chatId,
        CancellationToken cancellationToken)
    {
        var saglayicilar =
            _factory.AktifSaglayicilariGetir();

        if (saglayicilar.Count == 0)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text:
                    "❌ Aktif veri sağlayıcısı bulunmuyor.",
                cancellationToken: cancellationToken);
            return;
        }

        var metin = new StringBuilder();
        metin.AppendLine("🔌 VERİ KAYNAĞI BAĞLANTI TESTİ");
        metin.AppendLine();

        foreach (var saglayici in saglayicilar)
        {
            var sonuc = await saglayici.BaglantiTestiAsync(
                cancellationToken);

            metin.AppendLine(
                $"{(sonuc.Basarili ? "✅" : "❌")} " +
                $"{saglayici.Ad}");

            metin.AppendLine(sonuc.Mesaj);
            metin.AppendLine();
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: metin.ToString(),
            cancellationToken: cancellationToken);
    }

    private static DateTime IstanbulSaati(DateTime utc)
    {
        var tarih = utc.Kind == DateTimeKind.Utc
            ? utc
            : DateTime.SpecifyKind(utc, DateTimeKind.Utc);

        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
            tarih,
            "Turkey Standard Time");
    }
}
