using FEMEliteAnalysis.Api.Bot.Handlers;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types.Enums;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class TelegramBotBackgroundService : BackgroundService
{
    private readonly ITelegramBotClient _botClient;
    private readonly TelegramUpdateHandler _handler;
    private readonly ILogger<TelegramBotBackgroundService> _logger;

    public TelegramBotBackgroundService(
        ITelegramBotClient botClient,
        TelegramUpdateHandler handler,
        ILogger<TelegramBotBackgroundService> logger)
    {
        _botClient = botClient;
        _handler = handler;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var botInfo = await _botClient.GetMe(stoppingToken);

        _logger.LogInformation(
            "Telegram botu çalışıyor: @{BotUsername}",
            botInfo.Username);

        _botClient.StartReceiving(
            _handler.HandleUpdateAsync,
            _handler.HandleErrorAsync,
            new ReceiverOptions
            {
                AllowedUpdates = Array.Empty<UpdateType>(),
                DropPendingUpdates = true
            },
            stoppingToken);

        await Task.Delay(Timeout.Infinite, stoppingToken);
    }
}
