using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public class UygunMacTelegramService
{
    private readonly IUygunMacService _service;
    public UygunMacTelegramService(IUygunMacService service) => _service = service;

    public async Task ListeGonderAsync(ITelegramBotClient bot, long chatId, int gun, CancellationToken ct)
    {
        var sonuc = await _service.UygunMaclariGetirAsync(gun, 60, ct);
        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await bot.SendMessage(chatId, $"❌ {sonuc.Mesaj}", cancellationToken: ct); return;
        }
        var sb = new StringBuilder("🏆 ANALİZ SKORUNA GÖRE EN İYİ MAÇLAR\n\n");
        if (sonuc.Veri.Count == 0)
        {
            sb.AppendLine(sonuc.Mesaj);
            sb.AppendLine();
            sb.AppendLine("İpucu: /uygunmaclar 3 veya /uygunmaclar 7 ile tarih aralığını genişletebilirsiniz.");
        }
        foreach (var m in sonuc.Veri)
        {
            sb.AppendLine($"{new string('⭐', m.Yildiz)} {m.Rozet}");
            sb.AppendLine($"🆔 {m.MacId} | {m.EvSahibi} - {m.Deplasman}");
            sb.AppendLine($"🏆 {m.Lig} | {m.MacTarihi.ToLocalTime():dd.MM HH:mm}");
            sb.AppendLine($"📊 Analiz Skoru: %{m.VeriGuvenPuani} | Genel {m.EvGenelMac}/{m.DepGenelMac} | Saha {m.EvIcSahaMac}/{m.DepDisSahaMac} | H2H {m.H2HMac}");
            sb.AppendLine($"➡️ /macvericek {m.MacId}");
            sb.AppendLine("────────────");
        }
        var metin = sb.ToString();
        const int parcaBoyutu = 3800;
        for (var i = 0; i < metin.Length; i += parcaBoyutu)
        {
            var uzunluk = Math.Min(parcaBoyutu, metin.Length - i);
            await bot.SendMessage(chatId, metin.Substring(i, uzunluk), cancellationToken: ct);
        }
    }

    public async Task VeriCekAsync(ITelegramBotClient bot, long chatId, int macId, CancellationToken ct)
    {
        await bot.SendMessage(chatId, "⏳ Yalnızca seçilen maçın takım geçmişi ve H2H verisi güncelleniyor...", cancellationToken: ct);
        var sonuc = await _service.SeciliMacVerisiniCekAsync(macId, ct);
        if (!sonuc.Basarili || sonuc.Veri is null)
        {
            await bot.SendMessage(chatId, $"❌ {sonuc.Mesaj}", cancellationToken: ct); return;
        }
        var x = sonuc.Veri;
        var bilgi = x.Bilgiler.Count == 0 ? "" : "\n\n🔎 Derin veri:\n" + string.Join("\n", x.Bilgiler.Select(u => $"• {u}"));
        var uyari = x.Uyarilar.Count == 0 ? "" : "\n\n⚠️ Uyarılar:\n" + string.Join("\n", x.Uyarilar.Select(u => $"• {u}"));
        await bot.SendMessage(chatId,
            $"✅ SEÇİLİ MAÇ VERİSİ HAZIR\n\n⚽ {x.MacAdi}\n📥 API kaydı: {x.ApiKayitSayisi}\n➕ Eklenen: {x.EklenenMacSayisi}\n🔄 Güncellenen: {x.GuncellenenMacSayisi}\n📦 Veri kalitesi: %{x.VeriKalitesiOnce} → %{x.VeriKalitesiSonra}{bilgi}{uyari}\n\nŞimdi: /analiz {x.MacId}", cancellationToken: ct);
    }
}

