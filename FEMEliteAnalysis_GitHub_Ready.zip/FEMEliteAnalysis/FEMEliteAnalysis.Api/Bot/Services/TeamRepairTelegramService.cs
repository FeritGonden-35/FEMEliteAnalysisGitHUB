using System.Text;
using FEMEliteAnalysis.Api.Interfaces;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Bot.Services;

public sealed class TeamRepairTelegramService
{
    private readonly ITeamRepairService _service;
    public TeamRepairTelegramService(ITeamRepairService service) => _service=service;

    public async Task TaraAsync(ITelegramBotClient bot,long chatId,CancellationToken ct)
    {
        await bot.SendMessage(chatId,"🔎 Takım kayıtları güvenli eşleşme kurallarıyla taranıyor...",cancellationToken:ct);
        var r=await _service.TaraAsync(ct);
        if(!r.Basarili||r.Veri is null){await bot.SendMessage(chatId,"❌ "+r.Mesaj,cancellationToken:ct);return;}
        var sb=new StringBuilder();
        sb.AppendLine("✅ TAKIM TARAMASI TAMAMLANDI\n");
        sb.AppendLine($"Güvenli aday grup: {r.Veri.Count}");
        sb.AppendLine($"Birleştirilebilecek kayıt: {r.Veri.Sum(x=>x.BirlesecekTakimlar.Count)}");
        sb.AppendLine($"Taşınacak tahmini maç bağlantısı: {r.Veri.Sum(x=>x.ToplamTasinacakMacBaglantisi)}\n");
        foreach(var x in r.Veri.Take(12))
            sb.AppendLine($"• {x.AnaTakimAdi} [ID {x.AnaTakimId}] ← {string.Join(", ",x.BirlesecekTakimlar.Select(y=>$"{y.TakimAdi} ({y.MacSayisi})"))}");
        if(r.Veri.Count>12) sb.AppendLine($"\n… ve {r.Veri.Count-12} grup daha.");
        sb.AppendLine("\nDetay: /birlestirmeonizle\nUygula: /takimbirlestir");
        await bot.SendMessage(chatId,sb.ToString(),cancellationToken:ct);
    }

    public async Task OnizleAsync(ITelegramBotClient bot,long chatId,CancellationToken ct)
    {
        var p=_service.SonPlanGetir();
        if(p.Count==0){await bot.SendMessage(chatId,"Önce /takimtarama çalıştırın.",cancellationToken:ct);return;}
        var sayfa=1; var sb=new StringBuilder($"👁 BİRLEŞTİRME ÖN İZLEMESİ — {p.Count} GRUP\n\n");
        foreach(var x in p)
        {
            var satir=$"✅ ANA: {x.AnaTakimAdi} [ID {x.AnaTakimId}]\n   Birleşecek: {string.Join(", ",x.BirlesecekTakimlar.Select(y=>$"{y.TakimAdi} [ID {y.TakimId}]"))}\n\n";
            if(sb.Length+satir.Length>3500){await bot.SendMessage(chatId,$"Sayfa {sayfa++}\n\n"+sb,cancellationToken:ct);sb.Clear();}
            sb.Append(satir);
        }
        if(sb.Length>0) await bot.SendMessage(chatId,$"Sayfa {sayfa}\n\n"+sb,cancellationToken:ct);
    }

    public async Task UygulaAsync(ITelegramBotClient bot,long chatId,CancellationToken ct)
    {
        await bot.SendMessage(chatId,"⚠️ Takım bağlantıları transaction içinde birleştiriliyor. İşlem bitene kadar botu kapatmayın.",cancellationToken:ct);
        var r=await _service.UygulaAsync(ct);
        await bot.SendMessage(chatId,(r.Basarili?"✅ ":"❌ ")+r.Mesaj,cancellationToken:ct);
    }

    public Task DurumAsync(ITelegramBotClient bot,long chatId,CancellationToken ct)
    {
        var x=_service.DurumGetir();
        var m=$"🧹 DATABASE REPAIR DURUMU\n\nDurum: {(x.CalisiyorMu?"🟡 Çalışıyor":"🟢 Beklemede")}\nİncelenen takım: {x.IncelenenTakim}\nAday grup: {x.AdayGrup}\nBirleşen kayıt: {x.BirlesenTakim}\nGüncellenen maç bağlantısı: {x.GuncellenenMacBaglantisi}\nGüncellenen istatistik: {x.GuncellenenIstatistik}\nGüncellenen form: {x.GuncellenenForm}\nSon mesaj: {x.SonMesaj}";
        return bot.SendMessage(chatId,m,cancellationToken:ct);
    }
}
