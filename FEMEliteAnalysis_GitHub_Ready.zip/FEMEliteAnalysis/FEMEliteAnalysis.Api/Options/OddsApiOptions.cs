namespace FEMEliteAnalysis.Api.Options;

/// <summary>
/// V4.10 - Tek odds sağlayıcısı PulseScore.
/// Bet365 normalize edilmiş pre-match feed kullanılır.
/// </summary>
public class OddsApiOptions
{
    public const string SectionName = "OddsApi";
    public bool Aktif { get; set; } = true;
    public string ApiKey { get; set; } = string.Empty;
    public string BaseUrl { get; set; } = "https://api.pulsescore.net/api/v3/bet365/";
    public int CacheDakika { get; set; } = 30;
    public int MaksimumShortlist { get; set; } = 12;
    public int MaksimumKuponAdedi { get; set; } = 20;
    public int EventPageLimit { get; set; } = 30;
    public int MaksimumEventSayfasi { get; set; } = 24;
}
