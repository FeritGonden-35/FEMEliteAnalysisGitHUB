namespace FEMEliteAnalysis.Api.Options;

public class MacAnalizOptions
{
    public const string SectionName = "MacAnaliz";

    public int GenelFormMacSayisi { get; set; } = 20;
    public int IcDisSahaMacSayisi { get; set; } = 10;
    public int H2HMacSayisi { get; set; } = 10;

    public int MinimumAnalizMacSayisi { get; set; } = 5;
    public int MinimumKuponVeriKalitesi { get; set; } = 55;
}
