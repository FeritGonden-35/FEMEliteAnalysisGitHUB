namespace FEMEliteAnalysis.Api.Options;

public class TelegramJoinVerificationOptions
{
    public const string SectionName = "TelegramJoinVerification";

    public bool Aktif { get; set; } = true;
    public string BayiKodu { get; set; } = "303037";
    public long? FreeGroupId { get; set; }
    public long? VerificationAdminChatId { get; set; }
    public int TalepGecerlilikSaati { get; set; } = 24;
    public bool OtomatikReddet { get; set; } = false;
    public int DavetLinkiGecerlilikDakikasi { get; set; } = 30;
    public int DavetLinkiKullanimLimiti { get; set; } = 1;
}
