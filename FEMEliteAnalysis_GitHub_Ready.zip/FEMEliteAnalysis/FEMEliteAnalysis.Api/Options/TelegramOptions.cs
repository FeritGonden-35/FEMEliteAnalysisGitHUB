namespace FEMEliteAnalysis.Api.Options;

public class TelegramOptions
{
    public const string SectionName = "Telegram";

    public string BotToken { get; set; } = string.Empty;
    // Eski tek-admin ayarıyla geriye dönük uyumluluk için korunur.
    public long AdminUserId { get; set; }

    // Birden fazla Telegram yöneticisi tanımlamak için kullanılır.
    public List<long> AdminUserIds { get; set; } = [];
    public long? VipChannelId { get; set; }
    public long? FreeChannelId { get; set; }
    public string? BayiChannelUsername { get; set; }
    public string MarkaAdi { get; set; } = "FEM Elite Analysis";
    public string? KanalKullaniciAdi { get; set; }
}
