namespace FEMEliteAnalysis.Api.Options;

public class SofaScoreOptions
{
    public const string SectionName = "SofaScore";

    public bool Aktif { get; set; } = false;

    public string BaseUrl { get; set; } =
        "https://www.sofascore.com/api/v1/";

    public string UserAgent { get; set; } =
        "FEMEliteAnalysis/1.0";

    public int IsteklerArasiBeklemeMs { get; set; } = 750;
    public int MaksimumGunSayisi { get; set; } = 14;
}
