namespace FEMEliteAnalysis.Api.Options;

public class ModerasyonOptions
{
    public const string SectionName = "Moderasyon";

    public bool Aktif { get; set; } = true;
    public bool TumGruplardaCalis { get; set; } = true;
    public List<long> GrupIdleri { get; set; } = new();
    public long? LogChatId { get; set; }

    public int SpamPencereSaniye { get; set; } = 10;
    public int SpamMesajLimiti { get; set; } = 5;
    public int TekrarPencereSaniye { get; set; } = 60;
    public int AyniMesajLimiti { get; set; } = 3;
    public int TekMesajLinkLimiti { get; set; } = 1;
    public int BuyukHarfMinimumHarf { get; set; } = 12;
    public int BuyukHarfYuzdesi { get; set; } = 75;
    public int TekrarKarakterLimiti { get; set; } = 8;

    public List<string> IzinliAlanAdlari { get; set; } = new()
    {
        "t.me/FEMElite",
        "t.me/FEMEliteVIP"
    };

    public List<string> YasakliKelimeler { get; set; } = new()
    {
        "amk", "aq", "amina", "amına", "orospu", "pic", "piç",
        "siktir", "sikerim", "yarrak", "gotveren", "götveren",
        "ibne", "kahpe"
    };
}
