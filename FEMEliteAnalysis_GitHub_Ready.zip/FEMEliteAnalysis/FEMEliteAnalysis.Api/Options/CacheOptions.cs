namespace FEMEliteAnalysis.Api.Options;

public class CacheOptions
{
    public const string SectionName = "Cache";

    public int MacListesiDakika { get; set; } = 30;
    public int AnalizVerisiDakika { get; set; } = 15;
    public int VipUyelerDakika { get; set; } = 5;
}
