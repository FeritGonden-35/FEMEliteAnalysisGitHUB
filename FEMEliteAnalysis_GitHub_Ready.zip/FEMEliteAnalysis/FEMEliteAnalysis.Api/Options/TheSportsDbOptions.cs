namespace FEMEliteAnalysis.Api.Options;

public class TheSportsDbOptions
{
    public const string SectionName = "TheSportsDb";

    public bool Aktif { get; set; } = false;

    // Geriye dönük uyumluluk. V1ApiKey boşsa bu değer kullanılır.
    public string ApiKey { get; set; } = string.Empty;
    public string V1ApiKey { get; set; } = string.Empty;
    public string V2ApiKey { get; set; } = string.Empty;

    public string BaseUrl { get; set; } =
        "https://www.thesportsdb.com/api/v1/json/";

    public string V2BaseUrl { get; set; } =
        "https://www.thesportsdb.com/api/v2/json/";

    public int IsteklerArasiBeklemeMs { get; set; } = 600;
    public int IstatistikSyncBeklemeMs { get; set; } = 250;
    public int IstatistikSyncBatchBoyutu { get; set; } = 250;
    public int IstatistikSyncIlerlemeAdimi { get; set; } = 250;
    public bool TakimGecmisiAktif { get; set; } = true;
    public bool V2TakimDogrulamaAktif { get; set; } = true;
    public bool OtomatikTakimBirlestirmeAktif { get; set; } = true;

    public List<int> SeciliLigIdleri { get; set; } = new();

    public List<string> Sezonlar { get; set; } = new()
    {
        "2024-2025",
        "2025-2026",
        "2026-2027"
    };

    public bool LigSezonGecmisiAktif { get; set; } = true;
    public string VarsayilanSezon { get; set; } = "2026-2027";
}
