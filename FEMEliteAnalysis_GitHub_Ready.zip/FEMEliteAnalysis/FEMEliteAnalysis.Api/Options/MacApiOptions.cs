namespace FEMEliteAnalysis.Api.Options;

public class MacApiOptions
{
    public const string SectionName = "MacApi";

    public string BaseUrl { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public string ApiHost { get; set; } = string.Empty;
}
