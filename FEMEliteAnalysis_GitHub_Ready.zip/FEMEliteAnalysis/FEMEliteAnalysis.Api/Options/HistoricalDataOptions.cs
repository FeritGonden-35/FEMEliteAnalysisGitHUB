namespace FEMEliteAnalysis.Api.Options;

public class HistoricalDataOptions
{
    public const string SectionName = "HistoricalData";

    public bool Aktif { get; set; } = true;
    public string RootFolder { get; set; } = "HistoricalData";
    public string InboxFolder { get; set; } = "Inbox";
    public string ProcessedFolder { get; set; } = "Processed";
    public string FailedFolder { get; set; } = "Failed";
    public bool BasariliDosyayiTasi { get; set; } = true;

    public Dictionary<string, string> TakimAliaslari { get; set; } =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["Man United"] = "Manchester United",
            ["Man Utd"] = "Manchester United",
            ["Manchester Utd"] = "Manchester United",
            ["Paris SG"] = "Paris Saint-Germain",
            ["Paris Saint Germain"] = "Paris Saint-Germain",
            ["Ath Madrid"] = "Atletico Madrid",
            ["Atlético Madrid"] = "Atletico Madrid",
            ["Inter"] = "Inter Milan",
            ["Internazionale"] = "Inter Milan",
            ["Nott'm Forest"] = "Nottingham Forest",
            ["Wolves"] = "Wolverhampton Wanderers",
            ["Sheffield Weds"] = "Sheffield Wednesday"
        };
}
