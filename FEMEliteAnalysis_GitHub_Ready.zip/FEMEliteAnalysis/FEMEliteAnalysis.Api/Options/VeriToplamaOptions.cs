namespace FEMEliteAnalysis.Api.Options;

public class VeriToplamaOptions
{
    public const string SectionName = "VeriToplama";

    public bool Aktif { get; set; } = false;

    public int CalismaSaati { get; set; } = 3;
    public int CalismaDakikasi { get; set; } = 0;

    public int GecmisGunSayisi { get; set; } = 14;
    public int GelecekGunSayisi { get; set; } = 7;

    public int TekrarDenemeSayisi { get; set; } = 2;
    public int TekrarDenemeBeklemeSaniyesi { get; set; } = 10;

    public bool BaslangictaCalistir { get; set; } = false;

    public List<string> AktifSaglayicilar { get; set; } = new();
}
