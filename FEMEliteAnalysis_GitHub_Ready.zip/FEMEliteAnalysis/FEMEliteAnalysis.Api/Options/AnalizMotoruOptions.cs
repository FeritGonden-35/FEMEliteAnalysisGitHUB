namespace FEMEliteAnalysis.Api.Options;

public sealed class AnalizMotoruOptions
{
    public const string SectionName = "AnalizMotoru";
    public Dictionary<string, decimal> Agirliklar { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        ["FORM"] = 0.25m,
        ["SAHA"] = 0.25m,
        ["HUCUM"] = 0.18m,
        ["SAVUNMA"] = 0.17m,
        ["H2H"] = 0.07m,
        ["MOMENTUM"] = 0.08m
    };
    public int AnaMarketMinimumGuven { get; set; } = 64;
    public int AlternatifMinimumGuven { get; set; } = 50;
    public int UzakDurMaksimumGuven { get; set; } = 43;
    public int OneriMinimumGuven { get; set; } = 60;
    public int MaksimumGuven { get; set; } = 94;
    public decimal VarsayilanEvSahibiAvantaji { get; set; } = 5m;
    public decimal MinimumEdgeYuzdesi { get; set; } = 4m;
    public decimal MinimumBeklenenDeger { get; set; } = 0.03m;
}
