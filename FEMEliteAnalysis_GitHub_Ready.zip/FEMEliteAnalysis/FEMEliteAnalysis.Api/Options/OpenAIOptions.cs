namespace FEMEliteAnalysis.Api.Options;

public class OpenAIOptions
{
    public const string SectionName = "OpenAI";

    public string ApiKey { get; set; } = string.Empty;

    // User Secrets üzerinden değiştirilebilir.
    public string Model { get; set; } = "gpt-4o-mini";
}
