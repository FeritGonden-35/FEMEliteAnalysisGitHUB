/*
Bu dosya yalnızca SQL Server Authentication kullanacaksan örnektir.
Parolayı güçlü bir değerle değiştir.
Windows Authentication kullanıyorsan bu dosyaya ihtiyacın yoktur.
*/

USE master;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.server_principals
    WHERE name = N'fem_app'
)
BEGIN
    CREATE LOGIN fem_app
    WITH PASSWORD = N'GUCLU_PAROLA_BURAYA',
         CHECK_POLICY = ON,
         CHECK_EXPIRATION = OFF;
END
GO

USE FEMEliteAnalysis;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.database_principals
    WHERE name = N'fem_app'
)
BEGIN
    CREATE USER fem_app FOR LOGIN fem_app;
END
GO

ALTER ROLE db_datareader ADD MEMBER fem_app;
ALTER ROLE db_datawriter ADD MEMBER fem_app;
ALTER ROLE db_ddladmin ADD MEMBER fem_app;
GO
