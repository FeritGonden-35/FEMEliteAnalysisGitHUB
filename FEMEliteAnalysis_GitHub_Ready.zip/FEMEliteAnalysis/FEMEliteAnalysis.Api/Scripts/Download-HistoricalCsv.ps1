param(
    [Parameter(Mandatory=$true)][string]$Url,
    [Parameter(Mandatory=$true)][string]$FileName
)

$projectRoot = Split-Path -Parent $PSScriptRoot
$inbox = Join-Path $projectRoot "HistoricalData\Inbox"
New-Item -ItemType Directory -Force -Path $inbox | Out-Null
$target = Join-Path $inbox $FileName
Invoke-WebRequest -Uri $Url -OutFile $target
Write-Host "CSV indirildi: $target"
Write-Host "Telegram'da /historikimport komutunu çalıştırın."
