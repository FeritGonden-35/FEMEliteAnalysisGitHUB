IF DB_ID(N'FEMEliteAnalysis') IS NULL
BEGIN
    CREATE DATABASE FEMEliteAnalysis;
END
GO

USE FEMEliteAnalysis;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = N'fem'
)
BEGIN
    EXEC(N'CREATE SCHEMA fem AUTHORIZATION dbo');
END
GO
