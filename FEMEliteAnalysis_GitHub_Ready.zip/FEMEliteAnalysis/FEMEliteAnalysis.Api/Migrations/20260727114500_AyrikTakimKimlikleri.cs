using FEMEliteAnalysis.Api.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FEMEliteAnalysis.Api.Migrations;

[DbContext(typeof(FemDbContext))]
[Migration("20260727114500_AyrikTakimKimlikleri")]
public partial class AyrikTakimKimlikleri : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<int>(
            name: "ApiFootballTakimId",
            schema: "fem",
            table: "Takimlar",
            type: "int",
            nullable: true);

        migrationBuilder.AddColumn<int>(
            name: "TheSportsDbTakimId",
            schema: "fem",
            table: "Takimlar",
            type: "int",
            nullable: true);

        migrationBuilder.Sql(@"
UPDATE [fem].[Takimlar]
SET [TheSportsDbTakimId] = ABS([HariciTakimId]) / 10
WHERE [TheSportsDbTakimId] IS NULL
  AND [HariciTakimId] < 0
  AND ABS([HariciTakimId]) % 10 = 0;

UPDATE [fem].[Takimlar]
SET [ApiFootballTakimId] = [HariciTakimId]
WHERE [ApiFootballTakimId] IS NULL
  AND [HariciTakimId] > 0;");

        migrationBuilder.CreateIndex(
            name: "IX_Takimlar_ApiFootballTakimId",
            schema: "fem",
            table: "Takimlar",
            column: "ApiFootballTakimId");

        migrationBuilder.CreateIndex(
            name: "IX_Takimlar_TheSportsDbTakimId",
            schema: "fem",
            table: "Takimlar",
            column: "TheSportsDbTakimId");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "IX_Takimlar_ApiFootballTakimId",
            schema: "fem",
            table: "Takimlar");

        migrationBuilder.DropIndex(
            name: "IX_Takimlar_TheSportsDbTakimId",
            schema: "fem",
            table: "Takimlar");

        migrationBuilder.DropColumn(
            name: "ApiFootballTakimId",
            schema: "fem",
            table: "Takimlar");

        migrationBuilder.DropColumn(
            name: "TheSportsDbTakimId",
            schema: "fem",
            table: "Takimlar");
    }
}
