﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FEMEliteAnalysis.Api.Migrations
{
    /// <inheritdoc />
    public partial class IlkMssqlVeritabani : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "fem");

            migrationBuilder.CreateTable(
                name: "ApiSenkronizasyonLoglari",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Kaynak = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Islem = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    BasariliMi = table.Column<bool>(type: "bit", nullable: false),
                    KayitSayisi = table.Column<int>(type: "int", nullable: true),
                    HataMesaji = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BaslangicTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    BitisTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApiSenkronizasyonLoglari", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Ayarlar",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Anahtar = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    Deger = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Aciklama = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    GuncellemeTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ayarlar", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Kullanicilar",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TelegramKullaniciId = table.Column<long>(type: "bigint", nullable: false),
                    KullaniciAdi = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Ad = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Soyad = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    BotMu = table.Column<bool>(type: "bit", nullable: false),
                    EngellendiMi = table.Column<bool>(type: "bit", nullable: false),
                    AdminMi = table.Column<bool>(type: "bit", nullable: false),
                    KayitTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SonGorulmeTarihi = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kullanicilar", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Ligler",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HariciLigId = table.Column<int>(type: "int", nullable: true),
                    Ad = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    Ulke = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Sezon = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    LogoUrl = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AktifMi = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ligler", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BotLoglari",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KullaniciId = table.Column<int>(type: "int", nullable: true),
                    TelegramKullaniciId = table.Column<long>(type: "bigint", nullable: true),
                    Komut = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Detay = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LogSeviyesi = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    KayitTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BotLoglari", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BotLoglari_Kullanicilar_KullaniciId",
                        column: x => x.KullaniciId,
                        principalSchema: "fem",
                        principalTable: "Kullanicilar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Uyelikler",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KullaniciId = table.Column<int>(type: "int", nullable: false),
                    BaslangicTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    BitisTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Durum = table.Column<int>(type: "int", nullable: false),
                    Aciklama = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    OlusturanTelegramKullaniciId = table.Column<long>(type: "bigint", nullable: true),
                    OlusturmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    GuncellemeTarihi = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Uyelikler", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Uyelikler_Kullanicilar_KullaniciId",
                        column: x => x.KullaniciId,
                        principalSchema: "fem",
                        principalTable: "Kullanicilar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Takimlar",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HariciTakimId = table.Column<int>(type: "int", nullable: true),
                    LigId = table.Column<int>(type: "int", nullable: true),
                    Ad = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    Ulke = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    LogoUrl = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    AktifMi = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Takimlar", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Takimlar_Ligler_LigId",
                        column: x => x.LigId,
                        principalSchema: "fem",
                        principalTable: "Ligler",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Maclar",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HariciMacId = table.Column<int>(type: "int", nullable: true),
                    LigId = table.Column<int>(type: "int", nullable: true),
                    EvSahibiTakimId = table.Column<int>(type: "int", nullable: false),
                    DeplasmanTakimId = table.Column<int>(type: "int", nullable: false),
                    MacTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Durum = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EvSahibiSkor = table.Column<int>(type: "int", nullable: true),
                    DeplasmanSkor = table.Column<int>(type: "int", nullable: true),
                    IlkYariEvSahibiSkor = table.Column<int>(type: "int", nullable: true),
                    IlkYariDeplasmanSkor = table.Column<int>(type: "int", nullable: true),
                    Stadyum = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Hakem = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    OlusturmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    GuncellemeTarihi = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Maclar", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Maclar_Ligler_LigId",
                        column: x => x.LigId,
                        principalSchema: "fem",
                        principalTable: "Ligler",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_Maclar_Takimlar_DeplasmanTakimId",
                        column: x => x.DeplasmanTakimId,
                        principalSchema: "fem",
                        principalTable: "Takimlar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Maclar_Takimlar_EvSahibiTakimId",
                        column: x => x.EvSahibiTakimId,
                        principalSchema: "fem",
                        principalTable: "Takimlar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "TakimFormlari",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TakimId = table.Column<int>(type: "int", nullable: false),
                    LigId = table.Column<int>(type: "int", nullable: true),
                    Sezon = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    SonMacSayisi = table.Column<int>(type: "int", nullable: false),
                    Galibiyet = table.Column<int>(type: "int", nullable: false),
                    Beraberlik = table.Column<int>(type: "int", nullable: false),
                    Maglubiyet = table.Column<int>(type: "int", nullable: false),
                    AttigiGol = table.Column<int>(type: "int", nullable: false),
                    YedigiGol = table.Column<int>(type: "int", nullable: false),
                    MacBasinaGolOrtalamasi = table.Column<decimal>(type: "decimal(6,2)", precision: 6, scale: 2, nullable: true),
                    MacBasinaYenilenGolOrtalamasi = table.Column<decimal>(type: "decimal(6,2)", precision: 6, scale: 2, nullable: true),
                    IkiBucukUstYuzdesi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    KarsilikliGolYuzdesi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    HesaplamaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TakimFormlari", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TakimFormlari_Ligler_LigId",
                        column: x => x.LigId,
                        principalSchema: "fem",
                        principalTable: "Ligler",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_TakimFormlari_Takimlar_TakimId",
                        column: x => x.TakimId,
                        principalSchema: "fem",
                        principalTable: "Takimlar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Analizler",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MacId = table.Column<int>(type: "int", nullable: false),
                    AnalizTuru = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Tahmin = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    GuvenPuani = table.Column<int>(type: "int", nullable: false),
                    RiskSeviyesi = table.Column<int>(type: "int", nullable: false),
                    YapayZekaAnalizi = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnaFaktorlerJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EvSahibiKazanmaOlasiligi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    BeraberlikOlasiligi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    DeplasmanKazanmaOlasiligi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    Durum = table.Column<int>(type: "int", nullable: false),
                    Sonuc = table.Column<int>(type: "int", nullable: false),
                    TelegramMesajId = table.Column<long>(type: "bigint", nullable: true),
                    YayinlananKanalId = table.Column<long>(type: "bigint", nullable: true),
                    OlusturmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    YayinlanmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SonuclanmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Analizler", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Analizler_Maclar_MacId",
                        column: x => x.MacId,
                        principalSchema: "fem",
                        principalTable: "Maclar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MacIstatistikleri",
                schema: "fem",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MacId = table.Column<int>(type: "int", nullable: false),
                    TakimId = table.Column<int>(type: "int", nullable: false),
                    Sut = table.Column<int>(type: "int", nullable: true),
                    IsabetliSut = table.Column<int>(type: "int", nullable: true),
                    Korner = table.Column<int>(type: "int", nullable: true),
                    Faul = table.Column<int>(type: "int", nullable: true),
                    SariKart = table.Column<int>(type: "int", nullable: true),
                    KirmiziKart = table.Column<int>(type: "int", nullable: true),
                    TopaSahipOlmaYuzdesi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    BeklenenGol = table.Column<decimal>(type: "decimal(6,2)", precision: 6, scale: 2, nullable: true),
                    Ofsayt = table.Column<int>(type: "int", nullable: true),
                    PasSayisi = table.Column<int>(type: "int", nullable: true),
                    PasIsabetYuzdesi = table.Column<decimal>(type: "decimal(5,2)", precision: 5, scale: 2, nullable: true),
                    KayitTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MacIstatistikleri", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MacIstatistikleri_Maclar_MacId",
                        column: x => x.MacId,
                        principalSchema: "fem",
                        principalTable: "Maclar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MacIstatistikleri_Takimlar_TakimId",
                        column: x => x.TakimId,
                        principalSchema: "fem",
                        principalTable: "Takimlar",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Analizler_Durum",
                schema: "fem",
                table: "Analizler",
                column: "Durum");

            migrationBuilder.CreateIndex(
                name: "IX_Analizler_MacId",
                schema: "fem",
                table: "Analizler",
                column: "MacId");

            migrationBuilder.CreateIndex(
                name: "IX_Analizler_OlusturmaTarihi",
                schema: "fem",
                table: "Analizler",
                column: "OlusturmaTarihi");

            migrationBuilder.CreateIndex(
                name: "IX_ApiSenkronizasyonLoglari_BaslangicTarihi",
                schema: "fem",
                table: "ApiSenkronizasyonLoglari",
                column: "BaslangicTarihi");

            migrationBuilder.CreateIndex(
                name: "IX_ApiSenkronizasyonLoglari_Kaynak_Islem",
                schema: "fem",
                table: "ApiSenkronizasyonLoglari",
                columns: new[] { "Kaynak", "Islem" });

            migrationBuilder.CreateIndex(
                name: "IX_Ayarlar_Anahtar",
                schema: "fem",
                table: "Ayarlar",
                column: "Anahtar",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BotLoglari_KayitTarihi",
                schema: "fem",
                table: "BotLoglari",
                column: "KayitTarihi");

            migrationBuilder.CreateIndex(
                name: "IX_BotLoglari_KullaniciId",
                schema: "fem",
                table: "BotLoglari",
                column: "KullaniciId");

            migrationBuilder.CreateIndex(
                name: "IX_BotLoglari_TelegramKullaniciId",
                schema: "fem",
                table: "BotLoglari",
                column: "TelegramKullaniciId");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanicilar_KullaniciAdi",
                schema: "fem",
                table: "Kullanicilar",
                column: "KullaniciAdi");

            migrationBuilder.CreateIndex(
                name: "IX_Kullanicilar_TelegramKullaniciId",
                schema: "fem",
                table: "Kullanicilar",
                column: "TelegramKullaniciId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Ligler_Ad_Sezon",
                schema: "fem",
                table: "Ligler",
                columns: new[] { "Ad", "Sezon" });

            migrationBuilder.CreateIndex(
                name: "IX_Ligler_HariciLigId",
                schema: "fem",
                table: "Ligler",
                column: "HariciLigId");

            migrationBuilder.CreateIndex(
                name: "IX_MacIstatistikleri_MacId_TakimId",
                schema: "fem",
                table: "MacIstatistikleri",
                columns: new[] { "MacId", "TakimId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MacIstatistikleri_TakimId",
                schema: "fem",
                table: "MacIstatistikleri",
                column: "TakimId");

            migrationBuilder.CreateIndex(
                name: "IX_Maclar_DeplasmanTakimId",
                schema: "fem",
                table: "Maclar",
                column: "DeplasmanTakimId");

            migrationBuilder.CreateIndex(
                name: "IX_Maclar_EvSahibiTakimId_DeplasmanTakimId_MacTarihi",
                schema: "fem",
                table: "Maclar",
                columns: new[] { "EvSahibiTakimId", "DeplasmanTakimId", "MacTarihi" });

            migrationBuilder.CreateIndex(
                name: "IX_Maclar_HariciMacId",
                schema: "fem",
                table: "Maclar",
                column: "HariciMacId",
                unique: true,
                filter: "[HariciMacId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Maclar_LigId",
                schema: "fem",
                table: "Maclar",
                column: "LigId");

            migrationBuilder.CreateIndex(
                name: "IX_Maclar_MacTarihi",
                schema: "fem",
                table: "Maclar",
                column: "MacTarihi");

            migrationBuilder.CreateIndex(
                name: "IX_TakimFormlari_LigId",
                schema: "fem",
                table: "TakimFormlari",
                column: "LigId");

            migrationBuilder.CreateIndex(
                name: "IX_TakimFormlari_TakimId_LigId_Sezon_SonMacSayisi",
                schema: "fem",
                table: "TakimFormlari",
                columns: new[] { "TakimId", "LigId", "Sezon", "SonMacSayisi" });

            migrationBuilder.CreateIndex(
                name: "IX_Takimlar_Ad",
                schema: "fem",
                table: "Takimlar",
                column: "Ad");

            migrationBuilder.CreateIndex(
                name: "IX_Takimlar_HariciTakimId",
                schema: "fem",
                table: "Takimlar",
                column: "HariciTakimId");

            migrationBuilder.CreateIndex(
                name: "IX_Takimlar_LigId",
                schema: "fem",
                table: "Takimlar",
                column: "LigId");

            migrationBuilder.CreateIndex(
                name: "IX_Uyelikler_BitisTarihi",
                schema: "fem",
                table: "Uyelikler",
                column: "BitisTarihi");

            migrationBuilder.CreateIndex(
                name: "IX_Uyelikler_KullaniciId_Durum",
                schema: "fem",
                table: "Uyelikler",
                columns: new[] { "KullaniciId", "Durum" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Analizler",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "ApiSenkronizasyonLoglari",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "Ayarlar",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "BotLoglari",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "MacIstatistikleri",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "TakimFormlari",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "Uyelikler",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "Maclar",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "Kullanicilar",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "Takimlar",
                schema: "fem");

            migrationBuilder.DropTable(
                name: "Ligler",
                schema: "fem");
        }
    }
}
