# HistoricalData Inbox Paketi

Bu paket yüklenen arşivlerden otomatik ayrıştırılmıştır.

- Inbox içindeki maç CSV sayısı: 244
- Ayrı tutulan maç dışı/uyumsuz CSV sayısı: 1

## Kullanım

`Inbox` klasörünün içeriğini projenizdeki şu klasöre kopyalayın:

FEMEliteAnalysis.Api/HistoricalData/Inbox

Ardından Telegram:

/historikdosyalar
/historikimport
/historikdurum

## Not

`Excluded_NonMatch_Data` altındaki dosyalar mevcut maç importer'ına verilmemelidir.
Bunlar takım sezon özetleri veya otomatik olarak maç şeması tespit edilemeyen dosyalardır.

`inbox_manifest.json`, her dosyanın eski ve yeni adını gösterir.
