namespace FEMEliteAnalysis.Api.Common.Constants;

public static class BotKomutlari
{
    // Genel
    public const string Start = "/start";
    public const string Yardim = "/yardim";
    public const string Id = "/id";
    public const string Uyeligim = "/uyeligim";

    // Admin
    public const string Admin = "/admin";

    // Üyelik
    public const string UyeEkle = "/uyeekle";
    public const string UyeUzat = "/uyeuzat";
    public const string UyeSil = "/uyesil";
    public const string UyeBilgi = "/uyebilgi";
    public const string AktifUyeler = "/aktifuyeler";

    // Akıllı maç seçimi
    public const string UygunMaclar = "/uygunmaclar";
    public const string MacVeriCek = "/macvericek";


    // Football-data.co.uk doğrudan aktarım
    public const string FdLigler = "/fdligler";
    public const string FdIndir = "/fdindir";
    public const string FdToplu = "/fdtoplu";

    // Geçmiş CSV veri aktarımı
    public const string HistorikImport = "/historikimport";
    public const string HistorikDurum = "/historikdurum";
    public const string HistorikDosyalar = "/historikdosyalar";

    // Büyük tarihsel veri havuzu
    public const string HavuzImport = "/havuzimport";
    public const string HavuzDurum = "/havuzdurum";
    public const string HavuzLigler = "/havuzligler";
    public const string VeriSayisi = "/verisayisi";

    // Database repair / takım birleştirme
    public const string TakimTarama = "/takimtarama";
    public const string BirlestirmeOnizle = "/birlestirmeonizle";
    public const string TakimBirlestir = "/takimbirlestir";
    public const string BirlestirmeDurum = "/birlestirmedurum";

    // Analiz
    public const string Analiz = "/analiz";
    public const string Tahmin = "/tahmin";
    public const string Bugun = "/bugun";
    public const string Yarin = "/yarin";
    public const string Takim = "/takim";
    public const string Lig = "/lig";
    public const string MacAra = "/macara";

    // Çoklu kupon
    public const string KuponaEkle = "/kuponaekle";
    public const string Kuponum = "/kuponum";
    public const string KupondanCikar = "/kupondancikar";
    public const string KuponuTemizle = "/kuponutemizle";
    public const string KuponuKaydet = "/kuponukaydet";
    public const string Kuponlar = "/kuponlar";
    public const string KuponHazir = "/kuponhazir";
    public const string KuponOptimize = "/kuponoptimize";
    public const string KuponOtomatik = "/kuponotomatik";
    public const string OtomatikKupon = "/otomatikkupon";
    public const string Kupon = "/kupon";
    public const string KuponAnaliz = "/kuponanaliz";
    public const string KuponAlternatif = "/kuponalternatif";
    public const string KuponKritik = "/kuponkritik";

    // Kupon yayını
    public const string KuponOnizle = "/kupononizle";
    public const string KuponYayinla = "/kuponyayinla";
    public const string TwitterMetni = "/twittermetni";
    public const string Performans = "/performans";
    public const string KuponSonuclari = "/kuponsonuclari";
    public const string MarketPerformans = "/marketperformans";
    public const string HedefKupon = "/hedefkupon";

    // Gerçek oran havuzu
    public const string OranEkle = "/oranekle";
    public const string OranHavuzu = "/oranhavuzu";
    public const string OranCikar = "/orancikar";
    public const string OranTemizle = "/orantemizle";
    public const string OranlariCek = "/oranlaricek";
    public const string OranAnaliz = "/orananaliz";
    public const string KilitMaclar = "/kilitmaclar";
    public const string YuksekDeger = "/yuksekdeger";

    // Veri toplama
    public const string Sync = "/sync";
    public const string SyncDurum = "/syncdurum";
    public const string SyncBaglanti = "/syncbaglanti";
    public const string Sync3Sezon = "/sync3sezon";
    public const string SyncGenis = "/syncgenis";
    public const string SyncIstatistik = "/syncistatistik";
    public const string SyncIstatistikDurum = "/syncistatistikdurum";
    public const string LigAra = "/ligara";
    public const string SyncLig = "/synclig";

    // Debug
    public const string Debug = "/debug";
    public const string DebugTakim = "/debugtakim";
    public const string DebugH2H = "/debugh2h";
    public const string DebugMarket = "/debugmarket";

    // Sistem
    public const string Loglar = "/loglar";
    public const string Ayarlar = "/ayarlar";
    public const string ModDurum = "/moddurum";
    public const string ModAc = "/modac";
    public const string ModKapat = "/modkapat";
}
