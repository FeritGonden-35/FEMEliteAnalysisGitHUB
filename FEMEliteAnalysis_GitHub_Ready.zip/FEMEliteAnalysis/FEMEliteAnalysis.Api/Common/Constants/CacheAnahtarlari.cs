namespace FEMEliteAnalysis.Api.Common.Constants;

public static class CacheAnahtarlari
{
    public static string TarihMaclari(DateOnly tarih)
        => $"maclar:tarih:{tarih:yyyy-MM-dd}";

    public static string MacAnalizVerisi(int macId)
        => $"analiz-verisi:mac:{macId}";

    public static string KayitliAnaliz(int macId)
        => $"analiz:kayitli:mac:{macId}";

    public const string AktifVipUyeler = "vip:aktif-uyeler";
}
