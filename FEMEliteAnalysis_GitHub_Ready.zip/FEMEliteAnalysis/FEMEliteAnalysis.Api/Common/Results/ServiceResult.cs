namespace FEMEliteAnalysis.Api.Common.Results;

public class ServiceResult<T>
{
    public bool Basarili { get; init; }
    public string Mesaj { get; init; } = string.Empty;
    public T? Veri { get; init; }

    public static ServiceResult<T> BasariliSonuc(T veri, string mesaj = "")
        => new() { Basarili = true, Mesaj = mesaj, Veri = veri };

    public static ServiceResult<T> BasarisizSonuc(string mesaj)
        => new() { Basarili = false, Mesaj = mesaj };
}
