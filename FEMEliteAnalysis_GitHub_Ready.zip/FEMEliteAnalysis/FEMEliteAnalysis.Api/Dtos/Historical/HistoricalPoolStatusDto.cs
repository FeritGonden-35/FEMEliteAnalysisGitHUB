namespace FEMEliteAnalysis.Api.Dtos.Historical;

public class HistoricalPoolStatusDto
{
    public bool CalisiyorMu { get; set; }
    public DateTime? BaslamaZamani { get; set; }
    public DateTime? BitisZamani { get; set; }
    public string BaslangicSezonu { get; set; } = string.Empty;
    public string BitisSezonu { get; set; } = string.Empty;
    public int ToplamSezon { get; set; }
    public int IslenenSezon { get; set; }
    public int ToplamLig { get; set; }
    public int BasariliAktarim { get; set; }
    public int BasarisizAktarim { get; set; }
    public long EklenenMac { get; set; }
    public long GuncellenenMac { get; set; }
    public string SonIslem { get; set; } = "Henüz çalışma yapılmadı.";
    public string? SonHata { get; set; }
}
