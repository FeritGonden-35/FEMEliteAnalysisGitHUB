namespace FEMEliteAnalysis.Api.Dtos.Historical;

public class HistoricalImportResultDto
{
    public string DosyaAdi { get; set; } = string.Empty;
    public DateTime BaslamaZamani { get; set; }
    public DateTime BitisZamani { get; set; }
    public bool Basarili { get; set; }
    public string Mesaj { get; set; } = string.Empty;
    public int OkunanSatir { get; set; }
    public int EklenenMac { get; set; }
    public int GuncellenenMac { get; set; }
    public int AtlananSatir { get; set; }
    public int YeniTakim { get; set; }
    public int YeniLig { get; set; }
    public int AliasEslesmesi { get; set; }
    public List<string> Uyarilar { get; set; } = new();
}
