namespace FEMEliteAnalysis.Api.Dtos.Historical;

public class FootballDataImportResultDto
{
    public string LigKodu { get; set; } = string.Empty;
    public string LigAdi { get; set; } = string.Empty;
    public string Sezon { get; set; } = string.Empty;
    public DateTime BaslamaZamani { get; set; }
    public DateTime BitisZamani { get; set; }
    public bool Basarili { get; set; }
    public string Mesaj { get; set; } = string.Empty;
    public int KaynaktanGelenMac { get; set; }
    public int EklenenMac { get; set; }
    public int GuncellenenMac { get; set; }
    public int YeniTakim { get; set; }
    public int YeniLig { get; set; }
    public int EklenenIstatistik { get; set; }
    public int GuncellenenIstatistik { get; set; }
    public int AtlananMac { get; set; }
    public List<string> Uyarilar { get; set; } = new();
}
