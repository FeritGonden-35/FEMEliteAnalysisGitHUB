namespace FEMEliteAnalysis.Api.Dtos.Historical;

public class HistoricalImportStatusDto
{
    public bool CalisiyorMu { get; set; }
    public DateTime? SonBaslama { get; set; }
    public DateTime? SonBitis { get; set; }
    public string SonMesaj { get; set; } = "Henüz çalışmadı.";
    public List<HistoricalImportResultDto> SonSonuclar { get; set; } = new();
}
