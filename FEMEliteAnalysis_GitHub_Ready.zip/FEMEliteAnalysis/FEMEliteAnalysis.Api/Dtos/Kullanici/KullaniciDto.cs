namespace FEMEliteAnalysis.Api.Dtos.Kullanici;

public class KullaniciDto
{
    public int Id { get; set; }
    public long TelegramKullaniciId { get; set; }
    public string? KullaniciAdi { get; set; }
    public string? AdSoyad { get; set; }
    public bool AdminMi { get; set; }
    public bool EngellendiMi { get; set; }
    public bool AktifVipMi { get; set; }
    public DateTime? UyelikBitisTarihi { get; set; }
}
