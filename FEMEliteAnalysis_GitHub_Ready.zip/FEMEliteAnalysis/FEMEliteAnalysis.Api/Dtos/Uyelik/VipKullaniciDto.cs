namespace FEMEliteAnalysis.Api.Dtos.Uyelik;

public class VipKullaniciDto
{
    public int KullaniciId { get; set; }
    public long TelegramKullaniciId { get; set; }
    public string? KullaniciAdi { get; set; }
    public string AdSoyad { get; set; } = string.Empty;
    public DateTime BaslangicTarihi { get; set; }
    public DateTime BitisTarihi { get; set; }
    public int KalanGun { get; set; }
}
