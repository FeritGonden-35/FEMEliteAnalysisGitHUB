namespace FEMEliteAnalysis.Api.Dtos.Uyelik;

public class UyelikEkleRequest
{
    public long TelegramKullaniciId { get; set; }
    public int Gun { get; set; }
    public string? Aciklama { get; set; }
}
