namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class KuponOptimizasyonMacDto
{
    public int AnalizId { get; set; }
    public int MacId { get; set; }
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public string Market { get; set; } = string.Empty;
    public int HamGuvenPuani { get; set; }
    public int DuzenlenmisGuvenPuani { get; set; }
    public string Lig { get; set; } = string.Empty;
    public DateTime MacTarihi { get; set; }
    public string RiskSeviyesi { get; set; } = string.Empty;
    public List<string> Uyarilar { get; set; } = new();
}
