namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class CokluKuponMacSecimiDto
{
    public int MacId { get; set; }
    public int AnalizId { get; set; }

    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;

    public string SecilenMarket { get; set; } = string.Empty;
    public int GuvenPuani { get; set; }

    public bool AktifMi { get; set; } = true;
}
