namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class HedefKuponDto
{
    public decimal HedefOran { get; set; }
    public decimal ToplamOran { get; set; }
    public decimal HedefSapmaYuzdesi { get; set; }
    public int OrtalamaGuven { get; set; }
    public List<HedefKuponSecimDto> Secimler { get; set; } = new();
}

public class HedefKuponSecimDto
{
    public int AnalizId { get; set; }
    public int MacId { get; set; }
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public string Market { get; set; } = string.Empty;
    public decimal Oran { get; set; }
    public int Guven { get; set; }
    public int VeriKalitesi { get; set; }
    public bool TahminiOranMi { get; set; }
}
