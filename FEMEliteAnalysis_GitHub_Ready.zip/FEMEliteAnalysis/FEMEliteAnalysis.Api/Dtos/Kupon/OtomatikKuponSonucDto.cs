namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class OtomatikKuponSonucDto
{
    public string Mod { get; set; } = string.Empty;
    public int IstenenAdet { get; set; }
    public int UretilenAdet { get; set; }
    public int IncelenenMac { get; set; }
    public int ShortlistMac { get; set; }
    public int OddsApiIstek { get; set; }
    public int GercekOranliMac { get; set; }
    public List<OtomatikKuponKayitDto> Kuponlar { get; set; } = new();
}

public class OtomatikKuponKayitDto
{
    public int KuponId { get; set; }
    public string Baslik { get; set; } = string.Empty;
    public decimal ToplamOran { get; set; }
    public int OrtalamaGuven { get; set; }
    public int SecimSayisi { get; set; }
}
