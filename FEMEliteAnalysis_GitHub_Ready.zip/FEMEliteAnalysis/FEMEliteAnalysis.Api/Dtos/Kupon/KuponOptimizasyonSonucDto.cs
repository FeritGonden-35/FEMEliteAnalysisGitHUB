namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class KuponOptimizasyonSonucDto
{
    public int MevcutMacSayisi { get; set; }
    public int MevcutOrtalamaGuven { get; set; }
    public int MevcutOptimizasyonPuani { get; set; }
    public string MevcutRiskSeviyesi { get; set; } = string.Empty;
    public List<KuponOptimizasyonMacDto> TumMaclar { get; set; } = new();
    public KuponKombinasyonDto? OnerilenKupon { get; set; }
    public List<KuponKombinasyonDto> Alternatifler { get; set; } = new();
    public KuponOptimizasyonMacDto? EnZayifSecim { get; set; }
    public List<string> Kritikler { get; set; } = new();
}
