namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class KuponPerformansDto
{
    public int ToplamKupon { get; set; }
    public int KazananKupon { get; set; }
    public int KaybedenKupon { get; set; }
    public int BekleyenKupon { get; set; }
    public decimal KuponBasariYuzdesi { get; set; }
    public int ToplamSecim { get; set; }
    public int KazananSecim { get; set; }
    public int KaybedenSecim { get; set; }
    public int BekleyenSecim { get; set; }
    public decimal SecimBasariYuzdesi { get; set; }
    public List<MarketPerformansDto> Marketler { get; set; } = new();
    public List<OranBandPerformansDto> OranBantlari { get; set; } = new();
    public List<KuponSonucOzetDto> SonKuponlar { get; set; } = new();
}

public class MarketPerformansDto
{
    public string Market { get; set; } = string.Empty;
    public int Toplam { get; set; }
    public int Kazanan { get; set; }
    public int Kaybeden { get; set; }
    public decimal BasariYuzdesi { get; set; }
}

public class OranBandPerformansDto
{
    public string Bant { get; set; } = string.Empty;
    public int Toplam { get; set; }
    public int Kazanan { get; set; }
    public int Kaybeden { get; set; }
    public decimal BasariYuzdesi { get; set; }
}

public class KuponSonucOzetDto
{
    public int KuponId { get; set; }
    public string Baslik { get; set; } = string.Empty;
    public decimal? ToplamOran { get; set; }
    public string Sonuc { get; set; } = "Bekliyor";
    public int KazananSecim { get; set; }
    public int KaybedenSecim { get; set; }
    public int BekleyenSecim { get; set; }
    public DateTime? YayinlanmaTarihi { get; set; }
}
