namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class CokluKuponTaslakDto
{
    public long AdminTelegramId { get; set; }

    public List<CokluKuponMacSecimiDto> Maclar { get; set; } = new();

    public int OrtalamaGuvenPuani =>
        Maclar.Count == 0
            ? 0
            : (int)Math.Round(
                Maclar.Average(x => x.GuvenPuani));

    public string RiskSeviyesi =>
        OrtalamaGuvenPuani switch
        {
            >= 80 => "Düşük",
            >= 65 => "Orta",
            _ => "Yüksek"
        };
}
