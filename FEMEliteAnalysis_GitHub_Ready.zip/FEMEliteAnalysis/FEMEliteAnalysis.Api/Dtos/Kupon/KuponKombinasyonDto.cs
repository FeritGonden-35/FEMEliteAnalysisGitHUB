namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class KuponKombinasyonDto
{
    public int Sira { get; set; }
    public List<KuponOptimizasyonMacDto> Maclar { get; set; } = new();
    public int OrtalamaGuven { get; set; }
    public int OptimizasyonPuani { get; set; }
    public string RiskSeviyesi { get; set; } = string.Empty;
    public List<string> Uyarilar { get; set; } = new();
}
