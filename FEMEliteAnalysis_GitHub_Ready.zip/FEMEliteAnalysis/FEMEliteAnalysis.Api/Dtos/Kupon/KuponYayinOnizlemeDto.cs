namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class KuponYayinOnizlemeDto
{
    public int KuponId { get; set; }
    public string Baslik { get; set; } = string.Empty;
    public string VipMetni { get; set; } = string.Empty;
    public string UcretsizKanalMetni { get; set; } = string.Empty;
    public string TwitterMetni { get; set; } = string.Empty;
    public bool DahaOnceYayinlandiMi { get; set; }
    public DateTime? YayinlanmaTarihi { get; set; }
}
