namespace FEMEliteAnalysis.Api.Dtos.Kupon;

public class YuksekOranPatternKuponDto
{
    public int IncelenenMacSayisi { get; set; }
    public int YeterliVeriliMacSayisi { get; set; }
    public decimal ToplamOran { get; set; }
    public bool TahminiOranIceriyorMu { get; set; }
    public bool FallbackKullanildiMi { get; set; }
    public List<YuksekOranPatternSecimDto> Secimler { get; set; } = new();
}

public class YuksekOranPatternSecimDto
{
    public int AnalizId { get; set; }
    public int MacId { get; set; }
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public string Pattern { get; set; } = string.Empty;
    public int PatternSkoru { get; set; }
    public int VeriKalitesi { get; set; }
    public decimal Oran { get; set; }
    public bool TahminiOranMi { get; set; }
    public PatternTakimIstatistikDto EvIstatistik { get; set; } = new();
    public PatternTakimIstatistikDto DepIstatistik { get; set; } = new();
}

public class PatternTakimIstatistikDto
{
    public int Son10Isabet { get; set; }
    public int Son10Toplam { get; set; }
    public int Son20Isabet { get; set; }
    public int Son20Toplam { get; set; }
    public int Son40Isabet { get; set; }
    public int Son40Toplam { get; set; }
}
