namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class KuponMarketAnaliziDto
{
    public int MacId { get; set; }
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;

    public int VeriKalitesiPuani { get; set; }
    public string GenelRiskSeviyesi { get; set; } = string.Empty;

    public List<KuponMarketSkoruDto> Marketler { get; set; } = new();
    public List<KuponMarketSkoruDto> EnGucluAdaylar { get; set; } = new();
    public List<KuponMarketSkoruDto> UzakDurulacaklar { get; set; } = new();

    public List<string> VeriEksikleri { get; set; } = new();
}
