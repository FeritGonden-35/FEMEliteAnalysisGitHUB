namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class MacAnalizVerisiDto
{
    public int MacId { get; set; }
    public int? HariciMacId { get; set; }

    public string Lig { get; set; } = string.Empty;
    public string? Ulke { get; set; }
    public string? Sezon { get; set; }

    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;

    public DateTime MacTarihi { get; set; }
    public string? Stadyum { get; set; }
    public string? Hakem { get; set; }
    public string? Durum { get; set; }

    public TakimAnalizOzetiDto EvSahibiFormu { get; set; } = new();
    public TakimAnalizOzetiDto DeplasmanFormu { get; set; } = new();

    public List<GecmisMacOzetiDto> EvSahibiSonMaclar { get; set; } = new();
    public List<GecmisMacOzetiDto> DeplasmanSonMaclar { get; set; } = new();
    public List<GecmisMacOzetiDto> IkiliRekabet { get; set; } = new();
}

public class TakimAnalizOzetiDto
{
    public int TakimId { get; set; }
    public string TakimAdi { get; set; } = string.Empty;

    public int SonMacSayisi { get; set; }
    public int Galibiyet { get; set; }
    public int Beraberlik { get; set; }
    public int Maglubiyet { get; set; }

    public int AttigiGol { get; set; }
    public int YedigiGol { get; set; }

    public decimal MacBasinaGolOrtalamasi { get; set; }
    public decimal MacBasinaYenilenGolOrtalamasi { get; set; }
    public decimal IkiBucukUstYuzdesi { get; set; }
    public decimal KarsilikliGolYuzdesi { get; set; }
}

public class GecmisMacOzetiDto
{
    public int MacId { get; set; }
    public DateTime MacTarihi { get; set; }

    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;

    public int? EvSahibiSkor { get; set; }
    public int? DeplasmanSkor { get; set; }

    public string? Durum { get; set; }
}
