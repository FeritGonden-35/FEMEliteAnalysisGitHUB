namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class AnalizKategoriSkoruDto
{
    public string Kod { get; set; } = string.Empty;
    public string Ad { get; set; } = string.Empty;

    public int EvSahibiPuani { get; set; }
    public int DeplasmanPuani { get; set; }

    public string Aciklama { get; set; } = string.Empty;
}
