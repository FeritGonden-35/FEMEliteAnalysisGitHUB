namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class KuponMarketSkoruDto
{
    public string Kod { get; set; } = string.Empty;
    public string Ad { get; set; } = string.Empty;
    public string Kategori { get; set; } = "Genel";
    public bool SurprizMi { get; set; }
    public int OrneklemSayisi { get; set; }

    public int HamGuvenPuani { get; set; }
    public int GuvenPuani { get; set; }
    public decimal ModelOlasiligi { get; set; }
    public decimal? Oran { get; set; }
    public decimal? PiyasaOlasiligi { get; set; }
    public decimal? EdgeYuzdesi { get; set; }
    public decimal? BeklenenDeger { get; set; }
    public bool DegerliBahisMi { get; set; }
    public string RiskSeviyesi { get; set; } = string.Empty;

    public bool OneriliyorMu { get; set; }
    public bool UzakDurMu { get; set; }

    public List<string> Gerekceler { get; set; } = new();
}
