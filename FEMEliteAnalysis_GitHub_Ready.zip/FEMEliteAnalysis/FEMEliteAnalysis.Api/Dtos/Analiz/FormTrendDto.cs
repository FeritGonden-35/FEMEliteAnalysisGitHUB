namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class FormTrendDto
{
    public string TakimAdi { get; set; } = string.Empty;

    public decimal SonBesMacPuani { get; set; }
    public decimal OncekiBesMacPuani { get; set; }

    public decimal Degisim { get; set; }

    public string Trend { get; set; } = string.Empty;
    public string Aciklama { get; set; } = string.Empty;
}
