namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class AnalizOlusturRequest
{
    public int MacId { get; set; }
    public string AnalizTuru { get; set; } = string.Empty;
    public string KullaniciTahmini { get; set; } = string.Empty;
}
