namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class OddsPatternSonucDto
{
    public int PatternNo { get; set; }
    public string Referans { get; set; } = string.Empty;
    public decimal Benzerlik { get; set; }
    public bool Simetrik { get; set; }
    public int Orneklem { get; set; }
    public Dictionary<string, decimal> BasariOranlari { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public string EnGucluSinyal { get; set; } = string.Empty;
    public decimal EnGucluSinyalYuzdesi { get; set; }
    public string Durum { get; set; } = "Veri yetersiz";
}

public class KilitMacSecimDto
{
    public int MacId { get; set; }
    public DateTime MacTarihi { get; set; }
    public string Lig { get; set; } = string.Empty;
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public string Market { get; set; } = string.Empty;
    public decimal Oran { get; set; }
    public int ModelGuven { get; set; }
    public decimal Edge { get; set; }
    public decimal BeklenenDeger { get; set; }
    public int MarketOrneklem { get; set; }
    public decimal? GecmisMarketBasari { get; set; }
    public int GecmisMarketOrneklem { get; set; }
    public decimal PatternSkoru { get; set; }
    public string PatternBilgisi { get; set; } = string.Empty;
    public decimal FinalSkor { get; set; }
    public List<string> Nedenler { get; set; } = new();
}

public class KilitMaclarSonucDto
{
    public int IncelenenMac { get; set; }
    public int Shortlist { get; set; }
    public int ApiIstek { get; set; }
    public List<KilitMacSecimDto> Secimler { get; set; } = new();
}
