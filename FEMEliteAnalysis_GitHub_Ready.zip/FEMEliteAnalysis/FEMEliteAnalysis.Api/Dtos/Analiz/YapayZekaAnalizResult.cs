namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class YapayZekaAnalizResult
{
    public string Ozet { get; set; } = string.Empty;
    public int GuvenPuani { get; set; }
    public string RiskSeviyesi { get; set; } = "Orta";
    public decimal EvSahibiKazanmaOlasiligi { get; set; }
    public decimal BeraberlikOlasiligi { get; set; }
    public decimal DeplasmanKazanmaOlasiligi { get; set; }
    public List<string> AnaFaktorler { get; set; } = new();
}
