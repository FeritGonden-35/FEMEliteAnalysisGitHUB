namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class GuvenBileseniDto
{
    public string Ad { get; set; } = string.Empty;
    public int Puan { get; set; }
    public int Maksimum { get; set; }
}
