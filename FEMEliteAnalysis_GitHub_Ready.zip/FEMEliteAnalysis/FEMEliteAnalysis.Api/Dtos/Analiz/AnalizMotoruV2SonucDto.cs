namespace FEMEliteAnalysis.Api.Dtos.Analiz;

public class AnalizMotoruV2SonucDto
{
    public int MacId { get; set; }

    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;

    public int VeriKalitesiPuani { get; set; }
    public int GenelGuvenPuani { get; set; }

    public string GenelRiskSeviyesi { get; set; } = string.Empty;
    public string MacProfili { get; set; } = string.Empty;

    public List<AnalizKategoriSkoruDto> Kategoriler { get; set; } = new();
    public List<KuponMarketSkoruDto> Marketler { get; set; } = new();

    public List<KuponMarketSkoruDto> EnGucluAdaylar { get; set; } = new();
    public List<KuponMarketSkoruDto> AlternatifAdaylar { get; set; } = new();
    public List<KuponMarketSkoruDto> UzakDurulacaklar { get; set; } = new();

    public List<string> PozitifFaktorler { get; set; } = new();
    public List<string> RiskFaktorleri { get; set; } = new();
    public List<string> VeriEksikleri { get; set; } = new();

    public FormTrendDto EvSahibiFormTrendi { get; set; } = new();
    public FormTrendDto DeplasmanFormTrendi { get; set; } = new();
    public List<GuvenBileseniDto> GuvenDagilimi { get; set; } = new();
    public int EvSahibiGucPuani { get; set; }
    public int DeplasmanGucPuani { get; set; }
}
