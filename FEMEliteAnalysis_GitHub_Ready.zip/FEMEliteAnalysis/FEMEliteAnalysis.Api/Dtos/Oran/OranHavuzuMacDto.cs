namespace FEMEliteAnalysis.Api.Dtos.Oran;

public class OranHavuzuMacDto
{
    public int MacId { get; set; }
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public DateTime MacTarihi { get; set; }
}
