namespace FEMEliteAnalysis.Api.Dtos.Oran;

public class OranSyncSonucDto
{
    public int MacId { get; set; }
    public string MacAdi { get; set; } = string.Empty;
    public bool EslesmeBulundu { get; set; }
    public long? OddsEventId { get; set; }
    public int KaydedilenOran { get; set; }
    public int ApiIstekSayisi { get; set; }
    public string Mesaj { get; set; } = string.Empty;
}
