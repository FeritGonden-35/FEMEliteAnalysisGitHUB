namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class H2HOzetDto
{
    public int Takim1Id { get; set; }
    public string Takim1Adi { get; set; } = string.Empty;

    public int Takim2Id { get; set; }
    public string Takim2Adi { get; set; } = string.Empty;

    public int ToplamMac { get; set; }

    public int Takim1Galibiyet { get; set; }
    public int Beraberlik { get; set; }
    public int Takim2Galibiyet { get; set; }

    public decimal OrtalamaToplamGol { get; set; }
    public decimal BirBucukUstYuzdesi { get; set; }
    public decimal IkiBucukUstYuzdesi { get; set; }
    public decimal UcBucukUstYuzdesi { get; set; }
    public decimal KarsilikliGolYuzdesi { get; set; }
    public decimal IlkYariGolYuzdesi { get; set; }

    public List<TakimGecmisMacDto> Maclar { get; set; } = new();
}
