namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class TakimMarketIstatistikDto
{
    public int KayitSayisi { get; set; }
    public int KornerKayitSayisi { get; set; }
    public int KartKayitSayisi { get; set; }

    public decimal OrtalamaKorner { get; set; }
    public decimal MedyanKorner { get; set; }
    public decimal Son5OrtalamaKorner { get; set; }
    public decimal KornerStandartSapma { get; set; }
    public decimal OrtalamaRakipKorner { get; set; }
    public decimal MedyanRakipKorner { get; set; }

    public decimal OrtalamaKart { get; set; }
    public decimal MedyanKart { get; set; }
    public decimal OrtalamaSut { get; set; }
    public decimal OrtalamaIsabetliSut { get; set; }
    public decimal OrtalamaFaul { get; set; }

    // Market motoru gerçek gerçekleşme yüzdesini hesaplayabilsin diye son örneklemler.
    public List<int> KornerDegerleri { get; set; } = new();
    public List<int> RakipKornerDegerleri { get; set; } = new();
    public List<int> KartDegerleri { get; set; } = new();
}
