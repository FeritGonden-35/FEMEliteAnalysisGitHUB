namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class TakimGecmisVerisiDto
{
    public int TakimId { get; set; }
    public int HariciTakimId { get; set; }
    public string TakimAdi { get; set; } = string.Empty;

    public int ToplamMac { get; set; }
    public int Galibiyet { get; set; }
    public int Beraberlik { get; set; }
    public int Maglubiyet { get; set; }

    public int AttigiGol { get; set; }
    public int YedigiGol { get; set; }

    public decimal MacBasinaGol { get; set; }
    public decimal MacBasinaYenilenGol { get; set; }

    public decimal BirBucukUstYuzdesi { get; set; }
    public decimal IkiBucukUstYuzdesi { get; set; }
    public decimal UcBucukUstYuzdesi { get; set; }

    public decimal KarsilikliGolYuzdesi { get; set; }
    public decimal GolYemedenBitirmeYuzdesi { get; set; }
    public decimal IlkYariGolYuzdesi { get; set; }
    public decimal IlkYariBirBucukUstYuzdesi { get; set; }
    public decimal IlkYariKarsilikliGolYuzdesi { get; set; }

    public List<TakimGecmisMacDto> Maclar { get; set; } = new();
}
