using System.Text.Json.Serialization;

namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class ApiFootballFixtureResponse
{
    [JsonPropertyName("response")]
    public List<ApiFootballFixtureItem> Response { get; set; } = new();
}

public class ApiFootballFixtureItem
{
    [JsonPropertyName("fixture")]
    public ApiFootballFixture Fixture { get; set; } = new();

    [JsonPropertyName("league")]
    public ApiFootballLeague League { get; set; } = new();

    [JsonPropertyName("teams")]
    public ApiFootballTeams Teams { get; set; } = new();

    [JsonPropertyName("goals")]
    public ApiFootballGoals Goals { get; set; } = new();

    [JsonPropertyName("score")]
    public ApiFootballScore Score { get; set; } = new();
}

public class ApiFootballFixture
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("date")]
    public DateTime Date { get; set; }

    [JsonPropertyName("timezone")]
    public string? Timezone { get; set; }

    [JsonPropertyName("referee")]
    public string? Referee { get; set; }

    [JsonPropertyName("venue")]
    public ApiFootballVenue? Venue { get; set; }

    [JsonPropertyName("status")]
    public ApiFootballStatus Status { get; set; } = new();
}

public class ApiFootballVenue
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("city")]
    public string? City { get; set; }
}

public class ApiFootballStatus
{
    [JsonPropertyName("long")]
    public string? Long { get; set; }

    [JsonPropertyName("short")]
    public string? Short { get; set; }

    [JsonPropertyName("elapsed")]
    public int? Elapsed { get; set; }
}

public class ApiFootballLeague
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("country")]
    public string? Country { get; set; }

    [JsonPropertyName("logo")]
    public string? Logo { get; set; }

    [JsonPropertyName("season")]
    public int Season { get; set; }

    [JsonPropertyName("round")]
    public string? Round { get; set; }
}

public class ApiFootballTeams
{
    [JsonPropertyName("home")]
    public ApiFootballTeam Home { get; set; } = new();

    [JsonPropertyName("away")]
    public ApiFootballTeam Away { get; set; } = new();
}

public class ApiFootballTeam
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("logo")]
    public string? Logo { get; set; }

    [JsonPropertyName("winner")]
    public bool? Winner { get; set; }
}

public class ApiFootballGoals
{
    [JsonPropertyName("home")]
    public int? Home { get; set; }

    [JsonPropertyName("away")]
    public int? Away { get; set; }
}

public class ApiFootballScore
{
    [JsonPropertyName("halftime")]
    public ApiFootballGoals Halftime { get; set; } = new();

    [JsonPropertyName("fulltime")]
    public ApiFootballGoals Fulltime { get; set; } = new();
}
