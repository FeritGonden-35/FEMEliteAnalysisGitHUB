namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class MacKuponVerisiDto
{
    public int MacId { get; set; }
    public int HariciMacId { get; set; }

    public string Lig { get; set; } = string.Empty;
    public DateTime MacTarihi { get; set; }

    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;

    public TakimGecmisVerisiDto EvSahibiGenelForm { get; set; } = new();
    public TakimGecmisVerisiDto EvSahibiIcSahaForm { get; set; } = new();

    public TakimGecmisVerisiDto DeplasmanGenelForm { get; set; } = new();
    public TakimGecmisVerisiDto DeplasmanDisSahaForm { get; set; } = new();

    public H2HOzetDto H2H { get; set; } = new();

    public TakimMarketIstatistikDto EvSahibiIstatistik { get; set; } = new();
    public TakimMarketIstatistikDto DeplasmanIstatistik { get; set; } = new();

    // Genel veri kalitesi yalnızca temel maç/form verisinin kapsamasını temsil eder.
    // H2H, korner ve kart eksikliği artık genel puanı gereksiz yere aşağı çekmez.
    public int VeriKalitesiPuani { get; set; }

    // V4.2: market bazlı veri kalitesi. Her market kendi veri yeterliliğiyle değerlendirilir.
    public int MacSonucuVeriKalitesi { get; set; }
    public int GolMarketVeriKalitesi { get; set; }
    public int IlkYariVeriKalitesi { get; set; }
    public int KornerVeriKalitesi { get; set; }
    public int KartVeriKalitesi { get; set; }
    public int H2HVeriKalitesi { get; set; }

    public List<string> VeriEksikleri { get; set; } = new();
}
