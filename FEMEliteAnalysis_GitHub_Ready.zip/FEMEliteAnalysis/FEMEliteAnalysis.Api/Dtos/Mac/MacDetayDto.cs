namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class MacDetayDto
{
    public int Id { get; set; }
    public string Lig { get; set; } = string.Empty;
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public DateTime MacTarihi { get; set; }
    public string? Durum { get; set; }
}
