namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class SeciliMacVeriCekSonucDto
{
    public int MacId { get; set; }
    public string MacAdi { get; set; } = string.Empty;
    public int ApiKayitSayisi { get; set; }
    public int EklenenMacSayisi { get; set; }
    public int GuncellenenMacSayisi { get; set; }
    public int VeriKalitesiOnce { get; set; }
    public int VeriKalitesiSonra { get; set; }
    public List<string> Bilgiler { get; set; } = new();
    public List<string> Uyarilar { get; set; } = new();
}

