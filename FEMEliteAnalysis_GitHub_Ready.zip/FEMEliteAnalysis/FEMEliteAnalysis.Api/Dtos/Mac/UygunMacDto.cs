namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class UygunMacDto
{
    public int MacId { get; set; }
    public DateTime MacTarihi { get; set; }
    public string Lig { get; set; } = string.Empty;
    public string EvSahibi { get; set; } = string.Empty;
    public string Deplasman { get; set; } = string.Empty;
    public int EvGenelMac { get; set; }
    public int EvIcSahaMac { get; set; }
    public int DepGenelMac { get; set; }
    public int DepDisSahaMac { get; set; }
    public int H2HMac { get; set; }
    public int VeriGuvenPuani { get; set; }
    public int Yildiz { get; set; }
    public string Rozet { get; set; } = string.Empty;
}

