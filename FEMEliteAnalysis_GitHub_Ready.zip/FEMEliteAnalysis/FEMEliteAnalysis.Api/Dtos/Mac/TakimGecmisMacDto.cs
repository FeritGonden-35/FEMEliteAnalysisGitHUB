namespace FEMEliteAnalysis.Api.Dtos.Mac;

public class TakimGecmisMacDto
{
    public int MacId { get; set; }
    public int HariciMacId { get; set; }
    public DateTime MacTarihi { get; set; }

    public int LigId { get; set; }
    public string LigAdi { get; set; } = string.Empty;

    public int EvSahibiTakimId { get; set; }
    public string EvSahibiTakim { get; set; } = string.Empty;

    public int DeplasmanTakimId { get; set; }
    public string DeplasmanTakim { get; set; } = string.Empty;

    public int EvSahibiGol { get; set; }
    public int DeplasmanGol { get; set; }

    public int? IlkYariEvSahibiGol { get; set; }
    public int? IlkYariDeplasmanGol { get; set; }

    public bool TakimEvSahibiMi { get; set; }
    public bool KazandiMi { get; set; }
    public bool BerabereMi { get; set; }
    public bool KaybettiMi { get; set; }

    public bool BirBucukUstMu { get; set; }
    public bool IkiBucukUstMu { get; set; }
    public bool UcBucukUstMu { get; set; }
    public bool KarsilikliGolVarMi { get; set; }
    public bool GolYemedenBitirdiMi { get; set; }
    public bool IlkYaridaGolVarMi { get; set; }
    public bool IlkYariBirBucukUstMu { get; set; }
    public bool IlkYariKarsilikliGolVarMi { get; set; }
    public int IlkYariSonucu { get; set; } // 1: ev, 0: beraberlik, 2: dep
    public int MacSonucu { get; set; } // 1: ev, 0: beraberlik, 2: dep
}
