namespace FEMEliteAnalysis.Api.Dtos.Lig;

public sealed class LigAramaSonucuDto
{
    public int LigId { get; set; }
    public string Ad { get; set; } = string.Empty;
    public string Ulke { get; set; } = string.Empty;
    public string Tur { get; set; } = string.Empty;
    public string? Logo { get; set; }
    public List<int> Sezonlar { get; set; } = new();
}
