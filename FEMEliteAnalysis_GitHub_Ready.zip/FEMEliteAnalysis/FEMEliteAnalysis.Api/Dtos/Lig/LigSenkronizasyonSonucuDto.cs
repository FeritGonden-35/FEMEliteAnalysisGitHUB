namespace FEMEliteAnalysis.Api.Dtos.Lig;

public sealed class LigSenkronizasyonSonucuDto
{
    public int LigId { get; set; }
    public string LigAdi { get; set; } = string.Empty;
    public List<int> Sezonlar { get; set; } = new();
    public int GelenMacSayisi { get; set; }
    public int EklenenMacSayisi { get; set; }
    public int GuncellenenMacSayisi { get; set; }
    public int EklenenTakimSayisi { get; set; }
    public List<string> Uyarilar { get; set; } = new();
}
