using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Dtos.VeriToplama;

public class VeriToplamaSonucDto
{
    public VeriSaglayiciTuru SaglayiciTuru { get; set; }

    public DateTime BaslamaZamani { get; set; }
    public DateTime BitisZamani { get; set; }

    public bool Basarili { get; set; }
    public string Mesaj { get; set; } = string.Empty;

    public int GelenLigSayisi { get; set; }
    public int GelenTakimSayisi { get; set; }
    public int GelenMacSayisi { get; set; }

    public int EklenenKayitSayisi { get; set; }
    public int GuncellenenKayitSayisi { get; set; }
    public int AtlananKayitSayisi { get; set; }

    public List<string> Uyarilar { get; set; } = new();

    public TimeSpan GecenSure => BitisZamani - BaslamaZamani;
}
