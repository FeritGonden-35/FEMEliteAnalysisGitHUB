using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Dtos.VeriToplama;

public class VeriToplamaIstekDto
{
    public VeriSaglayiciTuru SaglayiciTuru { get; set; }
    public DateOnly BaslangicTarihi { get; set; }
    public DateOnly BitisTarihi { get; set; }

    public List<int> LigIdleri { get; set; } = new();

    public bool MaclariGetir { get; set; } = true;
    public bool TakimlariGetir { get; set; } = true;
    public bool SonuclariGuncelle { get; set; } = true;
    public bool GecmisFormuGetir { get; set; } = true;
}
