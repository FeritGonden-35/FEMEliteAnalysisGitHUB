namespace FEMEliteAnalysis.Api.Dtos.Debug;

public class MacDebugDto
{
    public int MacId { get; set; }
    public string MacAdi { get; set; } = string.Empty;
    public DateTime MacTarihi { get; set; }

    public int EvTakimId { get; set; }
    public string EvTakimAdi { get; set; } = string.Empty;
    public int? EvHariciTakimId { get; set; }
    public int EvGenelMacSayisi { get; set; }
    public int EvIcSahaMacSayisi { get; set; }
    public DateTime? EvSonMacTarihi { get; set; }

    public int DepTakimId { get; set; }
    public string DepTakimAdi { get; set; } = string.Empty;
    public int? DepHariciTakimId { get; set; }
    public int DepGenelMacSayisi { get; set; }
    public int DepDisSahaMacSayisi { get; set; }
    public DateTime? DepSonMacTarihi { get; set; }

    public int H2HMacSayisi { get; set; }
    public int VeriKalitesiPuani { get; set; }

    public List<string> Uyarilar { get; set; } = new();
}
