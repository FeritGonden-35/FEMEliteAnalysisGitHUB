using System.Text.Json.Serialization;

namespace FEMEliteAnalysis.Api.Dtos.TheSportsDb;

public class TheSportsDbEventDto
{
    [JsonPropertyName("idEvent")]
    public string? EventId { get; set; }

    [JsonPropertyName("idLeague")]
    public string? LeagueId { get; set; }

    [JsonPropertyName("strLeague")]
    public string? LeagueName { get; set; }

    [JsonPropertyName("strSeason")]
    public string? Season { get; set; }

    [JsonPropertyName("strEvent")]
    public string? EventName { get; set; }

    [JsonPropertyName("idHomeTeam")]
    public string? HomeTeamId { get; set; }

    [JsonPropertyName("strHomeTeam")]
    public string? HomeTeamName { get; set; }

    [JsonPropertyName("idAwayTeam")]
    public string? AwayTeamId { get; set; }

    [JsonPropertyName("strAwayTeam")]
    public string? AwayTeamName { get; set; }

    [JsonPropertyName("dateEvent")]
    public string? DateEvent { get; set; }

    [JsonPropertyName("strTime")]
    public string? Time { get; set; }

    [JsonPropertyName("strTimestamp")]
    public string? Timestamp { get; set; }

    [JsonPropertyName("intHomeScore")]
    public string? HomeScore { get; set; }

    [JsonPropertyName("intAwayScore")]
    public string? AwayScore { get; set; }

    [JsonPropertyName("intHomeScoreHalfTime")]
    public string? HomeHalfTimeScore { get; set; }

    [JsonPropertyName("intAwayScoreHalfTime")]
    public string? AwayHalfTimeScore { get; set; }

    [JsonPropertyName("strStatus")]
    public string? Status { get; set; }

    [JsonPropertyName("strVenue")]
    public string? Venue { get; set; }

    [JsonPropertyName("strCountry")]
    public string? Country { get; set; }

    [JsonPropertyName("strPostponed")]
    public string? Postponed { get; set; }
}
