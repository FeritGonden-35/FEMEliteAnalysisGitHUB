using System.Text.Json.Serialization;

namespace FEMEliteAnalysis.Api.Dtos.TheSportsDb;

public class TheSportsDbEventsResponse
{
    [JsonPropertyName("events")]
    public List<TheSportsDbEventDto>? Events { get; set; }

    // eventslast.php bazı yanıtlarda geçmiş maçları "results" alanında döndürür.
    [JsonPropertyName("results")]
    public List<TheSportsDbEventDto>? Results { get; set; }
}
