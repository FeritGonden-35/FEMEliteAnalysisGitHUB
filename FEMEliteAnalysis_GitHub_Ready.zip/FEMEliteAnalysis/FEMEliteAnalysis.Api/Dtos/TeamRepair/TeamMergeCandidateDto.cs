namespace FEMEliteAnalysis.Api.Dtos.TeamRepair;

public sealed class TeamMergeCandidateDto
{
    public string NormalizeAnahtari { get; set; } = string.Empty;
    public int AnaTakimId { get; set; }
    public string AnaTakimAdi { get; set; } = string.Empty;
    public int AnaTakimMacSayisi { get; set; }
    public List<TeamMergeMemberDto> BirlesecekTakimlar { get; set; } = [];
    public int ToplamTasinacakMacBaglantisi => BirlesecekTakimlar.Sum(x => x.MacSayisi);
}

public sealed class TeamMergeMemberDto
{
    public int TakimId { get; set; }
    public string TakimAdi { get; set; } = string.Empty;
    public int? HariciTakimId { get; set; }
    public int? LigId { get; set; }
    public string? Ulke { get; set; }
    public int MacSayisi { get; set; }
}
