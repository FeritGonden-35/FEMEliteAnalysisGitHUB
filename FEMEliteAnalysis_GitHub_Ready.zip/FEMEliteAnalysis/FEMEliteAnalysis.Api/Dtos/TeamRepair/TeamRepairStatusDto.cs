namespace FEMEliteAnalysis.Api.Dtos.TeamRepair;

public sealed class TeamRepairStatusDto
{
    public bool CalisiyorMu { get; set; }
    public DateTime? SonBaslangic { get; set; }
    public DateTime? SonBitis { get; set; }
    public int IncelenenTakim { get; set; }
    public int AdayGrup { get; set; }
    public int BirlesenTakim { get; set; }
    public int GuncellenenMacBaglantisi { get; set; }
    public int GuncellenenIstatistik { get; set; }
    public int GuncellenenForm { get; set; }
    public string SonMesaj { get; set; } = "Henüz tarama yapılmadı.";
}
