using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Services;

namespace FEMEliteAnalysis.Api.BackgroundServices;

public class HistoricalPoolBackgroundService : BackgroundService
{
    private readonly HistoricalPoolQueue _queue;
    private readonly HistoricalPoolStatusStore _status;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<HistoricalPoolBackgroundService> _logger;

    public HistoricalPoolBackgroundService(
        HistoricalPoolQueue queue,
        HistoricalPoolStatusStore status,
        IServiceScopeFactory scopeFactory,
        ILogger<HistoricalPoolBackgroundService> logger)
    {
        _queue = queue;
        _status = status;
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            HistoricalPoolRequest request;
            try
            {
                request = await _queue.BekleAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }

            await CalistirAsync(request, stoppingToken);
        }
    }

    private async Task CalistirAsync(HistoricalPoolRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var sezonlar = SezonAraligi(request.BaslangicSezonu, request.BitisSezonu);
            foreach (var sezon in sezonlar)
            {
                cancellationToken.ThrowIfCancellationRequested();
                using var scope = _scopeFactory.CreateScope();
                var service = scope.ServiceProvider.GetRequiredService<IFootballDataCoUkImportService>();
                var sonuc = await service.TopluAktarAsync(request.LigKodlari, sezon, cancellationToken);

                var basarili = 0;
                var basarisiz = 0;
                long eklenen = 0;
                long guncellenen = 0;
                string? hata = null;

                if (sonuc.Basarili && sonuc.Veri is not null)
                {
                    basarili = sonuc.Veri.Count(x => x.Basarili);
                    basarisiz = sonuc.Veri.Count(x => !x.Basarili);
                    eklenen = sonuc.Veri.Sum(x => (long)x.EklenenMac);
                    guncellenen = sonuc.Veri.Sum(x => (long)x.GuncellenenMac);
                    hata = sonuc.Veri.FirstOrDefault(x => !x.Basarili)?.Mesaj;
                }
                else
                {
                    basarisiz = request.LigKodlari.Count;
                    hata = sonuc.Mesaj;
                }

                _status.Guncelle(sezon, basarili, basarisiz, eklenen, guncellenen, hata);
                await Task.Delay(750, cancellationToken);
            }

            _status.Bitir("Tarihsel veri havuzu aktarımı tamamlandı.");
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _status.Bitir("Tarihsel veri havuzu aktarımı durduruldu.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Tarihsel veri havuzu aktarımı başarısız.");
            _status.Bitir("Tarihsel veri havuzu aktarımı hata ile sonlandı.", ex.Message);
        }
    }

    public static List<string> SezonAraligi(string baslangic, string bitis)
    {
        var bas = SezonBaslangicYili(baslangic);
        var son = SezonBaslangicYili(bitis);
        if (bas > son) (bas, son) = (son, bas);
        if (bas < 1993 || son > DateTime.UtcNow.Year + 1)
            throw new ArgumentOutOfRangeException(nameof(baslangic), "Sezon aralığı 1993'ten günümüze kadar olmalıdır.");

        return Enumerable.Range(bas, son - bas + 1)
            .Select(y => $"{y % 100:00}{(y + 1) % 100:00}")
            .ToList();
    }

    private static int SezonBaslangicYili(string value)
    {
        var digits = new string(value.Where(char.IsDigit).ToArray());
        if (digits.Length == 4)
        {
            var first = int.Parse(digits[..2]);
            return first >= 90 ? 1900 + first : 2000 + first;
        }
        if (digits.Length >= 8) return int.Parse(digits[..4]);
        throw new FormatException("Sezon biçimi geçersiz. Örnek: 9394 veya 2025-2026.");
    }
}
