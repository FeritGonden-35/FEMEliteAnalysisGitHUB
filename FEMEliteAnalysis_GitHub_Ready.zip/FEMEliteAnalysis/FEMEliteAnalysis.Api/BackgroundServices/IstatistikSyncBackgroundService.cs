using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Services;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.BackgroundServices;

public sealed class IstatistikSyncBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IstatistikSyncDurumStore _durum;
    private readonly ITelegramBotClient _bot;
    private readonly ILogger<IstatistikSyncBackgroundService> _logger;

    public IstatistikSyncBackgroundService(
        IServiceScopeFactory scopeFactory,
        IstatistikSyncDurumStore durum,
        ITelegramBotClient bot,
        ILogger<IstatistikSyncBackgroundService> logger)
    {
        _scopeFactory = scopeFactory;
        _durum = durum;
        _bot = bot;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            if (!_durum.IstegiAl(out var chatId))
            {
                await Task.Delay(1500, stoppingToken);
                continue;
            }

            try
            {
                using var scope = _scopeFactory.CreateScope();
                var service = scope.ServiceProvider.GetRequiredService<IIstatistikSyncService>();
                var sonIlerlemeMesaji = DateTime.MinValue;

                var sonuc = await service.TamSenkronizeEtAsync(async x =>
                {
                    _durum.Ilerle(x);
                    if ((DateTime.UtcNow - sonIlerlemeMesaji) < TimeSpan.FromMinutes(2)) return;
                    sonIlerlemeMesaji = DateTime.UtcNow;
                    await _bot.SendMessage(chatId, x.Mesaj, cancellationToken: stoppingToken);
                }, stoppingToken);

                var metin =
                    "✅ 3 SEZON İSTATİSTİK SENKRONİZASYONU TAMAMLANDI\n\n" +
                    $"⚽ Hedef maç: {sonuc.ToplamHedef}\n" +
                    $"⚽ Kontrol edilen: {sonuc.KontrolEdilen}\n" +
                    $"🚩 Korner verisi bulunan: {sonuc.KornerBulunan}\n" +
                    $"🟨 Kart verisi bulunan: {sonuc.KartBulunan}\n" +
                    $"🎯 Şut verisi bulunan: {sonuc.SutBulunan}\n" +
                    $"⏭ Zaten dolu: {sonuc.ZatenDolu}\n" +
                    $"❔ Stats bulunamayan: {sonuc.StatsBulunamayan}\n" +
                    $"❌ Hata: {sonuc.Hata}\n\n" +
                    "Artık /analiz çıktısında korner ve kart marketleri takım ortalamaları, medyan ve rakibe verilen kornerlerle birlikte değerlendirilir.";

                _durum.Tamamla(metin);
                await _bot.SendMessage(chatId, metin, cancellationToken: stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "İstatistik background sync çöktü.");
                _durum.Tamamla($"❌ İstatistik sync hata: {ex.Message}");
                try { await _bot.SendMessage(chatId, $"❌ İstatistik sync hata: {ex.Message}", cancellationToken: stoppingToken); } catch { }
            }
        }
    }
}
