using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.BackgroundServices;

public class VeriToplamaBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly VeriToplamaOptions _options;
    private readonly ILogger<VeriToplamaBackgroundService> _logger;

    public VeriToplamaBackgroundService(
        IServiceScopeFactory scopeFactory,
        IOptions<VeriToplamaOptions> options,
        ILogger<VeriToplamaBackgroundService> logger)
    {
        _scopeFactory = scopeFactory;
        _options = options.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        if (!_options.Aktif)
        {
            _logger.LogInformation(
                "Otomatik veri toplama kapalı. VeriToplama:Aktif=false");

            return;
        }

        if (_options.BaslangictaCalistir)
        {
            await VeriToplaAsync(stoppingToken);
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            var gecikme = SonrakiCalismaGecikmesiniHesapla();

            _logger.LogInformation(
                "Sonraki veri toplama çalışmasına kalan süre: {Gecikme}",
                gecikme);

            await Task.Delay(
                gecikme,
                stoppingToken);

            if (!stoppingToken.IsCancellationRequested)
            {
                await VeriToplaAsync(stoppingToken);
            }
        }
    }

    private async Task VeriToplaAsync(
        CancellationToken cancellationToken)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();

            var service =
                scope.ServiceProvider.GetRequiredService<IVeriToplamaService>();

            var bugun = DateOnly.FromDateTime(
                TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                    DateTime.UtcNow,
                    "Turkey Standard Time"));

            var baslangic = bugun.AddDays(
                -Math.Max(0, _options.GecmisGunSayisi));

            var bitis = bugun.AddDays(
                Math.Max(0, _options.GelecekGunSayisi));

            var sonuc =
                await service.TumAktifSaglayicilariCalistirAsync(
                    baslangic,
                    bitis,
                    cancellationToken);

            if (sonuc.Basarili)
            {
                _logger.LogInformation(
                    "Zamanlanmış veri toplama tamamlandı. {Mesaj}",
                    sonuc.Mesaj);
            }
            else
            {
                _logger.LogWarning(
                    "Zamanlanmış veri toplama başarısız. {Mesaj}",
                    sonuc.Mesaj);
            }
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            // Uygulama kapanıyor.
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Zamanlanmış veri toplama sırasında hata oluştu.");
        }
    }

    private TimeSpan SonrakiCalismaGecikmesiniHesapla()
    {
        var simdi = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
            DateTime.UtcNow,
            "Turkey Standard Time");

        var saat = Math.Clamp(
            _options.CalismaSaati,
            0,
            23);

        var dakika = Math.Clamp(
            _options.CalismaDakikasi,
            0,
            59);

        var sonraki = new DateTime(
            simdi.Year,
            simdi.Month,
            simdi.Day,
            saat,
            dakika,
            0);

        if (sonraki <= simdi)
        {
            sonraki = sonraki.AddDays(1);
        }

        return sonraki - simdi;
    }
}
