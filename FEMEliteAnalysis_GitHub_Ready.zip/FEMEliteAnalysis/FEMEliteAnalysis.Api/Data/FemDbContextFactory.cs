using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace FEMEliteAnalysis.Api.Data;

public class FemDbContextFactory : IDesignTimeDbContextFactory<FemDbContext>
{
    public FemDbContext CreateDbContext(string[] args)
    {
        var basePath = Directory.GetCurrentDirectory();

        var configuration = new ConfigurationBuilder()
    .SetBasePath(basePath)
    .AddJsonFile("appsettings.json", optional: false)
    .AddJsonFile("appsettings.Development.json", optional: true)
    .AddUserSecrets<FemDbContextFactory>(optional: true)
    .AddEnvironmentVariables()
    .Build();

        var connectionString =
            configuration.GetConnectionString("FemDatabase")
            ?? throw new InvalidOperationException(
                "ConnectionStrings:FemDatabase ayarı bulunamadı.");

        var optionsBuilder = new DbContextOptionsBuilder<FemDbContext>();

        optionsBuilder.UseSqlServer(
            connectionString,
            sqlServerOptions =>
            {
                sqlServerOptions.EnableRetryOnFailure();
                sqlServerOptions.CommandTimeout(60);
                sqlServerOptions.MigrationsHistoryTable(
                    "__EFMigrationsHistory",
                    "fem");
            });

        return new FemDbContext(optionsBuilder.Options);
    }
}
