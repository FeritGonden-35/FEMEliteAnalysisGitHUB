using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Data;

public static class FemDbInitializer
{
    public static async Task BaslatAsync(IServiceProvider serviceProvider)
    {
        using var scope = serviceProvider.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<FemDbContext>();

        await dbContext.Database.MigrateAsync();

        await dbContext.Database.ExecuteSqlRawAsync(@"
IF OBJECT_ID(N'[fem].[Kuponlar]', N'U') IS NULL
BEGIN
    CREATE TABLE [fem].[Kuponlar](
        [Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [AdminTelegramId] bigint NOT NULL,
        [Baslik] nvarchar(150) NOT NULL,
        [OrtalamaGuvenPuani] int NOT NULL,
        [RiskSeviyesi] nvarchar(30) NOT NULL,
        [Durum] nvarchar(30) NOT NULL,
        [YayinMetni] nvarchar(max) NULL,
        [OlusturmaTarihi] datetime2 NOT NULL,
        [GuncellemeTarihi] datetime2 NULL,
        [YayinlanmaTarihi] datetime2 NULL
    );
    CREATE INDEX [IX_Kuponlar_AdminTelegramId_OlusturmaTarihi] ON [fem].[Kuponlar]([AdminTelegramId], [OlusturmaTarihi]);
    CREATE INDEX [IX_Kuponlar_Durum] ON [fem].[Kuponlar]([Durum]);
END;
IF OBJECT_ID(N'[fem].[KuponMaclari]', N'U') IS NULL
BEGIN
    CREATE TABLE [fem].[KuponMaclari](
        [Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [KuponId] int NOT NULL,
        [AnalizId] int NOT NULL,
        [MacId] int NOT NULL,
        [EvSahibi] nvarchar(150) NOT NULL,
        [Deplasman] nvarchar(150) NOT NULL,
        [SecilenMarket] nvarchar(250) NOT NULL,
        [GuvenPuani] int NOT NULL,
        [Sira] int NOT NULL,
        CONSTRAINT [FK_KuponMaclari_Kuponlar_KuponId] FOREIGN KEY([KuponId]) REFERENCES [fem].[Kuponlar]([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_KuponMaclari_Analizler_AnalizId] FOREIGN KEY([AnalizId]) REFERENCES [fem].[Analizler]([Id]),
        CONSTRAINT [FK_KuponMaclari_Maclar_MacId] FOREIGN KEY([MacId]) REFERENCES [fem].[Maclar]([Id])
    );
    CREATE UNIQUE INDEX [IX_KuponMaclari_KuponId_Sira] ON [fem].[KuponMaclari]([KuponId], [Sira]);
    CREATE UNIQUE INDEX [IX_KuponMaclari_KuponId_MacId] ON [fem].[KuponMaclari]([KuponId], [MacId]);
END;
IF OBJECT_ID(N'[fem].[Kuponlar]', N'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('fem.Kuponlar', 'ToplamOran') IS NULL ALTER TABLE [fem].[Kuponlar] ADD [ToplamOran] decimal(10,3) NULL;
    IF COL_LENGTH('fem.Kuponlar', 'Sonuc') IS NULL ALTER TABLE [fem].[Kuponlar] ADD [Sonuc] nvarchar(30) NOT NULL CONSTRAINT [DF_Kuponlar_Sonuc] DEFAULT N'Bekliyor';
    IF COL_LENGTH('fem.Kuponlar', 'SonuclandirmaTarihi') IS NULL ALTER TABLE [fem].[Kuponlar] ADD [SonuclandirmaTarihi] datetime2 NULL;
END;
IF OBJECT_ID(N'[fem].[KuponMaclari]', N'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('fem.KuponMaclari', 'Oran') IS NULL ALTER TABLE [fem].[KuponMaclari] ADD [Oran] decimal(8,3) NULL;
    IF COL_LENGTH('fem.KuponMaclari', 'Sonuc') IS NULL ALTER TABLE [fem].[KuponMaclari] ADD [Sonuc] nvarchar(30) NOT NULL CONSTRAINT [DF_KuponMaclari_Sonuc] DEFAULT N'Bekliyor';
    IF COL_LENGTH('fem.KuponMaclari', 'SonuclandirmaTarihi') IS NULL ALTER TABLE [fem].[KuponMaclari] ADD [SonuclandirmaTarihi] datetime2 NULL;
END;
IF OBJECT_ID(N'[fem].[TahminKayitlari]', N'U') IS NULL
BEGIN
    CREATE TABLE [fem].[TahminKayitlari](
        [Id] bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [MacId] int NOT NULL,
        [MarketKodu] nvarchar(60) NOT NULL,
        [MarketAdi] nvarchar(150) NOT NULL,
        [HamGuvenPuani] int NOT NULL,
        [KalibreGuvenPuani] int NOT NULL,
        [VeriKalitesiPuani] int NOT NULL,
        [ModelOlasiligi] decimal(7,4) NOT NULL,
        [Oran] decimal(8,3) NULL,
        [PiyasaOlasiligi] decimal(7,4) NULL,
        [EdgeYuzdesi] decimal(7,2) NULL,
        [BeklenenDeger] decimal(8,4) NULL,
        [Sonuc] nvarchar(30) NOT NULL,
        [MotorVersiyonu] nvarchar(30) NOT NULL,
        [OlusturmaTarihi] datetime2 NOT NULL,
        [SonuclandirmaTarihi] datetime2 NULL,
        CONSTRAINT [FK_TahminKayitlari_Maclar_MacId] FOREIGN KEY([MacId]) REFERENCES [fem].[Maclar]([Id]) ON DELETE CASCADE
    );
    CREATE INDEX [IX_TahminKayitlari_Mac_Market_Motor] ON [fem].[TahminKayitlari]([MacId],[MarketKodu],[MotorVersiyonu]);
    CREATE INDEX [IX_TahminKayitlari_Sonuc_Tarih] ON [fem].[TahminKayitlari]([Sonuc],[OlusturmaTarihi]);
END;
IF OBJECT_ID(N'[fem].[BahisOranlari]', N'U') IS NULL
BEGIN
    CREATE TABLE [fem].[BahisOranlari](
        [Id] bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [MacId] int NOT NULL,
        [MarketKodu] nvarchar(60) NOT NULL,
        [Oran] decimal(8,3) NOT NULL,
        [Kaynak] nvarchar(100) NULL,
        [AlinmaTarihi] datetime2 NOT NULL,
        CONSTRAINT [FK_BahisOranlari_Maclar_MacId] FOREIGN KEY([MacId]) REFERENCES [fem].[Maclar]([Id]) ON DELETE CASCADE
    );
    CREATE INDEX [IX_BahisOranlari_Mac_Market_Tarih] ON [fem].[BahisOranlari]([MacId],[MarketKodu],[AlinmaTarihi]);
END;
IF OBJECT_ID(N'[fem].[TelegramJoinVerifications]', N'U') IS NULL
BEGIN
    CREATE TABLE [fem].[TelegramJoinVerifications](
        [Id] bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [TelegramUserId] bigint NOT NULL,
        [UserChatId] bigint NOT NULL,
        [Username] nvarchar(100) NULL,
        [FirstName] nvarchar(150) NULL,
        [LastName] nvarchar(150) NULL,
        [KayitAdi] nvarchar(100) NULL,
        [KayitSoyadi] nvarchar(100) NULL,
        [TelefonNumarasi] nvarchar(30) NULL,
        [GroupChatId] bigint NOT NULL,
        [ScreenshotFileId] nvarchar(300) NULL,
        [Status] nvarchar(40) NOT NULL,
        [RequestedAt] datetime2 NOT NULL,
        [ScreenshotReceivedAt] datetime2 NULL,
        [ReviewedAt] datetime2 NULL,
        [ReviewedByAdminId] bigint NULL,
        [InviteLink] nvarchar(500) NULL,
        [InviteLinkExpiresAt] datetime2 NULL,
        [InviteLinkCreatedAt] datetime2 NULL,
        [CreatedAt] datetime2 NOT NULL,
        [UpdatedAt] datetime2 NULL
    );
    CREATE INDEX [IX_TelegramJoinVerifications_User_Group_Status] ON [fem].[TelegramJoinVerifications]([TelegramUserId],[GroupChatId],[Status]);
    CREATE INDEX [IX_TelegramJoinVerifications_RequestedAt] ON [fem].[TelegramJoinVerifications]([RequestedAt]);
END;
IF COL_LENGTH(N'[fem].[TelegramJoinVerifications]', N'KayitAdi') IS NULL
    ALTER TABLE [fem].[TelegramJoinVerifications] ADD [KayitAdi] nvarchar(100) NULL;
IF COL_LENGTH(N'[fem].[TelegramJoinVerifications]', N'KayitSoyadi') IS NULL
    ALTER TABLE [fem].[TelegramJoinVerifications] ADD [KayitSoyadi] nvarchar(100) NULL;
IF COL_LENGTH(N'[fem].[TelegramJoinVerifications]', N'TelefonNumarasi') IS NULL
    ALTER TABLE [fem].[TelegramJoinVerifications] ADD [TelefonNumarasi] nvarchar(30) NULL;
IF COL_LENGTH(N'[fem].[TelegramJoinVerifications]', N'InviteLink') IS NULL
    ALTER TABLE [fem].[TelegramJoinVerifications] ADD [InviteLink] nvarchar(500) NULL;
IF COL_LENGTH(N'[fem].[TelegramJoinVerifications]', N'InviteLinkExpiresAt') IS NULL
    ALTER TABLE [fem].[TelegramJoinVerifications] ADD [InviteLinkExpiresAt] datetime2 NULL;
IF COL_LENGTH(N'[fem].[TelegramJoinVerifications]', N'InviteLinkCreatedAt') IS NULL
    ALTER TABLE [fem].[TelegramJoinVerifications] ADD [InviteLinkCreatedAt] datetime2 NULL;
");

        if (!await dbContext.Ayarlar.AnyAsync())
        {
            dbContext.Ayarlar.AddRange(
                new Ayar
                {
                    Anahtar = "UygulamaAdi",
                    Deger = "FEM Elite Analysis",
                    Aciklama = "Telegram botunda gösterilecek uygulama adı."
                },
                new Ayar
                {
                    Anahtar = "VarsayilanUyelikGunu",
                    Deger = "30",
                    Aciklama = "Yeni VIP üyeliklerde varsayılan gün sayısı."
                },
                new Ayar
                {
                    Anahtar = "AnalizUyarisi",
                    Deger = "Bu içerik istatistiksel değerlendirmedir ve kesin sonuç garantisi vermez.",
                    Aciklama = "Analiz mesajlarının altında gösterilecek uyarı."
                },
                new Ayar
                {
                    Anahtar = "VarsayilanDil",
                    Deger = "tr-TR",
                    Aciklama = "Uygulamanın varsayılan dil ve kültür ayarı."
                }
            );

            await dbContext.SaveChangesAsync();
        }
    }
}
