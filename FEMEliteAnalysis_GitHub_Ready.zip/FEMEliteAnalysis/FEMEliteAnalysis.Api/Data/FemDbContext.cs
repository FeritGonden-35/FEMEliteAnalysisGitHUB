using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Data;

public class FemDbContext : DbContext
{
    public FemDbContext(DbContextOptions<FemDbContext> options)
        : base(options)
    {
    }

    public DbSet<Kullanici> Kullanicilar => Set<Kullanici>();
    public DbSet<Uyelik> Uyelikler => Set<Uyelik>();
    public DbSet<Lig> Ligler => Set<Lig>();
    public DbSet<Takim> Takimlar => Set<Takim>();
    public DbSet<TakimSaglayiciKimligi> TakimSaglayiciKimlikleri => Set<TakimSaglayiciKimligi>();
    public DbSet<Mac> Maclar => Set<Mac>();
    public DbSet<MacIstatistigi> MacIstatistikleri => Set<MacIstatistigi>();
    public DbSet<TakimFormu> TakimFormlari => Set<TakimFormu>();
    public DbSet<Analiz> Analizler => Set<Analiz>();
    public DbSet<Ayar> Ayarlar => Set<Ayar>();
    public DbSet<BotLogu> BotLoglari => Set<BotLogu>();
    public DbSet<ApiSenkronizasyonLogu> ApiSenkronizasyonLoglari => Set<ApiSenkronizasyonLogu>();
    public DbSet<Kupon> Kuponlar => Set<Kupon>();
    public DbSet<KuponMaci> KuponMaclari => Set<KuponMaci>();
    public DbSet<TahminKaydi> TahminKayitlari => Set<TahminKaydi>();
    public DbSet<BahisOrani> BahisOranlari => Set<BahisOrani>();
    public DbSet<TelegramJoinVerification> TelegramJoinVerifications => Set<TelegramJoinVerification>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.HasDefaultSchema("fem");

        foreach (var property in modelBuilder.Model
                     .GetEntityTypes()
                     .SelectMany(t => t.GetProperties())
                     .Where(p => p.ClrType == typeof(string)))
        {
            property.SetIsUnicode(true);
        }

        modelBuilder.Entity<Kullanici>(entity =>
        {
            entity.HasIndex(x => x.TelegramKullaniciId).IsUnique();
            entity.HasIndex(x => x.KullaniciAdi);
        });

        modelBuilder.Entity<Uyelik>(entity =>
        {
            entity.HasIndex(x => new { x.KullaniciId, x.Durum });
            entity.HasIndex(x => x.BitisTarihi);

            entity.HasOne(x => x.Kullanici)
                .WithMany(x => x.Uyelikler)
                .HasForeignKey(x => x.KullaniciId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Lig>(entity =>
        {
            entity.HasIndex(x => x.HariciLigId);
            entity.HasIndex(x => new { x.Ad, x.Sezon });
        });

        modelBuilder.Entity<Takim>(entity =>
        {
            entity.HasIndex(x => x.HariciTakimId);
            entity.HasIndex(x => x.Ad);

            entity.HasOne(x => x.Lig)
                .WithMany(x => x.Takimlar)
                .HasForeignKey(x => x.LigId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<TakimSaglayiciKimligi>(entity =>
        {
            entity.HasIndex(x => new { x.TakimId, x.Saglayici }).IsUnique();
            entity.HasIndex(x => new { x.Saglayici, x.SaglayiciTakimId }).IsUnique();

            entity.HasOne(x => x.Takim)
                .WithMany()
                .HasForeignKey(x => x.TakimId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Mac>(entity =>
        {
            entity.HasIndex(x => x.HariciMacId).IsUnique();
            entity.HasIndex(x => x.MacTarihi);
            entity.HasIndex(x => new { x.EvSahibiTakimId, x.DeplasmanTakimId, x.MacTarihi });

            entity.HasOne(x => x.Lig)
                .WithMany(x => x.Maclar)
                .HasForeignKey(x => x.LigId)
                .OnDelete(DeleteBehavior.SetNull);

            entity.HasOne(x => x.EvSahibiTakim)
                .WithMany()
                .HasForeignKey(x => x.EvSahibiTakimId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.DeplasmanTakim)
                .WithMany()
                .HasForeignKey(x => x.DeplasmanTakimId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<MacIstatistigi>(entity =>
        {
            entity.HasIndex(x => new { x.MacId, x.TakimId }).IsUnique();

            entity.Property(x => x.TopaSahipOlmaYuzdesi).HasPrecision(5, 2);
            entity.Property(x => x.BeklenenGol).HasPrecision(6, 2);
            entity.Property(x => x.PasIsabetYuzdesi).HasPrecision(5, 2);

            entity.HasOne(x => x.Mac)
                .WithMany(x => x.Istatistikler)
                .HasForeignKey(x => x.MacId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.Takim)
                .WithMany()
                .HasForeignKey(x => x.TakimId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<TakimFormu>(entity =>
        {
            entity.HasIndex(x => new { x.TakimId, x.LigId, x.Sezon, x.SonMacSayisi });

            entity.Property(x => x.MacBasinaGolOrtalamasi).HasPrecision(6, 2);
            entity.Property(x => x.MacBasinaYenilenGolOrtalamasi).HasPrecision(6, 2);
            entity.Property(x => x.IkiBucukUstYuzdesi).HasPrecision(5, 2);
            entity.Property(x => x.KarsilikliGolYuzdesi).HasPrecision(5, 2);

            entity.HasOne(x => x.Takim)
                .WithMany()
                .HasForeignKey(x => x.TakimId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.Lig)
                .WithMany()
                .HasForeignKey(x => x.LigId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Analiz>(entity =>
        {
            entity.HasIndex(x => x.MacId);
            entity.HasIndex(x => x.Durum);
            entity.HasIndex(x => x.OlusturmaTarihi);

            entity.Property(x => x.EvSahibiKazanmaOlasiligi).HasPrecision(5, 2);
            entity.Property(x => x.BeraberlikOlasiligi).HasPrecision(5, 2);
            entity.Property(x => x.DeplasmanKazanmaOlasiligi).HasPrecision(5, 2);

            entity.HasOne(x => x.Mac)
                .WithMany(x => x.Analizler)
                .HasForeignKey(x => x.MacId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Ayar>(entity =>
        {
            entity.HasIndex(x => x.Anahtar).IsUnique();
        });

        modelBuilder.Entity<BotLogu>(entity =>
        {
            entity.HasIndex(x => x.KayitTarihi);
            entity.HasIndex(x => x.TelegramKullaniciId);

            entity.HasOne(x => x.Kullanici)
                .WithMany(x => x.BotLoglari)
                .HasForeignKey(x => x.KullaniciId)
                .OnDelete(DeleteBehavior.SetNull);
        });


        modelBuilder.Entity<Kupon>(entity =>
        {
            entity.HasIndex(x => new { x.AdminTelegramId, x.OlusturmaTarihi });
            entity.HasIndex(x => x.Durum);
            entity.Property(x => x.ToplamOran).HasPrecision(10, 3);
        });

        modelBuilder.Entity<KuponMaci>(entity =>
        {
            entity.HasIndex(x => new { x.KuponId, x.Sira }).IsUnique();
            entity.HasIndex(x => new { x.KuponId, x.MacId }).IsUnique();
            entity.Property(x => x.Oran).HasPrecision(8, 3);
            entity.HasOne(x => x.Kupon).WithMany(x => x.Maclar).HasForeignKey(x => x.KuponId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(x => x.Analiz).WithMany().HasForeignKey(x => x.AnalizId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(x => x.Mac).WithMany().HasForeignKey(x => x.MacId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ApiSenkronizasyonLogu>(entity =>
        {
            entity.HasIndex(x => x.BaslangicTarihi);
            entity.HasIndex(x => new { x.Kaynak, x.Islem });
        });

        modelBuilder.Entity<TahminKaydi>(entity =>
        {
            entity.HasIndex(x => new { x.MacId, x.MarketKodu, x.MotorVersiyonu });
            entity.HasIndex(x => new { x.Sonuc, x.OlusturmaTarihi });
            entity.Property(x => x.ModelOlasiligi).HasPrecision(7, 4);
            entity.Property(x => x.Oran).HasPrecision(8, 3);
            entity.Property(x => x.PiyasaOlasiligi).HasPrecision(7, 4);
            entity.Property(x => x.EdgeYuzdesi).HasPrecision(7, 2);
            entity.Property(x => x.BeklenenDeger).HasPrecision(8, 4);
            entity.HasOne(x => x.Mac).WithMany().HasForeignKey(x => x.MacId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<BahisOrani>(entity =>
        {
            entity.HasIndex(x => new { x.MacId, x.MarketKodu, x.AlinmaTarihi });
            entity.Property(x => x.Oran).HasPrecision(8, 3);
            entity.HasOne(x => x.Mac).WithMany().HasForeignKey(x => x.MacId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<TelegramJoinVerification>(entity =>
        {
            entity.HasIndex(x => new { x.TelegramUserId, x.GroupChatId, x.Status });
            entity.HasIndex(x => x.RequestedAt);
            entity.Property(x => x.Status).HasMaxLength(40);
            entity.Property(x => x.Username).HasMaxLength(100);
            entity.Property(x => x.FirstName).HasMaxLength(150);
            entity.Property(x => x.LastName).HasMaxLength(150);
            entity.Property(x => x.KayitAdi).HasMaxLength(100);
            entity.Property(x => x.KayitSoyadi).HasMaxLength(100);
            entity.Property(x => x.TelefonNumarasi).HasMaxLength(30);
            entity.Property(x => x.ScreenshotFileId).HasMaxLength(300);
            entity.Property(x => x.InviteLink).HasMaxLength(500);
        });
    }
}
