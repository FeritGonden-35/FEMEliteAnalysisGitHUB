using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("Kuponlar")]
public class Kupon
{
    [Key] public int Id { get; set; }
    public long AdminTelegramId { get; set; }
    [Required, MaxLength(150)] public string Baslik { get; set; } = "FEM Elite Kuponu";
    public int OrtalamaGuvenPuani { get; set; }
    [Required, MaxLength(30)] public string RiskSeviyesi { get; set; } = "Yüksek";
    [Required, MaxLength(30)] public string Durum { get; set; } = "Taslak";
    public string? YayinMetni { get; set; }
    public DateTime OlusturmaTarihi { get; set; } = DateTime.UtcNow;
    public DateTime? GuncellemeTarihi { get; set; }
    public DateTime? YayinlanmaTarihi { get; set; }
    public decimal? ToplamOran { get; set; }
    [MaxLength(30)] public string Sonuc { get; set; } = "Bekliyor";
    public DateTime? SonuclandirmaTarihi { get; set; }
    public ICollection<KuponMaci> Maclar { get; set; } = new List<KuponMaci>();
}
