using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("ApiSenkronizasyonLoglari")]
public class ApiSenkronizasyonLogu
{
    [Key]
    public long Id { get; set; }

    [Required, MaxLength(100)]
    public string Kaynak { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Islem { get; set; } = string.Empty;

    public bool BasariliMi { get; set; }

    public int? KayitSayisi { get; set; }

    public string? HataMesaji { get; set; }

    public DateTime BaslangicTarihi { get; set; }

    public DateTime BitisTarihi { get; set; }
}
