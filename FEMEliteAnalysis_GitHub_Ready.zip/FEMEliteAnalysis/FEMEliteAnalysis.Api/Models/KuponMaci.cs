using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("KuponMaclari")]
public class KuponMaci
{
    [Key] public int Id { get; set; }
    public int KuponId { get; set; }
    public int AnalizId { get; set; }
    public int MacId { get; set; }
    [Required, MaxLength(150)] public string EvSahibi { get; set; } = string.Empty;
    [Required, MaxLength(150)] public string Deplasman { get; set; } = string.Empty;
    [Required, MaxLength(250)] public string SecilenMarket { get; set; } = string.Empty;
    public int GuvenPuani { get; set; }
    public decimal? Oran { get; set; }
    [MaxLength(30)] public string Sonuc { get; set; } = "Bekliyor";
    public DateTime? SonuclandirmaTarihi { get; set; }
    public int Sira { get; set; }
    public Kupon Kupon { get; set; } = null!;
    public Analiz Analiz { get; set; } = null!;
    public Mac Mac { get; set; } = null!;
}
