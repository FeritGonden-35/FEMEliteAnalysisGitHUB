using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("BahisOranlari")]
public class BahisOrani
{
    [Key] public long Id { get; set; }
    public int MacId { get; set; }
    [Required, MaxLength(60)] public string MarketKodu { get; set; } = string.Empty;
    public decimal Oran { get; set; }
    [MaxLength(100)] public string? Kaynak { get; set; }
    public DateTime AlinmaTarihi { get; set; } = DateTime.UtcNow;
    public Mac Mac { get; set; } = null!;
}
