using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("TakimSaglayiciKimlikleri")]
public sealed class TakimSaglayiciKimligi
{
    [Key]
    public int Id { get; set; }

    public int TakimId { get; set; }

    [Required, MaxLength(40)]
    public string Saglayici { get; set; } = string.Empty;

    public int SaglayiciTakimId { get; set; }

    [MaxLength(150)]
    public string? SaglayiciTakimAdi { get; set; }

    public DateTime KayitTarihi { get; set; } = DateTime.UtcNow;
    public DateTime? GuncellemeTarihi { get; set; }

    public Takim Takim { get; set; } = null!;
}
