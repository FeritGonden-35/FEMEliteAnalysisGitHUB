using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Models;

[Table("Analizler")]
public class Analiz
{
    [Key]
    public int Id { get; set; }

    public int MacId { get; set; }

    [Required, MaxLength(100)]
    public string AnalizTuru { get; set; } = string.Empty;

    [Required, MaxLength(250)]
    public string Tahmin { get; set; } = string.Empty;

    public int GuvenPuani { get; set; }

    public RiskSeviyesi RiskSeviyesi { get; set; } = RiskSeviyesi.Orta;

    [Required]
    public string YapayZekaAnalizi { get; set; } = string.Empty;

    public string? AnaFaktorlerJson { get; set; }

    public decimal? EvSahibiKazanmaOlasiligi { get; set; }

    public decimal? BeraberlikOlasiligi { get; set; }

    public decimal? DeplasmanKazanmaOlasiligi { get; set; }

    public AnalizDurumu Durum { get; set; } = AnalizDurumu.Taslak;

    public AnalizSonucu Sonuc { get; set; } = AnalizSonucu.Bekliyor;

    public long? TelegramMesajId { get; set; }

    public long? YayinlananKanalId { get; set; }

    public DateTime OlusturmaTarihi { get; set; } = DateTime.UtcNow;

    public DateTime? YayinlanmaTarihi { get; set; }

    public DateTime? SonuclanmaTarihi { get; set; }

    public Mac Mac { get; set; } = null!;
}
