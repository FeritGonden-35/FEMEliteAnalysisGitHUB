using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("Ligler")]
public class Lig
{
    [Key]
    public int Id { get; set; }

    public int? HariciLigId { get; set; }

    [Required, MaxLength(150)]
    public string Ad { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? Ulke { get; set; }

    [MaxLength(20)]
    public string? Sezon { get; set; }

    [MaxLength(500)]
    public string? LogoUrl { get; set; }

    public bool AktifMi { get; set; } = true;

    public ICollection<Takim> Takimlar { get; set; } = new List<Takim>();
    public ICollection<Mac> Maclar { get; set; } = new List<Mac>();
}
