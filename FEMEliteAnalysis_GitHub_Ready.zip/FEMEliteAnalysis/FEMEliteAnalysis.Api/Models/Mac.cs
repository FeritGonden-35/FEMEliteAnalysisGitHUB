using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("Maclar")]
public class Mac
{
    [Key]
    public int Id { get; set; }

    public int? HariciMacId { get; set; }

    public int? LigId { get; set; }

    public int EvSahibiTakimId { get; set; }

    public int DeplasmanTakimId { get; set; }

    public DateTime MacTarihi { get; set; }

    [MaxLength(50)]
    public string? Durum { get; set; }

    public int? EvSahibiSkor { get; set; }

    public int? DeplasmanSkor { get; set; }

    public int? IlkYariEvSahibiSkor { get; set; }

    public int? IlkYariDeplasmanSkor { get; set; }

    [MaxLength(200)]
    public string? Stadyum { get; set; }

    [MaxLength(100)]
    public string? Hakem { get; set; }

    public DateTime OlusturmaTarihi { get; set; } = DateTime.UtcNow;

    public DateTime? GuncellemeTarihi { get; set; }

    public Lig? Lig { get; set; }
    public Takim EvSahibiTakim { get; set; } = null!;
    public Takim DeplasmanTakim { get; set; } = null!;
    public ICollection<MacIstatistigi> Istatistikler { get; set; } = new List<MacIstatistigi>();
    public ICollection<Analiz> Analizler { get; set; } = new List<Analiz>();
}
