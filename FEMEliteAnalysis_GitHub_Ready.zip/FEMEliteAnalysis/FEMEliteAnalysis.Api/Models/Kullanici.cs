using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("Kullanicilar")]
public class Kullanici
{
    [Key]
    public int Id { get; set; }

    public long TelegramKullaniciId { get; set; }

    [MaxLength(100)]
    public string? KullaniciAdi { get; set; }

    [MaxLength(100)]
    public string? Ad { get; set; }

    [MaxLength(100)]
    public string? Soyad { get; set; }

    public bool BotMu { get; set; }

    public bool EngellendiMi { get; set; }

    public bool AdminMi { get; set; }

    public DateTime KayitTarihi { get; set; } = DateTime.UtcNow;

    public DateTime? SonGorulmeTarihi { get; set; }

    public ICollection<Uyelik> Uyelikler { get; set; } = new List<Uyelik>();
    public ICollection<BotLogu> BotLoglari { get; set; } = new List<BotLogu>();
}
