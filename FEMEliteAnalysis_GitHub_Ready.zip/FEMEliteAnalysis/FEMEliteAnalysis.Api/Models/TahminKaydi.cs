using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("TahminKayitlari")]
public class TahminKaydi
{
    [Key] public long Id { get; set; }
    public int MacId { get; set; }
    [Required, MaxLength(60)] public string MarketKodu { get; set; } = string.Empty;
    [Required, MaxLength(150)] public string MarketAdi { get; set; } = string.Empty;
    public int HamGuvenPuani { get; set; }
    public int KalibreGuvenPuani { get; set; }
    public int VeriKalitesiPuani { get; set; }
    public decimal ModelOlasiligi { get; set; }
    public decimal? Oran { get; set; }
    public decimal? PiyasaOlasiligi { get; set; }
    public decimal? EdgeYuzdesi { get; set; }
    public decimal? BeklenenDeger { get; set; }
    [Required, MaxLength(30)] public string Sonuc { get; set; } = "Bekliyor";
    [Required, MaxLength(30)] public string MotorVersiyonu { get; set; } = "V3";
    public DateTime OlusturmaTarihi { get; set; } = DateTime.UtcNow;
    public DateTime? SonuclandirmaTarihi { get; set; }
    public Mac Mac { get; set; } = null!;
}
