using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Models;

[Table("Uyelikler")]
public class Uyelik
{
    [Key]
    public int Id { get; set; }

    public int KullaniciId { get; set; }

    public DateTime BaslangicTarihi { get; set; }

    public DateTime BitisTarihi { get; set; }

    public UyelikDurumu Durum { get; set; } = UyelikDurumu.Aktif;

    [MaxLength(250)]
    public string? Aciklama { get; set; }

    public long? OlusturanTelegramKullaniciId { get; set; }

    public DateTime OlusturmaTarihi { get; set; } = DateTime.UtcNow;

    public DateTime? GuncellemeTarihi { get; set; }

    public Kullanici Kullanici { get; set; } = null!;
}
