using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("BotLoglari")]
public class BotLogu
{
    [Key]
    public long Id { get; set; }

    public int? KullaniciId { get; set; }

    public long? TelegramKullaniciId { get; set; }

    [MaxLength(100)]
    public string? Komut { get; set; }

    public string? Detay { get; set; }

    [MaxLength(50)]
    public string? LogSeviyesi { get; set; }

    public DateTime KayitTarihi { get; set; } = DateTime.UtcNow;

    public Kullanici? Kullanici { get; set; }
}
