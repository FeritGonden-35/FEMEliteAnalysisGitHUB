using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("Takimlar")]
public class Takim
{
    [Key]
    public int Id { get; set; }

    public int? HariciTakimId { get; set; }

    // TheSportsDB üzerindeki gerçek idTeam değeri.
    public int? TheSportsDbTakimId { get; set; }

    // API-Football üzerindeki gerçek takım kimliği.
    public int? ApiFootballTakimId { get; set; }

    public int? LigId { get; set; }

    [Required, MaxLength(150)]
    public string Ad { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? Ulke { get; set; }

    [MaxLength(500)]
    public string? LogoUrl { get; set; }

    public bool AktifMi { get; set; } = true;

    public Lig? Lig { get; set; }
}
