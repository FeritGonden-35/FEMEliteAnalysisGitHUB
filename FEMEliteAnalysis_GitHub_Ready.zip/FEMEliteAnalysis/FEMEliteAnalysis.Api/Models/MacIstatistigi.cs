using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("MacIstatistikleri")]
public class MacIstatistigi
{
    [Key]
    public int Id { get; set; }

    public int MacId { get; set; }

    public int TakimId { get; set; }

    public int? Sut { get; set; }

    public int? IsabetliSut { get; set; }

    public int? Korner { get; set; }

    public int? Faul { get; set; }

    public int? SariKart { get; set; }

    public int? KirmiziKart { get; set; }

    public decimal? TopaSahipOlmaYuzdesi { get; set; }

    public decimal? BeklenenGol { get; set; }

    public int? Ofsayt { get; set; }

    public int? PasSayisi { get; set; }

    public decimal? PasIsabetYuzdesi { get; set; }

    public DateTime KayitTarihi { get; set; } = DateTime.UtcNow;

    public Mac Mac { get; set; } = null!;
    public Takim Takim { get; set; } = null!;
}
