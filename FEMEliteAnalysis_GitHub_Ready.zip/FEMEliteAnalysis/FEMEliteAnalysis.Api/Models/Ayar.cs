using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("Ayarlar")]
public class Ayar
{
    [Key]
    public int Id { get; set; }

    [Required, MaxLength(150)]
    public string Anahtar { get; set; } = string.Empty;

    [Required]
    public string Deger { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Aciklama { get; set; }

    public DateTime GuncellemeTarihi { get; set; } = DateTime.UtcNow;
}
