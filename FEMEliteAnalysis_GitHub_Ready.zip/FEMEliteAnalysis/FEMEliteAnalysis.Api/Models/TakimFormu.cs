using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FEMEliteAnalysis.Api.Models;

[Table("TakimFormlari")]
public class TakimFormu
{
    [Key]
    public int Id { get; set; }

    public int TakimId { get; set; }

    public int? LigId { get; set; }

    [MaxLength(20)]
    public string? Sezon { get; set; }

    public int SonMacSayisi { get; set; } = 5;

    public int Galibiyet { get; set; }

    public int Beraberlik { get; set; }

    public int Maglubiyet { get; set; }

    public int AttigiGol { get; set; }

    public int YedigiGol { get; set; }

    public decimal? MacBasinaGolOrtalamasi { get; set; }

    public decimal? MacBasinaYenilenGolOrtalamasi { get; set; }

    public decimal? IkiBucukUstYuzdesi { get; set; }

    public decimal? KarsilikliGolYuzdesi { get; set; }

    public DateTime HesaplamaTarihi { get; set; } = DateTime.UtcNow;

    public Takim Takim { get; set; } = null!;
    public Lig? Lig { get; set; }
}
