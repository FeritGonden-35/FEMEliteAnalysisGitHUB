namespace FEMEliteAnalysis.Api.Models;

public class TelegramJoinVerification
{
    public long Id { get; set; }
    public long TelegramUserId { get; set; }
    public long UserChatId { get; set; }
    public string? Username { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? KayitAdi { get; set; }
    public string? KayitSoyadi { get; set; }
    public string? TelefonNumarasi { get; set; }
    public long GroupChatId { get; set; }
    public string? ScreenshotFileId { get; set; }
    public string Status { get; set; } = TelegramJoinVerificationStatus.PendingVerification;
    public DateTime RequestedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ScreenshotReceivedAt { get; set; }
    public DateTime? ReviewedAt { get; set; }
    public long? ReviewedByAdminId { get; set; }
    public string? InviteLink { get; set; }
    public DateTime? InviteLinkExpiresAt { get; set; }
    public DateTime? InviteLinkCreatedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public static class TelegramJoinVerificationStatus
{
    public const string AwaitingFirstName = "AwaitingFirstName";
    public const string AwaitingLastName = "AwaitingLastName";
    public const string AwaitingPhone = "AwaitingPhone";
    public const string PendingVerification = "PendingVerification";
    public const string ScreenshotReceived = "ScreenshotReceived";
    public const string Approved = "Approved";
    public const string Rejected = "Rejected";
    public const string Expired = "Expired";
}
