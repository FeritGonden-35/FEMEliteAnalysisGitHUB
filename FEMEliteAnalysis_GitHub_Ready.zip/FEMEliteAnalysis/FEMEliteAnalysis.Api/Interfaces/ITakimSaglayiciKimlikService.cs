namespace FEMEliteAnalysis.Api.Interfaces;

public interface ITakimSaglayiciKimlikService
{
    Task<int?> ApiFootballIdGetirAsync(int takimId, CancellationToken ct);
    Task<int?> TheSportsDbIdGetirAsync(int takimId, CancellationToken ct);
    Task<TakimSaglayiciKimlikSonucu> TumKimlikleriGetirAsync(int takimId, CancellationToken ct);
}

public sealed class TakimSaglayiciKimlikSonucu
{
    public int TakimId { get; init; }
    public int? ApiFootballId { get; init; }
    public int? TheSportsDbId { get; init; }
}
