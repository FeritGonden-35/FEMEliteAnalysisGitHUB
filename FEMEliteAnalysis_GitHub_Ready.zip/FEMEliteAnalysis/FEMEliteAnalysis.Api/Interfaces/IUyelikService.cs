using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Uyelik;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IUyelikService
{
    Task<ServiceResult<DateTime>> UyeEkleVeyaUzatAsync(
        UyelikEkleRequest request,
        long olusturanTelegramKullaniciId,
        CancellationToken cancellationToken);

    Task<DateTime?> AktifUyelikBitisTarihiGetirAsync(
        int kullaniciId,
        CancellationToken cancellationToken);
}
