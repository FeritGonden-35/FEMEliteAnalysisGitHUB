using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Models;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKuponKaliciService
{
    Task<ServiceResult<Kupon>> KaydetAsync(long adminTelegramId, CokluKuponTaslakDto taslak, string? baslik, CancellationToken cancellationToken);
    Task<ServiceResult<List<Kupon>>> ListeleAsync(long adminTelegramId, CancellationToken cancellationToken);
    Task<ServiceResult<Kupon>> GetirAsync(int kuponId, long adminTelegramId, CancellationToken cancellationToken);
}
