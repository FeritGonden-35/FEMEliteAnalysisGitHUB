using FEMEliteAnalysis.Api.Common.Results;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IAnalizDuzenlemeService
{
    Task<ServiceResult<bool>> TahminGuncelleAsync(
        int analizId,
        string tahmin,
        CancellationToken cancellationToken);

    Task<ServiceResult<bool>> AnalizMetniniGuncelleAsync(
        int analizId,
        string analizMetni,
        CancellationToken cancellationToken);
}
