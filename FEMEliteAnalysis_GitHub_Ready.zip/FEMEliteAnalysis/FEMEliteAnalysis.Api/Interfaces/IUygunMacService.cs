using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IUygunMacService
{
    Task<ServiceResult<List<UygunMacDto>>> UygunMaclariGetirAsync(
        int gunSayisi,
        int limit,
        CancellationToken cancellationToken);

    Task<ServiceResult<SeciliMacVeriCekSonucDto>> SeciliMacVerisiniCekAsync(
        int macId,
        CancellationToken cancellationToken);
}

