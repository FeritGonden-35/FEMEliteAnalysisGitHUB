using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Historical;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IHistoricalImportService
{
    Task<ServiceResult<List<HistoricalImportResultDto>>> InboxAktarAsync(
        CancellationToken cancellationToken);

    HistoricalImportStatusDto DurumGetir();
    IReadOnlyList<string> BekleyenDosyalariGetir();
}
