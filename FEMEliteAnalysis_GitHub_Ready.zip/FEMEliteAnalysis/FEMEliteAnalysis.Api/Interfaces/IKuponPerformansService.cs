using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKuponPerformansService
{
    Task<ServiceResult<KuponPerformansDto>> GetirAsync(long adminTelegramId, int gun, CancellationToken cancellationToken);
    Task<ServiceResult<int>> SonuclariGuncelleAsync(long adminTelegramId, CancellationToken cancellationToken);
}
