using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface ISqlTakimFormService
{
    Task<ServiceResult<MacKuponVerisiDto>> MacKuponVerisiOlusturAsync(
        int macId,
        CancellationToken cancellationToken);
}
