using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IMacSenkronizasyonService
{
    Task<ServiceResult<List<MacDetayDto>>> TariheGoreMaclariGetirAsync(
        DateOnly tarih,
        CancellationToken cancellationToken);

    Task<ServiceResult<List<MacDetayDto>>> BugunVeYariniGetirAsync(
        CancellationToken cancellationToken);
}
