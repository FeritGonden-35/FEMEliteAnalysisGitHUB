using FEMEliteAnalysis.Api.Dtos.Oran;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IOranHavuzuService
{
    bool Ekle(long telegramId, OranHavuzuMacDto mac, out string mesaj);
    bool Cikar(long telegramId, int macId);
    void Temizle(long telegramId);
    IReadOnlyList<OranHavuzuMacDto> Listele(long telegramId);
    bool Iceriyor(long telegramId, int macId);
}
