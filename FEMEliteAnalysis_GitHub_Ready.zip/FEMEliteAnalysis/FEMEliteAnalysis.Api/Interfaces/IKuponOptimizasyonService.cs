using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKuponOptimizasyonService
{
    Task<ServiceResult<KuponOptimizasyonSonucDto>> OptimizeEtAsync(
        long adminTelegramId,
        int? hedefMacSayisi,
        CancellationToken cancellationToken);

    Task<ServiceResult<CokluKuponTaslakDto>> OnerilenKuponuUygulaAsync(
        long adminTelegramId,
        int hedefMacSayisi,
        CancellationToken cancellationToken);
}
