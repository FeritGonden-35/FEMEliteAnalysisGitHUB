using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IAnalizMotoruV2
{
    AnalizMotoruV2SonucDto AnalizEt(
        MacKuponVerisiDto veri);
}
