using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKuponYayinService
{
    Task<ServiceResult<KuponYayinOnizlemeDto>> OnizlemeGetirAsync(
        int kuponId,
        long adminTelegramId,
        CancellationToken cancellationToken);

    Task<ServiceResult<KuponYayinOnizlemeDto>> YayinlandiOlarakIsaretleAsync(
        int kuponId,
        long adminTelegramId,
        CancellationToken cancellationToken);
}
