using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IVeriSaglayiciFactory
{
    IVeriSaglayici Getir(VeriSaglayiciTuru tur);

    IReadOnlyCollection<IVeriSaglayici> AktifSaglayicilariGetir();
}
