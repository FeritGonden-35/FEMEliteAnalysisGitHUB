using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Debug;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IDebugService
{
    Task<ServiceResult<MacDebugDto>> MacDebugGetirAsync(
        int macId,
        CancellationToken cancellationToken);

    Task<ServiceResult<string>> TakimDebugGetirAsync(
        string takimAdi,
        CancellationToken cancellationToken);

    Task<ServiceResult<string>> H2HDebugGetirAsync(
        int macId,
        CancellationToken cancellationToken);

    Task<ServiceResult<AnalizMotoruV2SonucDto>> MarketDebugGetirAsync(
        int macId,
        CancellationToken cancellationToken);
}
