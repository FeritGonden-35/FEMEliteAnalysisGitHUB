using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IOddsPatternEngine
{
    Task<ServiceResult<OddsPatternSonucDto>> AnalizEtAsync(int macId, CancellationToken ct);
    Task<OddsPatternSonucDto?> HizliAnalizAsync(int macId, CancellationToken ct);
}
