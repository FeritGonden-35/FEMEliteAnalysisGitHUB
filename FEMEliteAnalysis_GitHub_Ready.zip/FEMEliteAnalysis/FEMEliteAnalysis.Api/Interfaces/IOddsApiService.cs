using FEMEliteAnalysis.Api.Dtos.Oran;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IOddsApiService
{
    Task<IReadOnlyList<OranSyncSonucDto>> HavuzOranlariniCekAsync(IEnumerable<int> macIdleri, CancellationToken ct);
    Task<OranSyncSonucDto> MacOraniniCekAsync(int macId, bool cacheKullan = true, CancellationToken ct = default);
    Task<bool> GuncelOranVarMiAsync(int macId, CancellationToken ct);
}
