using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Historical;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IFootballDataCoUkImportService
{
    IReadOnlyList<(string Kod, string Ad, string Ulke)> LigleriGetir();

    Task<ServiceResult<FootballDataImportResultDto>> LigSezonAktarAsync(
        string ligKodu,
        string sezonKodu,
        CancellationToken cancellationToken);

    Task<ServiceResult<List<FootballDataImportResultDto>>> TopluAktarAsync(
        IReadOnlyCollection<string> ligKodlari,
        string sezonKodu,
        CancellationToken cancellationToken);
}
