using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Lig;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface ILigYonetimService
{
    Task<ServiceResult<List<LigAramaSonucuDto>>> LigAraAsync(string arama, CancellationToken cancellationToken);
    Task<ServiceResult<List<LigAramaSonucuDto>>> GenisLigHavuzuGetirAsync(int maksimumLig, CancellationToken cancellationToken);
    Task<ServiceResult<LigSenkronizasyonSonucuDto>> LigSenkronizeEtAsync(int ligId, int sezonSayisi, CancellationToken cancellationToken);
}
