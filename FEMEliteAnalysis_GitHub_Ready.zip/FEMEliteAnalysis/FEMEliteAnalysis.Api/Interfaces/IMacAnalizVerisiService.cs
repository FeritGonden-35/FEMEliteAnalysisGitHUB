using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IMacAnalizVerisiService
{
    Task<ServiceResult<MacAnalizVerisiDto>> AnalizVerisiOlusturAsync(
        int macId,
        CancellationToken cancellationToken);

    string PromptVerisiOlustur(MacAnalizVerisiDto veri);
}
