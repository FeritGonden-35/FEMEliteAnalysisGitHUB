using FEMEliteAnalysis.Api.Dtos.Kullanici;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKullaniciService
{
    Task<KullaniciDto> KaydetVeyaGuncelleAsync(
        User telegramKullanicisi,
        CancellationToken cancellationToken);

    Task<KullaniciDto?> TelegramIdIleGetirAsync(
        long telegramKullaniciId,
        CancellationToken cancellationToken);
}
