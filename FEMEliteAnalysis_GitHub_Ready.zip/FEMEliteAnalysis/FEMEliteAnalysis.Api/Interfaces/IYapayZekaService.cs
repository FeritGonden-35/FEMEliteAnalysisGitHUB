using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IYapayZekaService
{
    Task<ServiceResult<YapayZekaAnalizResult>> MacAnaliziOlusturAsync(
        string veriMetni,
        CancellationToken cancellationToken);
}
