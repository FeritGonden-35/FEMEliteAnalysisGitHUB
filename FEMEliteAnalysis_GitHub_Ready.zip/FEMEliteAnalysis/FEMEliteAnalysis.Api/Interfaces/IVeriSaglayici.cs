using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.VeriToplama;
using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IVeriSaglayici
{
    VeriSaglayiciTuru Tur { get; }
    string Ad { get; }

    bool AktifMi { get; }

    Task<ServiceResult<bool>> BaglantiTestiAsync(
        CancellationToken cancellationToken);

    Task<ServiceResult<VeriToplamaSonucDto>> VeriToplaAsync(
        VeriToplamaIstekDto istek,
        CancellationToken cancellationToken);
}
