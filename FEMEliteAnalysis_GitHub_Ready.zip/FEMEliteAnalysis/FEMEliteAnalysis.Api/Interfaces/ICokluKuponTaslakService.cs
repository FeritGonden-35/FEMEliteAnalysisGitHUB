using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface ICokluKuponTaslakService
{
    ServiceResult<CokluKuponTaslakDto> MacEkle(
        long adminTelegramId,
        CokluKuponMacSecimiDto secim);

    ServiceResult<CokluKuponTaslakDto> MacCikar(
        long adminTelegramId,
        int analizId);

    ServiceResult<CokluKuponTaslakDto> TaslagiGetir(
        long adminTelegramId);

    ServiceResult<bool> Temizle(
        long adminTelegramId);
}
