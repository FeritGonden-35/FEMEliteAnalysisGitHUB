namespace FEMEliteAnalysis.Api.Interfaces;

public interface IVeriToplamaDurumStore
{
    bool CalisiyorMu { get; }
    DateTime? SonBaslamaZamani { get; }
    DateTime? SonBitisZamani { get; }
    string? SonMesaj { get; }

    void Basladi();
    void Tamamlandi(string mesaj);
    void Basarisiz(string mesaj);
}
