using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKilitMacService
{
    Task<ServiceResult<KilitMaclarSonucDto>> GetirAsync(int adet, bool yuksekDeger, CancellationToken ct);
}
