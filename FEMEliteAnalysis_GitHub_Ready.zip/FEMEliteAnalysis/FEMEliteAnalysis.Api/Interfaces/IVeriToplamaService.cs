using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.VeriToplama;
using FEMEliteAnalysis.Api.Enums;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IVeriToplamaService
{
    Task<ServiceResult<VeriToplamaSonucDto>> CalistirAsync(
        VeriToplamaIstekDto istek,
        CancellationToken cancellationToken);

    Task<ServiceResult<List<VeriToplamaSonucDto>>> TumAktifSaglayicilariCalistirAsync(
        DateOnly baslangicTarihi,
        DateOnly bitisTarihi,
        CancellationToken cancellationToken);

    bool CalisiyorMu { get; }
    DateTime? SonBaslamaZamani { get; }
    DateTime? SonBitisZamani { get; }
}
