using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.TeamRepair;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface ITeamRepairService
{
    Task<ServiceResult<List<TeamMergeCandidateDto>>> TaraAsync(CancellationToken cancellationToken);
    Task<ServiceResult<TeamRepairStatusDto>> UygulaAsync(CancellationToken cancellationToken);
    TeamRepairStatusDto DurumGetir();
    IReadOnlyList<TeamMergeCandidateDto> SonPlanGetir();
}
