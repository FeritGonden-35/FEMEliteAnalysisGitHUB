using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IKuponMarketMotoru
{
    KuponMarketAnaliziDto AnalizEt(MacKuponVerisiDto veri);
}
