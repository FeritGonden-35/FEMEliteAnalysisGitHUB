using FEMEliteAnalysis.Api.Common.Results;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IAnalizYayinService
{
    Task<ServiceResult<long>> VipKanalinaYayinlaAsync(
        int analizId,
        CancellationToken cancellationToken);

    Task<ServiceResult<string>> YayinOnizlemesiOlusturAsync(
        int analizId,
        CancellationToken cancellationToken);
}
