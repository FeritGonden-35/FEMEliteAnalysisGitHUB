using FEMEliteAnalysis.Api.Dtos.Analiz;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IFemAnalizMotoru
{
    YapayZekaAnalizResult AnalizEt(MacAnalizVerisiDto veri);
}
