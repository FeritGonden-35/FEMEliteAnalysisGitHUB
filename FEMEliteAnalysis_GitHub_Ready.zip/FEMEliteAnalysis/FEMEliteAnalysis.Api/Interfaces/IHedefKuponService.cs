using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IHedefKuponService
{
    Task<ServiceResult<HedefKuponDto>> DusukOlusturAsync(long adminTelegramId, CancellationToken cancellationToken);
    Task<ServiceResult<HedefKuponDto>> OrtaOlusturAsync(long adminTelegramId, CancellationToken cancellationToken);
    Task<ServiceResult<HedefKuponDto>> YuksekOlusturAsync(long adminTelegramId, CancellationToken cancellationToken);
    Task<ServiceResult<List<HedefKuponDto>>> CokluOlusturAsync(string mod, int adet, IReadOnlyCollection<int>? macIdleri, CancellationToken cancellationToken);
    Task<ServiceResult<CokluKuponTaslakDto>> TaslagaUygulaAsync(long adminTelegramId, HedefKuponDto kupon);
}
