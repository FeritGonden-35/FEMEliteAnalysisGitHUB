using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IMacVeriService
{
    Task<ServiceResult<List<MacDetayDto>>> BugununMaclariniGetirAsync(
        CancellationToken cancellationToken);
}
