using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IOtomatikKuponService
{
    Task<ServiceResult<OtomatikKuponSonucDto>> OlusturAsync(long adminTelegramId, string mod, int adet, CancellationToken ct);
}
