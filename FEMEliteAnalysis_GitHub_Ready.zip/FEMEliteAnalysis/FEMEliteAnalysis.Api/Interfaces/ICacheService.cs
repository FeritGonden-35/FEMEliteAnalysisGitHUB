namespace FEMEliteAnalysis.Api.Interfaces;

public interface ICacheService
{
    bool TryGet<T>(string key, out T? value);

    void Set<T>(
        string key,
        T value,
        TimeSpan duration);

    void Remove(string key);

    T GetOrCreate<T>(
        string key,
        Func<T> factory,
        TimeSpan duration);

    Task<T> GetOrCreateAsync<T>(
        string key,
        Func<CancellationToken, Task<T>> factory,
        TimeSpan duration,
        CancellationToken cancellationToken);
}
