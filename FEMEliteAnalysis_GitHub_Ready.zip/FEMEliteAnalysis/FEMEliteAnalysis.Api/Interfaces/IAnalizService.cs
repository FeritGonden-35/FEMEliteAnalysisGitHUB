using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IAnalizService
{
    Task<ServiceResult<int>> AnalizOlusturAsync(
        AnalizOlusturRequest request,
        CancellationToken cancellationToken);
}
