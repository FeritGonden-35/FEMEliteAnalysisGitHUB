using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Mac;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface ITakimGecmisSenkronizasyonService
{
    Task<ServiceResult<TakimGecmisVerisiDto>> SonMaclariGetirAsync(
        int takimId,
        int adet,
        CancellationToken cancellationToken);

    Task<ServiceResult<TakimGecmisVerisiDto>> IcSahaMaclariniGetirAsync(
        int takimId,
        int adet,
        CancellationToken cancellationToken);

    Task<ServiceResult<TakimGecmisVerisiDto>> DisSahaMaclariniGetirAsync(
        int takimId,
        int adet,
        CancellationToken cancellationToken);

    Task<ServiceResult<H2HOzetDto>> H2HGetirAsync(
        int takim1Id,
        int takim2Id,
        int adet,
        CancellationToken cancellationToken);

    Task<ServiceResult<MacKuponVerisiDto>> MacKuponVerisiOlusturAsync(
        int macId,
        CancellationToken cancellationToken);
}
