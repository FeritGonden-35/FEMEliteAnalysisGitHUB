using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Uyelik;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IVipYonetimService
{
    Task<ServiceResult<List<VipKullaniciDto>>> AktifUyeleriGetirAsync(
        CancellationToken cancellationToken);

    Task<ServiceResult<VipKullaniciDto>> UyeBilgisiGetirAsync(
        long telegramKullaniciId,
        CancellationToken cancellationToken);

    Task<ServiceResult<bool>> UyelikIptalEtAsync(
        long telegramKullaniciId,
        long islemiYapanTelegramKullaniciId,
        CancellationToken cancellationToken);
}
