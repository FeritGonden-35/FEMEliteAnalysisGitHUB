using FEMEliteAnalysis.Api.Services;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IIstatistikSyncService
{
    Task<IstatistikSyncSonuc> TamSenkronizeEtAsync(
        Func<IstatistikSyncIlerleme, Task>? ilerleme,
        CancellationToken cancellationToken);
}
