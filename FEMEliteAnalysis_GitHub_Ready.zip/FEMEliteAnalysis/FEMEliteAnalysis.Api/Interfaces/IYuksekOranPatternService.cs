using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;

namespace FEMEliteAnalysis.Api.Interfaces;

public interface IYuksekOranPatternService
{
    Task<ServiceResult<YuksekOranPatternKuponDto>> OlusturAsync(
        IReadOnlyCollection<int>? macIdleri,
        CancellationToken cancellationToken);
}
