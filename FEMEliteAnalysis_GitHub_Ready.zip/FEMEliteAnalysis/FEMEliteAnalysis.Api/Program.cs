using FEMEliteAnalysis.Api.BackgroundJobs;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Extensions;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddFemVeriToplama(builder.Configuration);
builder.Services.AddControllers();
builder.Services.AddOpenApi();
builder.Services.AddFemSofaScore(builder.Configuration);
builder.Services.AddFemTheSportsDb(builder.Configuration);
builder.Services.AddFemDebugMode();
builder.Host.UseWindowsService(options =>
{
    options.ServiceName = "FEMEliteAnalysis";
});


builder.Services
    .AddFemOptions(builder.Configuration)
    .AddFemDatabase(builder.Configuration)
    .AddFemServices()
    .AddFemTelegram();

builder.Services.AddHostedService<UyelikKontrolService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.MapControllers();

app.MapGet("/", () => new
{
    success = true,
    application = "FEM Elite Analysis API",
    status = "Running",
    time = DateTime.UtcNow
});

app.MapGet("/api/health", async (IServiceScopeFactory scopeFactory, CancellationToken cancellationToken) =>
{
    using var scope = scopeFactory.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<FemDbContext>();
    var databaseOk = await db.Database.CanConnectAsync(cancellationToken);
    var telegramConfigured = !string.IsNullOrWhiteSpace(
        builder.Configuration["Telegram:BotToken"]);

    return Results.Json(new
    {
        success = databaseOk && telegramConfigured,
        api = "running",
        database = databaseOk ? "connected" : "unavailable",
        telegram = telegramConfigured ? "configured" : "missing-token",
        time = DateTime.UtcNow
    }, statusCode: databaseOk && telegramConfigured ? 200 : 503);
});

await FemDbInitializer.BaslatAsync(app.Services);

app.Run();
