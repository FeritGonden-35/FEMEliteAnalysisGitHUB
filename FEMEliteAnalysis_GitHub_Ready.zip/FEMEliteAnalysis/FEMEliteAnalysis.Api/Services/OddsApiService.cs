using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Oran;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

/// <summary>
/// V4.10 - Tek odds sağlayıcısı PulseScore / Bet365.
/// Akış: /oranekle -> /oranhavuzu -> /oranlaricek -> /analiz.
/// PulseScore X-Secret header kullanır ve normalize canonicalMarket/period/selections şemasını döndürür.
/// </summary>
public class OddsApiService : IOddsApiService
{
    private const string KaynakPrefix = "PulseScore:Bet365";
    private readonly HttpClient _http;
    private readonly FemDbContext _db;
    private readonly OddsApiOptions _opt;
    private readonly ILogger<OddsApiService> _logger;

    public OddsApiService(HttpClient http, FemDbContext db, IOptions<OddsApiOptions> opt, ILogger<OddsApiService> logger)
    {
        _http = http;
        _db = db;
        _opt = opt.Value;
        _logger = logger;
    }

    public async Task<bool> GuncelOranVarMiAsync(int macId, CancellationToken ct)
    {
        var esik = DateTime.UtcNow.AddMinutes(-Math.Max(5, _opt.CacheDakika));
        return await _db.BahisOranlari.AsNoTracking()
            .AnyAsync(x => x.MacId == macId && x.AlinmaTarihi >= esik && x.Kaynak != null && x.Kaynak.StartsWith("PulseScore"), ct);
    }

    public async Task<OranSyncSonucDto> MacOraniniCekAsync(int macId, bool cacheKullan = true, CancellationToken ct = default)
    {
        if (cacheKullan && await GuncelOranVarMiAsync(macId, ct))
        {
            var mac = await MacGetirAsync(macId, ct);
            return new OranSyncSonucDto
            {
                MacId = macId,
                MacAdi = mac is null ? macId.ToString() : $"{mac.EvSahibiTakim.Ad} - {mac.DeplasmanTakim.Ad}",
                EslesmeBulundu = true,
                KaydedilenOran = await GuncelOranSayisi(macId, ct),
                ApiIstekSayisi = 0,
                Mesaj = "Güncel PulseScore oranı cache'den kullanıldı."
            };
        }

        var list = await HavuzOranlariniCekAsync(new[] { macId }, ct);
        return list.FirstOrDefault() ?? new OranSyncSonucDto { MacId = macId, Mesaj = "Oran sonucu üretilemedi." };
    }

    public async Task<IReadOnlyList<OranSyncSonucDto>> HavuzOranlariniCekAsync(IEnumerable<int> macIdleri, CancellationToken ct)
    {
        var ids = macIdleri.Distinct().Take(Math.Max(5, _opt.MaksimumShortlist)).ToList();
        if (ids.Count == 0) return Array.Empty<OranSyncSonucDto>();

        var maclar = await _db.Maclar.AsNoTracking()
            .Include(x => x.EvSahibiTakim).Include(x => x.DeplasmanTakim).Include(x => x.Lig)
            .Where(x => ids.Contains(x.Id)).OrderBy(x => x.MacTarihi).ToListAsync(ct);

        if (!_opt.Aktif || string.IsNullOrWhiteSpace(_opt.ApiKey))
            return maclar.Select(x => Sonuc(x, false, 0, 0, "PulseScore pasif veya OddsApi:ApiKey boş.")).ToList();

        AyarlaHeader();

        var bekleyen = new Dictionary<int, Mac>();
        var sonuclar = new Dictionary<int, OranSyncSonucDto>();
        foreach (var mac in maclar)
        {
            if (await GuncelOranVarMiAsync(mac.Id, ct))
                sonuclar[mac.Id] = Sonuc(mac, true, await GuncelOranSayisi(mac.Id, ct), 0, "Güncel PulseScore oranı cache'den kullanıldı.");
            else
                bekleyen[mac.Id] = mac;
        }

        var toplamIstek = 0;
        var eventMap = new Dictionary<int, PulseEvent>();

        // V4.10.2: PulseScore global /events feed'i startTime sirali geliyor.
        // /events?league=... bazı ortamlarda filtreyi uygulamayıp ilk global sayfayı döndürebiliyor;
        // bu da aynı sayfayı tekrar tekrar çekip hedef akşam maçlarına hiç ulaşamamıza neden oluyordu.
        // Bu nedenle doğrudan global pagination kullanıyoruz ve tüm hedefler bulununca hemen duruyoruz.
        // API gerçek cevapta limit=50 istense bile 30 döndürebildiğinden hasNextPage/totalPages sinyali esas alınır.
        var maxSayfa = Math.Max(54, _opt.MaksimumEventSayfasi);
        var tarananSayfa = 0;
        var sonApiHatasi = string.Empty;
        DateTime? ilkEventSaati = null;
        DateTime? sonEventSaati = null;

        // V4.10.3: PulseScore BASIC katmanında ardışık REST çağrıları çok hızlı yapılınca
        // ara sıra 429/5xx dönebiliyor. Sayfalar arasında küçük gecikme + retry kullanıyoruz.
        // Ayrıca API'nin hasNextPage alanı bazı cevaplarda tutarsız olabildiği için totalPages
        // bilgisini de dikkate alıyoruz; hedefler bulunana kadar erken kesmiyoruz.
        for (var page = 1; page <= maxSayfa && eventMap.Count < bekleyen.Count; page++)
        {
            PulsePage eventPage;
            try
            {
                eventPage = await EventSayfasi(page, ct);
                toplamIstek += eventPage.HttpIstekSayisi;
                tarananSayfa++;
            }
            catch (Exception ex)
            {
                toplamIstek++;
                sonApiHatasi = KisaHata(ex.Message);
                _logger.LogWarning(ex, "PulseScore event sayfası alınamadı. Page:{Page}", page);
                // Tek bir sayfa yüzünden tüm taramayı bırakma.
                if (page < maxSayfa)
                {
                    await Task.Delay(700, ct);
                    continue;
                }
                break;
            }

            var events = eventPage.Events;
            if (events.Count == 0)
            {
                // Gerçekten son sayfadaysak bitir; aradaki boş sayfayı tolere et.
                if (eventPage.TotalPages > 0 && page >= eventPage.TotalPages) break;
                await Task.Delay(350, ct);
                continue;
            }

            var validTimes = events.Where(x => x.StartTime != DateTime.MinValue).Select(x => x.StartTime).OrderBy(x => x).ToList();
            if (validTimes.Count > 0)
            {
                ilkEventSaati ??= validTimes[0];
                sonEventSaati = validTimes[^1];
            }

            foreach (var mac in bekleyen.Values.Where(x => !eventMap.ContainsKey(x.Id)))
            {
                var es = EnIyiEvent(mac, events);
                if (es is not null)
                {
                    eventMap[mac.Id] = es;
                    _logger.LogInformation("PulseScore event eşleşti. MacId:{MacId} {Home}-{Away} => {PulseHome}-{PulseAway} Event:{EventId} Page:{Page}",
                        mac.Id, mac.EvSahibiTakim.Ad, mac.DeplasmanTakim.Ad, es.Home, es.Away, es.EventId, page);
                }
            }

            var kesinSon = eventPage.TotalPages > 0 ? page >= eventPage.TotalPages : !eventPage.HasNextPage;
            if (kesinSon) break;

            // BASIC planda rate-limit'e çarpmamak için sayfalar arasında küçük ara.
            await Task.Delay(300, ct);
        }

        var taramaNotu = $"Tarama: {tarananSayfa} sayfa" +
                         (ilkEventSaati.HasValue ? $", event zamanı {ilkEventSaati:dd.MM HH:mm}-{sonEventSaati:dd.MM HH:mm} UTC" : string.Empty) +
                         (!string.IsNullOrWhiteSpace(sonApiHatasi) ? $", son API hata: {sonApiHatasi}" : string.Empty);

        // Event payload'ın kendi markets[] alanından oranları kaydet; ek event-detail isteği yakma.
        foreach (var mac in bekleyen.Values)
        {
            if (sonuclar.TryGetValue(mac.Id, out var mevcut) && !mevcut.EslesmeBulundu && !eventMap.ContainsKey(mac.Id))
                continue;

            if (!eventMap.TryGetValue(mac.Id, out var ev))
            {
                sonuclar[mac.Id] = Sonuc(mac, false, 0, 0, $"PulseScore Bet365 event eşleşmesi bulunamadı. {taramaNotu}");
                continue;
            }

            try
            {
                var count = await EventOranlariniKaydet(mac, ev, ct);
                sonuclar[mac.Id] = Sonuc(mac, true, count, 0, count > 0
                    ? $"Gerçek Bet365 pre-match oranları kaydedildi. Pulse event: {ev.EventId}"
                    : $"Event bulundu fakat FEM'e eşlenen kullanılabilir market yok. Pulse event: {ev.EventId}");
                sonuclar[mac.Id].OddsEventId = long.TryParse(ev.EventId, out var id) ? id : null;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "PulseScore market kaydı başarısız. MacId:{MacId} Event:{Event}", mac.Id, ev.EventId);
                sonuclar[mac.Id] = Sonuc(mac, true, 0, 0, $"PulseScore oran parse/kayıt hatası: {KisaHata(ex.Message)}");
            }
        }

        // Sayfa istek sayısını ilk sonuca ekle; Telegram toplam tüketimi doğru göstersin.
        var ordered = maclar.Select(m => sonuclar.TryGetValue(m.Id, out var s) ? s : Sonuc(m, false, 0, 0, "Sonuç oluşturulamadı.")).ToList();
        if (ordered.Count > 0) ordered[0].ApiIstekSayisi += toplamIstek;
        return ordered;
    }

    private void AyarlaHeader()
    {
        _http.DefaultRequestHeaders.Remove("X-Secret");
        _http.DefaultRequestHeaders.TryAddWithoutValidation("X-Secret", _opt.ApiKey.Trim());
    }

    private async Task<PulsePage> EventSayfasi(int page, CancellationToken ct)
    {
        var limit = Math.Clamp(_opt.EventPageLimit, 10, 100);
        HttpResponseMessage? res = null;
        string raw = string.Empty;
        var httpIstek = 0;

        for (var deneme = 1; deneme <= 3; deneme++)
        {
            res?.Dispose();
            res = await _http.GetAsync($"events?page={page}&limit={limit}", ct);
            httpIstek++;
            raw = await res.Content.ReadAsStringAsync(ct);
            if (res.IsSuccessStatusCode) break;

            var code = (int)res.StatusCode;
            if (code is 429 or 500 or 502 or 503 or 504)
            {
                var bekle = 650 * deneme;
                if (res.Headers.RetryAfter?.Delta is TimeSpan retry && retry.TotalMilliseconds > 0)
                    bekle = (int)Math.Min(5000, retry.TotalMilliseconds);
                await Task.Delay(bekle, ct);
                continue;
            }
            break;
        }

        if (res is null) throw new HttpRequestException("PulseScore HTTP cevabı alınamadı.");
        using (res)
        {
            if (!res.IsSuccessStatusCode)
                throw new HttpRequestException($"HTTP {(int)res.StatusCode}: {KisaHata(raw)}");
        }

        using var doc = JsonDocument.Parse(raw);
        var root = doc.RootElement;
        var arr = GetArray(root);
        var list = new List<PulseEvent>();
        foreach (var item in arr.EnumerateArray())
        {
            var ev = ParseEvent(item);
            if (ev is not null) list.Add(ev);
        }

        var hasNext = Bool(root, "hasNextPage");
        var totalPages = Int(root, "totalPages");
        if (!hasNext && totalPages > 0) hasNext = page < totalPages;
        return new PulsePage { Events = list, HasNextPage = hasNext, TotalPages = totalPages, HttpIstekSayisi = httpIstek };
    }

    private async Task<List<PulseEvent>> LigEventleri(string ligAdi, CancellationToken ct)
    {
        var encoded = Uri.EscapeDataString(ligAdi);
        using var res = await _http.GetAsync($"events?league={encoded}", ct);
        var raw = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new HttpRequestException($"HTTP {(int)res.StatusCode}: {KisaHata(raw)}");

        using var doc = JsonDocument.Parse(raw);
        var arr = GetArray(doc.RootElement);
        var list = new List<PulseEvent>();
        foreach (var item in arr.EnumerateArray())
        {
            var ev = ParseEvent(item);
            if (ev is not null) list.Add(ev);
        }
        return list;
    }

    private static JsonElement GetArray(JsonElement root)
    {
        if (root.ValueKind == JsonValueKind.Array) return root;
        foreach (var name in new[] { "data", "events", "response", "items" })
            if (root.TryGetProperty(name, out var x) && x.ValueKind == JsonValueKind.Array) return x;
        return EmptyArray();
    }

    private static JsonElement EmptyArray()
    {
        using var doc = JsonDocument.Parse("[]");
        return doc.RootElement.Clone();
    }

    private static PulseEvent? ParseEvent(JsonElement item)
    {
        var eventId = Str(item, "eventId") ?? Str(item, "id");
        var home = Str(item, "home") ?? Str(item, "homeTeam");
        var away = Str(item, "away") ?? Str(item, "awayTeam");
        if (string.IsNullOrWhiteSpace(eventId) || string.IsNullOrWhiteSpace(home) || string.IsNullOrWhiteSpace(away)) return null;

        DateTime start = DateTime.MinValue;
        var st = Str(item, "startTime") ?? Str(item, "date");
        if (!string.IsNullOrWhiteSpace(st) && DateTimeOffset.TryParse(st, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dto))
            start = dto.UtcDateTime;

        var markets = new List<PulseMarket>();
        if (item.TryGetProperty("markets", out var marr) && marr.ValueKind == JsonValueKind.Array)
        {
            foreach (var m in marr.EnumerateArray())
            {
                var pm = new PulseMarket
                {
                    Canonical = Str(m, "canonicalMarket") ?? "",
                    Period = Str(m, "period") ?? "",
                    RawName = Str(m, "rawName") ?? "",
                    Line = Str(m, "line") ?? NumStr(m, "line") ?? ""
                };
                if (m.TryGetProperty("selections", out var sels) && sels.ValueKind == JsonValueKind.Array)
                {
                    foreach (var s in sels.EnumerateArray())
                    {
                        // PulseScore normalize şemasının eski örneklerinde decimal/name, gerçek Bet365 çıktısında odds/canonicalOutcome/rawName geliyor.
                        var dec = Str(s, "decimal") ?? NumStr(s, "decimal") ?? Str(s, "odds") ?? NumStr(s, "odds");
                        if (!decimal.TryParse(dec, NumberStyles.Any, CultureInfo.InvariantCulture, out var odd) || odd <= 0) continue;

                        var active = !s.TryGetProperty("isActive", out var activeProp) || activeProp.ValueKind != JsonValueKind.False;
                        if (!active) continue;

                        var more = s.TryGetProperty("moreInfo", out var mi) && mi.ValueKind == JsonValueKind.Object ? mi : default;
                        pm.Selections.Add(new PulseSelection
                        {
                            Name = Str(s, "name") ?? Str(s, "canonicalOutcome") ?? "",
                            RawName = Str(s, "rawName") ?? "",
                            Outcome = Str(s, "canonicalOutcome") ?? "",
                            Line = Str(s, "line") ?? NumStr(s, "line") ?? "",
                            Hint = more.ValueKind == JsonValueKind.Object ? (Str(more, "N2") ?? Str(more, "HD") ?? Str(more, "HA") ?? "") : "",
                            Decimal = odd
                        });
                    }
                }
                markets.Add(pm);
            }
        }

        return new PulseEvent { EventId = eventId, Home = home, Away = away, League = Str(item, "league") ?? "", StartTime = start, Markets = markets };
    }

    private async Task<int> EventOranlariniKaydet(Mac mac, PulseEvent ev, CancellationToken ct)
    {
        var bulunan = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
        foreach (var market in ev.Markets)
        {
            foreach (var sel in market.Selections)
            {
                if (sel.Decimal <= 1.01m) continue;
                foreach (var kod in MarketKodlari(market, sel, mac, ev))
                    if (!bulunan.TryGetValue(kod, out var eski) || sel.Decimal > eski)
                        bulunan[kod] = sel.Decimal;
            }
        }

        if (bulunan.Count == 0) return 0;

        // Aynı PulseScore kaynağının eski kayıtlarını temizle; farklı provider geçmişine dokunma.
        var eskiKayitlar = await _db.BahisOranlari
            .Where(x => x.MacId == mac.Id && x.Kaynak != null && x.Kaynak.StartsWith("PulseScore"))
            .ToListAsync(ct);
        if (eskiKayitlar.Count > 0) _db.BahisOranlari.RemoveRange(eskiKayitlar);

        var now = DateTime.UtcNow;
        foreach (var (kod, odd) in bulunan)
        {
            _db.BahisOranlari.Add(new BahisOrani
            {
                MacId = mac.Id,
                MarketKodu = kod,
                Oran = odd,
                Kaynak = KaynakPrefix,
                AlinmaTarihi = now
            });
        }
        await _db.SaveChangesAsync(ct);
        return bulunan.Count;
    }

    private static IEnumerable<string> MarketKodlari(PulseMarket m, PulseSelection s, Mac mac, PulseEvent ev)
    {
        var list = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var canonical = N(m.Canonical);
        var period = N(m.Period);
        var rawMarket = N(m.RawName);
        var name = N(string.IsNullOrWhiteSpace(s.Name) ? s.RawName : s.Name);
        var rawSel = N(s.RawName);
        var outcome = N(s.Outcome);
        var hint = N(s.Hint);
        var line = NormalizeLine(!string.IsNullOrWhiteSpace(s.Line) ? s.Line : m.Line);

        bool firstHalf = period.Contains("FIRST_HALF") || period.Contains("1ST_HALF") || rawMarket.Contains("FIRST HALF") || rawMarket.Contains("1ST HALF");
        bool fulltime = string.IsNullOrWhiteSpace(period) || period.Contains("FULLTIME") || period.Contains("FULL_TIME") || period == "FT";

        if ((canonical.Contains("MATCH_WINNER") || canonical.Contains("MATCH_RESULT") || canonical == "1X2" || rawMarket.Contains("FULL TIME RESULT")) && fulltime)
        {
            if (IsHome(name, rawSel, mac, ev)) list.Add("MS1");
            else if (IsDraw(name, rawSel)) list.Add("MSX");
            else if (IsAway(name, rawSel, mac, ev)) list.Add("MS2");
        }

        if ((canonical.Contains("MATCH_WINNER") || canonical.Contains("MATCH_RESULT") || canonical.Contains("HALF_WINNER") || rawMarket.Contains("HALF TIME RESULT") || rawMarket.Contains("1ST HALF RESULT")) && firstHalf)
        {
            if (IsHome(name, rawSel, mac, ev)) list.Add("İY 1");
            else if (IsDraw(name, rawSel)) list.Add("İY X");
            else if (IsAway(name, rawSel, mac, ev)) list.Add("İY 2");
        }

        if (canonical.Contains("DOUBLE_CHANCE") || rawMarket.Contains("DOUBLE CHANCE"))
        {
            if (hint == "1X" || name == "1X" || rawSel == "1X" || (IsHome(name, rawSel, mac, ev) && (name.Contains("DRAW") || rawSel.Contains("DRAW")))) list.Add("1X");
            if (hint == "X2" || name == "X2" || rawSel == "X2" || (IsAway(name, rawSel, mac, ev) && (name.Contains("DRAW") || rawSel.Contains("DRAW")))) list.Add("X2");
            if (hint == "12" || name == "12" || rawSel == "12" || ((IsHome(name, rawSel, mac, ev) || name.Contains(N(ev.Home))) && (IsAway(name, rawSel, mac, ev) || name.Contains(N(ev.Away))))) list.Add("12");
        }

        if (canonical.Contains("BOTH_TEAMS_TO_SCORE") || canonical.Contains("BTTS") || rawMarket.Contains("BOTH TEAMS TO SCORE"))
        {
            if (outcome is "YES" or "VAR" || name is "YES" or "VAR" || rawSel is "YES" or "VAR") list.Add(firstHalf ? "İY KG VAR" : "KG VAR");
            if (outcome is "NO" or "YOK" || name is "NO" or "YOK" || rawSel is "NO" or "YOK") list.Add(firstHalf ? "İY KG YOK" : "KG YOK");
        }

        if (!canonical.Contains("CORNER") && !rawMarket.Contains("CORNER") && (canonical.Contains("OVER_UNDER") || canonical.Contains("TOTAL_GOALS") || canonical.Contains("GOALS_OVER_UNDER") || rawMarket.Contains("OVER/UNDER") || rawMarket.Contains("TOTAL GOALS") || rawMarket.Contains("GOAL LINE")))
        {
            var side = outcome == "OVER" || name.Contains("OVER") || rawSel.Contains("OVER") || hint.Contains("OVER") ? "ÜST" : outcome == "UNDER" || name.Contains("UNDER") || rawSel.Contains("UNDER") || hint.Contains("UNDER") ? "ALT" : null;
            var parsedLine = !string.IsNullOrWhiteSpace(line) ? line : ExtractLine(name + " " + rawSel + " " + rawMarket);
            if (side is not null && parsedLine is not null)
                list.Add($"{(firstHalf ? "İY " : "")}{parsedLine} {side}");
        }

        if (canonical.Contains("CORNER") || rawMarket.Contains("CORNER"))
        {
            var side = outcome == "OVER" || name.Contains("OVER") || rawSel.Contains("OVER") || hint.Contains("OVER") ? "ÜST" : outcome == "UNDER" || name.Contains("UNDER") || rawSel.Contains("UNDER") || hint.Contains("UNDER") ? "ALT" : null;
            var parsedLine = !string.IsNullOrWhiteSpace(line) ? line : ExtractAnyLine(name + " " + rawSel + " " + hint + " " + rawMarket);
            if (side is not null && parsedLine is not null)
                list.Add($"{parsedLine} KORNER {side}");
        }

        if (canonical.Contains("HALF_TIME_FULL_TIME") || canonical.Contains("HT_FT") || rawMarket.Contains("HALF TIME/FULL TIME") || rawMarket.Contains("HALF TIME - FULL TIME"))
        {
            var htft = HtFtToken(name + " " + rawSel, mac, ev);
            if (htft is not null) list.Add(htft);
        }

        // Takım gol alt/üst ve gerçek kombine marketler için raw fallback.
        var raw = rawMarket + " " + name + " " + rawSel + " " + hint;
        if (rawMarket.Contains("TEAM TOTAL GOALS") || rawMarket.Contains("TEAM GOALS"))
        {
            var takimPrefix = outcome == "HOME" || IsHome(name, rawSel, mac, ev) ? "EV " : outcome == "AWAY" || IsAway(name, rawSel, mac, ev) ? "DEP " : null;
            if (takimPrefix is not null) AddRawTotal(raw, takimPrefix, list);
        }
        else
        {
            if (rawMarket.Contains("HOME TEAM") && (raw.Contains("OVER") || raw.Contains("UNDER"))) AddRawTotal(raw, "EV ", list);
            if (rawMarket.Contains("AWAY TEAM") && (raw.Contains("OVER") || raw.Contains("UNDER"))) AddRawTotal(raw, "DEP ", list);
        }

        // Sadece market adı gerçekten Result/Goals veya Result/BTTS kombinasyonu belirtiyorsa kombine market üret.
        var kombineMarket = rawMarket.Contains("RESULT") && (rawMarket.Contains("TOTAL") || rawMarket.Contains("GOAL") || rawMarket.Contains("BOTH TEAMS") || rawMarket.Contains("BTTS"));
        if (kombineMarket)
        {
            var result = ResultTokenWithTeams(raw, mac, ev);
            var total = TotalToken(raw);
            if (result is not null && total is not null) list.Add($"{result} + {total}");
            if (result is "MS1" or "MS2" && (raw.Contains("BOTH TEAMS") || raw.Contains("BTTS")))
            {
                if (raw.Contains("YES")) list.Add($"{result} + KG VAR");
                if (raw.Contains("NO")) list.Add($"{result} + KG YOK");
            }
        }

        return list;
    }

    private static void AddRawTotal(string raw, string prefix, HashSet<string> list)
    {
        var total = TotalToken(raw);
        if (total is not null) list.Add(prefix + total);
    }

    private static string? HtFtToken(string text, Mac mac, PulseEvent ev)
    {
        var raw = text.Trim();
        var parts = Regex.Split(raw, @"\s+-\s+").Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();
        if (parts.Length >= 2)
        {
            var a = SonucParcasi(parts[0], mac, ev);
            var b = SonucParcasi(parts[1], mac, ev);
            if (a is not null && b is not null) return $"{a}/{b}";
        }

        var x = N(raw).Replace("HOME", "1").Replace("DRAW", "X").Replace("AWAY", "2").Replace("-", "/").Replace(" ", "");
        var m = Regex.Match(x, @"([1X2])/([1X2])");
        return m.Success ? $"{m.Groups[1].Value}/{m.Groups[2].Value}" : null;
    }

    private static string? SonucParcasi(string s, Mac mac, PulseEvent ev)
    {
        var n = N(s);
        if (n.Contains("DRAW") || n == "X" || n.Contains("TIE")) return "X";
        if (Benzerlik(mac.EvSahibiTakim.Ad, s) >= 50 || Benzerlik(ev.Home, s) >= 50) return "1";
        if (Benzerlik(mac.DeplasmanTakim.Ad, s) >= 50 || Benzerlik(ev.Away, s) >= 50) return "2";
        return null;
    }

    private static string? ResultToken(string s)
    {
        if (s.Contains("HOME") || Regex.IsMatch(s, @"(^|\W)1(\W|$)")) return "MS1";
        if (s.Contains("AWAY") || Regex.IsMatch(s, @"(^|\W)2(\W|$)")) return "MS2";
        if (s.Contains("DRAW") || Regex.IsMatch(s, @"(^|\W)X(\W|$)")) return "MSX";
        return null;
    }

    private static string? ResultTokenWithTeams(string s, Mac mac, PulseEvent ev)
    {
        if (Benzerlik(mac.EvSahibiTakim.Ad, s) >= 50 || Benzerlik(ev.Home, s) >= 50) return "MS1";
        if (Benzerlik(mac.DeplasmanTakim.Ad, s) >= 50 || Benzerlik(ev.Away, s) >= 50) return "MS2";
        return ResultToken(s);
    }

    private static string? TotalToken(string s)
    {
        var line = ExtractLine(s);
        if (line is null) return null;
        if (s.Contains("OVER")) return $"{line} ÜST";
        if (s.Contains("UNDER")) return $"{line} ALT";
        return null;
    }

    private static string? ExtractLine(string s)
    {
        var m = Regex.Match(s.Replace(',', '.'), @"(?<!\d)(0\.5|1\.5|2\.5|3\.5|4\.5|5\.5|6\.5|7\.5|8\.5|9\.5|10\.5|11\.5|12\.5)(?!\d)");
        return m.Success ? m.Groups[1].Value : null;
    }

    private static string? ExtractAnyLine(string s)
    {
        var m = Regex.Match(s.Replace(',', '.'), @"(?<!\d)(\d{1,2}(?:\.\d{1,2})?)(?!\d)");
        if (!m.Success) return null;
        return decimal.TryParse(m.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out var d)
            ? d.ToString("0.0", CultureInfo.InvariantCulture) : null;
    }

    private static string? NormalizeLine(string line)
    {
        if (string.IsNullOrWhiteSpace(line)) return null;
        var x = line.Replace(',', '.');
        return decimal.TryParse(x, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d.ToString("0.0", CultureInfo.InvariantCulture) : null;
    }

    private static bool IsHome(string n, string raw, Mac mac, PulseEvent ev) => n is "HOME" or "1" || raw is "HOME" or "1" || Benzerlik(mac.EvSahibiTakim.Ad, n) >= 55 || Benzerlik(ev.Home, n) >= 55;
    private static bool IsAway(string n, string raw, Mac mac, PulseEvent ev) => n is "AWAY" or "2" || raw is "AWAY" or "2" || Benzerlik(mac.DeplasmanTakim.Ad, n) >= 55 || Benzerlik(ev.Away, n) >= 55;
    private static bool IsDraw(string n, string raw) => n is "DRAW" or "X" || raw is "DRAW" or "X";

    private static PulseEvent? EnIyiEvent(Mac mac, List<PulseEvent> events)
    {
        return events.Select(e =>
            {
                var home = Benzerlik(mac.EvSahibiTakim.Ad, e.Home);
                var away = Benzerlik(mac.DeplasmanTakim.Ad, e.Away);
                var tarih = TarihPuani(mac.MacTarihi, e.StartTime);
                return new { E = e, Home = home, Away = away, Tarih = tarih, Score = home + away + tarih };
            })
            // Tek takım adı tesadüfen benziyor diye yanlış event bağlamayalım; iki tarafın da eşleşmesi gerekir.
            .Where(x => x.Home >= 34 && x.Away >= 34 && x.Tarih >= -3 && x.Score >= 100)
            .OrderByDescending(x => x.Score)
            .ThenByDescending(x => x.Tarih)
            .Select(x => x.E).FirstOrDefault();
    }

    private static int TarihPuani(DateTime localMac, DateTime utcEvent)
    {
        if (utcEvent == DateTime.MinValue) return 0;
        var diff = Math.Abs((localMac - utcEvent.ToLocalTime()).TotalHours);
        if (diff <= 2) return 20;
        if (diff <= 6) return 12;
        if (diff <= 18) return 3;
        return -20;
    }

    private static int Benzerlik(string a, string b)
    {
        if (string.IsNullOrWhiteSpace(a) || string.IsNullOrWhiteSpace(b)) return 0;
        var x = NormalizeTeam(a); var y = NormalizeTeam(b);
        if (x == y) return 70;
        if (x.Contains(y) || y.Contains(x)) return 62;
        var xa = x.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var ya = y.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var ortak = xa.Intersect(ya).Count();
        return ortak == 0 ? 0 : Math.Min(58, ortak * 24 + 10);
    }

    private static string NormalizeTeam(string s)
    {
        var x = s.ToUpperInvariant().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var c in x) if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return Regex.Replace(sb.ToString().Replace("FC", " ").Replace("FK", " ").Replace("SK", " "), @"[^A-Z0-9]+", " ").Trim();
    }

    private static IEnumerable<string> LigAdaylari(Lig? lig)
    {
        if (lig is null) yield break;
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Add(List<string> list, string? x)
        {
            if (!string.IsNullOrWhiteSpace(x) && seen.Add(x.Trim())) list.Add(x.Trim());
        }

        var result = new List<string>();
        Add(result, lig.Ad);
        if (!string.IsNullOrWhiteSpace(lig.Ulke))
        {
            Add(result, $"{lig.Ulke} {lig.Ad}");
            Add(result, $"{lig.Ulke}||{lig.Ad}");
        }

        var n = N(lig.Ad);
        if (n.Contains("BELGIAN PRO LEAGUE")) Add(result, "Belgium First Division A");
        if (n.Contains("IRISH PREMIER")) Add(result, "Republic of Ireland Premier Division");
        if (n.Contains("DANISH") && n.Contains("SUPER")) Add(result, "Denmark Superliga");
        if (n.Contains("AUSTRIAN") && n.Contains("BUNDESLIGA")) Add(result, "Austria Bundesliga");
        if (n.Contains("TURK") && (n.Contains("1. LIG") || n.Contains("1 LIG"))) Add(result, "Turkey 1 Lig");

        foreach (var x in result) yield return x;
    }

    private async Task<Mac?> MacGetirAsync(int id, CancellationToken ct) => await _db.Maclar.AsNoTracking()
        .Include(x => x.EvSahibiTakim).Include(x => x.DeplasmanTakim).Include(x => x.Lig).FirstOrDefaultAsync(x => x.Id == id, ct);

    private async Task<int> GuncelOranSayisi(int id, CancellationToken ct) => await _db.BahisOranlari.CountAsync(x =>
        x.MacId == id && x.AlinmaTarihi >= DateTime.UtcNow.AddMinutes(-Math.Max(5, _opt.CacheDakika)) && x.Kaynak != null && x.Kaynak.StartsWith("PulseScore"), ct);

    private static OranSyncSonucDto Sonuc(Mac m, bool ok, int count, int req, string msg) => new()
    {
        MacId = m.Id,
        MacAdi = $"{m.EvSahibiTakim.Ad} - {m.DeplasmanTakim.Ad}",
        EslesmeBulundu = ok,
        KaydedilenOran = count,
        ApiIstekSayisi = req,
        Mesaj = msg
    };

    private static string? Str(JsonElement x, string name) => x.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.String ? p.GetString() : null;
    private static string? NumStr(JsonElement x, string name) => x.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.Number ? p.GetRawText() : null;
    private static bool Bool(JsonElement x, string name) => x.ValueKind == JsonValueKind.Object && x.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.True;
    private static int Int(JsonElement x, string name) => x.ValueKind == JsonValueKind.Object && x.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.Number && p.TryGetInt32(out var v) ? v : 0;
    private static string N(string s) => (s ?? "").Trim().ToUpperInvariant().Replace('İ', 'I').Replace('Ü', 'U');
    private static string KisaHata(string s) => string.IsNullOrWhiteSpace(s) ? "Bilinmeyen hata" : (s.Length > 260 ? s[..260] : s);

    private sealed class PulsePage
    {
        public List<PulseEvent> Events { get; init; } = new();
        public bool HasNextPage { get; init; }
        public int TotalPages { get; init; }
        public int HttpIstekSayisi { get; init; } = 1;
    }
    private sealed class PulseEvent
    {
        public string EventId { get; init; } = "";
        public string Home { get; init; } = "";
        public string Away { get; init; } = "";
        public string League { get; init; } = "";
        public DateTime StartTime { get; init; }
        public List<PulseMarket> Markets { get; init; } = new();
    }
    private sealed class PulseMarket
    {
        public string Canonical { get; init; } = "";
        public string Period { get; init; } = "";
        public string RawName { get; init; } = "";
        public string Line { get; init; } = "";
        public List<PulseSelection> Selections { get; init; } = new();
    }
    private sealed class PulseSelection
    {
        public string Name { get; init; } = "";
        public string RawName { get; init; } = "";
        public string Outcome { get; init; } = "";
        public string Line { get; init; } = "";
        public string Hint { get; init; } = "";
        public decimal Decimal { get; init; }
    }
}
