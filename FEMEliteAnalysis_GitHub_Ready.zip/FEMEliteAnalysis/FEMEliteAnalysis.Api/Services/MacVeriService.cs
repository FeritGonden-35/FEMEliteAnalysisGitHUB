using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class MacVeriService : IMacVeriService
{
    public Task<ServiceResult<List<MacDetayDto>>> BugununMaclariniGetirAsync(
        CancellationToken cancellationToken)
    {
        return Task.FromResult(
            ServiceResult<List<MacDetayDto>>.BasariliSonuc(
                new List<MacDetayDto>(),
                "Maç API entegrasyonu henüz bağlanmadı."));
    }
}
