using System.Globalization;
using System.Text.Json;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public sealed class IstatistikSyncService : IIstatistikSyncService
{
    private const string CursorAnahtari = "IstatistikSync:CursorMacId";
    private readonly FemDbContext _db;
    private readonly HttpClient _http;
    private readonly TheSportsDbOptions _options;
    private readonly ILogger<IstatistikSyncService> _logger;

    public IstatistikSyncService(
        FemDbContext db,
        HttpClient http,
        IOptions<TheSportsDbOptions> options,
        ILogger<IstatistikSyncService> logger)
    {
        _db = db;
        _http = http;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<IstatistikSyncSonuc> TamSenkronizeEtAsync(
        Func<IstatistikSyncIlerleme, Task>? ilerleme,
        CancellationToken cancellationToken)
    {
        var sonuc = new IstatistikSyncSonuc();
        var cursor = await CursorOkuAsync(cancellationToken);
        sonuc.BaslangicCursor = cursor;

        var baslangic = UcSezonBaslangici();
        var simdi = DateTime.UtcNow;
        var batch = Math.Clamp(_options.IstatistikSyncBatchBoyutu, 50, 1000);
        var bekleme = Math.Clamp(_options.IstatistikSyncBeklemeMs, 0, 5000);
        var ilerlemeAdimi = Math.Clamp(_options.IstatistikSyncIlerlemeAdimi, 50, 2000);

        // V4.2: kullanıcı işlemin nereye kadar süreceğini görebilsin.
        sonuc.ToplamHedef = await _db.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .CountAsync(x => x.Id > cursor &&
                             x.MacTarihi >= baslangic && x.MacTarihi < simdi &&
                             x.EvSahibiSkor.HasValue && x.DeplasmanSkor.HasValue &&
                             x.HariciMacId.HasValue &&
                             x.LigId.HasValue && x.Lig != null && x.Lig.AktifMi,
                        cancellationToken);

        while (!cancellationToken.IsCancellationRequested)
        {
            var maclar = await _db.Maclar
                .AsNoTracking()
                .Include(x => x.Lig)
                .Where(x => x.Id > cursor &&
                            x.MacTarihi >= baslangic && x.MacTarihi < simdi &&
                            x.EvSahibiSkor.HasValue && x.DeplasmanSkor.HasValue &&
                            x.HariciMacId.HasValue &&
                            x.LigId.HasValue && x.Lig != null && x.Lig.AktifMi)
                .OrderBy(x => x.Id)
                .Take(batch)
                .Select(x => new SyncMac
                {
                    Id = x.Id,
                    HariciMacId = x.HariciMacId!.Value,
                    EvTakimId = x.EvSahibiTakimId,
                    DepTakimId = x.DeplasmanTakimId
                })
                .ToListAsync(cancellationToken);

            if (maclar.Count == 0) break;

            foreach (var mac in maclar)
            {
                cancellationToken.ThrowIfCancellationRequested();
                cursor = mac.Id;
                sonuc.KontrolEdilen++;

                var mevcut = await _db.MacIstatistikleri
                    .AsNoTracking()
                    .Where(x => x.MacId == mac.Id)
                    .ToListAsync(cancellationToken);

                if (mevcut.Count >= 2 && mevcut.Any(StatDoluMu))
                {
                    sonuc.ZatenDolu++;
                }
                else
                {
                    var sourceId = SourceEventId(mac.HariciMacId);
                    if (sourceId.HasValue)
                    {
                        try
                        {
                            var stats = await StatsGetirAsync(sourceId.Value, cancellationToken);
                            if (stats is null)
                            {
                                sonuc.StatsBulunamayan++;
                            }
                            else
                            {
                                // Bozuk/eski eşleştirmelerde iki tarafın aynı TakimId'ye düşmesi,
                                // (MacId,TakimId) unique index'ini patlatabiliyordu. Böyle kaydı atla.
                                if (mac.EvTakimId <= 0 || mac.DepTakimId <= 0 || mac.EvTakimId == mac.DepTakimId)
                                {
                                    sonuc.Hata++;
                                    _logger.LogWarning(
                                        "İstatistik sync atlandı: geçersiz takım eşleşmesi. MacId={MacId} EvTakimId={EvTakimId} DepTakimId={DepTakimId} Harici={Harici}",
                                        mac.Id, mac.EvTakimId, mac.DepTakimId, mac.HariciMacId);
                                }
                                else
                                {
                                    var home = ParseTaraf(stats.Value, true);
                                    var away = ParseTaraf(stats.Value, false);

                                    await UpsertAsync(mac.Id, mac.EvTakimId, home, cancellationToken);
                                    await UpsertAsync(mac.Id, mac.DepTakimId, away, cancellationToken);
                                    await _db.SaveChangesAsync(cancellationToken);

                                    if (home.Korner.HasValue || away.Korner.HasValue) sonuc.KornerBulunan++;
                                    if (home.SariKart.HasValue || away.SariKart.HasValue || home.KirmiziKart.HasValue || away.KirmiziKart.HasValue) sonuc.KartBulunan++;
                                    if (home.Sut.HasValue || away.Sut.HasValue) sonuc.SutBulunan++;
                                }
                            }
                        }
                        catch (DbUpdateException ex)
                        {
                            sonuc.Hata++;
                            var inner = ex.InnerException?.Message ?? ex.Message;
                            _logger.LogWarning(
                                ex,
                                "İstatistik DB kayıt hatası. MacId={MacId} Harici={Harici} EvTakimId={EvTakimId} DepTakimId={DepTakimId} Inner={Inner}",
                                mac.Id, mac.HariciMacId, mac.EvTakimId, mac.DepTakimId, inner);

                            // Başarısız Added/Modified entity'ler tracker'da kalırsa bir sonraki
                            // CursorYazAsync SaveChanges'ında aynı hata tekrar edip tüm sync'i durdurur.
                            _db.ChangeTracker.Clear();
                        }
                        catch (Exception ex)
                        {
                            sonuc.Hata++;
                            _logger.LogWarning(ex, "İstatistik sync hata. MacId={MacId} Harici={Harici}", mac.Id, mac.HariciMacId);
                            _db.ChangeTracker.Clear();
                        }

                        if (bekleme > 0)
                            await Task.Delay(bekleme, cancellationToken);
                    }
                    else
                    {
                        sonuc.StatsBulunamayan++;
                    }
                }

                if (sonuc.KontrolEdilen % ilerlemeAdimi == 0)
                {
                    await CursorYazAsync(cursor, cancellationToken);
                    if (ilerleme is not null)
                    {
                        var yuzde = sonuc.ToplamHedef > 0
                            ? Math.Round(sonuc.KontrolEdilen * 100m / sonuc.ToplamHedef, 1)
                            : 100m;

                        await ilerleme(new IstatistikSyncIlerleme
                        {
                            ToplamHedef = sonuc.ToplamHedef,
                            KontrolEdilen = sonuc.KontrolEdilen,
                            KornerBulunan = sonuc.KornerBulunan,
                            KartBulunan = sonuc.KartBulunan,
                            SutBulunan = sonuc.SutBulunan,
                            StatsBulunamayan = sonuc.StatsBulunamayan,
                            ZatenDolu = sonuc.ZatenDolu,
                            Hata = sonuc.Hata,
                            CursorMacId = cursor,
                            Mesaj = $"⏳ Stats sync | {sonuc.KontrolEdilen}/{sonuc.ToplamHedef} (%{yuzde:0.0}) | 🚩 {sonuc.KornerBulunan} | 🟨 {sonuc.KartBulunan} | ⏭ {sonuc.ZatenDolu} | ❔ {sonuc.StatsBulunamayan} | ❌ {sonuc.Hata}"
                        });
                    }
                }
            }

            await CursorYazAsync(cursor, cancellationToken);
        }

        sonuc.BitisCursor = cursor;
        // V4.2: cursor sıfırlanmaz. Sonraki manuel sync yalnızca yeni eklenen/tamamlanan
        // yüksek Id'li maçlara devam eder; binlerce eski maç tekrar taranmaz.
        await CursorYazAsync(cursor, cancellationToken);
        return sonuc;
    }

    private DateTime UcSezonBaslangici()
    {
        var yillar = _options.Sezonlar
            .Select(x => x?.Trim())
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x =>
            {
                var ilk = x!.Split(new[] { '-', '/' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
                return int.TryParse(ilk, out var y) ? y : 9999;
            })
            .Where(x => x is > 2000 and < 9999)
            .ToList();

        var yil = yillar.Count > 0 ? yillar.Min() : DateTime.UtcNow.Year - 2;
        return new DateTime(yil, 7, 1, 0, 0, 0, DateTimeKind.Utc);
    }

    private static int? SourceEventId(int harici)
    {
        if (harici > 0) return harici;
        if (harici < 0 && harici % 10 == 0)
        {
            var x = Math.Abs(harici / 10);
            return x > 1000 ? x : null;
        }
        return null;
    }

    private async Task<JsonElement?> StatsGetirAsync(int eventId, CancellationToken ct)
    {
        // V4.2: 429 artık "stats yok" gibi sessizce sayılmaz.
        // Kademeli backoff ile tekrar denenir; limit devam ederse hata olarak yukarı taşınır.
        var beklemeler = new[] { 5000, 15000, 30000 };

        for (var deneme = 0; deneme <= beklemeler.Length; deneme++)
        {
            using var response = await _http.GetAsync($"lookupeventstats.php?id={eventId}", ct);

            if ((int)response.StatusCode == 429)
            {
                if (deneme >= beklemeler.Length)
                    throw new HttpRequestException($"TheSportsDB HTTP 429: event stats rate limit. EventId={eventId}");

                var ms = beklemeler[deneme];
                _logger.LogWarning("TheSportsDB 429. EventId={EventId}, {BeklemeMs}ms beklenip tekrar denenecek.", eventId, ms);
                await Task.Delay(ms, ct);
                continue;
            }

            if ((int)response.StatusCode is 401 or 403)
                throw new HttpRequestException($"TheSportsDB HTTP {(int)response.StatusCode}: yetkilendirme hatası. EventId={eventId}");

            if (!response.IsSuccessStatusCode)
                return null;

            var body = await response.Content.ReadAsStringAsync(ct);
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("eventstats", out var arr) || arr.ValueKind != JsonValueKind.Array)
                return null;

            return arr.Clone();
        }

        return null;
    }

    private static ParsedStats ParseTaraf(JsonElement arr, bool home)
    {
        var p = new ParsedStats();
        foreach (var stat in arr.EnumerateArray())
        {
            var name = GetString(stat, "strStat", "strStatistic", "name");
            if (string.IsNullOrWhiteSpace(name)) continue;
            var key = Normalize(name);
            var value = home
                ? GetDecimal(stat, "intHome", "strHome", "home")
                : GetDecimal(stat, "intAway", "strAway", "away");
            if (!value.HasValue) continue;

            var i = (int)Math.Round(value.Value);
            switch (key)
            {
                case "totalshots": case "shots": p.Sut = i; break;
                case "shotsongoal": case "shotsontarget": p.IsabetliSut = i; break;
                case "cornerkicks": case "corners": p.Korner = i; break;
                case "fouls": case "foulscommitted": p.Faul = i; break;
                case "yellowcards": p.SariKart = i; break;
                case "redcards": p.KirmiziKart = i; break;
                case "offsides": case "offside": p.Ofsayt = i; break;
                case "possession": case "ballpossession": p.TopaSahipOlma = value; break;
            }
        }
        return p;
    }

    private async Task UpsertAsync(int macId, int takimId, ParsedStats p, CancellationToken ct)
    {
        var row = await _db.MacIstatistikleri.FirstOrDefaultAsync(x => x.MacId == macId && x.TakimId == takimId, ct);
        if (row is null)
        {
            row = new MacIstatistigi { MacId = macId, TakimId = takimId };
            _db.MacIstatistikleri.Add(row);
        }

        row.Sut = p.Sut ?? row.Sut;
        row.IsabetliSut = p.IsabetliSut ?? row.IsabetliSut;
        row.Korner = p.Korner ?? row.Korner;
        row.Faul = p.Faul ?? row.Faul;
        row.SariKart = p.SariKart ?? row.SariKart;
        row.KirmiziKart = p.KirmiziKart ?? row.KirmiziKart;
        row.Ofsayt = p.Ofsayt ?? row.Ofsayt;
        row.TopaSahipOlmaYuzdesi = p.TopaSahipOlma ?? row.TopaSahipOlmaYuzdesi;
        row.KayitTarihi = DateTime.UtcNow;
    }

    private async Task<int> CursorOkuAsync(CancellationToken ct)
    {
        var ayar = await _db.Ayarlar.AsNoTracking().FirstOrDefaultAsync(x => x.Anahtar == CursorAnahtari, ct);
        return ayar is not null && int.TryParse(ayar.Deger, out var x) ? x : 0;
    }

    private async Task CursorYazAsync(int cursor, CancellationToken ct)
    {
        var ayar = await _db.Ayarlar.FirstOrDefaultAsync(x => x.Anahtar == CursorAnahtari, ct);
        if (ayar is null)
        {
            ayar = new Ayar { Anahtar = CursorAnahtari, Deger = cursor.ToString(CultureInfo.InvariantCulture), Aciklama = "3 sezon event stats senkronizasyon cursor'u" };
            _db.Ayarlar.Add(ayar);
        }
        else
        {
            ayar.Deger = cursor.ToString(CultureInfo.InvariantCulture);
            ayar.GuncellemeTarihi = DateTime.UtcNow;
        }
        try
        {
            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex)
        {
            // Önceki bir kayıt hatasından kalan tracker state'i cursor kaydını düşürmesin.
            _logger.LogWarning(ex, "İstatistik cursor kaydı ilk denemede başarısız. Cursor={Cursor} Inner={Inner}", cursor, ex.InnerException?.Message ?? ex.Message);
            _db.ChangeTracker.Clear();

            var tekrar = await _db.Ayarlar.FirstOrDefaultAsync(x => x.Anahtar == CursorAnahtari, ct);
            if (tekrar is null)
            {
                tekrar = new Ayar
                {
                    Anahtar = CursorAnahtari,
                    Deger = cursor.ToString(CultureInfo.InvariantCulture),
                    Aciklama = "3 sezon event stats senkronizasyon cursor'u"
                };
                _db.Ayarlar.Add(tekrar);
            }
            else
            {
                tekrar.Deger = cursor.ToString(CultureInfo.InvariantCulture);
                tekrar.GuncellemeTarihi = DateTime.UtcNow;
            }

            await _db.SaveChangesAsync(ct);
        }
    }

    private static bool StatDoluMu(MacIstatistigi x) =>
        x.Korner.HasValue || x.SariKart.HasValue || x.KirmiziKart.HasValue ||
        x.Sut.HasValue || x.IsabetliSut.HasValue || x.Faul.HasValue || x.Ofsayt.HasValue;

    private static string Normalize(string value) =>
        new(value.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

    private static string? GetString(JsonElement e, params string[] names)
    {
        foreach (var name in names)
            if (e.TryGetProperty(name, out var p) && p.ValueKind != JsonValueKind.Null)
                return p.ToString();
        return null;
    }

    private static decimal? GetDecimal(JsonElement e, params string[] names)
    {
        var s = GetString(e, names);
        if (string.IsNullOrWhiteSpace(s)) return null;
        s = s.Replace("%", string.Empty).Trim().Replace(',', '.');
        return decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : null;
    }

    private sealed class SyncMac
    {
        public int Id { get; init; }
        public int HariciMacId { get; init; }
        public int EvTakimId { get; init; }
        public int DepTakimId { get; init; }
    }

    private sealed class ParsedStats
    {
        public int? Sut { get; set; }
        public int? IsabetliSut { get; set; }
        public int? Korner { get; set; }
        public int? Faul { get; set; }
        public int? SariKart { get; set; }
        public int? KirmiziKart { get; set; }
        public int? Ofsayt { get; set; }
        public decimal? TopaSahipOlma { get; set; }
    }
}
