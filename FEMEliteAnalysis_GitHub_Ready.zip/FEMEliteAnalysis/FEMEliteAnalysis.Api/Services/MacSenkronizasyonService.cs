using System.Net.Http.Json;
using FEMEliteAnalysis.Api.Common.Constants;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class MacSenkronizasyonService : IMacSenkronizasyonService
{
    private readonly HttpClient _httpClient;
    private readonly FemDbContext _dbContext;
    private readonly ICacheService _cacheService;
    private readonly MacApiOptions _options;
    private readonly CacheOptions _cacheOptions;
    private readonly ILogger<MacSenkronizasyonService> _logger;

    public MacSenkronizasyonService(
        HttpClient httpClient,
        FemDbContext dbContext,
        ICacheService cacheService,
        IOptions<MacApiOptions> options,
        IOptions<CacheOptions> cacheOptions,
        ILogger<MacSenkronizasyonService> logger)
    {
        _httpClient = httpClient;
        _dbContext = dbContext;
        _cacheService = cacheService;
        _options = options.Value;
        _cacheOptions = cacheOptions.Value;
        _logger = logger;
    }

    public async Task<ServiceResult<List<MacDetayDto>>> BugunVeYariniGetirAsync(
        CancellationToken cancellationToken)
    {
        var bugun = DateOnly.FromDateTime(
            TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                DateTime.UtcNow,
                "Turkey Standard Time"));

        var bugunSonuc = await TariheGoreMaclariGetirAsync(
            bugun,
            cancellationToken);

        if (!bugunSonuc.Basarili)
            return bugunSonuc;

        var yarinSonuc = await TariheGoreMaclariGetirAsync(
            bugun.AddDays(1),
            cancellationToken);

        if (!yarinSonuc.Basarili)
            return yarinSonuc;

        var birlesik = (bugunSonuc.Veri ?? new List<MacDetayDto>())
            .Concat(yarinSonuc.Veri ?? new List<MacDetayDto>())
            .OrderBy(x => x.MacTarihi)
            .ToList();

        return ServiceResult<List<MacDetayDto>>.BasariliSonuc(
            birlesik,
            $"{birlesik.Count} maç getirildi.");
    }

    public async Task<ServiceResult<List<MacDetayDto>>> TariheGoreMaclariGetirAsync(
        DateOnly tarih,
        CancellationToken cancellationToken)
    {
        var cacheKey = CacheAnahtarlari.TarihMaclari(tarih);

        if (_cacheService.TryGet<List<MacDetayDto>>(cacheKey, out var cacheMaclari) &&
            cacheMaclari is not null)
        {
            _logger.LogInformation(
                "Maç listesi cache üzerinden döndü. Tarih: {Tarih}, Adet: {Adet}",
                tarih,
                cacheMaclari.Count);

            return ServiceResult<List<MacDetayDto>>.BasariliSonuc(
                cacheMaclari,
                "Maçlar cache üzerinden getirildi.");
        }

        var veritabaniMaclari = await VeritabanindanTariheGoreGetirAsync(
            tarih,
            cancellationToken);

        if (veritabaniMaclari.Count > 0)
        {
            CacheeYaz(cacheKey, veritabaniMaclari);

            _logger.LogInformation(
                "Maç listesi veritabanından döndü. Tarih: {Tarih}, Adet: {Adet}",
                tarih,
                veritabaniMaclari.Count);

            return ServiceResult<List<MacDetayDto>>.BasariliSonuc(
                veritabaniMaclari,
                "Maçlar veritabanından getirildi.");
        }

        if (string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            return ServiceResult<List<MacDetayDto>>.BasarisizSonuc(
                "Maç API anahtarı tanımlanmamış.");
        }

        try
        {
            using var request = new HttpRequestMessage(
                HttpMethod.Get,
                $"fixtures?date={tarih:yyyy-MM-dd}&timezone=Europe/Istanbul");

            request.Headers.TryAddWithoutValidation(
                "x-apisports-key",
                _options.ApiKey);

            using var response = await _httpClient.SendAsync(
                request,
                cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                var hata = await response.Content.ReadAsStringAsync(
                    cancellationToken);

                _logger.LogWarning(
                    "Maç API isteği başarısız. Status: {Status}, Body: {Body}",
                    response.StatusCode,
                    hata);

                return ServiceResult<List<MacDetayDto>>.BasarisizSonuc(
                    $"Maç API isteği başarısız: {(int)response.StatusCode}");
            }

            var apiResponse =
                await response.Content.ReadFromJsonAsync<ApiFootballFixtureResponse>(
                    cancellationToken: cancellationToken);

            if (apiResponse is null)
            {
                return ServiceResult<List<MacDetayDto>>.BasarisizSonuc(
                    "Maç API yanıtı okunamadı.");
            }

            foreach (var item in apiResponse.Response)
            {
                var lig = await LigGetirVeyaOlusturAsync(
                    item.League,
                    cancellationToken);

                var evSahibi = await TakimGetirVeyaOlusturAsync(
                    item.Teams.Home,
                    lig.Id,
                    item.League.Country,
                    cancellationToken);

                var deplasman = await TakimGetirVeyaOlusturAsync(
                    item.Teams.Away,
                    lig.Id,
                    item.League.Country,
                    cancellationToken);

                var mac = await _dbContext.Maclar
                    .FirstOrDefaultAsync(
                        x => x.HariciMacId == item.Fixture.Id,
                        cancellationToken);

                if (mac is null)
                {
                    mac = new Mac
                    {
                        HariciMacId = item.Fixture.Id,
                        LigId = lig.Id,
                        EvSahibiTakimId = evSahibi.Id,
                        DeplasmanTakimId = deplasman.Id,
                        OlusturmaTarihi = DateTime.UtcNow
                    };

                    _dbContext.Maclar.Add(mac);
                }

                mac.MacTarihi = item.Fixture.Date.ToUniversalTime();
                mac.Durum = item.Fixture.Status.Short
                    ?? item.Fixture.Status.Long;
                mac.EvSahibiSkor = item.Goals.Home;
                mac.DeplasmanSkor = item.Goals.Away;
                mac.IlkYariEvSahibiSkor = item.Score.Halftime.Home;
                mac.IlkYariDeplasmanSkor = item.Score.Halftime.Away;
                mac.Stadyum = item.Fixture.Venue?.Name;
                mac.Hakem = item.Fixture.Referee;
                mac.GuncellemeTarihi = DateTime.UtcNow;
            }

            await _dbContext.SaveChangesAsync(cancellationToken);

            var maclar = await VeritabanindanTariheGoreGetirAsync(
                tarih,
                cancellationToken);

            CacheeYaz(cacheKey, maclar);

            return ServiceResult<List<MacDetayDto>>.BasariliSonuc(
                maclar,
                $"{tarih:dd.MM.yyyy} için {maclar.Count} maç API'den getirildi.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Maç verileri senkronize edilirken hata oluştu. Tarih: {Tarih}",
                tarih);

            return ServiceResult<List<MacDetayDto>>.BasarisizSonuc(
                "Maç verileri alınırken beklenmeyen bir hata oluştu.");
        }
    }

    private async Task<List<MacDetayDto>> VeritabanindanTariheGoreGetirAsync(
        DateOnly tarih,
        CancellationToken cancellationToken)
    {
        var baslangicYerel = tarih.ToDateTime(TimeOnly.MinValue);
        var bitisYerel = baslangicYerel.AddDays(1);

        var baslangicUtc = TimeZoneInfo.ConvertTimeToUtc(
            baslangicYerel,
            TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time"));

        var bitisUtc = TimeZoneInfo.ConvertTimeToUtc(
            bitisYerel,
            TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time"));

        return await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x =>
                x.MacTarihi >= baslangicUtc &&
                x.MacTarihi < bitisUtc)
            .OrderBy(x => x.MacTarihi)
            .Select(x => new MacDetayDto
            {
                Id = x.Id,
                Lig = x.Lig != null ? x.Lig.Ad : "Bilinmeyen Lig",
                EvSahibi = x.EvSahibiTakim.Ad,
                Deplasman = x.DeplasmanTakim.Ad,
                MacTarihi = x.MacTarihi,
                Durum = x.Durum
            })
            .ToListAsync(cancellationToken);
    }

    private void CacheeYaz(
        string key,
        List<MacDetayDto> maclar)
    {
        var dakika = Math.Max(
            1,
            _cacheOptions.MacListesiDakika);

        _cacheService.Set(
            key,
            maclar,
            TimeSpan.FromMinutes(dakika));
    }

    private async Task<Lig> LigGetirVeyaOlusturAsync(
        ApiFootballLeague apiLig,
        CancellationToken cancellationToken)
    {
        var lig = await _dbContext.Ligler
            .FirstOrDefaultAsync(
                x => x.HariciLigId == apiLig.Id &&
                     x.Sezon == apiLig.Season.ToString(),
                cancellationToken);

        if (lig is not null)
            return lig;

        lig = new Lig
        {
            HariciLigId = apiLig.Id,
            Ad = apiLig.Name,
            Ulke = apiLig.Country,
            Sezon = apiLig.Season.ToString(),
            LogoUrl = apiLig.Logo,
            AktifMi = true
        };

        _dbContext.Ligler.Add(lig);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return lig;
    }

    private async Task<Takim> TakimGetirVeyaOlusturAsync(
        ApiFootballTeam apiTakim,
        int ligId,
        string? ulke,
        CancellationToken cancellationToken)
    {
        var takim = await _dbContext.Takimlar
            .FirstOrDefaultAsync(
                x => x.HariciTakimId == apiTakim.Id,
                cancellationToken);

        if (takim is null)
        {
            takim = new Takim
            {
                HariciTakimId = apiTakim.Id,
                LigId = ligId,
                Ad = apiTakim.Name,
                Ulke = ulke,
                LogoUrl = apiTakim.Logo,
                AktifMi = true
            };

            _dbContext.Takimlar.Add(takim);
            await _dbContext.SaveChangesAsync(cancellationToken);
        }
        else
        {
            takim.Ad = apiTakim.Name;
            takim.LogoUrl = apiTakim.Logo;
            takim.Ulke = ulke;
            takim.LigId = ligId;
        }

        return takim;
    }
}
