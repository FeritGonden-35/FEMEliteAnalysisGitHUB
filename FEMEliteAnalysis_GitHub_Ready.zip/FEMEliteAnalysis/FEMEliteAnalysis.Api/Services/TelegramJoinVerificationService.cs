using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Telegram.Bot;
using Telegram.Bot.Requests;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace FEMEliteAnalysis.Api.Services;

public class TelegramJoinVerificationService
{
    private readonly FemDbContext _db;
    private readonly TelegramJoinVerificationOptions _options;
    private readonly TelegramOptions _telegramOptions;
    private readonly ILogger<TelegramJoinVerificationService> _logger;

    public TelegramJoinVerificationService(
        FemDbContext db,
        IOptions<TelegramJoinVerificationOptions> options,
        IOptions<TelegramOptions> telegramOptions,
        ILogger<TelegramJoinVerificationService> logger)
    {
        _db = db;
        _options = options.Value;
        _telegramOptions = telegramOptions.Value;
        _logger = logger;
    }


    public async Task<bool> HandleStartAsync(
        ITelegramBotClient botClient,
        Message message,
        string startParameter,
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif || message.Chat.Type != Telegram.Bot.Types.Enums.ChatType.Private || message.From is null)
            return false;

        if (!string.Equals(startParameter, "katilim", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(startParameter, "join", StringComparison.OrdinalIgnoreCase))
            return false;

        var groupId = _options.FreeGroupId ?? _telegramOptions.FreeChannelId;
        if (!groupId.HasValue || groupId.Value == 0)
        {
            await botClient.SendMessage(message.Chat.Id,
                "⚠️ Katılım grubu henüz yapılandırılmamış. Lütfen yöneticiyle iletişime geç.",
                cancellationToken: cancellationToken);
            return true;
        }

        var now = DateTime.UtcNow;
        var existing = await _db.TelegramJoinVerifications
            .OrderByDescending(x => x.Id)
            .FirstOrDefaultAsync(x =>
                x.TelegramUserId == message.From.Id &&
                x.GroupChatId == groupId.Value &&
                x.Status != TelegramJoinVerificationStatus.Approved &&
                x.Status != TelegramJoinVerificationStatus.Rejected,
                cancellationToken);

        if (existing is null)
        {
            existing = new TelegramJoinVerification
            {
                TelegramUserId = message.From.Id,
                UserChatId = message.Chat.Id,
                Username = message.From.Username,
                FirstName = message.From.FirstName,
                LastName = message.From.LastName,
                GroupChatId = groupId.Value,
                Status = TelegramJoinVerificationStatus.AwaitingFirstName,
                RequestedAt = now,
                CreatedAt = now
            };
            _db.TelegramJoinVerifications.Add(existing);
        }
        else
        {
            existing.UserChatId = message.Chat.Id;
            existing.Username = message.From.Username;
            existing.FirstName = message.From.FirstName;
            existing.LastName = message.From.LastName;
            existing.RequestedAt = now;
            existing.Status = TelegramJoinVerificationStatus.AwaitingFirstName;
            existing.KayitAdi = null;
            existing.KayitSoyadi = null;
            existing.TelefonNumarasi = null;
            existing.ScreenshotFileId = null;
            existing.ScreenshotReceivedAt = null;
            existing.InviteLink = null;
            existing.InviteLinkExpiresAt = null;
            existing.InviteLinkCreatedAt = null;
            existing.UpdatedAt = now;
        }

        await _db.SaveChangesAsync(cancellationToken);

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: BuildWelcomeMessage(),
            cancellationToken: cancellationToken);

        _logger.LogInformation("JOIN_BOT_START VerificationId={VerificationId} UserId={UserId} Group={GroupId}", existing.Id, message.From.Id, groupId.Value);
        return true;
    }

    public async Task<bool> HandleJoinRequestAsync(
        ITelegramBotClient botClient,
        ChatJoinRequest request,
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif)
            return false;

        var targetGroupId = _options.FreeGroupId ?? _telegramOptions.FreeChannelId;
        if (targetGroupId.HasValue && request.Chat.Id != targetGroupId.Value)
            return false;

        var now = DateTime.UtcNow;
        var existing = await _db.TelegramJoinVerifications
            .OrderByDescending(x => x.Id)
            .FirstOrDefaultAsync(x =>
                x.TelegramUserId == request.From.Id &&
                x.GroupChatId == request.Chat.Id &&
                x.Status != TelegramJoinVerificationStatus.Approved &&
                x.Status != TelegramJoinVerificationStatus.Rejected,
                cancellationToken);

        if (existing is null)
        {
            existing = new TelegramJoinVerification
            {
                TelegramUserId = request.From.Id,
                UserChatId = request.UserChatId,
                Username = request.From.Username,
                FirstName = request.From.FirstName,
                LastName = request.From.LastName,
                GroupChatId = request.Chat.Id,
                Status = TelegramJoinVerificationStatus.AwaitingFirstName,
                RequestedAt = now,
                CreatedAt = now
            };
            _db.TelegramJoinVerifications.Add(existing);
        }
        else
        {
            existing.UserChatId = request.UserChatId;
            existing.Username = request.From.Username;
            existing.FirstName = request.From.FirstName;
            existing.LastName = request.From.LastName;
            existing.RequestedAt = now;
            existing.Status = TelegramJoinVerificationStatus.AwaitingFirstName;
            existing.KayitAdi = null;
            existing.KayitSoyadi = null;
            existing.TelefonNumarasi = null;
            existing.ScreenshotFileId = null;
            existing.ScreenshotReceivedAt = null;
            existing.UpdatedAt = now;
        }

        await _db.SaveChangesAsync(cancellationToken);

        _logger.LogInformation("JOIN_REQUEST_RECEIVED VerificationId={VerificationId} UserId={UserId} Group={GroupId}", existing.Id, request.From.Id, request.Chat.Id);

        try
        {
            await botClient.SendMessage(
                chatId: request.UserChatId,
                text: "👋 FEM Elite katılım doğrulaması için bot sohbetini başlatman gerekiyor.\n\nBot profilini açıp /start katilim yaz. Ardından ad, soyad, telefon ve 303037 bayi doğrulamasını tamamlayabilirsin.",
                cancellationToken: cancellationToken);

            _logger.LogInformation("JOIN_DM_SENT VerificationId={VerificationId} UserId={UserId}", existing.Id, request.From.Id);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "JOIN_DM_FAILED VerificationId={VerificationId} UserId={UserId}", existing.Id, request.From.Id);
            await NotifyAdminDmFailedAsync(botClient, existing, cancellationToken);
        }

        return true;
    }

    public async Task<bool> HandleProfileInputAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif || message.Chat.Type != Telegram.Bot.Types.Enums.ChatType.Private || message.From is null)
            return false;

        var verification = await _db.TelegramJoinVerifications
            .OrderByDescending(x => x.Id)
            .FirstOrDefaultAsync(x =>
                x.TelegramUserId == message.From.Id &&
                (x.Status == TelegramJoinVerificationStatus.AwaitingFirstName ||
                 x.Status == TelegramJoinVerificationStatus.AwaitingLastName ||
                 x.Status == TelegramJoinVerificationStatus.AwaitingPhone),
                cancellationToken);

        if (verification is null)
            return false;

        var text = (message.Text ?? string.Empty).Trim();
        if (text.StartsWith("/", StringComparison.Ordinal))
            return false;

        if (verification.Status == TelegramJoinVerificationStatus.AwaitingFirstName)
        {
            if (!IsValidNamePart(text))
            {
                await botClient.SendMessage(message.Chat.Id,
                    "👤 Lütfen sadece adını yaz.\n\nÖrnek: Ferit",
                    cancellationToken: cancellationToken);
                return true;
            }

            verification.KayitAdi = NormalizeName(text);
            verification.Status = TelegramJoinVerificationStatus.AwaitingLastName;
            verification.UpdatedAt = DateTime.UtcNow;
            await _db.SaveChangesAsync(cancellationToken);

            await botClient.SendMessage(message.Chat.Id,
                "✅ Adını kaydettim.\n\n👤 Şimdi lütfen soyadını yaz.\n\nÖrnek: Gönden",
                cancellationToken: cancellationToken);
            return true;
        }

        if (verification.Status == TelegramJoinVerificationStatus.AwaitingLastName)
        {
            if (!IsValidNamePart(text))
            {
                await botClient.SendMessage(message.Chat.Id,
                    "👤 Lütfen sadece soyadını yaz.\n\nÖrnek: Gönden",
                    cancellationToken: cancellationToken);
                return true;
            }

            verification.KayitSoyadi = NormalizeName(text);
            verification.Status = TelegramJoinVerificationStatus.AwaitingPhone;
            verification.UpdatedAt = DateTime.UtcNow;
            await _db.SaveChangesAsync(cancellationToken);

            await botClient.SendMessage(message.Chat.Id,
                "✅ Soyadını da kaydettim.\n\n📱 Son olarak telefon numaranı gönder.\n\nAşağıdaki butondan Telegram numaranı paylaşabilir veya numaranı mesaj olarak yazabilirsin.",
                replyMarkup: BuildPhoneKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (verification.Status == TelegramJoinVerificationStatus.AwaitingPhone)
        {
            string? phone = null;

            if (message.Contact is not null)
            {
                // Başkasının contact bilgisinin yanlışlıkla kullanılmasını engelle.
                if (message.Contact.UserId.HasValue && message.Contact.UserId.Value != message.From.Id)
                {
                    await botClient.SendMessage(message.Chat.Id,
                        "⚠️ Lütfen kendi telefon numaranı paylaş.",
                        cancellationToken: cancellationToken);
                    return true;
                }
                phone = NormalizePhone(message.Contact.PhoneNumber);
            }
            else if (!string.IsNullOrWhiteSpace(text))
            {
                phone = NormalizePhone(text);
            }

            if (string.IsNullOrWhiteSpace(phone) || phone.Length < 10 || phone.Length > 15)
            {
                await botClient.SendMessage(message.Chat.Id,
                    "📱 Telefon numarası geçerli görünmüyor.\n\nÖrnek: 05XXXXXXXXX veya +905XXXXXXXXX\nYa da aşağıdaki butondan kendi numaranı paylaş.",
                    replyMarkup: BuildPhoneKeyboard(),
                    cancellationToken: cancellationToken);
                return true;
            }

            verification.TelefonNumarasi = phone;
            verification.Status = TelegramJoinVerificationStatus.PendingVerification;
            verification.UpdatedAt = DateTime.UtcNow;
            await _db.SaveChangesAsync(cancellationToken);

            await botClient.SendMessage(message.Chat.Id,
                $"✅ KAYIT BİLGİLERİN ALINDI\n\n👤 Ad Soyad: {verification.KayitAdi} {verification.KayitSoyadi}\n📱 Telefon: {FormatPhoneForUser(phone)}\n\n🔐 Şimdi son adım:\nİddaa.com hesabının {_options.BayiKodu} kodlu bayiye bağlı olduğunu gösteren ekran görüntüsünü bu sohbete gönder. 📸\n\n🔒 Güvenliğin için ekran görüntüsünde şifre, kart bilgisi veya gereksiz kişisel bilgileri paylaşma.",
                replyMarkup: new ReplyKeyboardRemove(),
                cancellationToken: cancellationToken);

            _logger.LogInformation("JOIN_PROFILE_COMPLETED VerificationId={VerificationId} UserId={UserId}", verification.Id, verification.TelegramUserId);
            return true;
        }

        return false;
    }

    public async Task<bool> HandleScreenshotAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif || message.Chat.Type != Telegram.Bot.Types.Enums.ChatType.Private || message.From is null)
            return false;

        if (message.Photo is null || message.Photo.Length == 0)
            return false;

        var verification = await _db.TelegramJoinVerifications
            .OrderByDescending(x => x.Id)
            .FirstOrDefaultAsync(x =>
                x.TelegramUserId == message.From.Id &&
                (x.Status == TelegramJoinVerificationStatus.PendingVerification ||
                 x.Status == TelegramJoinVerificationStatus.ScreenshotReceived),
                cancellationToken);

        if (verification is null)
            return false;

        var largestPhoto = message.Photo.OrderByDescending(x => x.FileSize ?? 0).FirstOrDefault() ?? message.Photo[^1];
        verification.ScreenshotFileId = largestPhoto.FileId;
        verification.ScreenshotReceivedAt = DateTime.UtcNow;
        verification.Status = TelegramJoinVerificationStatus.ScreenshotReceived;
        verification.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);

        var adminChatId = GetVerificationAdminChatId();
        if (adminChatId is null)
        {
            _logger.LogWarning("SCREENSHOT_RECEIVED fakat VerificationAdminChatId/AdminUserId tanımlı değil. VerificationId={VerificationId}", verification.Id);
            await botClient.SendMessage(
                message.Chat.Id,
                "✅ Ekran görüntün alındı. Yönetici kontrolü bekleniyor.",
                cancellationToken: cancellationToken);
            return true;
        }

        try
        {
            await botClient.CopyMessage(
                chatId: adminChatId.Value,
                fromChatId: message.Chat.Id,
                messageId: message.MessageId,
                cancellationToken: cancellationToken);

            await botClient.SendMessage(
                chatId: adminChatId.Value,
                text: BuildAdminReviewMessage(verification),
                replyMarkup: BuildAdminKeyboard(verification.Id),
                cancellationToken: cancellationToken);

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "✅ Ekran görüntün alındı. Yönetici kontrolünden sonra onaylanırsa sana özel tek kullanımlık grup davet linkin gönderilecek.",
                cancellationToken: cancellationToken);

            _logger.LogInformation("SCREENSHOT_RECEIVED VerificationId={VerificationId} UserId={UserId}", verification.Id, verification.TelegramUserId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Doğrulama görseli admin'e gönderilemedi. VerificationId={VerificationId}", verification.Id);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "⚠️ Görselin alındı ancak yöneticiye iletilirken geçici bir hata oluştu. Lütfen biraz sonra tekrar gönder.",
                cancellationToken: cancellationToken);
        }

        return true;
    }

    public async Task<string> ApproveAsync(
        ITelegramBotClient botClient,
        long verificationId,
        long adminId,
        CancellationToken cancellationToken)
    {
        var verification = await _db.TelegramJoinVerifications.FirstOrDefaultAsync(x => x.Id == verificationId, cancellationToken);
        if (verification is null)
            return "Doğrulama kaydı bulunamadı.";

        if (verification.Status == TelegramJoinVerificationStatus.Approved)
            return "Bu kullanıcı zaten onaylanmış.";
        if (verification.Status == TelegramJoinVerificationStatus.Rejected)
            return "Bu doğrulama daha önce reddedilmiş.";

        // Eski join-request akışından kalan bekleyen bir istek varsa kapat.
        try
        {
            await botClient.DeclineChatJoinRequest(
                chatId: verification.GroupChatId,
                userId: verification.TelegramUserId,
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Onay öncesi bekleyen join request yok veya kapatılamadı. VerificationId={VerificationId}", verification.Id);
        }

        var invite = await CreatePersonalInviteLinkAsync(botClient, verification, cancellationToken);

        verification.Status = TelegramJoinVerificationStatus.Approved;
        verification.ReviewedAt = DateTime.UtcNow;
        verification.ReviewedByAdminId = adminId;
        verification.InviteLink = invite.InviteLink;
        verification.InviteLinkCreatedAt = DateTime.UtcNow;
        verification.InviteLinkExpiresAt = DateTime.UtcNow.AddMinutes(Math.Max(5, _options.DavetLinkiGecerlilikDakikasi));
        verification.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);

        var keyboard = new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithUrl("🔓 GRUBA KATIL", invite.InviteLink) }
        });

        try
        {
            await botClient.SendMessage(
                chatId: verification.UserChatId,
                text: $"✅ DOĞRULAMAN ONAYLANDI!\n\n{_options.BayiKodu} bayi doğrulaman tamamlandı. 💚\n\nSana özel grup davet bağlantın hazır. Link {_options.DavetLinkiGecerlilikDakikasi} dakika geçerlidir ve yalnızca {_options.DavetLinkiKullanimLimiti} kişi tarafından kullanılabilir.\n\nBağlantıyı paylaşma; aşağıdaki butondan gruba katıl.",
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Kişisel davet linki kullanıcıya gönderilemedi. VerificationId={VerificationId}", verification.Id);
        }

        _logger.LogInformation("VERIFICATION_APPROVED_INVITE_CREATED VerificationId={VerificationId} UserId={UserId} AdminId={AdminId}", verification.Id, verification.TelegramUserId, adminId);
        return $"✅ ONAYLANDI + DAVET LİNKİ OLUŞTURULDU\n\n👤 {verification.KayitAdi} {verification.KayitSoyadi}\n📱 {verification.TelefonNumarasi ?? "-"}\n🔗 Telegram: {FormatUser(verification)}\n🔢 Bayi: {_options.BayiKodu}\n⏱ Link: {_options.DavetLinkiGecerlilikDakikasi} dk / {_options.DavetLinkiKullanimLimiti} kullanım\n👮 Onaylayan: {adminId}";
    }

    public async Task<string> RejectAsync(
        ITelegramBotClient botClient,
        long verificationId,
        long adminId,
        CancellationToken cancellationToken)
    {
        var verification = await _db.TelegramJoinVerifications.FirstOrDefaultAsync(x => x.Id == verificationId, cancellationToken);
        if (verification is null)
            return "Doğrulama kaydı bulunamadı.";

        if (verification.Status == TelegramJoinVerificationStatus.Approved)
            return "Bu kullanıcı daha önce onaylanmış.";
        if (verification.Status == TelegramJoinVerificationStatus.Rejected)
            return "Bu kullanıcı zaten reddedilmiş.";

        // Bot-first akışında join request bulunmayabilir. Varsa kapat, yoksa devam et.
        try
        {
            await botClient.DeclineChatJoinRequest(
                chatId: verification.GroupChatId,
                userId: verification.TelegramUserId,
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Reddedilecek bekleyen join request bulunamadı. VerificationId={VerificationId}", verification.Id);
        }

        verification.Status = TelegramJoinVerificationStatus.Rejected;
        verification.ReviewedAt = DateTime.UtcNow;
        verification.ReviewedByAdminId = adminId;
        verification.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);

        await SafeSendUserAsync(botClient, verification.UserChatId,
            $"❌ Doğrulama tamamlanamadı.\n\nGönderdiğin ekran görüntüsünde {_options.BayiKodu} bayi doğrulaması net olarak görülemiyor.\n\nİddaa.com hesabının {_options.BayiKodu} kodlu bayiye bağlı olduğunu kontrol edip yeniden başvurabilirsin.",
            cancellationToken);

        _logger.LogInformation("VERIFICATION_REJECTED VerificationId={VerificationId} UserId={UserId} AdminId={AdminId}", verification.Id, verification.TelegramUserId, adminId);
        return $"❌ REDDEDİLDİ\n\n👤 {verification.KayitAdi} {verification.KayitSoyadi}\n📱 {verification.TelefonNumarasi ?? "-"}\n🔗 Telegram: {FormatUser(verification)}\n🔢 Bayi: {_options.BayiKodu}\n👮 İşlem yapan: {adminId}";
    }

    public async Task<string> RequestNewScreenshotAsync(
        ITelegramBotClient botClient,
        long verificationId,
        long adminId,
        CancellationToken cancellationToken)
    {
        var verification = await _db.TelegramJoinVerifications.FirstOrDefaultAsync(x => x.Id == verificationId, cancellationToken);
        if (verification is null)
            return "Doğrulama kaydı bulunamadı.";

        if (verification.Status == TelegramJoinVerificationStatus.Approved || verification.Status == TelegramJoinVerificationStatus.Rejected)
            return "Bu doğrulama daha önce sonuçlandırılmış.";

        verification.Status = TelegramJoinVerificationStatus.PendingVerification;
        verification.ScreenshotFileId = null;
        verification.UpdatedAt = DateTime.UtcNow;
        verification.ReviewedByAdminId = adminId;
        await _db.SaveChangesAsync(cancellationToken);

        await SafeSendUserAsync(botClient, verification.UserChatId,
            $"📸 Gönderdiğin görüntü doğrulama için yeterince net değil.\n\nLütfen {_options.BayiKodu} bayi kodunun açık şekilde göründüğü yeni bir ekran görüntüsü gönder.\n\n🔒 Şifre, kart bilgisi veya gereksiz kişisel bilgileri paylaşma.",
            cancellationToken);

        _logger.LogInformation("VERIFICATION_RESUBMIT_REQUESTED VerificationId={VerificationId} UserId={UserId} AdminId={AdminId}", verification.Id, verification.TelegramUserId, adminId);
        return $"🔄 YENİ EKRAN GÖRÜNTÜSÜ İSTENDİ\n\n👤 {FormatUser(verification)}\n🔢 Bayi: {_options.BayiKodu}";
    }


    private async Task<ChatInviteLink> CreatePersonalInviteLinkAsync(
        ITelegramBotClient botClient,
        TelegramJoinVerification verification,
        CancellationToken cancellationToken)
    {
        var minutes = Math.Max(5, _options.DavetLinkiGecerlilikDakikasi);
        var memberLimit = Math.Clamp(_options.DavetLinkiKullanimLimiti, 1, 10);
        var expiresAt = DateTime.UtcNow.AddMinutes(minutes);
        var linkName = $"FEM-{verification.Id}-{verification.TelegramUserId}";
        if (linkName.Length > 32)
            linkName = linkName[..32];

        var invite = await botClient.SendRequest(
            new CreateChatInviteLinkRequest
            {
                ChatId = verification.GroupChatId,
                Name = linkName,
                ExpireDate = expiresAt,
                MemberLimit = memberLimit,
                CreatesJoinRequest = false
            },
            cancellationToken);

        return invite;
    }

    private string BuildWelcomeMessage() =>
        $"👋 FEM ELITE'E HOŞ GELDİN! 💚\n\n" +
        "Grubumuza katılım için ayrıca üyelik ücreti yoktur.\n\n" +
        "Katılım doğrulaması için senden 3 kısa bilgi alacağız:\n" +
        "👤 Ad\n👤 Soyad\n📱 Telefon numarası\n\n" +
        $"Ardından İddaa.com hesabının {_options.BayiKodu} kodlu bayiye bağlı olduğunu gösteren ekran görüntüsünü isteyeceğiz.\n\n" +
        "Doğrulama onaylanınca sana özel, süreli ve tek kullanımlık grup davet bağlantısı gönderilecek.\n\n" +
        "➡️ İlk olarak lütfen sadece ADINI yaz.\n\n" +
        "🔒 Bilgilerin yalnızca FEM Elite üyelik/bayi doğrulama kaydı için kullanılacaktır.\n" +
        "⚠️ Bahis finansal risk içerir. Kesin kazanç garantisi verilmez.";

    private string BuildAdminReviewMessage(TelegramJoinVerification verification) =>
        $"🔐 YENİ FEM KATILIM DOĞRULAMASI\n\n" +
        $"👤 Kullanıcı: {FormatUser(verification)}\n" +
        $"🔗 Username: {(string.IsNullOrWhiteSpace(verification.Username) ? "-" : "@" + verification.Username)}\n" +
        $"🆔 Telegram ID: {verification.TelegramUserId}\n\n" +
        $"📝 Kayıt Ad Soyad: {verification.KayitAdi} {verification.KayitSoyadi}\n" +
        $"📱 Telefon: {verification.TelefonNumarasi ?? "-"}\n\n" +
        $"🏦 Gerekli bayi: {_options.BayiKodu}\n" +
        $"📅 Talep: {verification.RequestedAt.ToLocalTime():dd.MM.yyyy HH:mm}\n" +
        $"🧾 Doğrulama ID: {verification.Id}\n\n" +
        "📸 Kullanıcının gönderdiği doğrulama görseli bir önceki mesajda.\n\n✅ Onay verirsen bot kullanıcıya süreli ve tek kullanımlık özel grup davet linki oluşturacak.";

    private static ReplyKeyboardMarkup BuildPhoneKeyboard() => new(new[]
    {
        new[] { new KeyboardButton("📱 Telefonumu Paylaş") { RequestContact = true } }
    })
    {
        ResizeKeyboard = true,
        OneTimeKeyboard = true
    };

    private static bool IsValidNamePart(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length < 2 || value.Length > 50)
            return false;
        return value.All(c => char.IsLetter(c) || c == ' ' || c == '-' || c == '\'');
    }

    private static string NormalizeName(string value) =>
        string.Join(' ', value.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            .Trim();

    private static string NormalizePhone(string value)
    {
        var hasPlus = value.TrimStart().StartsWith('+');
        var digits = new string(value.Where(char.IsDigit).ToArray());
        if (digits.StartsWith("00"))
        {
            digits = digits[2..];
            hasPlus = true;
        }
        return hasPlus ? "+" + digits : digits;
    }

    private static string FormatPhoneForUser(string phone)
    {
        if (phone.Length <= 7) return phone;
        var visible = phone[^4..];
        return new string('*', Math.Max(0, phone.Length - 4)) + visible;
    }

    private static InlineKeyboardMarkup BuildAdminKeyboard(long verificationId) => new(new[]
    {
        new[]
        {
            InlineKeyboardButton.WithCallbackData("✅ ONAYLA", $"joinapprove:{verificationId}"),
            InlineKeyboardButton.WithCallbackData("🔄 YENİDEN SS", $"joinresubmit:{verificationId}")
        },
        new[]
        {
            InlineKeyboardButton.WithCallbackData("❌ REDDET", $"joinreject:{verificationId}")
        }
    });

    private long? GetVerificationAdminChatId()
    {
        if (_options.VerificationAdminChatId.HasValue && _options.VerificationAdminChatId.Value != 0)
            return _options.VerificationAdminChatId.Value;
        if (_telegramOptions.AdminUserId != 0)
            return _telegramOptions.AdminUserId;
        var fallbackAdminId = _telegramOptions.AdminUserIds.FirstOrDefault();
        return fallbackAdminId != 0 ? fallbackAdminId : null;
    }

    private async Task NotifyAdminDmFailedAsync(ITelegramBotClient botClient, TelegramJoinVerification verification, CancellationToken cancellationToken)
    {
        var adminChatId = GetVerificationAdminChatId();
        if (!adminChatId.HasValue)
            return;
        try
        {
            await botClient.SendMessage(
                adminChatId.Value,
                $"⚠️ Katılım isteği geldi ancak otomatik DM gönderilemedi.\n\n👤 {FormatUser(verification)}\n🆔 {verification.TelegramUserId}\n🧾 Doğrulama ID: {verification.Id}",
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Admin'e DM hata bildirimi gönderilemedi. VerificationId={VerificationId}", verification.Id);
        }
    }

    private async Task SafeSendUserAsync(ITelegramBotClient botClient, long chatId, string text, CancellationToken cancellationToken)
    {
        try
        {
            await botClient.SendMessage(chatId, text, cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Kullanıcıya doğrulama sonucu gönderilemedi. ChatId={ChatId}", chatId);
        }
    }

    private static string FormatUser(TelegramJoinVerification verification)
    {
        var fullName = $"{verification.FirstName} {verification.LastName}".Trim();
        return string.IsNullOrWhiteSpace(fullName)
            ? (!string.IsNullOrWhiteSpace(verification.Username) ? "@" + verification.Username : verification.TelegramUserId.ToString())
            : fullName;
    }
}
