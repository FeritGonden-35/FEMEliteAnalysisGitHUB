using System.Net.Http.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class TakimGecmisSenkronizasyonService
    : ITakimGecmisSenkronizasyonService
{
    private readonly HttpClient _httpClient;
    private readonly FemDbContext _dbContext;
    private readonly MacApiOptions _macApiOptions;
    private readonly MacAnalizOptions _analizOptions;
    private readonly ITakimSaglayiciKimlikService _kimlikService;
    private readonly ILogger<TakimGecmisSenkronizasyonService> _logger;

    public TakimGecmisSenkronizasyonService(
        HttpClient httpClient,
        FemDbContext dbContext,
        IOptions<MacApiOptions> macApiOptions,
        IOptions<MacAnalizOptions> analizOptions,
        ITakimSaglayiciKimlikService kimlikService,
        ILogger<TakimGecmisSenkronizasyonService> logger)
    {
        _httpClient = httpClient;
        _dbContext = dbContext;
        _macApiOptions = macApiOptions.Value;
        _analizOptions = analizOptions.Value;
        _kimlikService = kimlikService;
        _logger = logger;
    }

    public Task<ServiceResult<TakimGecmisVerisiDto>> SonMaclariGetirAsync(
        int takimId,
        int adet,
        CancellationToken cancellationToken)
    {
        return TakimMaclariniGetirAsync(
            takimId,
            adet,
            sahaFiltresi: null,
            cancellationToken);
    }

    public Task<ServiceResult<TakimGecmisVerisiDto>> IcSahaMaclariniGetirAsync(
        int takimId,
        int adet,
        CancellationToken cancellationToken)
    {
        return TakimMaclariniGetirAsync(
            takimId,
            adet,
            sahaFiltresi: true,
            cancellationToken);
    }

    public Task<ServiceResult<TakimGecmisVerisiDto>> DisSahaMaclariniGetirAsync(
        int takimId,
        int adet,
        CancellationToken cancellationToken)
    {
        return TakimMaclariniGetirAsync(
            takimId,
            adet,
            sahaFiltresi: false,
            cancellationToken);
    }

    public async Task<ServiceResult<H2HOzetDto>> H2HGetirAsync(
        int takim1Id,
        int takim2Id,
        int adet,
        CancellationToken cancellationToken)
    {
        var takim1 = await TakimGetirAsync(
            takim1Id,
            cancellationToken);

        var takim2 = await TakimGetirAsync(
            takim2Id,
            cancellationToken);

        if (takim1 is null || takim2 is null)
        {
            return ServiceResult<H2HOzetDto>.BasarisizSonuc(
                "H2H için takım kaydı bulunamadı.");
        }

        var takim1HariciId = await _kimlikService.ApiFootballIdGetirAsync(
            takim1Id,
            cancellationToken);
        var takim2HariciId = await _kimlikService.ApiFootballIdGetirAsync(
            takim2Id,
            cancellationToken);

        if (!takim1HariciId.HasValue || !takim2HariciId.HasValue)
        {
            return ServiceResult<H2HOzetDto>.BasarisizSonuc(
                "Takımların API-Football takım ID bilgisi bulunamadı veya otomatik eşleştirilemedi.");
        }

        if (!ApiHazirMi())
        {
            return ServiceResult<H2HOzetDto>.BasarisizSonuc(
                "Maç API anahtarı tanımlanmamış.");
        }

        try
        {
            var endpoint =
                $"fixtures/headtohead?h2h=" +
                $"{takim1HariciId.Value}-{takim2HariciId.Value}";

            var response = await ApiGetirAsync(
                endpoint,
                cancellationToken);

            if (!response.Basarili || response.Veri is null)
            {
                return ServiceResult<H2HOzetDto>.BasarisizSonuc(
                    response.Mesaj);
            }

            var apiMaclari = TamamlanmisMaclariFiltrele(
                    response.Veri.Response)
                .Take(Sinirla(adet, 1, 20))
                .ToList();

            await MaclariKaydetAsync(
                apiMaclari,
                cancellationToken);

            var maclar = apiMaclari
                .Select(x => MacDtoOlustur(
                    x,
                    takim1HariciId.Value))
                .ToList();

            var dto = H2HOzetOlustur(
                takim1,
                takim2,
                maclar);

            return ServiceResult<H2HOzetDto>.BasariliSonuc(
                dto,
                $"{dto.ToplamMac} H2H maçı getirildi.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "H2H verileri alınırken hata oluştu. Takim1Id: {Takim1Id}, Takim2Id: {Takim2Id}",
                takim1Id,
                takim2Id);

            return ServiceResult<H2HOzetDto>.BasarisizSonuc(
                "H2H verileri alınırken beklenmeyen hata oluştu.");
        }
    }

    public async Task<ServiceResult<MacKuponVerisiDto>>
        MacKuponVerisiOlusturAsync(
            int macId,
            CancellationToken cancellationToken)
    {
        var mac = await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == macId,
                cancellationToken);

        if (mac is null)
        {
            return ServiceResult<MacKuponVerisiDto>.BasarisizSonuc(
                "Kupon verisi oluşturulacak maç bulunamadı.");
        }

        var genelAdet = Math.Max(
            5,
            _analizOptions.GenelFormMacSayisi);

        var sahaAdet = Math.Max(
            5,
            _analizOptions.IcDisSahaMacSayisi);

        var h2hAdet = Math.Max(
            3,
            _analizOptions.H2HMacSayisi);

        var evGenel = await SonMaclariGetirAsync(
            mac.EvSahibiTakimId,
            genelAdet,
            cancellationToken);

        var evIcSaha = await IcSahaMaclariniGetirAsync(
            mac.EvSahibiTakimId,
            sahaAdet,
            cancellationToken);

        var depGenel = await SonMaclariGetirAsync(
            mac.DeplasmanTakimId,
            genelAdet,
            cancellationToken);

        var depDisSaha = await DisSahaMaclariniGetirAsync(
            mac.DeplasmanTakimId,
            sahaAdet,
            cancellationToken);

        var h2h = await H2HGetirAsync(
            mac.EvSahibiTakimId,
            mac.DeplasmanTakimId,
            h2hAdet,
            cancellationToken);

        var eksikler = new List<string>();

        EksikEkle(
            eksikler,
            evGenel,
            "Ev sahibinin genel formu alınamadı.");

        EksikEkle(
            eksikler,
            evIcSaha,
            "Ev sahibinin iç saha formu alınamadı.");

        EksikEkle(
            eksikler,
            depGenel,
            "Deplasmanın genel formu alınamadı.");

        EksikEkle(
            eksikler,
            depDisSaha,
            "Deplasmanın dış saha formu alınamadı.");

        if (!h2h.Basarili)
        {
            eksikler.Add("H2H verileri alınamadı.");
        }

        var dto = new MacKuponVerisiDto
        {
            MacId = mac.Id,
            HariciMacId = mac.HariciMacId ?? 0,
            Lig = mac.Lig?.Ad ?? "Bilinmeyen Lig",
            MacTarihi = mac.MacTarihi,
            EvSahibi = mac.EvSahibiTakim.Ad,
            Deplasman = mac.DeplasmanTakim.Ad,
            EvSahibiGenelForm =
                evGenel.Veri ?? BosTakimVerisi(mac.EvSahibiTakim),
            EvSahibiIcSahaForm =
                evIcSaha.Veri ?? BosTakimVerisi(mac.EvSahibiTakim),
            DeplasmanGenelForm =
                depGenel.Veri ?? BosTakimVerisi(mac.DeplasmanTakim),
            DeplasmanDisSahaForm =
                depDisSaha.Veri ?? BosTakimVerisi(mac.DeplasmanTakim),
            H2H = h2h.Veri ?? new H2HOzetDto
            {
                Takim1Id = mac.EvSahibiTakimId,
                Takim1Adi = mac.EvSahibiTakim.Ad,
                Takim2Id = mac.DeplasmanTakimId,
                Takim2Adi = mac.DeplasmanTakim.Ad
            },
            VeriEksikleri = eksikler
        };

        dto.VeriKalitesiPuani = VeriKalitesiHesapla(dto);
        MarketVeriKaliteleriniHesapla(dto);

        return ServiceResult<MacKuponVerisiDto>.BasariliSonuc(
            dto,
            $"Kupon verisi hazırlandı. Veri kalitesi: %{dto.VeriKalitesiPuani}");
    }

    private async Task<ServiceResult<TakimGecmisVerisiDto>>
        TakimMaclariniGetirAsync(
            int takimId,
            int adet,
            bool? sahaFiltresi,
            CancellationToken cancellationToken)
    {
        var takim = await TakimGetirAsync(
            takimId,
            cancellationToken);

        if (takim is null)
        {
            return ServiceResult<TakimGecmisVerisiDto>.BasarisizSonuc(
                "Takım bulunamadı.");
        }

        var hariciTakimId = await _kimlikService.ApiFootballIdGetirAsync(
            takimId,
            cancellationToken);

        if (!hariciTakimId.HasValue)
        {
            return ServiceResult<TakimGecmisVerisiDto>.BasarisizSonuc(
                $"{takim.Ad} takımının API-Football takım ID bilgisi bulunamadı veya otomatik eşleştirilemedi.");
        }

        if (!ApiHazirMi())
        {
            return ServiceResult<TakimGecmisVerisiDto>.BasarisizSonuc(
                "Maç API anahtarı tanımlanmamış.");
        }

        try
        {
            var apiAdet = sahaFiltresi.HasValue
                ? Math.Min(Math.Max(adet * 3, 20), 50)
                : Sinirla(adet, 1, 50);

            var bugun = DateOnly.FromDateTime(
                TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
                    DateTime.UtcNow,
                    "Turkey Standard Time"));

            // Ücretsiz planda `last` parametresi kullanılamıyor.
            // Son 365 gün çekilip gerekli son maçlar uygulama içinde seçiliyor.
            var baslangic = bugun.AddDays(-365);

            var endpoint =
                $"fixtures?team={hariciTakimId.Value}" +
                $"&from={baslangic:yyyy-MM-dd}" +
                $"&to={bugun:yyyy-MM-dd}";

            var response = await ApiGetirAsync(
                endpoint,
                cancellationToken);

            if (!response.Basarili || response.Veri is null)
            {
                return ServiceResult<TakimGecmisVerisiDto>.BasarisizSonuc(
                    response.Mesaj);
            }

            var apiMaclari = TamamlanmisMaclariFiltrele(
                    response.Veri.Response)
                .Where(x =>
                    !sahaFiltresi.HasValue ||
                    (
                        sahaFiltresi.Value
                            ? x.Teams.Home.Id == hariciTakimId
                            : x.Teams.Away.Id == hariciTakimId
                    ))
                .OrderByDescending(x => x.Fixture.Date)
                .Take(Sinirla(adet, 1, 20))
                .ToList();

            await MaclariKaydetAsync(
                apiMaclari,
                cancellationToken);

            var maclar = apiMaclari
                .Select(x => MacDtoOlustur(
                    x,
                    hariciTakimId.Value))
                .ToList();

            var dto = TakimOzetiniOlustur(
                takim,
                maclar);

            return ServiceResult<TakimGecmisVerisiDto>.BasariliSonuc(
                dto,
                $"{takim.Ad} için {dto.ToplamMac} geçmiş maç getirildi.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Takım geçmişi alınırken hata oluştu. TakimId: {TakimId}",
                takimId);

            return ServiceResult<TakimGecmisVerisiDto>.BasarisizSonuc(
                "Takım geçmişi alınırken beklenmeyen hata oluştu.");
        }
    }

    private async Task<ServiceResult<ApiFootballFixtureResponse>>
        ApiGetirAsync(
            string endpoint,
            CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(
            HttpMethod.Get,
            endpoint);

        request.Headers.TryAddWithoutValidation(
            "x-apisports-key",
            _macApiOptions.ApiKey);

        using var response = await _httpClient.SendAsync(
            request,
            cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(
                cancellationToken);

            _logger.LogWarning(
                "API-Football isteği başarısız. Endpoint: {Endpoint}, Status: {Status}, Body: {Body}",
                endpoint,
                response.StatusCode,
                body);

            return ServiceResult<ApiFootballFixtureResponse>.BasarisizSonuc(
                $"Maç API isteği başarısız: {(int)response.StatusCode}");
        }

        var result =
            await response.Content.ReadFromJsonAsync<ApiFootballFixtureResponse>(
                cancellationToken: cancellationToken);

        return result is null
            ? ServiceResult<ApiFootballFixtureResponse>.BasarisizSonuc(
                "Maç API yanıtı okunamadı.")
            : ServiceResult<ApiFootballFixtureResponse>.BasariliSonuc(result);
    }

    private async Task MaclariKaydetAsync(
        IReadOnlyCollection<ApiFootballFixtureItem> apiMaclari,
        CancellationToken cancellationToken)
    {
        foreach (var item in apiMaclari)
        {
            var lig = await LigGetirVeyaOlusturAsync(
                item.League,
                cancellationToken);

            var evSahibi = await TakimGetirVeyaOlusturAsync(
                item.Teams.Home,
                lig.Id,
                item.League.Country,
                cancellationToken);

            var deplasman = await TakimGetirVeyaOlusturAsync(
                item.Teams.Away,
                lig.Id,
                item.League.Country,
                cancellationToken);

            var mac = await _dbContext.Maclar
                .FirstOrDefaultAsync(
                    x => x.HariciMacId == item.Fixture.Id,
                    cancellationToken);

            if (mac is null)
            {
                mac = new Mac
                {
                    HariciMacId = item.Fixture.Id,
                    LigId = lig.Id,
                    EvSahibiTakimId = evSahibi.Id,
                    DeplasmanTakimId = deplasman.Id,
                    OlusturmaTarihi = DateTime.UtcNow
                };

                _dbContext.Maclar.Add(mac);
            }

            mac.MacTarihi = item.Fixture.Date.ToUniversalTime();
            mac.Durum = item.Fixture.Status.Short
                ?? item.Fixture.Status.Long;
            mac.EvSahibiSkor = item.Goals.Home;
            mac.DeplasmanSkor = item.Goals.Away;
            mac.IlkYariEvSahibiSkor = item.Score.Halftime.Home;
            mac.IlkYariDeplasmanSkor = item.Score.Halftime.Away;
            mac.Stadyum = item.Fixture.Venue?.Name;
            mac.Hakem = item.Fixture.Referee;
            mac.GuncellemeTarihi = DateTime.UtcNow;
        }

        await _dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task<Takim?> TakimGetirAsync(
        int takimId,
        CancellationToken cancellationToken)
    {
        return await _dbContext.Takimlar
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.Id == takimId,
                cancellationToken);
    }

    private async Task<Lig> LigGetirVeyaOlusturAsync(
        ApiFootballLeague apiLig,
        CancellationToken cancellationToken)
    {
        var sezon = apiLig.Season.ToString();

        var lig = await _dbContext.Ligler
            .FirstOrDefaultAsync(
                x => x.HariciLigId == apiLig.Id &&
                     x.Sezon == sezon,
                cancellationToken);

        if (lig is not null)
            return lig;

        lig = new Lig
        {
            HariciLigId = apiLig.Id,
            Ad = apiLig.Name,
            Ulke = apiLig.Country,
            Sezon = sezon,
            LogoUrl = apiLig.Logo,
            AktifMi = true
        };

        _dbContext.Ligler.Add(lig);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return lig;
    }

    private async Task<Takim> TakimGetirVeyaOlusturAsync(
        ApiFootballTeam apiTakim,
        int ligId,
        string? ulke,
        CancellationToken cancellationToken)
    {
        var takim = await _dbContext.Takimlar
            .FirstOrDefaultAsync(
                x => x.HariciTakimId == apiTakim.Id,
                cancellationToken);

        if (takim is null)
        {
            takim = new Takim
            {
                HariciTakimId = apiTakim.Id,
                LigId = ligId,
                Ad = apiTakim.Name,
                Ulke = ulke,
                LogoUrl = apiTakim.Logo,
                AktifMi = true
            };

            _dbContext.Takimlar.Add(takim);
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        return takim;
    }

    private static List<ApiFootballFixtureItem>
        TamamlanmisMaclariFiltrele(
            IEnumerable<ApiFootballFixtureItem> maclar)
    {
        var tamamlananDurumlar = new[]
        {
            "FT",
            "AET",
            "PEN"
        };

        return maclar
            .Where(x =>
                tamamlananDurumlar.Contains(
                    x.Fixture.Status.Short,
                    StringComparer.OrdinalIgnoreCase) &&
                x.Goals.Home.HasValue &&
                x.Goals.Away.HasValue)
            .OrderByDescending(x => x.Fixture.Date)
            .ToList();
    }

    private static TakimGecmisMacDto MacDtoOlustur(
        ApiFootballFixtureItem item,
        int incelenenHariciTakimId)
    {
        var evGol = item.Goals.Home ?? 0;
        var depGol = item.Goals.Away ?? 0;
        var takimEvSahibiMi =
            item.Teams.Home.Id == incelenenHariciTakimId;

        var takimGol = takimEvSahibiMi ? evGol : depGol;
        var rakipGol = takimEvSahibiMi ? depGol : evGol;
        var toplamGol = evGol + depGol;

        var ilkYariToplam =
            (item.Score.Halftime.Home ?? 0) +
            (item.Score.Halftime.Away ?? 0);

        return new TakimGecmisMacDto
        {
            HariciMacId = item.Fixture.Id,
            MacTarihi = item.Fixture.Date.ToUniversalTime(),
            LigId = item.League.Id,
            LigAdi = item.League.Name,
            EvSahibiTakimId = item.Teams.Home.Id,
            EvSahibiTakim = item.Teams.Home.Name,
            DeplasmanTakimId = item.Teams.Away.Id,
            DeplasmanTakim = item.Teams.Away.Name,
            EvSahibiGol = evGol,
            DeplasmanGol = depGol,
            IlkYariEvSahibiGol = item.Score.Halftime.Home,
            IlkYariDeplasmanGol = item.Score.Halftime.Away,
            TakimEvSahibiMi = takimEvSahibiMi,
            KazandiMi = takimGol > rakipGol,
            BerabereMi = takimGol == rakipGol,
            KaybettiMi = takimGol < rakipGol,
            BirBucukUstMu = toplamGol >= 2,
            IkiBucukUstMu = toplamGol >= 3,
            UcBucukUstMu = toplamGol >= 4,
            KarsilikliGolVarMi = evGol > 0 && depGol > 0,
            GolYemedenBitirdiMi = rakipGol == 0,
            IlkYaridaGolVarMi = ilkYariToplam > 0
        };
    }

    private static TakimGecmisVerisiDto TakimOzetiniOlustur(
        Takim takim,
        List<TakimGecmisMacDto> maclar)
    {
        var toplam = maclar.Count;

        var attigiGol = maclar.Sum(x =>
            x.TakimEvSahibiMi
                ? x.EvSahibiGol
                : x.DeplasmanGol);

        var yedigiGol = maclar.Sum(x =>
            x.TakimEvSahibiMi
                ? x.DeplasmanGol
                : x.EvSahibiGol);

        return new TakimGecmisVerisiDto
        {
            TakimId = takim.Id,
            HariciTakimId = takim.HariciTakimId ?? 0,
            TakimAdi = takim.Ad,
            ToplamMac = toplam,
            Galibiyet = maclar.Count(x => x.KazandiMi),
            Beraberlik = maclar.Count(x => x.BerabereMi),
            Maglubiyet = maclar.Count(x => x.KaybettiMi),
            AttigiGol = attigiGol,
            YedigiGol = yedigiGol,
            MacBasinaGol = Ortalama(attigiGol, toplam),
            MacBasinaYenilenGol = Ortalama(yedigiGol, toplam),
            BirBucukUstYuzdesi =
                Yuzde(maclar.Count(x => x.BirBucukUstMu), toplam),
            IkiBucukUstYuzdesi =
                Yuzde(maclar.Count(x => x.IkiBucukUstMu), toplam),
            UcBucukUstYuzdesi =
                Yuzde(maclar.Count(x => x.UcBucukUstMu), toplam),
            KarsilikliGolYuzdesi =
                Yuzde(maclar.Count(x => x.KarsilikliGolVarMi), toplam),
            GolYemedenBitirmeYuzdesi =
                Yuzde(maclar.Count(x => x.GolYemedenBitirdiMi), toplam),
            IlkYariGolYuzdesi =
                Yuzde(maclar.Count(x => x.IlkYaridaGolVarMi), toplam),
            Maclar = maclar
        };
    }

    private static H2HOzetDto H2HOzetOlustur(
        Takim takim1,
        Takim takim2,
        List<TakimGecmisMacDto> maclar)
    {
        var takim1Galibiyet = 0;
        var takim2Galibiyet = 0;
        var beraberlik = 0;

        foreach (var mac in maclar)
        {
            if (mac.EvSahibiGol == mac.DeplasmanGol)
            {
                beraberlik++;
                continue;
            }

            var kazananHariciId =
                mac.EvSahibiGol > mac.DeplasmanGol
                    ? mac.EvSahibiTakimId
                    : mac.DeplasmanTakimId;

            if (kazananHariciId == takim1.HariciTakimId)
                takim1Galibiyet++;
            else if (kazananHariciId == takim2.HariciTakimId)
                takim2Galibiyet++;
        }

        var toplam = maclar.Count;
        var toplamGol = maclar.Sum(
            x => x.EvSahibiGol + x.DeplasmanGol);

        return new H2HOzetDto
        {
            Takim1Id = takim1.Id,
            Takim1Adi = takim1.Ad,
            Takim2Id = takim2.Id,
            Takim2Adi = takim2.Ad,
            ToplamMac = toplam,
            Takim1Galibiyet = takim1Galibiyet,
            Beraberlik = beraberlik,
            Takim2Galibiyet = takim2Galibiyet,
            OrtalamaToplamGol = Ortalama(toplamGol, toplam),
            BirBucukUstYuzdesi =
                Yuzde(maclar.Count(x => x.BirBucukUstMu), toplam),
            IkiBucukUstYuzdesi =
                Yuzde(maclar.Count(x => x.IkiBucukUstMu), toplam),
            UcBucukUstYuzdesi =
                Yuzde(maclar.Count(x => x.UcBucukUstMu), toplam),
            KarsilikliGolYuzdesi =
                Yuzde(maclar.Count(x => x.KarsilikliGolVarMi), toplam),
            IlkYariGolYuzdesi =
                Yuzde(maclar.Count(x => x.IlkYaridaGolVarMi), toplam),
            Maclar = maclar
        };
    }

    private int VeriKalitesiHesapla(
        MacKuponVerisiDto veri)
    {
        static decimal Oran(int mevcut, int hedef) =>
            hedef <= 0 ? 0m : Math.Min(mevcut / (decimal)hedef, 1m);

        // V4.2: genel kaliteyi H2H eksikliği yüzünden cezalandırma.
        // Ana kalite form + saha kapsamasıdır; H2H yalnızca küçük bonus sağlar.
        var puan =
            Oran(veri.EvSahibiGenelForm.ToplamMac, _analizOptions.GenelFormMacSayisi) * 30m +
            Oran(veri.DeplasmanGenelForm.ToplamMac, _analizOptions.GenelFormMacSayisi) * 30m +
            Oran(veri.EvSahibiIcSahaForm.ToplamMac, _analizOptions.IcDisSahaMacSayisi) * 17.5m +
            Oran(veri.DeplasmanDisSahaForm.ToplamMac, _analizOptions.IcDisSahaMacSayisi) * 17.5m;

        puan += veri.H2H.ToplamMac > 0
            ? Oran(veri.H2H.ToplamMac, _analizOptions.H2HMacSayisi) * 5m
            : 3m;

        return Math.Clamp((int)Math.Round(puan), 0, 100);
    }

    private void MarketVeriKaliteleriniHesapla(MacKuponVerisiDto veri)
    {
        static decimal Oran(int mevcut, int hedef) =>
            hedef <= 0 ? 0m : Math.Min(mevcut / (decimal)hedef, 1m);

        var genelHedef = _analizOptions.GenelFormMacSayisi;
        var sahaHedef = _analizOptions.IcDisSahaMacSayisi;
        var h2hHedef = _analizOptions.H2HMacSayisi;

        var temel =
            Oran(veri.EvSahibiGenelForm.ToplamMac, genelHedef) * 30m +
            Oran(veri.DeplasmanGenelForm.ToplamMac, genelHedef) * 30m +
            Oran(veri.EvSahibiIcSahaForm.ToplamMac, sahaHedef) * 20m +
            Oran(veri.DeplasmanDisSahaForm.ToplamMac, sahaHedef) * 20m;

        veri.MacSonucuVeriKalitesi = Math.Clamp((int)Math.Round(temel), 0, 100);

        // Gol ve ilk yarı marketleri temel form verisiyle güçlü biçimde çalışabilir.
        // H2H varsa küçük bir bonus sağlar; yokluğu ana marketi cezalandırmaz.
        var h2hBonus = veri.H2H.ToplamMac > 0 ? Oran(veri.H2H.ToplamMac, h2hHedef) * 5m : 2m;
        veri.GolMarketVeriKalitesi = Math.Clamp((int)Math.Round(temel * .95m + h2hBonus), 0, 100);
        veri.IlkYariVeriKalitesi = Math.Clamp((int)Math.Round(temel * .90m + h2hBonus), 0, 100);

        veri.H2HVeriKalitesi = Math.Clamp((int)Math.Round(Oran(veri.H2H.ToplamMac, h2hHedef) * 100m), 0, 100);

        // Korner/kart kalitesi yalnızca gerçekten mevcut event-stats örneklemine bağlıdır.
        // Bir tarafın verisi azsa market güveni de otomatik olarak düşer.
        var kornerOrneklem = Math.Min(veri.EvSahibiIstatistik.KornerKayitSayisi, veri.DeplasmanIstatistik.KornerKayitSayisi);
        var kartOrneklem = Math.Min(veri.EvSahibiIstatistik.KartKayitSayisi, veri.DeplasmanIstatistik.KartKayitSayisi);
        veri.KornerVeriKalitesi = Math.Clamp((int)Math.Round(Oran(kornerOrneklem, 20) * 100m), 0, 100);
        veri.KartVeriKalitesi = Math.Clamp((int)Math.Round(Oran(kartOrneklem, 20) * 100m), 0, 100);
    }

    private static int VeriAdediPuani(
        int mevcut,
        int hedef,
        int maksimumPuan)
    {
        if (hedef <= 0)
            return 0;

        var oran = Math.Min(
            mevcut / (decimal)hedef,
            1m);

        return (int)Math.Round(
            oran * maksimumPuan);
    }

    private static void EksikEkle<T>(
        List<string> eksikler,
        ServiceResult<T> sonuc,
        string mesaj)
    {
        if (!sonuc.Basarili)
            eksikler.Add(mesaj);
    }

    private static TakimGecmisVerisiDto BosTakimVerisi(
        Takim takim)
    {
        return new TakimGecmisVerisiDto
        {
            TakimId = takim.Id,
            HariciTakimId = takim.HariciTakimId ?? 0,
            TakimAdi = takim.Ad
        };
    }

    private bool ApiHazirMi()
    {
        return !string.IsNullOrWhiteSpace(
            _macApiOptions.ApiKey);
    }

    private static int Sinirla(
        int deger,
        int minimum,
        int maksimum)
    {
        return Math.Clamp(
            deger,
            minimum,
            maksimum);
    }

    private static decimal Ortalama(
        int toplam,
        int adet)
    {
        return adet == 0
            ? 0
            : Math.Round(
                toplam / (decimal)adet,
                2);
    }

    private static decimal Yuzde(
        int uygunAdet,
        int toplamAdet)
    {
        return toplamAdet == 0
            ? 0
            : Math.Round(
                uygunAdet / (decimal)toplamAdet * 100m,
                2);
    }
}
