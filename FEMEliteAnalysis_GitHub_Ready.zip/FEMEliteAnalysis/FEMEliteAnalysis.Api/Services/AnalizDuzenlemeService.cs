using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class AnalizDuzenlemeService : IAnalizDuzenlemeService
{
    private readonly FemDbContext _dbContext;
    private readonly ILogger<AnalizDuzenlemeService> _logger;

    public AnalizDuzenlemeService(
        FemDbContext dbContext,
        ILogger<AnalizDuzenlemeService> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<ServiceResult<bool>> TahminGuncelleAsync(
        int analizId,
        string tahmin,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(tahmin))
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Tahmin metni boş olamaz.");
        }

        tahmin = tahmin.Trim();

        if (tahmin.Length > 250)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Tahmin metni en fazla 250 karakter olabilir.");
        }

        var analiz = await _dbContext.Analizler
            .FirstOrDefaultAsync(
                x => x.Id == analizId,
                cancellationToken);

        if (analiz is null)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Güncellenecek analiz bulunamadı.");
        }

        if (analiz.Durum == AnalizDurumu.Yayinlandi)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Yayınlanmış analizin tahmini değiştirilemez.");
        }

        if (analiz.Durum != AnalizDurumu.Taslak)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Yalnızca taslak analizler düzenlenebilir.");
        }

        analiz.Tahmin = tahmin;

        await _dbContext.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Admin tahmini güncellendi. AnalizId: {AnalizId}, Tahmin: {Tahmin}",
            analizId,
            tahmin);

        return ServiceResult<bool>.BasariliSonuc(
            true,
            "Tahmin başarıyla güncellendi.");
    }

    public async Task<ServiceResult<bool>> AnalizMetniniGuncelleAsync(
        int analizId,
        string analizMetni,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(analizMetni))
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Analiz metni boş olamaz.");
        }

        analizMetni = analizMetni.Trim();

        if (analizMetni.Length > 8000)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Analiz metni en fazla 8000 karakter olabilir.");
        }

        var analiz = await _dbContext.Analizler
            .FirstOrDefaultAsync(
                x => x.Id == analizId,
                cancellationToken);

        if (analiz is null)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Güncellenecek analiz bulunamadı.");
        }

        if (analiz.Durum == AnalizDurumu.Yayinlandi)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Yayınlanmış analiz değiştirilemez.");
        }

        if (analiz.Durum != AnalizDurumu.Taslak)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "Yalnızca taslak analizler düzenlenebilir.");
        }

        analiz.YapayZekaAnalizi = analizMetni;

        await _dbContext.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Analiz metni güncellendi. AnalizId: {AnalizId}",
            analizId);

        return ServiceResult<bool>.BasariliSonuc(
            true,
            "Analiz metni başarıyla güncellendi.");
    }
}
