using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.Extensions.Caching.Memory;

namespace FEMEliteAnalysis.Api.Services;

public class MemoryCacheService : ICacheService
{
    private readonly IMemoryCache _memoryCache;
    private readonly ILogger<MemoryCacheService> _logger;

    public MemoryCacheService(
        IMemoryCache memoryCache,
        ILogger<MemoryCacheService> logger)
    {
        _memoryCache = memoryCache;
        _logger = logger;
    }

    public bool TryGet<T>(string key, out T? value)
    {
        return _memoryCache.TryGetValue(key, out value);
    }

    public void Set<T>(
        string key,
        T value,
        TimeSpan duration)
    {
        _memoryCache.Set(
            key,
            value,
            new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = duration
            });

        _logger.LogDebug(
            "Cache kaydı oluşturuldu. Key: {CacheKey}, Süre: {Duration}",
            key,
            duration);
    }

    public void Remove(string key)
    {
        _memoryCache.Remove(key);

        _logger.LogDebug(
            "Cache kaydı silindi. Key: {CacheKey}",
            key);
    }

    public T GetOrCreate<T>(
        string key,
        Func<T> factory,
        TimeSpan duration)
    {
        if (_memoryCache.TryGetValue(key, out T? cachedValue) &&
            cachedValue is not null)
        {
            return cachedValue;
        }

        var value = factory();

        Set(key, value, duration);

        return value;
    }

    public async Task<T> GetOrCreateAsync<T>(
        string key,
        Func<CancellationToken, Task<T>> factory,
        TimeSpan duration,
        CancellationToken cancellationToken)
    {
        if (_memoryCache.TryGetValue(key, out T? cachedValue) &&
            cachedValue is not null)
        {
            return cachedValue;
        }

        var value = await factory(cancellationToken);

        Set(key, value, duration);

        return value;
    }
}
