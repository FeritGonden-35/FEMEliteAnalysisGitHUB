using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Historical;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using FootballData;
using FootballData.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using FdLeague = FootballData.Entities.League;
using FdResult = FootballData.Entities.Result;
using FemLeague = FEMEliteAnalysis.Api.Models.Lig;

namespace FEMEliteAnalysis.Api.Services;

public class FootballDataCoUkImportService : IFootballDataCoUkImportService
{
    private static readonly SemaphoreSlim ImportLock = new(1, 1);

    private readonly FemDbContext _db;
    private readonly HistoricalDataOptions _options;
    private readonly ILogger<FootballDataCoUkImportService> _logger;

    private static readonly Dictionary<string, (string Ad, string Ulke)> LigAdlari =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["E0"] = ("Premier League", "England"),
            ["E1"] = ("Championship", "England"),
            ["E2"] = ("League One", "England"),
            ["E3"] = ("League Two", "England"),
            ["EC"] = ("National League", "England"),
            ["SC0"] = ("Scottish Premiership", "Scotland"),
            ["SC1"] = ("Scottish Championship", "Scotland"),
            ["SC2"] = ("Scottish League One", "Scotland"),
            ["SC3"] = ("Scottish League Two", "Scotland"),
            ["D1"] = ("Bundesliga", "Germany"),
            ["D2"] = ("2. Bundesliga", "Germany"),
            ["I1"] = ("Serie A", "Italy"),
            ["I2"] = ("Serie B", "Italy"),
            ["SP1"] = ("La Liga", "Spain"),
            ["SP2"] = ("Segunda Division", "Spain"),
            ["F1"] = ("Ligue 1", "France"),
            ["F2"] = ("Ligue 2", "France"),
            ["N1"] = ("Eredivisie", "Netherlands"),
            ["B1"] = ("Belgian Pro League", "Belgium"),
            ["P1"] = ("Primeira Liga", "Portugal"),
            ["T1"] = ("Super Lig", "Turkey"),
            ["G1"] = ("Super League Greece", "Greece")
        };

    public FootballDataCoUkImportService(
        FemDbContext db,
        IOptions<HistoricalDataOptions> options,
        ILogger<FootballDataCoUkImportService> logger)
    {
        _db = db;
        _options = options.Value;
        _logger = logger;
    }

    public IReadOnlyList<(string Kod, string Ad, string Ulke)> LigleriGetir()
    {
        return Leagues.GetAll()
            .Select(x =>
            {
                var bilgi = LigBilgisi(x);
                return (x.Id, bilgi.Ad, bilgi.Ulke);
            })
            .OrderBy(x => x.Ulke)
            .ThenBy(x => x.Ad)
            .ToList();
    }

    public async Task<ServiceResult<FootballDataImportResultDto>> LigSezonAktarAsync(
        string ligKodu,
        string sezonKodu,
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif)
            return ServiceResult<FootballDataImportResultDto>.BasarisizSonuc(
                "HistoricalData modülü kapalı.");

        ligKodu = ligKodu.Trim().ToUpperInvariant();
        sezonKodu = NormalizeSezonKodu(sezonKodu);

        var lig = Leagues.GetAll().FirstOrDefault(x =>
            x.Id.Equals(ligKodu, StringComparison.OrdinalIgnoreCase));
        if (lig is null)
            return ServiceResult<FootballDataImportResultDto>.BasarisizSonuc(
                $"Football-data.co.uk lig kodu bulunamadı: {ligKodu}");

        var sezon = Seasons.Get().FirstOrDefault(x =>
            x.Id.Equals(sezonKodu, StringComparison.OrdinalIgnoreCase));
        if (sezon is null)
            return ServiceResult<FootballDataImportResultDto>.BasarisizSonuc(
                $"Sezon kodu bulunamadı: {sezonKodu}. Örnek: 2526");

        if (!await ImportLock.WaitAsync(0, cancellationToken))
            return ServiceResult<FootballDataImportResultDto>.BasarisizSonuc(
                "Başka bir football-data.co.uk aktarımı zaten çalışıyor.");

        try
        {
            var sonuc = await AktarAsync(lig, sezon, cancellationToken);
            return sonuc.Basarili
                ? ServiceResult<FootballDataImportResultDto>.BasariliSonuc(sonuc, sonuc.Mesaj)
                : ServiceResult<FootballDataImportResultDto>.BasarisizSonuc(sonuc.Mesaj);
        }
        finally
        {
            ImportLock.Release();
        }
    }

    public async Task<ServiceResult<List<FootballDataImportResultDto>>> TopluAktarAsync(
        IReadOnlyCollection<string> ligKodlari,
        string sezonKodu,
        CancellationToken cancellationToken)
    {
        if (ligKodlari.Count == 0)
            return ServiceResult<List<FootballDataImportResultDto>>.BasarisizSonuc(
                "En az bir lig kodu gönderilmelidir.");

        sezonKodu = NormalizeSezonKodu(sezonKodu);
        var sezon = Seasons.Get().FirstOrDefault(x => x.Id == sezonKodu);
        if (sezon is null)
            return ServiceResult<List<FootballDataImportResultDto>>.BasarisizSonuc(
                $"Sezon kodu bulunamadı: {sezonKodu}");

        if (!await ImportLock.WaitAsync(0, cancellationToken))
            return ServiceResult<List<FootballDataImportResultDto>>.BasarisizSonuc(
                "Başka bir football-data.co.uk aktarımı zaten çalışıyor.");

        try
        {
            var ligler = Leagues.GetAll();
            var sonuclar = new List<FootballDataImportResultDto>();
            foreach (var kod in ligKodlari.Select(x => x.Trim().ToUpperInvariant()).Distinct())
            {
                cancellationToken.ThrowIfCancellationRequested();
                var lig = ligler.FirstOrDefault(x => x.Id == kod);
                if (lig is null)
                {
                    sonuclar.Add(new FootballDataImportResultDto
                    {
                        LigKodu = kod,
                        Sezon = sezonKodu,
                        BaslamaZamani = DateTime.UtcNow,
                        BitisZamani = DateTime.UtcNow,
                        Basarili = false,
                        Mesaj = "Lig kodu bulunamadı."
                    });
                    continue;
                }

                sonuclar.Add(await AktarAsync(lig, sezon, cancellationToken));
                await Task.Delay(350, cancellationToken);
            }

            var basarili = sonuclar.Count(x => x.Basarili);
            return ServiceResult<List<FootballDataImportResultDto>>.BasariliSonuc(
                sonuclar,
                $"{sonuclar.Count} lig işlendi; {basarili} başarılı.");
        }
        finally
        {
            ImportLock.Release();
        }
    }

    private async Task<FootballDataImportResultDto> AktarAsync(
        FdLeague kaynakLig,
        Season sezon,
        CancellationToken cancellationToken)
    {
        var bilgi = LigBilgisi(kaynakLig);
        var sonuc = new FootballDataImportResultDto
        {
            LigKodu = kaynakLig.Id,
            LigAdi = bilgi.Ad,
            Sezon = $"{sezon.StartYear}-{sezon.EndYear}",
            BaslamaZamani = DateTime.UtcNow
        };

        try
        {
            var kaynak = await FootballData.Results.Get(kaynakLig, sezon);
            var maclar = kaynak.Results ?? new List<FdResult>();
            sonuc.KaynaktanGelenMac = maclar.Count;

            var takimlar = await _db.Takimlar.ToListAsync(cancellationToken);
            var takimMap = takimlar
                .GroupBy(x => Normalize(x.Ad))
                .ToDictionary(x => x.Key, x => x.First());

            var ligler = await _db.Ligler.ToListAsync(cancellationToken);
            var ligMap = ligler
                .GroupBy(x => LigKey(x.Ad, x.Sezon))
                .ToDictionary(x => x.Key, x => x.First());

            var femLig = LigGetirVeyaOlustur(bilgi.Ad, bilgi.Ulke,
                sonuc.Sezon, ligMap, sonuc);

            var hazir = new List<(FdResult Kaynak, Takim Ev, Takim Dep)>();
            foreach (FdResult kaynakMac in maclar)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (kaynakMac.HomeTeam is null || kaynakMac.AwayTeam is null)
                {
                    sonuc.AtlananMac++;
                    continue;
                }

                var ev = TakimGetirVeyaOlustur(kaynakMac.HomeTeam.Name,
                    femLig, takimMap, sonuc);
                var dep = TakimGetirVeyaOlustur(kaynakMac.AwayTeam.Name,
                    femLig, takimMap, sonuc);
                hazir.Add((kaynakMac, ev, dep));
            }

            await _db.SaveChangesAsync(cancellationToken);

            if (hazir.Count == 0)
                throw new InvalidOperationException("Kaynakta işlenebilir maç bulunamadı.");

            var minTarih = hazir.Min(x => x.Kaynak.MatchDate).Date.AddDays(-1);
            var maxTarih = hazir.Max(x => x.Kaynak.MatchDate).Date.AddDays(2);
            var mevcutMaclar = await _db.Maclar
                .Include(x => x.Istatistikler)
                .Where(x => x.MacTarihi >= minTarih && x.MacTarihi <= maxTarih)
                .ToListAsync(cancellationToken);

            var macMap = mevcutMaclar
                .GroupBy(x => MacKey(x.EvSahibiTakimId, x.DeplasmanTakimId, x.MacTarihi.Date))
                .ToDictionary(x => x.Key, x => x.First());

            foreach (var item in hazir)
            {
                // Kaynak geçmiş CSV'lerde çoğunlukla yalnızca tarih bulunur.
                // UTC dönüşümünde günün geriye kaymaması için öğlen UTC saklıyoruz.
                var tarih = DateTime.SpecifyKind(
                    item.Kaynak.MatchDate.Date.AddHours(12),
                    DateTimeKind.Utc);
                var key = MacKey(item.Ev.Id, item.Dep.Id, tarih.Date);
                var yeniMi = !macMap.TryGetValue(key, out var mac);

                if (yeniMi)
                {
                    mac = new Mac
                    {
                        HariciMacId = null,
                        LigId = femLig.Id,
                        EvSahibiTakimId = item.Ev.Id,
                        DeplasmanTakimId = item.Dep.Id,
                        MacTarihi = tarih,
                        OlusturmaTarihi = DateTime.UtcNow
                    };
                    _db.Maclar.Add(mac);
                    macMap[key] = mac;
                    sonuc.EklenenMac++;
                }
                else
                {
                    sonuc.GuncellenenMac++;
                }

                mac!.LigId = femLig.Id;
                mac.Durum = "finished";
                mac.EvSahibiSkor = item.Kaynak.FullTimeScore?.HomeGoals;
                mac.DeplasmanSkor = item.Kaynak.FullTimeScore?.AwayGoals;
                mac.IlkYariEvSahibiSkor = item.Kaynak.HalfTimeScore?.HomeGoals;
                mac.IlkYariDeplasmanSkor = item.Kaynak.HalfTimeScore?.AwayGoals;
                mac.Hakem = item.Kaynak.Referee?.Name;
                mac.GuncellemeTarihi = DateTime.UtcNow;

                await _db.SaveChangesAsync(cancellationToken);
                await IstatistikleriKaydetAsync(mac, item.Ev.Id, item.Kaynak.HomeTeam.Stats,
                    sonuc, cancellationToken);
                await IstatistikleriKaydetAsync(mac, item.Dep.Id, item.Kaynak.AwayTeam.Stats,
                    sonuc, cancellationToken);
            }

            await _db.SaveChangesAsync(cancellationToken);
            sonuc.Basarili = true;
            sonuc.Mesaj = $"{sonuc.KaynaktanGelenMac} maç alındı; " +
                          $"{sonuc.EklenenMac} eklendi, {sonuc.GuncellenenMac} güncellendi.";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Football-data.co.uk aktarımı başarısız. Lig: {Lig}, Sezon: {Sezon}",
                kaynakLig.Id, sezon.Id);
            sonuc.Basarili = false;
            sonuc.Mesaj = ex.Message;
        }
        finally
        {
            sonuc.BitisZamani = DateTime.UtcNow;
        }

        return sonuc;
    }

    private async Task IstatistikleriKaydetAsync(
        Mac mac,
        int takimId,
        IReadOnlyCollection<Statistic>? kaynak,
        FootballDataImportResultDto sonuc,
        CancellationToken cancellationToken)
    {
        if (kaynak is null || kaynak.Count == 0)
            return;

        var istatistik = await _db.MacIstatistikleri.FirstOrDefaultAsync(
            x => x.MacId == mac.Id && x.TakimId == takimId,
            cancellationToken);
        var yeniMi = istatistik is null;
        if (istatistik is null)
        {
            istatistik = new MacIstatistigi
            {
                MacId = mac.Id,
                TakimId = takimId,
                KayitTarihi = DateTime.UtcNow
            };
            _db.MacIstatistikleri.Add(istatistik);
        }

        int? Get(Statistic.StatType type) =>
            kaynak.FirstOrDefault(x => x.Type == type)?.Value;

        istatistik.Sut = Get(Statistic.StatType.Shots);
        istatistik.IsabetliSut = Get(Statistic.StatType.ShotsOnTarget);
        istatistik.Korner = Get(Statistic.StatType.Corners);
        istatistik.Faul = Get(Statistic.StatType.FoulsCommitted);
        istatistik.Ofsayt = Get(Statistic.StatType.Offsides);
        istatistik.SariKart = Get(Statistic.StatType.YellowCards);
        istatistik.KirmiziKart = Get(Statistic.StatType.RedCards);

        await _db.SaveChangesAsync(cancellationToken);
        if (yeniMi) sonuc.EklenenIstatistik++;
        else sonuc.GuncellenenIstatistik++;
    }

    private FemLeague LigGetirVeyaOlustur(
        string ad,
        string ulke,
        string sezon,
        Dictionary<string, FemLeague> map,
        FootballDataImportResultDto sonuc)
    {
        var key = LigKey(ad, sezon);
        if (map.TryGetValue(key, out var mevcut))
            return mevcut;

        var lig = new FemLeague
        {
            HariciLigId = null,
            Ad = ad,
            Ulke = ulke,
            Sezon = sezon,
            AktifMi = true
        };
        _db.Ligler.Add(lig);
        map[key] = lig;
        sonuc.YeniLig++;
        return lig;
    }

    private Takim TakimGetirVeyaOlustur(
        string hamAd,
        FemLeague lig,
        Dictionary<string, Takim> map,
        FootballDataImportResultDto sonuc)
    {
        var ad = AliasUygula(hamAd);
        var key = Normalize(ad);
        if (map.TryGetValue(key, out var mevcut))
            return mevcut;

        var takim = new Takim
        {
            HariciTakimId = null,
            Lig = lig,
            Ad = ad,
            Ulke = lig.Ulke,
            AktifMi = true
        };
        _db.Takimlar.Add(takim);
        map[key] = takim;
        sonuc.YeniTakim++;
        return takim;
    }

    private string AliasUygula(string ad)
    {
        return _options.TakimAliaslari.TryGetValue(ad.Trim(), out var alias)
            ? alias.Trim()
            : ad.Trim();
    }

    private static (string Ad, string Ulke) LigBilgisi(FdLeague lig)
    {
        return LigAdlari.TryGetValue(lig.Id, out var bilgi)
            ? bilgi
            : (lig.Name, lig.Country?.Name ?? "Unknown");
    }

    private static string NormalizeSezonKodu(string value)
    {
        var digits = new string(value.Where(char.IsDigit).ToArray());
        if (digits.Length == 8)
            return digits[2..4] + digits[6..8];
        if (digits.Length == 4)
            return digits;
        return value.Trim();
    }

    private static string Normalize(string value)
    {
        var formD = value.Trim().ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var chars = formD.Where(c =>
            CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark).ToArray();
        var text = new string(chars).Normalize(NormalizationForm.FormC);
        text = Regex.Replace(text, @"\b(fc|fk|cf|afc|sc|sk|club|football|futbol)\b", " ");
        return Regex.Replace(text, @"[^a-z0-9]+", string.Empty);
    }

    private static string LigKey(string ad, string? sezon) =>
        $"{Normalize(ad)}|{sezon?.Trim()}";

    private static string MacKey(int evId, int depId, DateTime tarih) =>
        $"{evId}|{depId}|{tarih:yyyyMMdd}";
}
