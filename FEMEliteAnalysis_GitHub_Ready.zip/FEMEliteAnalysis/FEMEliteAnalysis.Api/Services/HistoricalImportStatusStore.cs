using FEMEliteAnalysis.Api.Dtos.Historical;

namespace FEMEliteAnalysis.Api.Services;

public class HistoricalImportStatusStore
{
    private readonly object _lock = new();
    private HistoricalImportStatusDto _status = new();

    public HistoricalImportStatusDto Getir()
    {
        lock (_lock)
        {
            return new HistoricalImportStatusDto
            {
                CalisiyorMu = _status.CalisiyorMu,
                SonBaslama = _status.SonBaslama,
                SonBitis = _status.SonBitis,
                SonMesaj = _status.SonMesaj,
                SonSonuclar = _status.SonSonuclar.ToList()
            };
        }
    }

    public bool Baslat()
    {
        lock (_lock)
        {
            if (_status.CalisiyorMu) return false;
            _status.CalisiyorMu = true;
            _status.SonBaslama = DateTime.UtcNow;
            _status.SonMesaj = "Geçmiş veri aktarımı çalışıyor.";
            return true;
        }
    }

    public void Bitir(string mesaj, List<HistoricalImportResultDto> sonuclar)
    {
        lock (_lock)
        {
            _status.CalisiyorMu = false;
            _status.SonBitis = DateTime.UtcNow;
            _status.SonMesaj = mesaj;
            _status.SonSonuclar = sonuclar.TakeLast(10).ToList();
        }
    }
}
