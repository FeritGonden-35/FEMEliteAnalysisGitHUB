using FEMEliteAnalysis.Api.Common.Constants;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Uyelik;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class VipYonetimService : IVipYonetimService
{
    private readonly FemDbContext _dbContext;
    private readonly ICacheService _cacheService;
    private readonly CacheOptions _cacheOptions;
    private readonly ILogger<VipYonetimService> _logger;

    public VipYonetimService(
        FemDbContext dbContext,
        ICacheService cacheService,
        IOptions<CacheOptions> cacheOptions,
        ILogger<VipYonetimService> logger)
    {
        _dbContext = dbContext;
        _cacheService = cacheService;
        _cacheOptions = cacheOptions.Value;
        _logger = logger;
    }

    public async Task<ServiceResult<List<VipKullaniciDto>>> AktifUyeleriGetirAsync(
        CancellationToken cancellationToken)
    {
        if (_cacheService.TryGet<List<VipKullaniciDto>>(
                CacheAnahtarlari.AktifVipUyeler,
                out var cacheUyeler) &&
            cacheUyeler is not null)
        {
            return ServiceResult<List<VipKullaniciDto>>.BasariliSonuc(
                cacheUyeler,
                "Aktif VIP üyeler cache üzerinden getirildi.");
        }

        var simdi = DateTime.UtcNow;

        var uyeler = await _dbContext.Uyelikler
            .AsNoTracking()
            .Where(x =>
                x.Durum == UyelikDurumu.Aktif &&
                x.BaslangicTarihi <= simdi &&
                x.BitisTarihi > simdi)
            .OrderBy(x => x.BitisTarihi)
            .Select(x => new VipKullaniciDto
            {
                KullaniciId = x.KullaniciId,
                TelegramKullaniciId =
                    x.Kullanici.TelegramKullaniciId,
                KullaniciAdi = x.Kullanici.KullaniciAdi,
                AdSoyad =
                    ((x.Kullanici.Ad ?? "") + " " +
                     (x.Kullanici.Soyad ?? "")).Trim(),
                BaslangicTarihi = x.BaslangicTarihi,
                BitisTarihi = x.BitisTarihi,
                KalanGun = (int)Math.Ceiling(
                    EF.Functions.DateDiffMinute(
                        simdi,
                        x.BitisTarihi) / 1440.0)
            })
            .ToListAsync(cancellationToken);

        _cacheService.Set(
            CacheAnahtarlari.AktifVipUyeler,
            uyeler,
            TimeSpan.FromMinutes(
                Math.Max(1, _cacheOptions.VipUyelerDakika)));

        return ServiceResult<List<VipKullaniciDto>>.BasariliSonuc(
            uyeler,
            $"{uyeler.Count} aktif VIP üye bulundu.");
    }

    public async Task<ServiceResult<VipKullaniciDto>> UyeBilgisiGetirAsync(
        long telegramKullaniciId,
        CancellationToken cancellationToken)
    {
        var simdi = DateTime.UtcNow;

        var uye = await _dbContext.Uyelikler
            .AsNoTracking()
            .Where(x =>
                x.Kullanici.TelegramKullaniciId ==
                    telegramKullaniciId &&
                x.Durum == UyelikDurumu.Aktif &&
                x.BitisTarihi > simdi)
            .OrderByDescending(x => x.BitisTarihi)
            .Select(x => new VipKullaniciDto
            {
                KullaniciId = x.KullaniciId,
                TelegramKullaniciId =
                    x.Kullanici.TelegramKullaniciId,
                KullaniciAdi = x.Kullanici.KullaniciAdi,
                AdSoyad =
                    ((x.Kullanici.Ad ?? "") + " " +
                     (x.Kullanici.Soyad ?? "")).Trim(),
                BaslangicTarihi = x.BaslangicTarihi,
                BitisTarihi = x.BitisTarihi,
                KalanGun = (int)Math.Ceiling(
                    EF.Functions.DateDiffMinute(
                        simdi,
                        x.BitisTarihi) / 1440.0)
            })
            .FirstOrDefaultAsync(cancellationToken);

        return uye is null
            ? ServiceResult<VipKullaniciDto>.BasarisizSonuc(
                "Aktif VIP üyelik bulunamadı.")
            : ServiceResult<VipKullaniciDto>.BasariliSonuc(uye);
    }

    public async Task<ServiceResult<bool>> UyelikIptalEtAsync(
        long telegramKullaniciId,
        long islemiYapanTelegramKullaniciId,
        CancellationToken cancellationToken)
    {
        var simdi = DateTime.UtcNow;

        var uyelik = await _dbContext.Uyelikler
            .Include(x => x.Kullanici)
            .Where(x =>
                x.Kullanici.TelegramKullaniciId ==
                    telegramKullaniciId &&
                x.Durum == UyelikDurumu.Aktif)
            .OrderByDescending(x => x.BitisTarihi)
            .FirstOrDefaultAsync(cancellationToken);

        if (uyelik is null)
        {
            return ServiceResult<bool>.BasarisizSonuc(
                "İptal edilecek aktif üyelik bulunamadı.");
        }

        uyelik.Durum = UyelikDurumu.IptalEdildi;
        uyelik.GuncellemeTarihi = simdi;

        await _dbContext.SaveChangesAsync(cancellationToken);

        _cacheService.Remove(CacheAnahtarlari.AktifVipUyeler);

        _logger.LogInformation(
            "VIP üyelik iptal edildi. TelegramId: {TelegramId}, AdminId: {AdminId}",
            telegramKullaniciId,
            islemiYapanTelegramKullaniciId);

        return ServiceResult<bool>.BasariliSonuc(
            true,
            "VIP üyelik iptal edildi.");
    }
}
