using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class VeriSaglayiciFactory : IVeriSaglayiciFactory
{
    private readonly IReadOnlyCollection<IVeriSaglayici> _saglayicilar;

    public VeriSaglayiciFactory(
        IEnumerable<IVeriSaglayici> saglayicilar)
    {
        _saglayicilar = saglayicilar.ToList();
    }

    public IVeriSaglayici Getir(
        VeriSaglayiciTuru tur)
    {
        var saglayici = _saglayicilar.FirstOrDefault(
            x => x.Tur == tur);

        return saglayici
            ?? throw new InvalidOperationException(
                $"{tur} türünde veri sağlayıcı kaydı bulunamadı.");
    }

    public IReadOnlyCollection<IVeriSaglayici> AktifSaglayicilariGetir()
    {
        return _saglayicilar
            .Where(x => x.AktifMi)
            .ToList();
    }
}
