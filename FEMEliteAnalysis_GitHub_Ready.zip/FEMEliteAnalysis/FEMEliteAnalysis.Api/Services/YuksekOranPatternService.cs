using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

/// <summary>
/// Yüksek oran modu için geçmiş İY/MS patternlerini tarar.
/// Ev takımı yalnız iç saha, deplasman takımı yalnız dış saha geçmişiyle değerlendirilir.
/// Bu servis bookmaker oranı uydurmaz; yalnız veri/pattern gücünü sıralar.
/// </summary>
public class YuksekOranPatternService : IYuksekOranPatternService
{
    private readonly FemDbContext _db;

    private static readonly PatternTanim[] Patternler =
    {
        new("2/1", 2, 1, 1.30m),
        new("1/2", 1, 2, 1.30m),
        new("X/1", 0, 1, 1.18m),
        new("X/2", 0, 2, 1.18m),
        new("1/X", 1, 0, 1.12m),
        new("2/X", 2, 0, 1.12m),
        new("1/1", 1, 1, 0.92m),
        new("2/2", 2, 2, 0.92m),
        new("X/X", 0, 0, 0.88m)
    };

    public YuksekOranPatternService(FemDbContext db) => _db = db;

    public async Task<ServiceResult<YuksekOranPatternKuponDto>> OlusturAsync(
        IReadOnlyCollection<int>? macIdleri,
        CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;

        // Aynı maç için birden fazla analiz varsa en güncel/yüksek güvenli olanı kullan.
        var analizQuery = _db.Analizler.AsNoTracking()
            .Include(x => x.Mac).ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac).ThenInclude(x => x.DeplasmanTakim)
            .Where(x => x.Mac.MacTarihi >= now.AddHours(-2) &&
                        x.Mac.MacTarihi <= now.AddDays(5) &&
                        x.GuvenPuani >= 55);

        if (macIdleri is { Count: > 0 })
            analizQuery = analizQuery.Where(x => macIdleri.Contains(x.MacId));

        var analizler = await analizQuery
            .OrderByDescending(x => x.GuvenPuani)
            .ThenByDescending(x => x.OlusturmaTarihi)
            .Take(120)
            .ToListAsync(cancellationToken);

        var tekilAnalizler = analizler
            .GroupBy(x => x.MacId)
            .Select(g => g.First())
            .Take(70)
            .ToList();

        if (tekilAnalizler.Count == 0)
            return ServiceResult<YuksekOranPatternKuponDto>.BasarisizSonuc("Yüksek oran pattern taraması için uygun maç bulunamadı.");

        var gucluAdaylar = new List<YuksekOranPatternSecimDto>();
        var fallbackAdaylar = new List<YuksekOranPatternSecimDto>();
        var yeterliVeriliMac = 0;

        foreach (var analiz in tekilAnalizler)
        {
            var mac = analiz.Mac;

            var evGecmis = await GecmisGetirAsync(mac.EvSahibiTakimId, evSahibiMi: true, mac.MacTarihi, cancellationToken);
            var depGecmis = await GecmisGetirAsync(mac.DeplasmanTakimId, evSahibiMi: false, mac.MacTarihi, cancellationToken);

            // Yüksek mod boş dönmesin diye 8 maç altını reddet; 12+ maç güçlü örneklem sayılır.
            if (evGecmis.Count < 8 || depGecmis.Count < 8)
                continue;

            yeterliVeriliMac++;
            YuksekOranPatternSecimDto? macEnIyiGuclu = null;
            YuksekOranPatternSecimDto? macEnIyiFallback = null;
            var oddsEsik = DateTime.UtcNow.AddHours(-4);
            var oranlar = await _db.BahisOranlari.AsNoTracking()
                .Where(x => x.MacId == mac.Id && x.AlinmaTarihi >= oddsEsik && x.Oran > 1m)
                .OrderByDescending(x => x.AlinmaTarihi)
                .ToListAsync(cancellationToken);

            foreach (var p in Patternler)
            {
                var evStat = Istatistik(evGecmis, p.IlkYari, p.MacSonu);
                var depStat = Istatistik(depGecmis, p.IlkYari, p.MacSonu);
                var veriKalitesi = VeriKalitesi(evStat.Son40Toplam, depStat.Son40Toplam);
                var skor = PatternSkoru(evStat, depStat, p.Carpan, veriKalitesi);

                // İki katmanlı filtre: önce güçlü pattern, bulunamazsa kontrollü fallback.
                var ev20 = Oran(evStat.Son20Isabet, evStat.Son20Toplam);
                var dep20 = Oran(depStat.Son20Isabet, depStat.Son20Toplam);
                var ortak20 = (ev20 + dep20) / 2m;
                var gucluMu = evGecmis.Count >= 12 && depGecmis.Count >= 12 && ortak20 >= 8m && skor >= 42;
                var fallbackMi = ortak20 >= 3m && skor >= 28;
                if (!gucluMu && !fallbackMi)
                    continue;

                var gercekOran = oranlar
                    .Where(x => Normalize(x.MarketKodu) == Normalize(p.Kod))
                    .OrderByDescending(x => x.Oran)
                    .FirstOrDefault()?.Oran;
                // V4.8: yüksek kupon gerçek oran olmadan üretilmez.
                if (!gercekOran.HasValue)
                    continue;
                var oran = gercekOran.Value;

                var aday = new YuksekOranPatternSecimDto
                {
                    AnalizId = analiz.Id,
                    MacId = mac.Id,
                    EvSahibi = mac.EvSahibiTakim.Ad,
                    Deplasman = mac.DeplasmanTakim.Ad,
                    Pattern = p.Kod,
                    PatternSkoru = skor,
                    VeriKalitesi = veriKalitesi,
                    Oran = Math.Round(oran, 2),
                    TahminiOranMi = false,
                    EvIstatistik = evStat,
                    DepIstatistik = depStat
                };

                var adaySirasi = aday.PatternSkoru + YuksekOranBonusu(aday.Pattern, aday.Oran);
                if (gucluMu)
                {
                    var mevcutSirasi = macEnIyiGuclu is null ? decimal.MinValue : macEnIyiGuclu.PatternSkoru + YuksekOranBonusu(macEnIyiGuclu.Pattern, macEnIyiGuclu.Oran);
                    if (macEnIyiGuclu is null || adaySirasi > mevcutSirasi)
                        macEnIyiGuclu = aday;
                }
                else
                {
                    var mevcutSirasi = macEnIyiFallback is null ? decimal.MinValue : macEnIyiFallback.PatternSkoru + YuksekOranBonusu(macEnIyiFallback.Pattern, macEnIyiFallback.Oran);
                    if (macEnIyiFallback is null || adaySirasi > mevcutSirasi)
                        macEnIyiFallback = aday;
                }
            }

            if (macEnIyiGuclu is not null)
                gucluAdaylar.Add(macEnIyiGuclu);
            else if (macEnIyiFallback is not null)
                fallbackAdaylar.Add(macEnIyiFallback);
        }

        var secimler = YuksekKombinasyonSec(gucluAdaylar, 12m, 500m, 40m);
        var fallbackKullanildi = false;

        // Güçlü havuz 12+ oran üretemezse, güçlü + kontrollü fallback havuzunu birlikte tara.
        if (secimler.Count == 0)
        {
            var genisHavuz = gucluAdaylar.Concat(fallbackAdaylar)
                .GroupBy(x => x.MacId)
                .Select(g => g.OrderByDescending(x => x.PatternSkoru + YuksekOranBonusu(x.Pattern, x.Oran)).First())
                .ToList();
            secimler = YuksekKombinasyonSec(genisHavuz, 12m, 500m, 35m);
            fallbackKullanildi = secimler.Count > 0;
        }

        if (secimler.Count == 0)
            return ServiceResult<YuksekOranPatternKuponDto>.BasarisizSonuc(
                $"Bugün yüksek oran için yeterli kombinasyon oluşmadı. İncelenen {tekilAnalizler.Count} maçın {yeterliVeriliMac} tanesinde İY/MS örneklemi vardı.");

        return ServiceResult<YuksekOranPatternKuponDto>.BasariliSonuc(new YuksekOranPatternKuponDto
        {
            IncelenenMacSayisi = tekilAnalizler.Count,
            YeterliVeriliMacSayisi = yeterliVeriliMac,
            ToplamOran = Math.Round(secimler.Aggregate(1m, (a, b) => a * b.Oran), 2),
            TahminiOranIceriyorMu = secimler.Any(x => x.TahminiOranMi),
            FallbackKullanildiMi = fallbackKullanildi,
            Secimler = secimler
        }, secimler.Count < 3
            ? $"Kriteri geçen {secimler.Count} güçlü pattern bulundu."
            : "Günün en güçlü 3 İY/MS patterni bulundu.");
    }

    private async Task<List<Mac>> GecmisGetirAsync(int takimId, bool evSahibiMi, DateTime macTarihi, CancellationToken ct)
    {
        var q = _db.Maclar.AsNoTracking()
            .Where(x => x.MacTarihi < macTarihi &&
                        x.EvSahibiSkor.HasValue && x.DeplasmanSkor.HasValue &&
                        x.IlkYariEvSahibiSkor.HasValue && x.IlkYariDeplasmanSkor.HasValue);

        q = evSahibiMi
            ? q.Where(x => x.EvSahibiTakimId == takimId)
            : q.Where(x => x.DeplasmanTakimId == takimId);

        return await q.OrderByDescending(x => x.MacTarihi).Take(40).ToListAsync(ct);
    }

    private static PatternTakimIstatistikDto Istatistik(List<Mac> maclar, int iy, int ms)
    {
        var son10 = maclar.Take(10).ToList();
        var son20 = maclar.Take(20).ToList();
        var son40 = maclar.Take(40).ToList();

        return new PatternTakimIstatistikDto
        {
            Son10Toplam = son10.Count,
            Son10Isabet = son10.Count(x => Sonuc(x.IlkYariEvSahibiSkor!.Value, x.IlkYariDeplasmanSkor!.Value) == iy &&
                                           Sonuc(x.EvSahibiSkor!.Value, x.DeplasmanSkor!.Value) == ms),
            Son20Toplam = son20.Count,
            Son20Isabet = son20.Count(x => Sonuc(x.IlkYariEvSahibiSkor!.Value, x.IlkYariDeplasmanSkor!.Value) == iy &&
                                           Sonuc(x.EvSahibiSkor!.Value, x.DeplasmanSkor!.Value) == ms),
            Son40Toplam = son40.Count,
            Son40Isabet = son40.Count(x => Sonuc(x.IlkYariEvSahibiSkor!.Value, x.IlkYariDeplasmanSkor!.Value) == iy &&
                                           Sonuc(x.EvSahibiSkor!.Value, x.DeplasmanSkor!.Value) == ms)
        };
    }

    // 1=ev önde/kazandı, 0=berabere, 2=deplasman önde/kazandı
    private static int Sonuc(int ev, int dep) => ev > dep ? 1 : ev < dep ? 2 : 0;

    private static int PatternSkoru(PatternTakimIstatistikDto ev, PatternTakimIstatistikDto dep, decimal carpan, int veriKalitesi)
    {
        var ev10 = Oran(ev.Son10Isabet, ev.Son10Toplam);
        var ev20 = Oran(ev.Son20Isabet, ev.Son20Toplam);
        var ev40 = Oran(ev.Son40Isabet, ev.Son40Toplam);
        var dep10 = Oran(dep.Son10Isabet, dep.Son10Toplam);
        var dep20 = Oran(dep.Son20Isabet, dep.Son20Toplam);
        var dep40 = Oran(dep.Son40Isabet, dep.Son40Toplam);

        // Son dönem daha ağır; iki tarafın aynı patterni desteklemesi zorunlu olarak skora yansır.
        var evTrend = ev10 * .45m + ev20 * .35m + ev40 * .20m;
        var depTrend = dep10 * .45m + dep20 * .35m + dep40 * .20m;
        var ortak = evTrend * .52m + depTrend * .48m;

        // Tek taraf çok güçlü, diğer taraf çok zayıfsa cezalandır.
        var uyumCezasi = Math.Abs(evTrend - depTrend) * .18m;
        var ham = Math.Max(0m, ortak - uyumCezasi) * carpan;
        var skor = ham * .82m + veriKalitesi * .18m;

        return (int)Math.Round(Math.Clamp(skor, 0m, 100m));
    }


    private static List<YuksekOranPatternSecimDto> YuksekKombinasyonSec(
        List<YuksekOranPatternSecimDto> adaylar, decimal min, decimal max, decimal hedef)
    {
        var havuz = adaylar
            .OrderByDescending(x => x.PatternSkoru + YuksekOranBonusu(x.Pattern, x.Oran))
            .Take(36)
            .ToList();

        var kombinasyonlar = new List<List<YuksekOranPatternSecimDto>>();

        void Ekle(List<YuksekOranPatternSecimDto> secim)
        {
            var oran = secim.Aggregate(1m, (a, b) => a * b.Oran);
            if (oran >= min && oran <= max)
                kombinasyonlar.Add(secim);
        }

        // Tek bir 2/1 veya 1/2 zaten 12+ ise tek seçim de geçerli kabul edilir.
        foreach (var x in havuz) Ekle(new List<YuksekOranPatternSecimDto> { x });

        for (var i = 0; i < havuz.Count; i++)
        for (var j = i + 1; j < havuz.Count; j++)
        {
            Ekle(new List<YuksekOranPatternSecimDto> { havuz[i], havuz[j] });

            for (var k = j + 1; k < havuz.Count; k++)
            {
                Ekle(new List<YuksekOranPatternSecimDto> { havuz[i], havuz[j], havuz[k] });

                // Düşük fiyatlı 1/1-X/X gibi patternlerle de 12 bandına ulaşabilmek için 4 seçim desteği.
                for (var l = k + 1; l < havuz.Count; l++)
                    Ekle(new List<YuksekOranPatternSecimDto> { havuz[i], havuz[j], havuz[k], havuz[l] });
            }
        }

        return kombinasyonlar
            .OrderBy(x =>
            {
                var oran = x.Aggregate(1m, (a, b) => a * b.Oran);
                var sapma = Math.Abs(oran - hedef) / hedef * 100m;
                var guven = (decimal)x.Average(y => y.PatternSkoru);
                var veri = (decimal)x.Average(y => y.VeriKalitesi);
                return sapma +
                       Math.Max(0, 45m - guven) * .45m +
                       Math.Max(0, 60m - veri) * .18m +
                       Math.Max(0, x.Count - 3) * 1.5m;
            })
            .FirstOrDefault() ?? new();
    }

    private static decimal YuksekOranBonusu(string pattern, decimal oran)
    {
        var patternBonus = pattern is "2/1" or "1/2" ? 9m
            : pattern is "X/1" or "X/2" ? 6m
            : pattern is "1/X" or "2/X" ? 5m : 1m;
        return patternBonus + Math.Min(8m, oran / 2m);
    }

    private static decimal PatternTahminiOrani(string pattern, int skor)
    {
        (decimal min, decimal max) = pattern switch
        {
            "2/1" or "1/2" => (10m, 24m),
            "1/X" or "2/X" => (6m, 13m),
            "X/1" or "X/2" => (4m, 8m),
            "X/X" => (3m, 5.5m),
            "1/1" or "2/2" => (2m, 4m),
            _ => (3m, 8m)
        };
        var risk = Math.Clamp((75m - skor) / 45m, 0m, 1m);
        return Math.Round(min + (max - min) * risk, 2);
    }

    private static string Normalize(string x) =>
        string.Join(' ', (x ?? string.Empty).Trim().ToUpperInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries));

    private static int VeriKalitesi(int evN, int depN)
    {
        var min = Math.Min(evN, depN);
        return min switch
        {
            >= 40 => 100,
            >= 32 => 94,
            >= 25 => 88,
            >= 20 => 80,
            >= 16 => 72,
            >= 12 => 64,
            _ => 45
        };
    }

    private static decimal Oran(int hit, int toplam) => toplam <= 0 ? 0m : hit * 100m / toplam;

    private sealed record PatternTanim(string Kod, int IlkYari, int MacSonu, decimal Carpan);
}
