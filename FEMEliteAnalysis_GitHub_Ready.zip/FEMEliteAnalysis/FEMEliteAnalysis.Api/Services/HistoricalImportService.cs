using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Historical;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class HistoricalImportService : IHistoricalImportService
{
    private static readonly SemaphoreSlim ImportLock = new(1, 1);
    private readonly FemDbContext _db;
    private readonly HistoricalDataOptions _options;
    private readonly HistoricalImportStatusStore _statusStore;
    private readonly IWebHostEnvironment _environment;
    private readonly ILogger<HistoricalImportService> _logger;

    private static readonly Dictionary<string, (string Ad, string Ulke)> Ligler =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["E0"] = ("Premier League", "England"),
            ["E1"] = ("Championship", "England"),
            ["E2"] = ("League One", "England"),
            ["E3"] = ("League Two", "England"),
            ["SC0"] = ("Scottish Premiership", "Scotland"),
            ["D1"] = ("Bundesliga", "Germany"),
            ["D2"] = ("2. Bundesliga", "Germany"),
            ["SP1"] = ("La Liga", "Spain"),
            ["SP2"] = ("Segunda Division", "Spain"),
            ["I1"] = ("Serie A", "Italy"),
            ["I2"] = ("Serie B", "Italy"),
            ["F1"] = ("Ligue 1", "France"),
            ["F2"] = ("Ligue 2", "France"),
            ["N1"] = ("Eredivisie", "Netherlands"),
            ["P1"] = ("Primeira Liga", "Portugal"),
            ["B1"] = ("Belgian Pro League", "Belgium"),
            ["T1"] = ("Super Lig", "Turkey"),
            ["G1"] = ("Super League Greece", "Greece"),
            ["UCL"] = ("UEFA Champions League", "Europe")
        };

    public HistoricalImportService(
        FemDbContext db,
        IOptions<HistoricalDataOptions> options,
        HistoricalImportStatusStore statusStore,
        IWebHostEnvironment environment,
        ILogger<HistoricalImportService> logger)
    {
        _db = db;
        _options = options.Value;
        _statusStore = statusStore;
        _environment = environment;
        _logger = logger;
        KlasorleriHazirla();
    }

    public HistoricalImportStatusDto DurumGetir() => _statusStore.Getir();

    public IReadOnlyList<string> BekleyenDosyalariGetir() =>
        Directory.Exists(InboxPath)
            ? Directory.GetFiles(InboxPath, "*.csv")
                .Select(Path.GetFileName)
                .Where(x => x is not null)
                .Cast<string>()
                .OrderBy(x => x)
                .ToList()
            : new List<string>();

    public async Task<ServiceResult<List<HistoricalImportResultDto>>> InboxAktarAsync(
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif)
            return ServiceResult<List<HistoricalImportResultDto>>.BasarisizSonuc(
                "HistoricalData modülü kapalı.");

        if (!await ImportLock.WaitAsync(0, cancellationToken))
            return ServiceResult<List<HistoricalImportResultDto>>.BasarisizSonuc(
                "Başka bir geçmiş veri aktarımı zaten çalışıyor.");

        if (!_statusStore.Baslat())
        {
            ImportLock.Release();
            return ServiceResult<List<HistoricalImportResultDto>>.BasarisizSonuc(
                "Başka bir geçmiş veri aktarımı zaten çalışıyor.");
        }

        var sonuclar = new List<HistoricalImportResultDto>();
        try
        {
            KlasorleriHazirla();
            var dosyalar = Directory.GetFiles(InboxPath, "*.csv")
                .OrderBy(x => x)
                .ToList();

            if (dosyalar.Count == 0)
            {
                const string inboxBosMesaji =
                    "HistoricalData/Inbox klasöründe CSV bulunamadı.";

                _statusStore.Bitir(
                    inboxBosMesaji,
                    sonuclar);

                return ServiceResult<List<HistoricalImportResultDto>>
                    .BasarisizSonuc(inboxBosMesaji);
            }

            foreach (var dosya in dosyalar)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var sonuc = await DosyaAktarAsync(dosya, cancellationToken);
                sonuclar.Add(sonuc);
                DosyayiTasi(dosya, sonuc.Basarili);
            }

            var eklenen = sonuclar.Sum(x => x.EklenenMac);
            var guncellenen = sonuclar.Sum(x => x.GuncellenenMac);
            var tamamlanmaMesaji =
                $"{sonuclar.Count} dosya işlendi; " +
                $"{eklenen} maç eklendi, " +
                $"{guncellenen} maç güncellendi.";

            _statusStore.Bitir(
                tamamlanmaMesaji,
                sonuclar);

            return ServiceResult<List<HistoricalImportResultDto>>
                .BasariliSonuc(
                    sonuclar,
                    tamamlanmaMesaji);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            const string iptalMesaji =
                "Geçmiş veri aktarımı iptal edildi.";

            _statusStore.Bitir(
                iptalMesaji,
                sonuclar);

            return ServiceResult<List<HistoricalImportResultDto>>
                .BasarisizSonuc(iptalMesaji);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Geçmiş veri aktarımı başarısız.");
            const string beklenmeyenHataMesaji =
                "Geçmiş veri aktarımında beklenmeyen hata oluştu.";

            _statusStore.Bitir(
                beklenmeyenHataMesaji,
                sonuclar);

            return ServiceResult<List<HistoricalImportResultDto>>
                .BasarisizSonuc(beklenmeyenHataMesaji);
        }
        finally
        {
            ImportLock.Release();
        }
    }

    private async Task<HistoricalImportResultDto> DosyaAktarAsync(
        string dosya,
        CancellationToken cancellationToken)
    {
        var sonuc = new HistoricalImportResultDto
        {
            DosyaAdi = Path.GetFileName(dosya),
            BaslamaZamani = DateTime.UtcNow
        };

        try
        {
            var satirlar = await File.ReadAllLinesAsync(dosya, cancellationToken);
            if (satirlar.Length < 2)
                throw new InvalidOperationException("CSV boş veya başlık satırı yok.");

            var ayirici = AyiriciBul(satirlar[0]);
            var basliklar = CsvSatiriCoz(satirlar[0], ayirici)
                .Select((x, i) => new { Ad = x.Trim(), Index = i })
                .ToDictionary(x => x.Ad, x => x.Index, StringComparer.OrdinalIgnoreCase);

            CsvSemasiDogrula(basliklar);

            var kayitlar = new List<CsvMac>();
            for (var i = 1; i < satirlar.Length; i++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (string.IsNullOrWhiteSpace(satirlar[i])) continue;
                sonuc.OkunanSatir++;
                try
                {
                    var alanlar = CsvSatiriCoz(satirlar[i], ayirici);
                    var kayit = KaydiCoz(alanlar, basliklar, sonuc.DosyaAdi);
                    if (kayit is null) sonuc.AtlananSatir++;
                    else kayitlar.Add(kayit);
                }
                catch (Exception ex)
                {
                    sonuc.AtlananSatir++;
                    if (sonuc.Uyarilar.Count < 10)
                        sonuc.Uyarilar.Add($"Satır {i + 1}: {ex.Message}");
                }
            }

            if (kayitlar.Count == 0)
                throw new InvalidOperationException("İçe aktarılabilir maç satırı bulunamadı.");

            var takimlar = await _db.Takimlar.ToListAsync(cancellationToken);
            var takimMap = takimlar
                .GroupBy(x => Normalize(x.Ad))
                .ToDictionary(x => x.Key, x => x.First());

            var ligler = await _db.Ligler.ToListAsync(cancellationToken);
            var ligMap = ligler
                .GroupBy(x => LigKey(x.Ad, x.Sezon))
                .ToDictionary(x => x.Key, x => x.First());

            foreach (var kayit in kayitlar)
            {
                var lig = LigGetirVeyaOlustur(kayit, ligMap, sonuc);
                var ev = TakimGetirVeyaOlustur(kayit.EvSahibi, lig, takimMap, sonuc);
                var dep = TakimGetirVeyaOlustur(kayit.Deplasman, lig, takimMap, sonuc);
                kayit.Lig = lig;
                kayit.EvTakim = ev;
                kayit.DepTakim = dep;
            }

            await _db.SaveChangesAsync(cancellationToken);

            var minTarih = kayitlar.Min(x => x.Tarih).AddDays(-1);
            var maxTarih = kayitlar.Max(x => x.Tarih).AddDays(1);
            var mevcutlar = await _db.Maclar
                .Where(x => x.MacTarihi >= minTarih && x.MacTarihi <= maxTarih)
                .ToListAsync(cancellationToken);

            var mevcutMap = mevcutlar
                .GroupBy(x => MacKey(x.EvSahibiTakimId, x.DeplasmanTakimId, x.MacTarihi.Date))
                .ToDictionary(x => x.Key, x => x.First());

            foreach (var kayit in kayitlar)
            {
                var key = MacKey(kayit.EvTakim!.Id, kayit.DepTakim!.Id, kayit.Tarih.Date);
                if (!mevcutMap.TryGetValue(key, out var mac))
                {
                    mac = new Mac
                    {
                        HariciMacId = null,
                        LigId = kayit.Lig!.Id,
                        EvSahibiTakimId = kayit.EvTakim.Id,
                        DeplasmanTakimId = kayit.DepTakim.Id,
                        MacTarihi = kayit.Tarih,
                        Durum = "finished",
                        EvSahibiSkor = kayit.EvGol,
                        DeplasmanSkor = kayit.DepGol,
                        IlkYariEvSahibiSkor = kayit.IlkYariEvGol,
                        IlkYariDeplasmanSkor = kayit.IlkYariDepGol,
                        OlusturmaTarihi = DateTime.UtcNow,
                        GuncellemeTarihi = DateTime.UtcNow
                    };
                    _db.Maclar.Add(mac);
                    mevcutMap[key] = mac;
                    sonuc.EklenenMac++;
                }
                else
                {
                    mac.LigId ??= kayit.Lig!.Id;
                    mac.EvSahibiSkor = kayit.EvGol;
                    mac.DeplasmanSkor = kayit.DepGol;
                    mac.IlkYariEvSahibiSkor ??= kayit.IlkYariEvGol;
                    mac.IlkYariDeplasmanSkor ??= kayit.IlkYariDepGol;
                    mac.Durum = "finished";
                    mac.GuncellemeTarihi = DateTime.UtcNow;
                    sonuc.GuncellenenMac++;
                }
            }

            await _db.SaveChangesAsync(cancellationToken);
            sonuc.Basarili = true;
            sonuc.Mesaj = $"{sonuc.EklenenMac} eklendi, {sonuc.GuncellenenMac} güncellendi.";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "CSV aktarımı başarısız. Dosya: {Dosya}", dosya);
            sonuc.Basarili = false;
            sonuc.Mesaj = ex.Message;
        }
        finally
        {
            sonuc.BitisZamani = DateTime.UtcNow;
        }
        return sonuc;
    }

    private Lig LigGetirVeyaOlustur(
        CsvMac kayit,
        Dictionary<string, Lig> ligMap,
        HistoricalImportResultDto sonuc)
    {
        var bilgi = Ligler.TryGetValue(kayit.Div, out var bulunan)
            ? bulunan
            : ($"Historical {kayit.Div}", "Unknown");
        var key = LigKey(bilgi.Item1, kayit.Sezon);
        if (ligMap.TryGetValue(key, out var lig)) return lig;
        lig = new Lig
        {
            HariciLigId = null,
            Ad = bilgi.Item1,
            Ulke = bilgi.Item2,
            Sezon = kayit.Sezon,
            AktifMi = true
        };
        _db.Ligler.Add(lig);
        ligMap[key] = lig;
        sonuc.YeniLig++;
        return lig;
    }

    private Takim TakimGetirVeyaOlustur(
        string hamAd,
        Lig lig,
        Dictionary<string, Takim> takimMap,
        HistoricalImportResultDto sonuc)
    {
        var canonical = AliasUygula(hamAd, sonuc);
        var key = Normalize(canonical);
        if (takimMap.TryGetValue(key, out var takim)) return takim;
        takim = new Takim
        {
            HariciTakimId = null,
            Lig = lig,
            Ad = canonical,
            Ulke = lig.Ulke,
            AktifMi = true
        };
        _db.Takimlar.Add(takim);
        takimMap[key] = takim;
        sonuc.YeniTakim++;
        return takim;
    }

    private string AliasUygula(string ad, HistoricalImportResultDto sonuc)
    {
        if (_options.TakimAliaslari.TryGetValue(ad.Trim(), out var alias))
        {
            sonuc.AliasEslesmesi++;
            return alias.Trim();
        }
        return ad.Trim();
    }

    private CsvMac? KaydiCoz(
        IReadOnlyList<string> alanlar,
        Dictionary<string, int> basliklar,
        string dosyaAdi)
    {
        string Get(params string[] names)
        {
            foreach (var name in names)
            {
                if (basliklar.TryGetValue(name, out var index) &&
                    index >= 0 &&
                    index < alanlar.Count)
                {
                    var value = alanlar[index].Trim();

                    if (!string.IsNullOrWhiteSpace(value))
                        return value;
                }
            }

            return string.Empty;
        }

        var ev = TakimAdiniTemizle(
            Get(
                "HomeTeam",
                "Home Team",
                "Team 1",
                "Team1",
                "home_team_name",
                "home_team"));

        var dep = TakimAdiniTemizle(
            Get(
                "AwayTeam",
                "Away Team",
                "Team 2",
                "Team2",
                "away_team_name",
                "away_team"));

        if (string.IsNullOrWhiteSpace(ev) ||
            string.IsNullOrWhiteSpace(dep))
        {
            return null;
        }

        int evGol;
        int depGol;

        var evGolMetni = Get(
            "FTHG",
            "HomeGoals",
            "Home Score",
            "home_team_goal_count",
            "home_score");

        var depGolMetni = Get(
            "FTAG",
            "AwayGoals",
            "Away Score",
            "away_team_goal_count",
            "away_score");

        if (int.TryParse(evGolMetni, out evGol) &&
            int.TryParse(depGolMetni, out depGol))
        {
            // Ayrı skor kolonları başarıyla çözüldü.
        }
        else
        {
            var tamZaman = Get(
                "FT",
                "Score",
                "FullTime",
                "Full Time",
                "result");

            if (!SkorCoz(tamZaman, out evGol, out depGol))
                return null;
        }

        var tarih = TarihCoz(
            Get("Date", "MatchDate", "match_date", "datetime", "timestamp"),
            Get("Time", "KickOff", "Kickoff", "kickoff_time"));

        if (!tarih.HasValue)
            return null;

        int? ilkYariEvGol = ParseNullable(
            Get(
                "HTHG",
                "HalfTimeHomeGoals",
                "half_time_home_goals"));

        int? ilkYariDepGol = ParseNullable(
            Get(
                "HTAG",
                "HalfTimeAwayGoals",
                "half_time_away_goals"));

        if (!ilkYariEvGol.HasValue ||
            !ilkYariDepGol.HasValue)
        {
            var ilkYari = Get(
                "HT",
                "HalfTime",
                "Half Time");

            if (SkorCoz(
                    ilkYari,
                    out var iyEv,
                    out var iyDep))
            {
                ilkYariEvGol = iyEv;
                ilkYariDepGol = iyDep;
            }
        }

        var div = Get(
            "Div",
            "League",
            "Competition",
            "Tournament");

        if (string.IsNullOrWhiteSpace(div))
        {
            div = DosyadanLigKoduBul(dosyaAdi);
        }

        return new CsvMac
        {
            Div = div,
            Sezon = SezonBul(
                dosyaAdi,
                tarih.Value),
            Tarih = tarih.Value,
            EvSahibi = ev,
            Deplasman = dep,
            EvGol = evGol,
            DepGol = depGol,
            IlkYariEvGol = ilkYariEvGol,
            IlkYariDepGol = ilkYariDepGol
        };
    }

    private static void CsvSemasiDogrula(
        IReadOnlyDictionary<string, int> basliklar)
    {
        bool Var(params string[] names) =>
            names.Any(basliklar.ContainsKey);

        var takimlarVar =
            Var(
                "HomeTeam",
                "Home Team",
                "Team 1",
                "Team1",
                "home_team_name",
                "home_team") &&
            Var(
                "AwayTeam",
                "Away Team",
                "Team 2",
                "Team2",
                "away_team_name",
                "away_team");

        var tarihVar =
            Var(
                "Date",
                "MatchDate",
                "match_date",
                "datetime",
                "timestamp");

        var ayriSkorVar =
            Var(
                "FTHG",
                "HomeGoals",
                "Home Score",
                "home_team_goal_count",
                "home_score") &&
            Var(
                "FTAG",
                "AwayGoals",
                "Away Score",
                "away_team_goal_count",
                "away_score");

        var birlesikSkorVar =
            Var(
                "FT",
                "Score",
                "FullTime",
                "Full Time",
                "result");

        if (!takimlarVar)
        {
            throw new InvalidOperationException(
                "CSV takım kolonları bulunamadı. " +
                "Desteklenen örnekler: " +
                "HomeTeam/AwayTeam veya Team 1/Team 2.");
        }

        if (!tarihVar)
        {
            throw new InvalidOperationException(
                "CSV tarih kolonu bulunamadı.");
        }

        if (!ayriSkorVar && !birlesikSkorVar)
        {
            throw new InvalidOperationException(
                "CSV skor kolonları bulunamadı. " +
                "Desteklenen örnekler: " +
                "FTHG/FTAG veya FT.");
        }
    }

    private static int? ParseNullable(
        string value)
    {
        return int.TryParse(
            value,
            NumberStyles.Integer,
            CultureInfo.InvariantCulture,
            out var number)
                ? number
                : null;
    }

    private static bool SkorCoz(
        string value,
        out int evGol,
        out int depGol)
    {
        evGol = 0;
        depGol = 0;

        if (string.IsNullOrWhiteSpace(value))
            return false;

        var temiz = value
            .Trim()
            .Replace('–', '-')
            .Replace('—', '-')
            .Replace(':', '-');

        var match = Regex.Match(
            temiz,
            @"(?<!\d)(\d{1,2})\s*-\s*(\d{1,2})(?!\d)");

        if (!match.Success)
            return false;

        evGol = int.Parse(
            match.Groups[1].Value,
            CultureInfo.InvariantCulture);

        depGol = int.Parse(
            match.Groups[2].Value,
            CultureInfo.InvariantCulture);

        return true;
    }

    private static string TakimAdiniTemizle(
        string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var temiz = value.Trim();

        temiz = Regex.Replace(
            temiz,
            @"\s*[›>]\s*[A-Z]{2,4}.*$",
            string.Empty,
            RegexOptions.IgnoreCase);

        temiz = Regex.Replace(
            temiz,
            @"\s*\([A-Z]{2,4}(?:\s*\d+)?\)\s*$",
            string.Empty,
            RegexOptions.IgnoreCase);

        return temiz.Trim();
    }

    private static string DosyadanLigKoduBul(
        string dosyaAdi)
    {
        var ad = Path
            .GetFileNameWithoutExtension(dosyaAdi)
            .ToLowerInvariant();

        if (ad.Contains("champ") ||
            ad.Contains("ucl"))
        {
            return "UCL";
        }

        if (ad.Contains("eng.1") ||
            ad.Contains("premier"))
        {
            return "E0";
        }

        if (ad.Contains("eng.2") ||
            ad.Contains("championship"))
        {
            return "E1";
        }

        if (ad.Contains("de.1") ||
            ad.Contains("bundesliga"))
        {
            return "D1";
        }

        if (ad.Contains("es.1") ||
            ad.Contains("laliga") ||
            ad.Contains("primera"))
        {
            return "SP1";
        }

        return Path
            .GetFileNameWithoutExtension(dosyaAdi)
            .Split('_', StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault()
            ?? "HIST";
    }

    private static DateTime? TarihCoz(
        string tarih,
        string saat)
    {
        if (string.IsNullOrWhiteSpace(tarih))
            return null;

        var temizTarih = tarih.Trim();

        // UCL arşiv tarihleri:
        // (Wed) 7 Sep 1955 (W36)
        // (Sun) 4 Sep 1955 (W35)
        temizTarih = Regex.Replace(
            temizTarih,
            @"^\s*\([A-Za-z]{3,9}\)\s*",
            string.Empty);

        temizTarih = Regex.Replace(
            temizTarih,
            @"\s*\(W\d{1,2}\)\s*$",
            string.Empty,
            RegexOptions.IgnoreCase);

        temizTarih = Regex.Replace(
            temizTarih,
            @"\s+",
            " ").Trim();

        var metin = string.IsNullOrWhiteSpace(saat)
            ? temizTarih
            : $"{temizTarih} {saat.Trim()}";

        var formatlar = new[]
        {
            // Football-data klasik biçimleri
            "dd/MM/yy",
            "dd/MM/yyyy",
            "d/M/yy",
            "d/M/yyyy",
            "dd/MM/yy HH:mm",
            "dd/MM/yyyy HH:mm",
            "d/M/yy HH:mm",
            "d/M/yyyy HH:mm",

            // ISO ve ABD biçimleri
            "yyyy-MM-dd",
            "yyyy-MM-dd HH:mm",
            "MM/dd/yyyy",
            "MM/dd/yyyy HH:mm",

            // UCL/OpenFootball İngilizce ay biçimleri
            "d MMM yyyy",
            "dd MMM yyyy",
            "d MMMM yyyy",
            "dd MMMM yyyy",
            "d MMM yyyy HH:mm",
            "dd MMM yyyy HH:mm",
            "d MMMM yyyy HH:mm",
            "dd MMMM yyyy HH:mm"
        };

        var cultures = new[]
        {
            CultureInfo.InvariantCulture,
            CultureInfo.GetCultureInfo("en-US"),
            CultureInfo.GetCultureInfo("en-GB"),
            CultureInfo.GetCultureInfo("tr-TR")
        };

        foreach (var culture in cultures)
        {
            if (DateTime.TryParseExact(
                    metin,
                    formatlar,
                    culture,
                    DateTimeStyles.AllowWhiteSpaces |
                    DateTimeStyles.AssumeLocal,
                    out var exact))
            {
                return exact.ToUniversalTime();
            }
        }

        foreach (var culture in cultures)
        {
            if (DateTime.TryParse(
                    metin,
                    culture,
                    DateTimeStyles.AllowWhiteSpaces |
                    DateTimeStyles.AssumeLocal,
                    out var parsed))
            {
                return parsed.ToUniversalTime();
            }
        }

        return null;
    }

    private static string SezonBul(string dosyaAdi, DateTime tarih)
    {
        var match = Regex.Match(dosyaAdi, @"(?<!\d)(\d{2})(\d{2})(?!\d)");
        if (match.Success)
        {
            var bas = 2000 + int.Parse(match.Groups[1].Value);
            var bit = 2000 + int.Parse(match.Groups[2].Value);
            return $"{bas}-{bit}";
        }
        var yil = tarih.Month >= 7 ? tarih.Year : tarih.Year - 1;
        return $"{yil}-{yil + 1}";
    }

    private static char AyiriciBul(string baslik) =>
        baslik.Count(x => x == ';') > baslik.Count(x => x == ',') ? ';' : ',';

    private static List<string> CsvSatiriCoz(string satir, char ayirici)
    {
        var sonuc = new List<string>();
        var buffer = new StringBuilder();
        var tirnak = false;
        for (var i = 0; i < satir.Length; i++)
        {
            var c = satir[i];
            if (c == '"')
            {
                if (tirnak && i + 1 < satir.Length && satir[i + 1] == '"')
                { buffer.Append('"'); i++; }
                else tirnak = !tirnak;
            }
            else if (c == ayirici && !tirnak)
            { sonuc.Add(buffer.ToString()); buffer.Clear(); }
            else buffer.Append(c);
        }
        sonuc.Add(buffer.ToString());
        return sonuc;
    }

    private static string Normalize(string value)
    {
        var formD = value.Trim().ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var chars = formD.Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark).ToArray();
        var text = new string(chars).Normalize(NormalizationForm.FormC);
        text = Regex.Replace(text, @"\b(fc|fk|cf|afc|sc|sk|club|football|futbol)\b", " ");
        return Regex.Replace(text, @"[^a-z0-9]+", string.Empty);
    }

    private static string LigKey(string ad, string? sezon) => $"{Normalize(ad)}|{sezon?.Trim()}";
    private static string MacKey(int evId, int depId, DateTime tarih) => $"{evId}|{depId}|{tarih:yyyyMMdd}";

    private void KlasorleriHazirla()
    {
        Directory.CreateDirectory(InboxPath);
        Directory.CreateDirectory(ProcessedPath);
        Directory.CreateDirectory(FailedPath);
    }

    private void DosyayiTasi(string dosya, bool basarili)
    {
        if (!_options.BasariliDosyayiTasi && basarili) return;
        var hedefKlasor = basarili ? ProcessedPath : FailedPath;
        var hedef = Path.Combine(hedefKlasor,
            $"{DateTime.Now:yyyyMMdd_HHmmss}_{Path.GetFileName(dosya)}");
        File.Move(dosya, hedef, true);
    }

    private string RootPath => Path.IsPathRooted(_options.RootFolder)
        ? _options.RootFolder
        : Path.Combine(_environment.ContentRootPath, _options.RootFolder);
    private string InboxPath => Path.Combine(RootPath, _options.InboxFolder);
    private string ProcessedPath => Path.Combine(RootPath, _options.ProcessedFolder);
    private string FailedPath => Path.Combine(RootPath, _options.FailedFolder);

    private sealed class CsvMac
    {
        public string Div { get; set; } = string.Empty;
        public string Sezon { get; set; } = string.Empty;
        public DateTime Tarih { get; set; }
        public string EvSahibi { get; set; } = string.Empty;
        public string Deplasman { get; set; } = string.Empty;
        public int EvGol { get; set; }
        public int DepGol { get; set; }
        public int? IlkYariEvGol { get; set; }
        public int? IlkYariDepGol { get; set; }
        public Lig? Lig { get; set; }
        public Takim? EvTakim { get; set; }
        public Takim? DepTakim { get; set; }
    }
}