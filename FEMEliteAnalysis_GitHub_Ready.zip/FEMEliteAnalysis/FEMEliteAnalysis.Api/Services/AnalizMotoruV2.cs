using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class AnalizMotoruV2 : IAnalizMotoruV2
{
    private readonly IKuponMarketMotoru _marketMotoru;
    private readonly AnalizMotoruOptions _options;

    public AnalizMotoruV2(IKuponMarketMotoru marketMotoru, IOptions<AnalizMotoruOptions> options)
    {
        _marketMotoru = marketMotoru;
        _options = options.Value;
    }

    public AnalizMotoruV2SonucDto AnalizEt(MacKuponVerisiDto veri)
    {
        ArgumentNullException.ThrowIfNull(veri);

        var marketAnalizi = _marketMotoru.AnalizEt(veri);
        MarketleriKalibreEt(marketAnalizi.Marketler, veri);

        var evTrend = FormTrendiHesapla(veri.EvSahibi, veri.EvSahibiGenelForm);
        var depTrend = FormTrendiHesapla(veri.Deplasman, veri.DeplasmanGenelForm);

        var kategoriler = new List<AnalizKategoriSkoruDto>
        {
            FormKategorisi(veri),
            SahaPerformansiKategorisi(veri),
            GolUretimiKategorisi(veri),
            SavunmaKategorisi(veri),
            H2HKategorisi(veri),
            MomentumKategorisi(evTrend, depTrend)
        };

        var evToplam = AgirlikliTakimPuani(kategoriler, true);
        var depToplam = AgirlikliTakimPuani(kategoriler, false);
        var gucFarki = Math.Abs(evToplam - depToplam);

        var pozitifFaktorler = PozitifFaktorleriOlustur(veri, kategoriler, evTrend, depTrend);
        var riskFaktorleri = RiskFaktorleriniOlustur(veri, marketAnalizi, evToplam, depToplam, evTrend, depTrend);

        var enGucluAdaylar = CesitliMarketleriSec(
            marketAnalizi.Marketler.Where(x =>
                x.GuvenPuani >= _options.AnaMarketMinimumGuven &&
                !x.UzakDurMu &&
                !x.SurprizMi &&
                AnaListeyeUygunMu(x)), 3);

        var secilenKodlar = enGucluAdaylar.Select(x => x.Kod)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var alternatifAdaylar = CesitliMarketleriSec(
            marketAnalizi.Marketler.Where(x =>
                x.GuvenPuani >= _options.AlternatifMinimumGuven &&
                !x.UzakDurMu &&
                !secilenKodlar.Contains(x.Kod) &&
                AlternatifListeyeUygunMu(x)), 5);

        var uzakDurulacaklar = marketAnalizi.Marketler
            .Where(x => x.GuvenPuani <= _options.UzakDurMaksimumGuven || x.UzakDurMu)
            .OrderBy(x => x.GuvenPuani)
            .Take(4)
            .ToList();

        var genelGuven = GenelGuvenPuaniHesapla(veri.VeriKalitesiPuani, enGucluAdaylar, riskFaktorleri.Count, gucFarki);
        var breakdown = GuvenDagilimiOlustur(veri, kategoriler, enGucluAdaylar, riskFaktorleri.Count);

        return new AnalizMotoruV2SonucDto
        {
            MacId = veri.MacId,
            EvSahibi = veri.EvSahibi,
            Deplasman = veri.Deplasman,
            VeriKalitesiPuani = veri.VeriKalitesiPuani,
            GenelGuvenPuani = genelGuven,
            GenelRiskSeviyesi = RiskBelirle(genelGuven, veri.VeriKalitesiPuani, gucFarki),
            MacProfili = MacProfiliBelirle(veri, evTrend, depTrend),
            Kategoriler = kategoriler,
            Marketler = marketAnalizi.Marketler.OrderByDescending(x => x.GuvenPuani).ToList(),
            EnGucluAdaylar = enGucluAdaylar,
            AlternatifAdaylar = alternatifAdaylar,
            UzakDurulacaklar = uzakDurulacaklar,
            PozitifFaktorler = pozitifFaktorler,
            RiskFaktorleri = riskFaktorleri,
            VeriEksikleri = veri.VeriEksikleri,
            EvSahibiFormTrendi = evTrend,
            DeplasmanFormTrendi = depTrend,
            GuvenDagilimi = breakdown,
            EvSahibiGucPuani = Math.Clamp((int)Math.Round(evToplam), 0, 100),
            DeplasmanGucPuani = Math.Clamp((int)Math.Round(depToplam), 0, 100)
        };
    }

    private void MarketleriKalibreEt(List<KuponMarketSkoruDto> marketler, MacKuponVerisiDto veri)
    {
        var genelOrneklem = Math.Min(veri.EvSahibiGenelForm.ToplamMac, veri.DeplasmanGenelForm.ToplamMac);
        var sahaOrneklem = Math.Min(veri.EvSahibiIcSahaForm.ToplamMac, veri.DeplasmanDisSahaForm.ToplamMac);
        var orneklemKatsayisi = Math.Clamp((genelOrneklem / 20m * 0.6m) + (sahaOrneklem / 10m * 0.4m), 0.35m, 1m);
        var kaliteKatsayisi = Math.Clamp(veri.VeriKalitesiPuani / 100m, 0.45m, 1m);

        foreach (var market in marketler)
        {
            var ham = market.GuvenPuani;
            market.HamGuvenPuani = ham;
            var kalibre = 50m + (ham - 50m) * orneklemKatsayisi * kaliteKatsayisi;

            if (market.Kod.Contains('/', StringComparison.OrdinalIgnoreCase))
                kalibre -= 5m;

            if (market.SurprizMi)
                kalibre -= 3m;

            if (market.OrneklemSayisi <= 0)
                market.OrneklemSayisi = Math.Min(genelOrneklem, 20);
            market.GuvenPuani = Math.Clamp((int)Math.Round(kalibre), 0, _options.MaksimumGuven);
            market.ModelOlasiligi = Math.Round(market.GuvenPuani / 100m, 4);
            market.OneriliyorMu = market.GuvenPuani >= _options.OneriMinimumGuven && !market.UzakDurMu;
            market.RiskSeviyesi = market.GuvenPuani switch
            {
                >= 78 => "Düşük",
                >= 64 => "Orta",
                >= 50 => "Yüksek",
                _ => "Çok Yüksek"
            };

            if (genelOrneklem < 10)
                market.Gerekceler.Add($"Örneklem sınırlı: {genelOrneklem} ortak form maçı.");
        }
    }

    private static bool AnaListeyeUygunMu(KuponMarketSkoruDto market)
    {
        if (market.Kategori.Equals("Korner", StringComparison.OrdinalIgnoreCase) ||
            market.Kategori.Equals("Kart", StringComparison.OrdinalIgnoreCase))
            return false;

        // Çok düşük oran üretme eğilimindeki marketler ana öneriyi işgal etmesin.
        if (DusukOranProfilMi(market.Kod))
            return false;

        // İY X ve İY 1.5 Alt yüksek ham puan üretip listeyi sürekli ele geçiriyordu.
        if (market.Kod is "İY X" or "İY 1.5 ALT")
            return false;

        if (market.Kod.Contains('/', StringComparison.OrdinalIgnoreCase))
            return false;

        return true;
    }

    private static bool AlternatifListeyeUygunMu(KuponMarketSkoruDto market)
    {
        if (DusukOranProfilMi(market.Kod))
            return false;

        if (market.Kategori.Equals("Korner", StringComparison.OrdinalIgnoreCase) ||
            market.Kategori.Equals("Kart", StringComparison.OrdinalIgnoreCase))
            return market.OrneklemSayisi >= 10 && market.GuvenPuani >= 64;

        if (market.Kod is "İY X" or "İY 1.5 ALT")
            return market.GuvenPuani >= 82;

        return true;
    }

    private static bool DusukOranProfilMi(string kod) => kod is
        "EV 0.5 ÜST" or "DEP 0.5 ÜST" or "4.5 ALT" or "İY 2.5 ALT";

    private decimal AgirlikliTakimPuani(IEnumerable<AnalizKategoriSkoruDto> kategoriler, bool ev)
    {
        return kategoriler.Sum(x =>
            (ev ? x.EvSahibiPuani : x.DeplasmanPuani) *
            _options.Agirliklar.GetValueOrDefault(x.Kod, 0m));
    }

    private static AnalizKategoriSkoruDto FormKategorisi(MacKuponVerisiDto veri) => new()
    {
        Kod = "FORM",
        Ad = "Ağırlıklı Genel Form",
        EvSahibiPuani = AgirlikliFormPuani(veri.EvSahibiGenelForm),
        DeplasmanPuani = AgirlikliFormPuani(veri.DeplasmanGenelForm),
        Aciklama = $"{veri.EvSahibi}: {FormMetni(veri.EvSahibiGenelForm)} | {veri.Deplasman}: {FormMetni(veri.DeplasmanGenelForm)}"
    };

    private AnalizKategoriSkoruDto SahaPerformansiKategorisi(MacKuponVerisiDto veri) => new()
    {
        Kod = "SAHA",
        Ad = "İç/Dış Saha Performansı",
        EvSahibiPuani = Math.Clamp(AgirlikliFormPuani(veri.EvSahibiIcSahaForm) + (int)Math.Round(_options.VarsayilanEvSahibiAvantaji), 0, 100),
        DeplasmanPuani = AgirlikliFormPuani(veri.DeplasmanDisSahaForm),
        Aciklama = $"{veri.EvSahibi} iç saha: {FormMetni(veri.EvSahibiIcSahaForm)} | {veri.Deplasman} dış saha: {FormMetni(veri.DeplasmanDisSahaForm)}"
    };

    private static AnalizKategoriSkoruDto GolUretimiKategorisi(MacKuponVerisiDto veri)
    {
        var ev = veri.EvSahibiGenelForm.MacBasinaGol * 0.35m + veri.EvSahibiIcSahaForm.MacBasinaGol * 0.65m;
        var dep = veri.DeplasmanGenelForm.MacBasinaGol * 0.35m + veri.DeplasmanDisSahaForm.MacBasinaGol * 0.65m;
        return new AnalizKategoriSkoruDto { Kod = "HUCUM", Ad = "Gol Üretimi", EvSahibiPuani = GolPuani(ev), DeplasmanPuani = GolPuani(dep), Aciklama = $"Ağırlıklı gol ortalaması: {veri.EvSahibi} {ev:0.00} | {veri.Deplasman} {dep:0.00}" };
    }

    private static AnalizKategoriSkoruDto SavunmaKategorisi(MacKuponVerisiDto veri)
    {
        var ev = veri.EvSahibiGenelForm.MacBasinaYenilenGol * 0.35m + veri.EvSahibiIcSahaForm.MacBasinaYenilenGol * 0.65m;
        var dep = veri.DeplasmanGenelForm.MacBasinaYenilenGol * 0.35m + veri.DeplasmanDisSahaForm.MacBasinaYenilenGol * 0.65m;
        return new AnalizKategoriSkoruDto { Kod = "SAVUNMA", Ad = "Savunma Gücü", EvSahibiPuani = SavunmaPuani(ev), DeplasmanPuani = SavunmaPuani(dep), Aciklama = $"Ağırlıklı yenilen gol: {veri.EvSahibi} {ev:0.00} | {veri.Deplasman} {dep:0.00}" };
    }

    private static AnalizKategoriSkoruDto H2HKategorisi(MacKuponVerisiDto veri)
    {
        if (veri.H2H.ToplamMac == 0)
            return new AnalizKategoriSkoruDto { Kod = "H2H", Ad = "İkili Rekabet", EvSahibiPuani = 50, DeplasmanPuani = 50, Aciklama = "Yeterli H2H verisi bulunmuyor." };

        var guven = Math.Clamp(veri.H2H.ToplamMac / 8m, 0m, 1m);
        var evHam = veri.H2H.Takim1Galibiyet / (decimal)veri.H2H.ToplamMac * 100m;
        var depHam = veri.H2H.Takim2Galibiyet / (decimal)veri.H2H.ToplamMac * 100m;
        return new AnalizKategoriSkoruDto
        {
            Kod = "H2H", Ad = "İkili Rekabet",
            EvSahibiPuani = (int)Math.Round(50m + (evHam - 50m) * guven),
            DeplasmanPuani = (int)Math.Round(50m + (depHam - 50m) * guven),
            Aciklama = $"Son {veri.H2H.ToplamMac}: {veri.EvSahibi} {veri.H2H.Takim1Galibiyet}G, {veri.H2H.Beraberlik}B, {veri.Deplasman} {veri.H2H.Takim2Galibiyet}G"
        };
    }

    private static AnalizKategoriSkoruDto MomentumKategorisi(FormTrendDto ev, FormTrendDto dep) => new()
    {
        Kod = "MOMENTUM", Ad = "Form İvmesi",
        EvSahibiPuani = TrendPuani(ev.Degisim),
        DeplasmanPuani = TrendPuani(dep.Degisim),
        Aciklama = $"{ev.Aciklama} | {dep.Aciklama}"
    };

    private static int AgirlikliFormPuani(TakimGecmisVerisiDto form)
    {
        var maclar = form.Maclar.OrderByDescending(x => x.MacTarihi).Take(20).ToList();
        if (maclar.Count == 0) return 0;

        decimal toplam = 0, agirlikToplam = 0;
        for (var i = 0; i < maclar.Count; i++)
        {
            var agirlik = Math.Max(0.25m, 1m - i * 0.04m);
            var m = maclar[i];
            var sonuc = m.KazandiMi ? 3m : m.BerabereMi ? 1m : 0m;
            var atilan = m.TakimEvSahibiMi ? m.EvSahibiGol : m.DeplasmanGol;
            var yenilen = m.TakimEvSahibiMi ? m.DeplasmanGol : m.EvSahibiGol;
            var averaj = Math.Clamp((atilan - yenilen) * 0.15m, -0.45m, 0.45m);
            toplam += (sonuc + averaj) * agirlik;
            agirlikToplam += 3m * agirlik;
        }
        return Math.Clamp((int)Math.Round(toplam / agirlikToplam * 100m), 0, 100);
    }

    private static FormTrendDto FormTrendiHesapla(string takimAdi, TakimGecmisVerisiDto form)
    {
        var maclar = form.Maclar.OrderByDescending(x => x.MacTarihi).ToList();
        var son = GrupFormPuani(maclar.Take(5));
        var onceki = GrupFormPuani(maclar.Skip(5).Take(5));
        var degisim = son - onceki;
        var trend = degisim >= 0.35m ? "Yükseliş" : degisim <= -0.35m ? "Düşüş" : "Dengeli";
        return new FormTrendDto { TakimAdi = takimAdi, SonBesMacPuani = son, OncekiBesMacPuani = onceki, Degisim = degisim, Trend = trend, Aciklama = $"{takimAdi}: {trend} ({degisim:+0.00;-0.00;0.00})" };
    }

    private static decimal GrupFormPuani(IEnumerable<TakimGecmisMacDto> kaynak)
    {
        var maclar = kaynak.ToList();
        if (maclar.Count == 0) return 0;
        return maclar.Average(x => x.KazandiMi ? 3m : x.BerabereMi ? 1m : 0m);
    }

    private static int TrendPuani(decimal degisim) => Math.Clamp((int)Math.Round(50m + degisim * 18m), 10, 90);

    private static List<string> PozitifFaktorleriOlustur(MacKuponVerisiDto veri, IReadOnlyCollection<AnalizKategoriSkoruDto> kategoriler, FormTrendDto evTrend, FormTrendDto depTrend)
    {
        var liste = new List<string>();
        foreach (var k in kategoriler.OrderByDescending(x => Math.Abs(x.EvSahibiPuani - x.DeplasmanPuani)).Take(2))
        {
            var taraf = k.EvSahibiPuani >= k.DeplasmanPuani ? veri.EvSahibi : veri.Deplasman;
            liste.Add($"{k.Ad}: {taraf} önde ({Math.Max(k.EvSahibiPuani, k.DeplasmanPuani)}/100). ");
        }
        if (evTrend.Trend == "Yükseliş") liste.Add(evTrend.Aciklama);
        if (depTrend.Trend == "Yükseliş") liste.Add(depTrend.Aciklama);
        if (veri.H2H.ToplamMac >= 3 && veri.H2H.IkiBucukUstYuzdesi >= 65) liste.Add($"H2H 2.5 üst oranı %{veri.H2H.IkiBucukUstYuzdesi:0.#}.");
        if (veri.H2H.ToplamMac >= 3 && veri.H2H.KarsilikliGolYuzdesi >= 65) liste.Add($"H2H KG Var oranı %{veri.H2H.KarsilikliGolYuzdesi:0.#}.");
        return liste.Distinct(StringComparer.OrdinalIgnoreCase).Take(7).ToList();
    }

    private static List<string> RiskFaktorleriniOlustur(MacKuponVerisiDto veri, KuponMarketAnaliziDto market, decimal ev, decimal dep, FormTrendDto evTrend, FormTrendDto depTrend)
    {
        var liste = new List<string>();
        if (veri.VeriKalitesiPuani < 60) liste.Add($"Veri kalitesi sınırlı: %{veri.VeriKalitesiPuani}.");
        if (Math.Abs(ev - dep) < 8m) liste.Add("Takım güçleri çok yakın; maç sonucu marketi riskli.");
        if (veri.H2H.ToplamMac < 3) liste.Add("H2H örneklemi üç maçın altında.");
        if (veri.EvSahibiGenelForm.ToplamMac < 10 || veri.DeplasmanGenelForm.ToplamMac < 10) liste.Add("Takımlardan en az birinin genel form örneklemi 10 maçın altında.");
        if (evTrend.Trend == "Düşüş") liste.Add($"{veri.EvSahibi} son beş maçta düşüş eğiliminde.");
        if (depTrend.Trend == "Düşüş") liste.Add($"{veri.Deplasman} son beş maçta düşüş eğiliminde.");
        if (market.Marketler.Count(x => x.GuvenPuani >= 65 && !x.UzakDurMu) < 2) liste.Add("Birbirini destekleyen güçlü market sayısı düşük.");
        return liste.Distinct(StringComparer.OrdinalIgnoreCase).Take(7).ToList();
    }

    private static List<GuvenBileseniDto> GuvenDagilimiOlustur(MacKuponVerisiDto veri, IReadOnlyCollection<AnalizKategoriSkoruDto> kategoriler, IReadOnlyCollection<KuponMarketSkoruDto> adaylar, int riskSayisi)
    {
        int Kat(string kod) => kategoriler.First(x => x.Kod == kod).EvSahibiPuani + kategoriler.First(x => x.Kod == kod).DeplasmanPuani;
        var market = adaylar.Select(x => x.GuvenPuani).DefaultIfEmpty(0).Max();
        return new List<GuvenBileseniDto>
        {
            new() { Ad = "Veri Kalitesi", Puan = (int)Math.Round(veri.VeriKalitesiPuani * 0.20m), Maksimum = 20 },
            new() { Ad = "Form ve Saha", Puan = Math.Clamp((int)Math.Round((Kat("FORM") + Kat("SAHA")) / 400m * 30m), 0, 30), Maksimum = 30 },
            new() { Ad = "Hücum ve Savunma", Puan = Math.Clamp((int)Math.Round((Kat("HUCUM") + Kat("SAVUNMA")) / 400m * 22m), 0, 22), Maksimum = 22 },
            new() { Ad = "H2H ve Momentum", Puan = Math.Clamp((int)Math.Round((Kat("H2H") + Kat("MOMENTUM")) / 400m * 12m), 0, 12), Maksimum = 12 },
            new() { Ad = "En Güçlü Market", Puan = Math.Clamp((int)Math.Round(market / 100m * 16m) - riskSayisi, 0, 16), Maksimum = 16 }
        };
    }

    private static List<KuponMarketSkoruDto> CesitliMarketleriSec(IEnumerable<KuponMarketSkoruDto> kaynak, int maksimum)
    {
        var sirali = kaynak
            .OrderByDescending(OynanabilirlikSkoru)
            .ThenByDescending(x => x.GuvenPuani)
            .ThenBy(x => x.SurprizMi)
            .ToList();
        var sonuc = new List<KuponMarketSkoruDto>();
        var aileler = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var m in sirali)
        {
            if (sonuc.Count >= maksimum) break;
            if (sonuc.Any(x => MarketlerCakisiyor(x.Kod, m.Kod))) continue;
            var aile = MarketAilesi(m.Kod);
            if (aileler.Contains(aile)) continue;
            sonuc.Add(m); aileler.Add(aile);
        }
        foreach (var m in sirali)
        {
            if (sonuc.Count >= maksimum) break;
            if (sonuc.Any(x => x.Kod.Equals(m.Kod, StringComparison.OrdinalIgnoreCase) || MarketlerCakisiyor(x.Kod, m.Kod))) continue;
            sonuc.Add(m);
        }
        return sonuc;
    }

    private static string MarketAilesi(string kod)
    {
        if (kod.Contains(" + ", StringComparison.OrdinalIgnoreCase))
        {
            if (kod.StartsWith("MS1", StringComparison.OrdinalIgnoreCase)) return "KOMBINE_MS1";
            if (kod.StartsWith("MS2", StringComparison.OrdinalIgnoreCase)) return "KOMBINE_MS2";
            if (kod.StartsWith("X ", StringComparison.OrdinalIgnoreCase)) return "KOMBINE_X";
            if (kod.StartsWith("1X", StringComparison.OrdinalIgnoreCase)) return "KOMBINE_1X";
            if (kod.StartsWith("X2", StringComparison.OrdinalIgnoreCase)) return "KOMBINE_X2";
            if (kod.StartsWith("İY", StringComparison.OrdinalIgnoreCase)) return "KOMBINE_IY";
            return "KOMBINE";
        }

        if (kod.Contains('/')) return "IYMS";
        if (kod.StartsWith("İY ", StringComparison.OrdinalIgnoreCase)) return "ILK_YARI";
        if (kod is "MS1" or "MSX" or "MS2" or "1X" or "X2" or "12") return "SONUC";
        if (kod.Contains("KG", StringComparison.OrdinalIgnoreCase)) return "KG";
        if (kod.StartsWith("EV ", StringComparison.OrdinalIgnoreCase) || kod.StartsWith("DEP ", StringComparison.OrdinalIgnoreCase)) return "TAKIM_GOL";
        if (kod.Contains("ÜST", StringComparison.OrdinalIgnoreCase) || kod.Contains("ALT", StringComparison.OrdinalIgnoreCase)) return "GOL";
        return "DIGER";
    }

    private static int OynanabilirlikSkoru(KuponMarketSkoruDto market)
    {
        var bonus = market.Kategori.Equals("Kombine", StringComparison.OrdinalIgnoreCase) ? 7 : 0;

        if (market.Kod is "MS1" or "MS2" or "1X" or "X2" or "2.5 ÜST" or "2.5 ALT" or "KG VAR" or "KG YOK")
            bonus += 2;

        if (DusukOranProfilMi(market.Kod))
            bonus -= 15;

        if (market.SurprizMi)
            bonus -= 4;

        return market.GuvenPuani + bonus;
    }

    private static bool MarketlerCakisiyor(string a, string b)
    {
        var x = a.ToUpperInvariant(); var y = b.ToUpperInvariant();
        if (x == y) return true;
        if ((x == "MS1" && y is "MS2" or "X2") || (y == "MS1" && x is "MS2" or "X2")) return true;
        if ((x == "MS2" && y is "MS1" or "1X") || (y == "MS2" && x is "MS1" or "1X")) return true;
        if ((x.Contains("KG VAR") && y.Contains("KG YOK")) || (y.Contains("KG VAR") && x.Contains("KG YOK"))) return true;
        foreach (var cizgi in new[] { "1.5", "2.5", "3.5" })
            if ((x.Contains(cizgi + " ÜST") && y.Contains(cizgi + " ALT")) || (y.Contains(cizgi + " ÜST") && x.Contains(cizgi + " ALT"))) return true;
        return false;
    }

    private static int GenelGuvenPuaniHesapla(int kalite, IReadOnlyCollection<KuponMarketSkoruDto> adaylar, int risk, decimal gucFarki)
    {
        var en = adaylar.Select(x => x.GuvenPuani).DefaultIfEmpty(0).Max();
        if (en == 0) return Math.Clamp(kalite / 2, 0, 50);
        var puan = en * 0.62m + kalite * 0.25m + Math.Min(gucFarki, 25m) * 0.35m - risk * 2.5m;
        return Math.Clamp((int)Math.Round(puan), 0, 94);
    }

    private static string RiskBelirle(int guven, int kalite, decimal gucFarki)
    {
        if (kalite < 45) return "Çok Yüksek";
        if (gucFarki < 5m && guven < 75) return "Yüksek";
        return guven >= 80 ? "Düşük" : guven >= 65 ? "Orta" : guven >= 50 ? "Yüksek" : "Çok Yüksek";
    }

    private static string MacProfiliBelirle(MacKuponVerisiDto veri, FormTrendDto ev, FormTrendDto dep)
    {
        var gol = veri.EvSahibiIcSahaForm.MacBasinaGol + veri.DeplasmanDisSahaForm.MacBasinaGol;
        var kg = Ortalama(veri.EvSahibiIcSahaForm.KarsilikliGolYuzdesi, veri.DeplasmanDisSahaForm.KarsilikliGolYuzdesi, veri.H2H.KarsilikliGolYuzdesi);
        var formFarki = Math.Abs(AgirlikliFormPuani(veri.EvSahibiGenelForm) - AgirlikliFormPuani(veri.DeplasmanGenelForm));
        if (formFarki >= 30) return "Tek taraflı favori maçı";
        if (gol >= 3m && kg >= 58m) return "Açık ve gollü maç";
        if (gol <= 1.8m && kg <= 45m) return "Kontrollü ve düşük skorlu maç";
        if (ev.Trend == "Düşüş" && dep.Trend == "Düşüş") return "Form riski yüksek maç";
        if (formFarki <= 10) return "Dengeli ve sonuç riski yüksek maç";
        return "Orta dengeli maç";
    }

    private static int GolPuani(decimal ort) => Math.Clamp((int)Math.Round(ort / 2.5m * 100m), 0, 100);
    private static int SavunmaPuani(decimal ort) => Math.Clamp(100 - (int)Math.Round(ort / 2.5m * 100m), 0, 100);
    private static string FormMetni(TakimGecmisVerisiDto f) => $"{f.ToplamMac} maç, {f.Galibiyet}G {f.Beraberlik}B {f.Maglubiyet}M";
    private static decimal Ortalama(params decimal[] d) { var x = d.Where(v => v > 0).ToArray(); return x.Length == 0 ? 0 : x.Average(); }
}
