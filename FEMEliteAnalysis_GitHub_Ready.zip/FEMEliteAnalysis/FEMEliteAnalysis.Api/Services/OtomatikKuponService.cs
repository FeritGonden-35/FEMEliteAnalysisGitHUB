using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

/// <summary>
/// /otomatikkupon MOD ADET akışı:
/// DB maçları -> yerel kalite shortlist -> tek sağlayıcıdan gerçek oran -> analiz -> farklı kuponlar -> SQL kayıt.
/// </summary>
public class OtomatikKuponService : IOtomatikKuponService
{
    private readonly FemDbContext _db;
    private readonly IUygunMacService _uygunMac;
    private readonly ISqlTakimFormService _form;
    private readonly IAnalizMotoruV2 _motor;
    private readonly IOddsApiService _odds;
    private readonly IAnalizService _analiz;
    private readonly IHedefKuponService _hedef;
    private readonly IKuponKaliciService _kalici;

    public OtomatikKuponService(FemDbContext db, IUygunMacService uygunMac, ISqlTakimFormService form, IAnalizMotoruV2 motor,
        IOddsApiService odds, IAnalizService analiz, IHedefKuponService hedef, IKuponKaliciService kalici)
    { _db=db; _uygunMac=uygunMac; _form=form; _motor=motor; _odds=odds; _analiz=analiz; _hedef=hedef; _kalici=kalici; }

    public async Task<ServiceResult<OtomatikKuponSonucDto>> OlusturAsync(long adminTelegramId, string mod, int adet, CancellationToken ct)
    {
        mod = Mod(mod);
        if (mod.Length == 0) return ServiceResult<OtomatikKuponSonucDto>.BasarisizSonuc("Mod: dusuk, orta veya yuksek olmalı.");
        adet = Math.Clamp(adet, 1, 20);
        var minGuven = mod == "dusuk" ? 74 : mod == "orta" ? 64 : 52;
        var uygun = await _uygunMac.UygunMaclariGetirAsync(3, 100, ct);
        if (!uygun.Basarili || uygun.Veri is null || uygun.Veri.Count == 0)
            return ServiceResult<OtomatikKuponSonucDto>.BasarisizSonuc("/uygunmaclar kriterlerini geçen maç bulunamadı.");
        var maclar = uygun.Veri;

        var local = new List<(int MacId,int Score)>();
        foreach (var mac in maclar)
        {
            var v = await _form.MacKuponVerisiOlusturAsync(mac.MacId, ct);
            if (!v.Basarili || v.Veri is null) continue;
            try
            {
                var m = _motor.AnalizEt(v.Veri);
                if (m.VeriKalitesiPuani < 55 || m.GenelGuvenPuani < minGuven) continue;
                var oynanabilir = m.Marketler.Where(x=>!x.UzakDurMu && x.GuvenPuani>=minGuven-5).OrderByDescending(x=>x.GuvenPuani).FirstOrDefault();
                if (oynanabilir is null) continue;
                local.Add((mac.MacId, m.GenelGuvenPuani*2 + m.VeriKalitesiPuani + oynanabilir.GuvenPuani + mac.VeriGuvenPuani));
            }
            catch { /* tek maç motor hatası tüm otomatik akışı durdurmasın */ }
        }

        if (local.Count < 2) return ServiceResult<OtomatikKuponSonucDto>.BasarisizSonuc("Bugün otomatik kupon için yeterli kaliteli maç bulunamadı.");

        // Kupon adedi artsa bile odds quota'yı koru. Aynı shortlist'ten çok sayıda farklı kombinasyon üretilebilir.
        var shortlistCount = Math.Min(12, Math.Max(6, adet + 5));
        var shortlist = local.OrderByDescending(x=>x.Score).Take(shortlistCount).Select(x=>x.MacId).ToList();
        var sync = await _odds.HavuzOranlariniCekAsync(shortlist, ct);
        var realIds = sync.Where(x=>x.KaydedilenOran>0 || x.Mesaj.Contains("cache",StringComparison.OrdinalIgnoreCase)).Select(x=>x.MacId).Distinct().ToList();
        if (realIds.Count < 2)
        {
            var detay = string.Join(" | ", sync.Take(4).Select(x=>$"{x.MacAdi}: {x.Mesaj}"));
            return ServiceResult<OtomatikKuponSonucDto>.BasarisizSonuc($"Gerçek oran bulunan yeterli maç yok. {detay}");
        }

        // Oran geldikten sonra analiz oluştur/güncelle; analiz metni de gerçek piyasa değerini görebilsin.
        foreach (var id in realIds)
            await _analiz.AnalizOlusturAsync(new AnalizOlusturRequest { MacId=id, AnalizTuru="Otomatik Kupon", KullaniciTahmini="" }, ct);

        var gen = await _hedef.CokluOlusturAsync(mod, Math.Min(20, adet*3), realIds, ct);
        if (!gen.Basarili || gen.Veri is null || gen.Veri.Count==0)
            return ServiceResult<OtomatikKuponSonucDto>.BasarisizSonuc(gen.Mesaj);

        var bugun = DateTime.UtcNow.Date;
        var mevcut = await _db.Kuponlar.AsNoTracking().Include(x=>x.Maclar)
            .Where(x=>x.AdminTelegramId==adminTelegramId && x.OlusturmaTarihi>=bugun && x.Baslik.StartsWith("FEM-AUTO-"))
            .ToListAsync(ct);
        var imzalar = mevcut.Select(k=>Imza(k.Maclar.Select(m=>(m.MacId,m.SecilenMarket)))).ToHashSet(StringComparer.OrdinalIgnoreCase);

        var sonuc = new OtomatikKuponSonucDto { Mod=mod, IstenenAdet=adet, IncelenenMac=maclar.Count, ShortlistMac=shortlist.Count, OddsApiIstek=sync.Sum(x=>x.ApiIstekSayisi), GercekOranliMac=realIds.Count };
        var no=1;
        foreach (var kupon in gen.Veri)
        {
            if (sonuc.Kuponlar.Count>=adet) break;
            // V5.1: aynı gerçek maç bir kupon içinde iki ayrı marketle tekrar edemez.
            if (kupon.Secimler.Select(x => x.MacId).Distinct().Count() != kupon.Secimler.Count) continue;
            var imza = Imza(kupon.Secimler.Select(x=>(x.MacId,x.Market)));
            if (!imzalar.Add(imza)) continue;

            var taslak = new CokluKuponTaslakDto { AdminTelegramId=adminTelegramId, Maclar=kupon.Secimler.Select(x=>new CokluKuponMacSecimiDto
            { MacId=x.MacId, AnalizId=x.AnalizId, EvSahibi=x.EvSahibi, Deplasman=x.Deplasman, SecilenMarket=$"{x.Market} @{x.Oran:0.00}", GuvenPuani=x.Guven, AktifMi=true }).ToList() };
            var baslik=$"FEM-AUTO-{mod.ToUpperInvariant()}-{DateTime.Now:yyyyMMdd}-{no:00}";
            var kayit=await _kalici.KaydetAsync(adminTelegramId,taslak,baslik,ct);
            if(!kayit.Basarili||kayit.Veri is null) continue;
            sonuc.Kuponlar.Add(new OtomatikKuponKayitDto { KuponId=kayit.Veri.Id, Baslik=kayit.Veri.Baslik, ToplamOran=kayit.Veri.ToplamOran??kupon.ToplamOran, OrtalamaGuven=kayit.Veri.OrtalamaGuvenPuani, SecimSayisi=kayit.Veri.Maclar.Count });
            no++;
        }
        sonuc.UretilenAdet=sonuc.Kuponlar.Count;
        if(sonuc.UretilenAdet==0) return ServiceResult<OtomatikKuponSonucDto>.BasarisizSonuc("Yeni ve benzersiz kupon üretilemedi; bugünkü mevcut kuponlarla aynı kombinasyonlar çıktı.");
        return ServiceResult<OtomatikKuponSonucDto>.BasariliSonuc(sonuc, sonuc.UretilenAdet<adet ? $"{adet} istendi; kalite/çeşitlilik kriterini geçen {sonuc.UretilenAdet} kupon kaydedildi." : $"{sonuc.UretilenAdet} farklı kupon kaydedildi.");
    }

    private static string Mod(string x)=>x.Trim().ToLowerInvariant() switch { "dusuk" or "düşük"=>"dusuk", "orta"=>"orta", "yuksek" or "yüksek"=>"yuksek", _=>"" };
    private static string Imza(IEnumerable<(int MacId,string Market)> x)=>string.Join("|",x.Select(a=>$"{a.MacId}:{N(a.Market)}").OrderBy(x=>x));
    private static string N(string x)=>string.Join(' ',x.ToUpperInvariant().Replace('İ','I').Replace('Ü','U').Split(' ',StringSplitOptions.RemoveEmptyEntries));
}
