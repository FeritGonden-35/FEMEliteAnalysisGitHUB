using System.Globalization;
using System.Text.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Lig;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public sealed class LigYonetimService : ILigYonetimService
{
    private readonly HttpClient _httpClient;
    private readonly FemDbContext _db;
    private readonly TheSportsDbOptions _options;
    private readonly ILogger<LigYonetimService> _logger;

    public LigYonetimService(HttpClient httpClient, FemDbContext db, IOptions<TheSportsDbOptions> options, ILogger<LigYonetimService> logger)
    {
        _httpClient = httpClient;
        _db = db;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<ServiceResult<List<LigAramaSonucuDto>>> LigAraAsync(string arama, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(arama) || arama.Trim().Length < 2)
            return ServiceResult<List<LigAramaSonucuDto>>.BasarisizSonuc("Lig araması en az 2 karakter olmalıdır.");

        try
        {
            using var doc = await GetJsonAsync("all_leagues.php", cancellationToken);
            if (!doc.RootElement.TryGetProperty("leagues", out var leagues) || leagues.ValueKind != JsonValueKind.Array)
                return ServiceResult<List<LigAramaSonucuDto>>.BasarisizSonuc("TheSportsDB lig listesi alınamadı.");

            var query = arama.Trim();
            var seasons = GetConfiguredSeasonYears();
            var list = leagues.EnumerateArray()
                .Where(x => string.Equals(GetString(x, "strSport"), "Soccer", StringComparison.OrdinalIgnoreCase))
                .Where(x => (GetString(x, "strLeague") ?? string.Empty).Contains(query, StringComparison.OrdinalIgnoreCase)
                         || (GetString(x, "strLeagueAlternate") ?? string.Empty).Contains(query, StringComparison.OrdinalIgnoreCase)
                         || (GetString(x, "strCountry") ?? string.Empty).Contains(query, StringComparison.OrdinalIgnoreCase))
                .Select(x => new LigAramaSonucuDto
                {
                    LigId = GetInt(x, "idLeague") ?? 0,
                    Ad = GetString(x, "strLeague") ?? "Bilinmeyen Lig",
                    Ulke = GetString(x, "strCountry") ?? string.Empty,
                    Tur = GetString(x, "strSport") ?? "Soccer",
                    Logo = GetString(x, "strBadge"),
                    Sezonlar = seasons
                })
                .Where(x => x.LigId > 0)
                .OrderBy(x => x.Ad)
                .Take(50)
                .ToList();

            return ServiceResult<List<LigAramaSonucuDto>>.BasariliSonuc(list, $"{list.Count} lig bulundu.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "TheSportsDB lig araması sırasında hata. Arama: {Arama}", arama);
            return ServiceResult<List<LigAramaSonucuDto>>.BasarisizSonuc($"TheSportsDB lig araması başarısız: {ex.Message}");
        }
    }

    public async Task<ServiceResult<List<LigAramaSonucuDto>>> GenisLigHavuzuGetirAsync(
        int maksimumLig,
        CancellationToken cancellationToken)
    {
        maksimumLig = Math.Clamp(maksimumLig, 20, 100);
        try
        {
            using var doc = await GetJsonAsync("all_leagues.php", cancellationToken);
            if (!doc.RootElement.TryGetProperty("leagues", out var leagues) || leagues.ValueKind != JsonValueKind.Array)
                return ServiceResult<List<LigAramaSonucuDto>>.BasarisizSonuc("TheSportsDB geniş lig listesi alınamadı.");

            var oncelikliUlkeler = new[]
            {
                "England", "Spain", "Germany", "Italy", "France", "Netherlands", "Portugal", "Belgium",
                "Scotland", "Turkey", "Greece", "Austria", "Switzerland", "Denmark", "Norway", "Sweden",
                "Poland", "Czech Republic", "Croatia", "Serbia", "Romania", "Ukraine", "Hungary",
                "Brazil", "Argentina", "Mexico", "USA", "Japan", "South Korea", "Australia"
            };
            var ulkeSirasi = oncelikliUlkeler
                .Select((x, i) => new { x, i })
                .ToDictionary(x => x.x, x => x.i, StringComparer.OrdinalIgnoreCase);
            var seasons = GetConfiguredSeasonYears();

            static bool Engelli(string text)
            {
                var x = text.ToLowerInvariant();
                string[] yasak = { "women", "woman", "female", "u17", "u18", "u19", "u20", "u21", "u23", "youth", "reserve", "academy", "friendly" };
                return yasak.Any(x.Contains);
            }

            static int LigAdiPuani(string ad)
            {
                var x = ad.ToLowerInvariant();
                var p = 0;
                if (x.Contains("champions league")) p += 60;
                if (x.Contains("europa league")) p += 55;
                if (x.Contains("conference league")) p += 50;
                if (x.Contains("premier")) p += 35;
                if (x.Contains("bundesliga")) p += 35;
                if (x.Contains("serie a")) p += 35;
                if (x.Contains("la liga") || x.Contains("primera")) p += 35;
                if (x.Contains("ligue 1")) p += 35;
                if (x.Contains("eredivisie")) p += 35;
                if (x.Contains("super league") || x.Contains("superliga")) p += 28;
                if (x.Contains("championship")) p += 25;
                if (x.Contains("liga")) p += 18;
                if (x.Contains("division")) p += 12;
                if (x.Contains("cup") || x.Contains("pokal") || x.Contains("copa")) p -= 8;
                return p;
            }

            var list = leagues.EnumerateArray()
                .Where(x => string.Equals(GetString(x, "strSport"), "Soccer", StringComparison.OrdinalIgnoreCase))
                .Select(x => new
                {
                    Id = GetInt(x, "idLeague") ?? 0,
                    Ad = GetString(x, "strLeague") ?? string.Empty,
                    Ulke = GetString(x, "strCountry") ?? string.Empty,
                    Logo = GetString(x, "strBadge")
                })
                .Where(x => x.Id > 0 && !string.IsNullOrWhiteSpace(x.Ad) && !Engelli($"{x.Ad} {x.Ulke}"))
                .Select(x => new
                {
                    x.Id, x.Ad, x.Ulke, x.Logo,
                    Puan = (ulkeSirasi.TryGetValue(x.Ulke, out var idx) ? 100 - idx * 2 : 15) + LigAdiPuani(x.Ad)
                })
                .OrderByDescending(x => x.Puan)
                .ThenBy(x => x.Ulke)
                .ThenBy(x => x.Ad)
                .Take(maksimumLig)
                .Select(x => new LigAramaSonucuDto
                {
                    LigId = x.Id,
                    Ad = x.Ad,
                    Ulke = x.Ulke,
                    Tur = "Soccer",
                    Logo = x.Logo,
                    Sezonlar = seasons
                })
                .ToList();

            if (list.Count < 20)
            {
                return ServiceResult<List<LigAramaSonucuDto>>.BasarisizSonuc(
                    $"Geniş lig havuzu yalnızca {list.Count} lig döndürdü. TheSportsDB Premium V1 anahtarınızı TheSportsDb:V1ApiKey alanına tanımlayın; ücretsiz anahtar all_leagues sonucunu sınırlar.");
            }

            return ServiceResult<List<LigAramaSonucuDto>>.BasariliSonuc(list, $"{list.Count} liglik geniş havuz hazırlandı.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Geniş lig havuzu oluşturulamadı.");
            return ServiceResult<List<LigAramaSonucuDto>>.BasarisizSonuc($"Geniş lig havuzu oluşturulamadı: {ex.Message}");
        }
    }

    public async Task<ServiceResult<LigSenkronizasyonSonucuDto>> LigSenkronizeEtAsync(int ligId, int sezonSayisi, CancellationToken cancellationToken)
    {
        sezonSayisi = Math.Clamp(sezonSayisi, 1, 5);
        try
        {
            using var leagueDoc = await GetJsonAsync($"lookupleague.php?id={ligId}", cancellationToken);
            if (!leagueDoc.RootElement.TryGetProperty("leagues", out var leagueArray) || leagueArray.ValueKind != JsonValueKind.Array || leagueArray.GetArrayLength() == 0)
                return ServiceResult<LigSenkronizasyonSonucuDto>.BasarisizSonuc($"TheSportsDB üzerinde {ligId} ID'li lig bulunamadı.");

            var leagueNode = leagueArray[0];
            var leagueName = GetString(leagueNode, "strLeague") ?? $"Lig {ligId}";
            var country = GetString(leagueNode, "strCountry");
            var logo = GetString(leagueNode, "strBadge");
            var seasonNames = GetConfiguredSeasons().Take(sezonSayisi).ToList();

            var result = new LigSenkronizasyonSonucuDto
            {
                LigId = ligId,
                LigAdi = leagueName,
                Sezonlar = seasonNames.Select(SeasonStartYear).Where(x => x > 0).ToList()
            };

            foreach (var season in seasonNames)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var seasonResponse = await GetSeasonEventsWithFallbackAsync(ligId, season, cancellationToken);
                using var eventsDoc = seasonResponse.Document;
                var usedSeason = seasonResponse.UsedSeason;

                if (!TryGetEvents(eventsDoc, out var events))
                {
                    var fallbackInfo = string.Equals(season, usedSeason, StringComparison.OrdinalIgnoreCase)
                        ? season
                        : $"{season} ve {usedSeason}";
                    result.Uyarilar.Add($"{fallbackInfo}: maç verisi dönmedi.");
                    continue;
                }

                if (!string.Equals(season, usedSeason, StringComparison.OrdinalIgnoreCase))
                    result.Uyarilar.Add($"{season} boş döndü; {usedSeason} formatı kullanıldı ({events.GetArrayLength()} maç).");

                var dbLeague = await GetOrCreateLeagueAsync(ligId, leagueName, country, usedSeason, logo, cancellationToken);
                foreach (var item in events.EnumerateArray())
                {
                    result.GelenMacSayisi++;
                    var externalId = GetInt(item, "idEvent");
                    var homeSourceId = GetInt(item, "idHomeTeam");
                    var awaySourceId = GetInt(item, "idAwayTeam");
                    if (!externalId.HasValue || !homeSourceId.HasValue || !awaySourceId.HasValue)
                    {
                        result.Uyarilar.Add($"{season}: kimliği eksik bir maç atlandı.");
                        continue;
                    }

                    var home = await GetOrCreateTeamAsync(homeSourceId.Value, GetString(item, "strHomeTeam"), GetString(item, "strHomeTeamBadge"), country, dbLeague.Id, cancellationToken);
                    var away = await GetOrCreateTeamAsync(awaySourceId.Value, GetString(item, "strAwayTeam"), GetString(item, "strAwayTeamBadge"), country, dbLeague.Id, cancellationToken);
                    if (home.Created) result.EklenenTakimSayisi++;
                    if (away.Created) result.EklenenTakimSayisi++;

                    var match = await _db.Maclar.FirstOrDefaultAsync(x => x.HariciMacId == externalId.Value, cancellationToken);
                    if (match is null)
                    {
                        match = new Mac { HariciMacId = externalId.Value, OlusturmaTarihi = DateTime.UtcNow };
                        _db.Maclar.Add(match);
                        result.EklenenMacSayisi++;
                    }
                    else result.GuncellenenMacSayisi++;

                    match.LigId = dbLeague.Id;
                    match.EvSahibiTakimId = home.Team.Id;
                    match.DeplasmanTakimId = away.Team.Id;
                    match.MacTarihi = ParseEventDate(item) ?? DateTime.UtcNow;
                    match.Durum = NormalizeStatus(GetString(item, "strStatus"), GetString(item, "strPostponed"), GetInt(item, "intHomeScore"), GetInt(item, "intAwayScore"));
                    match.EvSahibiSkor = GetInt(item, "intHomeScore");
                    match.DeplasmanSkor = GetInt(item, "intAwayScore");
                    match.IlkYariEvSahibiSkor = GetInt(item, "intHomeScoreHT");
                    match.IlkYariDeplasmanSkor = GetInt(item, "intAwayScoreHT");
                    match.Stadyum = GetString(item, "strVenue");
                    match.Hakem = GetString(item, "strReferee");
                    match.GuncellemeTarihi = DateTime.UtcNow;
                }
                await _db.SaveChangesAsync(cancellationToken);
                if (_options.IsteklerArasiBeklemeMs > 0)
                    await Task.Delay(_options.IsteklerArasiBeklemeMs, cancellationToken);
            }

            return ServiceResult<LigSenkronizasyonSonucuDto>.BasariliSonuc(result, "TheSportsDB lig senkronizasyonu tamamlandı.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "TheSportsDB lig senkronizasyonu başarısız. LigId: {LigId}", ligId);
            return ServiceResult<LigSenkronizasyonSonucuDto>.BasarisizSonuc($"Lig senkronizasyonu başarısız: {ex.Message}");
        }
    }


    private async Task<(JsonDocument Document, string UsedSeason)> GetSeasonEventsWithFallbackAsync(
        int ligId,
        string season,
        CancellationToken cancellationToken)
    {
        var primaryDocument = await GetJsonAsync(
            $"eventsseason.php?id={ligId}&s={Uri.EscapeDataString(season)}",
            cancellationToken);

        if (TryGetEvents(primaryDocument, out _))
            return (primaryDocument, season);

        var singleYear = SeasonStartYear(season).ToString(CultureInfo.InvariantCulture);
        if (singleYear == "0" || string.Equals(singleYear, season, StringComparison.OrdinalIgnoreCase))
            return (primaryDocument, season);

        primaryDocument.Dispose();

        var fallbackDocument = await GetJsonAsync(
            $"eventsseason.php?id={ligId}&s={Uri.EscapeDataString(singleYear)}",
            cancellationToken);

        return (fallbackDocument, singleYear);
    }

    private static bool TryGetEvents(JsonDocument document, out JsonElement events)
    {
        if (document.RootElement.TryGetProperty("events", out events) &&
            events.ValueKind == JsonValueKind.Array &&
            events.GetArrayLength() > 0)
        {
            return true;
        }

        events = default;
        return false;
    }

    private async Task<JsonDocument> GetJsonAsync(string relativeUrl, CancellationToken cancellationToken)
    {
        var key = !string.IsNullOrWhiteSpace(_options.V1ApiKey) ? _options.V1ApiKey : _options.ApiKey;
        if (string.IsNullOrWhiteSpace(key)) throw new InvalidOperationException("TheSportsDb:ApiKey veya TheSportsDb:V1ApiKey tanımlı değil.");
        using var response = await _httpClient.GetAsync(relativeUrl, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException($"TheSportsDB HTTP {(int)response.StatusCode}: {body[..Math.Min(body.Length, 300)]}");
        return JsonDocument.Parse(body);
    }

    private async Task<Lig> GetOrCreateLeagueAsync(int sourceId, string name, string? country, string season, string? logo, CancellationToken ct)
    {
        var dbLeague = await _db.Ligler.FirstOrDefaultAsync(x => x.HariciLigId == sourceId && x.Sezon == season, ct);
        if (dbLeague is not null) return dbLeague;
        dbLeague = new Lig { HariciLigId = sourceId, Ad = name, Ulke = country, Sezon = season, LogoUrl = logo, AktifMi = true };
        _db.Ligler.Add(dbLeague);
        await _db.SaveChangesAsync(ct);
        return dbLeague;
    }

    private async Task<(Takim Team, bool Created)> GetOrCreateTeamAsync(int sourceId, string? name, string? logo, string? country, int leagueId, CancellationToken ct)
    {
        var team = await _db.Takimlar.FirstOrDefaultAsync(x => x.TheSportsDbTakimId == sourceId || x.HariciTakimId == sourceId, ct);
        if (team is not null)
        {
            team.TheSportsDbTakimId ??= sourceId;
            team.HariciTakimId ??= sourceId;
            if (string.IsNullOrWhiteSpace(team.LogoUrl)) team.LogoUrl = logo;
            return (team, false);
        }
        team = new Takim { HariciTakimId = sourceId, TheSportsDbTakimId = sourceId, Ad = name ?? $"Takım {sourceId}", LogoUrl = logo, Ulke = country, LigId = leagueId, AktifMi = true };
        _db.Takimlar.Add(team);
        await _db.SaveChangesAsync(ct);
        return (team, true);
    }

    private List<string> GetConfiguredSeasons() => _options.Sezonlar
        .Where(x => !string.IsNullOrWhiteSpace(x))
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .OrderByDescending(SeasonStartYear)
        .ToList() is { Count: > 0 } configured
            ? configured
            : new List<string> { _options.VarsayilanSezon };

    private List<int> GetConfiguredSeasonYears() => GetConfiguredSeasons().Select(SeasonStartYear).Where(x => x > 0).ToList();
    private static int SeasonStartYear(string season) => int.TryParse(season.Split('-', '/', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault(), out var y) ? y : 0;
    private static string? GetString(JsonElement e, string name) => e.TryGetProperty(name, out var p) && p.ValueKind != JsonValueKind.Null ? p.ToString().Trim() is { Length: > 0 } s ? s : null : null;
    private static int? GetInt(JsonElement e, string name) => int.TryParse(GetString(e, name), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : null;

    private static DateTime? ParseEventDate(JsonElement e)
    {
        var timestamp = GetString(e, "strTimestamp");
        if (DateTimeOffset.TryParse(timestamp, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dto)) return dto.UtcDateTime;
        var date = GetString(e, "dateEvent");
        var time = GetString(e, "strTime") ?? "00:00:00";
        if (DateTime.TryParse($"{date} {time}", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dt)) return DateTime.SpecifyKind(dt, DateTimeKind.Utc);
        return null;
    }

    private static string NormalizeStatus(string? status, string? postponed, int? home, int? away)
    {
        if (string.Equals(postponed, "yes", StringComparison.OrdinalIgnoreCase)) return "postponed";
        if (!string.IsNullOrWhiteSpace(status)) return status.Trim().ToLowerInvariant();
        return home.HasValue && away.HasValue ? "finished" : "scheduled";
    }
}
