using System.Text;
using System.Globalization;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class KuponKaliciService : IKuponKaliciService
{
    private readonly FemDbContext _db;
    public KuponKaliciService(FemDbContext db) => _db = db;

    public async Task<ServiceResult<Kupon>> KaydetAsync(long adminTelegramId, CokluKuponTaslakDto taslak, string? baslik, CancellationToken cancellationToken)
    {
        if (taslak.Maclar.Count is < 1 or > 5)
            return ServiceResult<Kupon>.BasarisizSonuc("Kupon 1 ile 5 maç arasında olmalıdır.");

        if (taslak.Maclar.Select(x => x.MacId).Distinct().Count() != taslak.Maclar.Count)
            return ServiceResult<Kupon>.BasarisizSonuc("Aynı maç kupona iki kez eklenemez.");

        var kupon = new Kupon
        {
            AdminTelegramId = adminTelegramId,
            Baslik = string.IsNullOrWhiteSpace(baslik) ? $"FEM Elite Kuponu - {DateTime.Now:dd.MM.yyyy}" : baslik.Trim(),
            OrtalamaGuvenPuani = taslak.OrtalamaGuvenPuani,
            RiskSeviyesi = taslak.RiskSeviyesi,
            Durum = "Taslak",
            OlusturmaTarihi = DateTime.UtcNow
        };

        var sira = 1;
        decimal toplamOran = 1m;
        var oranTamMi = true;
        foreach (var secim in taslak.Maclar)
        {
            var (temizMarket, manuelOran) = MarketVeOran(secim.SecilenMarket);
            var oran = manuelOran;
            if (!oran.HasValue)
            {
                oran = await _db.BahisOranlari.AsNoTracking()
                    .Where(x => x.MacId == secim.MacId && x.MarketKodu == temizMarket)
                    .OrderByDescending(x => x.AlinmaTarihi)
                    .Select(x => (decimal?)x.Oran)
                    .FirstOrDefaultAsync(cancellationToken);
            }
            if (oran.HasValue) toplamOran *= oran.Value; else oranTamMi = false;

            kupon.Maclar.Add(new KuponMaci
            {
                AnalizId = secim.AnalizId,
                MacId = secim.MacId,
                EvSahibi = secim.EvSahibi,
                Deplasman = secim.Deplasman,
                SecilenMarket = temizMarket,
                GuvenPuani = secim.GuvenPuani,
                Oran = oran,
                Sonuc = "Bekliyor",
                Sira = sira++
            });
        }
        kupon.ToplamOran = oranTamMi ? Math.Round(toplamOran, 3) : null;
        kupon.Sonuc = "Bekliyor";

        kupon.YayinMetni = YayinMetniOlustur(kupon);
        _db.Kuponlar.Add(kupon);
        await _db.SaveChangesAsync(cancellationToken);
        return ServiceResult<Kupon>.BasariliSonuc(kupon, "Kupon SQL'e kaydedildi.");
    }

    public async Task<ServiceResult<List<Kupon>>> ListeleAsync(long adminTelegramId, CancellationToken cancellationToken)
    {
        var liste = await _db.Kuponlar.AsNoTracking().Include(x => x.Maclar)
            .Where(x => x.AdminTelegramId == adminTelegramId)
            .OrderByDescending(x => x.Id).Take(20).ToListAsync(cancellationToken);
        return ServiceResult<List<Kupon>>.BasariliSonuc(liste, $"{liste.Count} kupon bulundu.");
    }

    public async Task<ServiceResult<Kupon>> GetirAsync(int kuponId, long adminTelegramId, CancellationToken cancellationToken)
    {
        var kupon = await _db.Kuponlar.AsNoTracking().Include(x => x.Maclar)
            .FirstOrDefaultAsync(x => x.Id == kuponId && x.AdminTelegramId == adminTelegramId, cancellationToken);
        return kupon is null
            ? ServiceResult<Kupon>.BasarisizSonuc("Kupon bulunamadı.")
            : ServiceResult<Kupon>.BasariliSonuc(kupon, "Kupon getirildi.");
    }

    private static (string Market, decimal? Oran) MarketVeOran(string metin)
    {
        var m = Regex.Match(metin.Trim(), @"^(.*?)(?:\s*@\s*(\d+(?:[\.,]\d+)?))?$");
        var market = m.Groups[1].Value.Trim();
        decimal? oran = null;
        if (m.Groups[2].Success && decimal.TryParse(m.Groups[2].Value.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out var parsed))
            oran = parsed;
        return (market, oran);
    }

    private static string YayinMetniOlustur(Kupon kupon)
    {
        var sb = new StringBuilder();
        sb.AppendLine("🎫 FEM ELITE KUPONU"); sb.AppendLine();
        foreach (var m in kupon.Maclar.OrderBy(x => x.Sira))
        {
            sb.AppendLine($"{m.Sira}️⃣ {m.EvSahibi} - {m.Deplasman}");
            sb.AppendLine($"🎯 {m.SecilenMarket}{(m.Oran.HasValue ? $" ({m.Oran:0.00})" : string.Empty)}");
            sb.AppendLine($"📊 Güven: %{m.GuvenPuani}"); sb.AppendLine();
        }
        sb.AppendLine($"📦 Maç sayısı: {kupon.Maclar.Count}");
        sb.AppendLine($"🎯 Ortalama güven: %{kupon.OrtalamaGuvenPuani}");
        sb.AppendLine($"🛡️ Risk: {kupon.RiskSeviyesi}");
        if (kupon.ToplamOran.HasValue) sb.AppendLine($"💰 Toplam oran: {kupon.ToplamOran:0.00}");
        sb.AppendLine();
        sb.AppendLine("⚠️ İstatistiksel değerlendirmedir, kesin sonuç garantisi içermez.");
        return sb.ToString().Trim();
    }
}
