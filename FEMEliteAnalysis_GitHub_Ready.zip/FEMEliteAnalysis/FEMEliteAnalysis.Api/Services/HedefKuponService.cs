using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

/// <summary>
/// V4.9 - Gerçek oran tabanlı düşük/orta/yüksek kupon motoru.
/// Tekil tahmini oran üretmez. Birden fazla kupon istendiğinde aynı seçim setini tekrar etmez.
/// </summary>
public class HedefKuponService : IHedefKuponService
{
    private readonly FemDbContext _db;
    private readonly ISqlTakimFormService _form;
    private readonly IAnalizMotoruV2 _motor;
    private readonly ICokluKuponTaslakService _taslak;

    public HedefKuponService(FemDbContext db, ISqlTakimFormService form, IAnalizMotoruV2 motor, ICokluKuponTaslakService taslak)
    { _db = db; _form = form; _motor = motor; _taslak = taslak; }

    public async Task<ServiceResult<HedefKuponDto>> DusukOlusturAsync(long adminTelegramId, CancellationToken ct)
        => Tek(await CokluOlusturAsync("dusuk", 1, null, ct));
    public async Task<ServiceResult<HedefKuponDto>> OrtaOlusturAsync(long adminTelegramId, CancellationToken ct)
        => Tek(await CokluOlusturAsync("orta", 1, null, ct));
    public async Task<ServiceResult<HedefKuponDto>> YuksekOlusturAsync(long adminTelegramId, CancellationToken ct)
        => Tek(await CokluOlusturAsync("yuksek", 1, null, ct));

    public async Task<ServiceResult<List<HedefKuponDto>>> CokluOlusturAsync(string mod, int adet, IReadOnlyCollection<int>? macIdleri, CancellationToken ct)
    {
        var cfg = ModAyar(mod);
        if (cfg is null) return ServiceResult<List<HedefKuponDto>>.BasarisizSonuc("Mod yalnızca dusuk, orta veya yuksek olabilir.");
        adet = Math.Clamp(adet, 1, 20);
        var adaylar = await AdaylariOlustur(cfg, macIdleri, ct);
        if (adaylar.Count < 2) return ServiceResult<List<HedefKuponDto>>.BasarisizSonuc("Gerçek oranı bulunan yeterli kaliteli market yok.");

        var kombinasyonlar = BeamAraCoklu(adaylar, cfg, Math.Max(adet * 8, 30));
        if (kombinasyonlar.Count == 0)
            return ServiceResult<List<HedefKuponDto>>.BasarisizSonuc($"{cfg.MinToplam:0.00}-{cfg.MaxToplam:0.00} oran aralığında gerçek oranlı kupon bulunamadı.");

        var secilen = Cesitlendir(kombinasyonlar, adet);
        var list = secilen.Select(x => Dto(x, cfg.Hedef)).ToList();
        return ServiceResult<List<HedefKuponDto>>.BasariliSonuc(list,
            $"İstenen {adet}, kalite/oran kriterini geçen {list.Count} farklı {cfg.Ad} kupon üretildi.");
    }

    private async Task<List<HedefKuponSecimDto>> AdaylariOlustur(ModCfg cfg, IReadOnlyCollection<int>? macIds, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var q = _db.Analizler.AsNoTracking()
            .Include(x => x.Mac).ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac).ThenInclude(x => x.DeplasmanTakim)
            .Where(x => x.Mac.MacTarihi >= now.AddHours(-2) && x.Mac.MacTarihi <= now.AddDays(4) && x.GuvenPuani >= cfg.MinGuven);
        if (macIds is { Count: > 0 }) q = q.Where(x => macIds.Contains(x.MacId));
        var analizler = await q.OrderByDescending(x => x.GuvenPuani).Take(120).ToListAsync(ct);
        analizler = analizler.GroupBy(x => x.MacId).Select(g => g.OrderByDescending(x => x.OlusturmaTarihi).First()).Take(80).ToList();
        var adaylar = new List<HedefKuponSecimDto>();
        var oddsEsik = DateTime.UtcNow.AddHours(-6);

        foreach (var analiz in analizler)
        {
            var veri = await _form.MacKuponVerisiOlusturAsync(analiz.MacId, ct);
            if (!veri.Basarili || veri.Veri is null) continue;
            var sonuc = _motor.AnalizEt(veri.Veri);
            var oranlar = await _db.BahisOranlari.AsNoTracking()
                .Where(x => x.MacId == analiz.MacId && x.AlinmaTarihi >= oddsEsik && x.Oran >= cfg.MinTekil && x.Oran <= cfg.MaxTekil)
                .OrderByDescending(x => x.AlinmaTarihi).ToListAsync(ct);
            if (oranlar.Count == 0) continue;

            foreach (var market in sonuc.Marketler.Where(x => !x.UzakDurMu && x.GuvenPuani >= cfg.MinGuven && MarketUygun(x, cfg.Ad))
                         .OrderByDescending(x => MarketSkoru(x, cfg.Ad)).Take(30))
            {
                var oran = oranlar.Where(x => EsitMarket(x.MarketKodu, market.Kod)).OrderByDescending(x => x.Oran).Select(x => (decimal?)x.Oran).FirstOrDefault();
                if (!oran.HasValue || oran < cfg.MinTekil || oran > cfg.MaxTekil) continue;
                adaylar.Add(new HedefKuponSecimDto
                {
                    AnalizId = analiz.Id, MacId = analiz.MacId,
                    EvSahibi = analiz.Mac.EvSahibiTakim.Ad, Deplasman = analiz.Mac.DeplasmanTakim.Ad,
                    Market = market.Kod, Oran = Math.Round(oran.Value, 2), Guven = market.GuvenPuani,
                    VeriKalitesi = MarketVeriKalitesi(veri.Veri, market.Kategori), TahminiOranMi = false
                });
            }
        }

        return adaylar.GroupBy(x => x.MacId)
            .SelectMany(g => g.OrderByDescending(x => x.Guven + x.VeriKalitesi / 5m + Math.Min(12m, x.Oran * 2)).Take(cfg.MacBasinaMarket))
            .OrderByDescending(x => x.Guven + x.VeriKalitesi / 6m + Math.Min(10m, x.Oran)).Take(140).ToList();
    }

    private static List<List<HedefKuponSecimDto>> BeamAraCoklu(List<HedefKuponSecimDto> adaylar, ModCfg cfg, int limit)
    {
        var states = new List<List<HedefKuponSecimDto>> { new() };
        var uygun = new List<List<HedefKuponSecimDto>>();
        for (var step = 0; step < cfg.MaxSecim; step++)
        {
            var next = new List<List<HedefKuponSecimDto>>();
            foreach (var st in states)
            foreach (var aday in adaylar)
            {
                if (st.Any(x => x.MacId == aday.MacId)) continue;
                var yeni = st.Append(aday).ToList();
                var oran = Toplam(yeni);
                if (oran > cfg.MaxToplam * 1.04m) continue;
                if (yeni.Count >= cfg.MinSecim && oran >= cfg.MinToplam && oran <= cfg.MaxToplam) uygun.Add(yeni);
                next.Add(yeni);
            }
            states = next.OrderBy(x => Skor(x, cfg.Hedef, cfg)).Take(3500).ToList();
            if (states.Count == 0) break;
        }
        return uygun.GroupBy(Signature).Select(g => g.OrderBy(x => Skor(x, cfg.Hedef, cfg)).First())
            .OrderBy(x => Skor(x, cfg.Hedef, cfg)).Take(limit).ToList();
    }

    private static List<List<HedefKuponSecimDto>> Cesitlendir(List<List<HedefKuponSecimDto>> kaynak, int adet)
    {
        var secilen = new List<List<HedefKuponSecimDto>>();
        foreach (var k in kaynak)
        {
            if (secilen.Count >= adet) break;
            var ks = k.Select(x => $"{x.MacId}:{Normalize(x.Market)}").ToHashSet();
            var cokBenzer = secilen.Any(s =>
            {
                var ss = s.Select(x => $"{x.MacId}:{Normalize(x.Market)}").ToHashSet();
                var ortak = ks.Intersect(ss).Count();
                var oran = ortak / (decimal)Math.Max(1, Math.Min(ks.Count, ss.Count));
                return oran > 0.60m;
            });
            if (!cokBenzer) secilen.Add(k);
        }
        if (secilen.Count < adet)
            foreach (var k in kaynak.Where(k => !secilen.Any(s => Signature(s) == Signature(k)))) { secilen.Add(k); if (secilen.Count >= adet) break; }
        return secilen.Take(adet).ToList();
    }

    private static HedefKuponDto Dto(List<HedefKuponSecimDto> x, decimal hedef)
    {
        var toplam = Toplam(x);
        return new HedefKuponDto { HedefOran = hedef, ToplamOran = Math.Round(toplam, 2), HedefSapmaYuzdesi = Math.Round(Math.Abs(toplam-hedef)*100m/hedef,1), OrtalamaGuven = (int)Math.Round(x.Average(a=>a.Guven)), Secimler=x };
    }

    public Task<ServiceResult<CokluKuponTaslakDto>> TaslagaUygulaAsync(long adminTelegramId, HedefKuponDto kupon)
    {
        _taslak.Temizle(adminTelegramId); ServiceResult<CokluKuponTaslakDto>? son = null;
        foreach (var x in kupon.Secimler)
            son = _taslak.MacEkle(adminTelegramId, new CokluKuponMacSecimiDto { AnalizId=x.AnalizId, MacId=x.MacId, EvSahibi=x.EvSahibi, Deplasman=x.Deplasman, SecilenMarket=$"{x.Market} @{x.Oran:0.00}", GuvenPuani=x.Guven, AktifMi=true });
        return Task.FromResult(son is null ? ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc("Kupon taslağa uygulanamadı.") : ServiceResult<CokluKuponTaslakDto>.BasariliSonuc(son.Veri!, "Kupon taslağa uygulandı."));
    }

    private static ServiceResult<HedefKuponDto> Tek(ServiceResult<List<HedefKuponDto>> r) => !r.Basarili || r.Veri is null || r.Veri.Count==0 ? ServiceResult<HedefKuponDto>.BasarisizSonuc(r.Mesaj) : ServiceResult<HedefKuponDto>.BasariliSonuc(r.Veri[0], r.Mesaj);
    private static decimal Toplam(IEnumerable<HedefKuponSecimDto> x) => x.Aggregate(1m,(a,b)=>a*b.Oran);
    private static string Signature(IEnumerable<HedefKuponSecimDto> x) => string.Join("|", x.OrderBy(a=>a.MacId).Select(a=>$"{a.MacId}:{Normalize(a.Market)}"));
    private static decimal Skor(List<HedefKuponSecimDto> s, decimal hedef, ModCfg cfg)
    {
        var oran=Toplam(s); var sapma=Math.Abs(oran-hedef)/hedef*100m; var g=(decimal)s.Average(x=>x.Guven); var v=(decimal)s.Average(x=>x.VeriKalitesi);
        return sapma + Math.Max(0,cfg.MinGuven+6-g)*.35m + Math.Max(0,65-v)*.15m + Math.Max(0,s.Count-cfg.IdealSecim)*1.5m;
    }

    private static ModCfg? ModAyar(string mod) => Normalize(mod) switch
    {
        "DUSUK" or "DÜŞÜK" => new("dusuk",2m,4m,2.8m,1.20m,3.20m,74,2,4,3,5),
        "ORTA" => new("orta",4m,12m,7m,1.30m,5.50m,65,2,6,4,6),
        "YUKSEK" or "YÜKSEK" => new("yuksek",12m,500m,35m,1.45m,80m,52,2,5,3,8),
        _ => null
    };

    private static bool MarketUygun(KuponMarketSkoruDto m, string mod)
    {
        if (m.Kategori.Equals("Korner",StringComparison.OrdinalIgnoreCase)||m.Kategori.Equals("Kart",StringComparison.OrdinalIgnoreCase)) return false;
        if (m.Kod is "EV 0.5 ÜST" or "DEP 0.5 ÜST" or "İY 2.5 ALT") return false;
        if (mod=="dusuk") return !m.SurprizMi && (m.Kategori.Equals("Kombine",StringComparison.OrdinalIgnoreCase) ? m.Kod.Contains("1.5 ÜST")||m.Kod.Contains("3.5 ALT")||m.Kod.Contains("4.5 ALT") : m.Kod is "MS1" or "MS2" or "1X" or "X2" or "1.5 ÜST" or "2.5 ALT" or "2.5 ÜST" or "KG YOK");
        if (mod=="orta") return m.Kategori.Equals("Kombine",StringComparison.OrdinalIgnoreCase) || m.Kod is "MS1" or "MS2" or "2.5 ÜST" or "2.5 ALT" or "KG VAR" or "KG YOK" or "1/1" or "2/2";
        // yüksek: gerçek oranı varsa agresif kombine, İY/MS, yüksek gol ve sonuç marketlerini kullan.
        return m.SurprizMi || m.Kategori.Equals("Kombine",StringComparison.OrdinalIgnoreCase) || m.Kod.Contains('/') || m.Kod is "3.5 ÜST" or "4.5 ÜST" or "MSX" or "KG VAR" or "MS1" or "MS2";
    }

    private static int MarketSkoru(KuponMarketSkoruDto m,string mod)
    {
        var s=m.GuvenPuani;
        if(m.Kategori.Equals("Kombine",StringComparison.OrdinalIgnoreCase)) s += mod=="orta"?15:mod=="yuksek"?10:5;
        if(m.Kod.Contains('/')) s += mod=="yuksek"?18:2;
        if(m.Kod.Contains("4.5 ALT")||m.Kod.Contains("3.5 ALT")||m.Kod.Contains("1.5 ÜST")) s+=3;
        return s;
    }
    private static bool EsitMarket(string a,string b)=>Normalize(a)==Normalize(b);
    private static string Normalize(string x)=>string.Join(' ',x.Trim().ToUpperInvariant().Replace('İ','I').Replace('Ü','U').Split(' ',StringSplitOptions.RemoveEmptyEntries));
    private static int MarketVeriKalitesi(FEMEliteAnalysis.Api.Dtos.Mac.MacKuponVerisiDto v,string k){if(k.Equals("Korner",StringComparison.OrdinalIgnoreCase))return v.KornerVeriKalitesi;if(k.Equals("Kart",StringComparison.OrdinalIgnoreCase))return v.KartVeriKalitesi;if(k.Contains("İlk",StringComparison.OrdinalIgnoreCase))return v.IlkYariVeriKalitesi;if(k.Equals("Maç Sonucu",StringComparison.OrdinalIgnoreCase))return v.MacSonucuVeriKalitesi;if(k.Equals("Kombine",StringComparison.OrdinalIgnoreCase))return Math.Min(v.MacSonucuVeriKalitesi,v.GolMarketVeriKalitesi);return v.GolMarketVeriKalitesi;}
    private sealed record ModCfg(string Ad,decimal MinToplam,decimal MaxToplam,decimal Hedef,decimal MinTekil,decimal MaxTekil,int MinGuven,int MinSecim,int MaxSecim,int IdealSecim,int MacBasinaMarket);
}
