using System.Threading.Channels;

namespace FEMEliteAnalysis.Api.Services;

public sealed record HistoricalPoolRequest(
    string BaslangicSezonu,
    string BitisSezonu,
    IReadOnlyCollection<string> LigKodlari);

public class HistoricalPoolQueue
{
    private readonly Channel<HistoricalPoolRequest> _channel =
        Channel.CreateBounded<HistoricalPoolRequest>(new BoundedChannelOptions(1)
        {
            FullMode = BoundedChannelFullMode.DropWrite,
            SingleReader = true,
            SingleWriter = false
        });

    public bool Ekle(HistoricalPoolRequest request) => _channel.Writer.TryWrite(request);

    public ValueTask<HistoricalPoolRequest> BekleAsync(CancellationToken cancellationToken) =>
        _channel.Reader.ReadAsync(cancellationToken);
}
