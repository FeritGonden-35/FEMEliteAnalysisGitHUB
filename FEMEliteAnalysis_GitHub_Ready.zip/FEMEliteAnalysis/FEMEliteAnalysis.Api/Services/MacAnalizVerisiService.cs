using System.Text;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class MacAnalizVerisiService : IMacAnalizVerisiService
{
    private readonly FemDbContext _dbContext;
    private readonly ILogger<MacAnalizVerisiService> _logger;

    public MacAnalizVerisiService(
        FemDbContext dbContext,
        ILogger<MacAnalizVerisiService> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<ServiceResult<MacAnalizVerisiDto>> AnalizVerisiOlusturAsync(
        int macId,
        CancellationToken cancellationToken)
    {
        var mac = await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == macId,
                cancellationToken);

        if (mac is null)
        {
            return ServiceResult<MacAnalizVerisiDto>.BasarisizSonuc(
                "Analiz edilecek maç bulunamadı.");
        }

        var evSahibiFormu = await TakimFormuGetirAsync(
            mac.EvSahibiTakimId,
            mac.LigId,
            cancellationToken);

        var deplasmanFormu = await TakimFormuGetirAsync(
            mac.DeplasmanTakimId,
            mac.LigId,
            cancellationToken);

        var evSahibiSonMaclar = await SonMaclariGetirAsync(
            mac.EvSahibiTakimId,
            mac.Id,
            5,
            cancellationToken);

        var deplasmanSonMaclar = await SonMaclariGetirAsync(
            mac.DeplasmanTakimId,
            mac.Id,
            5,
            cancellationToken);

        var ikiliRekabet = await IkiliRekabetGetirAsync(
            mac.EvSahibiTakimId,
            mac.DeplasmanTakimId,
            mac.Id,
            5,
            cancellationToken);

        var sonuc = new MacAnalizVerisiDto
        {
            MacId = mac.Id,
            HariciMacId = mac.HariciMacId,
            Lig = mac.Lig?.Ad ?? "Bilinmeyen Lig",
            Ulke = mac.Lig?.Ulke,
            Sezon = mac.Lig?.Sezon,
            EvSahibi = mac.EvSahibiTakim.Ad,
            Deplasman = mac.DeplasmanTakim.Ad,
            MacTarihi = mac.MacTarihi,
            Stadyum = mac.Stadyum,
            Hakem = mac.Hakem,
            Durum = mac.Durum,
            EvSahibiFormu = TakimFormunuDonustur(
                mac.EvSahibiTakim,
                evSahibiFormu),
            DeplasmanFormu = TakimFormunuDonustur(
                mac.DeplasmanTakim,
                deplasmanFormu),
            EvSahibiSonMaclar = evSahibiSonMaclar,
            DeplasmanSonMaclar = deplasmanSonMaclar,
            IkiliRekabet = ikiliRekabet
        };

        _logger.LogInformation(
            "Maç analiz verisi hazırlandı. MacId: {MacId}",
            macId);

        return ServiceResult<MacAnalizVerisiDto>.BasariliSonuc(
            sonuc,
            "Maç analiz verisi hazırlandı.");
    }

    public string PromptVerisiOlustur(MacAnalizVerisiDto veri)
    {
        var metin = new StringBuilder();

        metin.AppendLine("MAÇ BİLGİSİ");
        metin.AppendLine($"Maç ID: {veri.MacId}");
        metin.AppendLine($"Lig: {veri.Lig}");
        metin.AppendLine($"Ülke: {veri.Ulke ?? "Bilinmiyor"}");
        metin.AppendLine($"Sezon: {veri.Sezon ?? "Bilinmiyor"}");
        metin.AppendLine($"Maç: {veri.EvSahibi} - {veri.Deplasman}");
        metin.AppendLine($"Tarih UTC: {veri.MacTarihi:O}");
        metin.AppendLine($"Stadyum: {veri.Stadyum ?? "Bilinmiyor"}");
        metin.AppendLine($"Hakem: {veri.Hakem ?? "Bilinmiyor"}");
        metin.AppendLine();

        TakimFormunuYaz(
            metin,
            "EV SAHİBİ FORMU",
            veri.EvSahibiFormu);

        TakimFormunuYaz(
            metin,
            "DEPLASMAN FORMU",
            veri.DeplasmanFormu);

        MacListesiniYaz(
            metin,
            "EV SAHİBİNİN SON MAÇLARI",
            veri.EvSahibiSonMaclar);

        MacListesiniYaz(
            metin,
            "DEPLASMANIN SON MAÇLARI",
            veri.DeplasmanSonMaclar);

        MacListesiniYaz(
            metin,
            "İKİLİ REKABET",
            veri.IkiliRekabet);

        return metin.ToString();
    }

    private async Task<TakimFormu?> TakimFormuGetirAsync(
        int takimId,
        int? ligId,
        CancellationToken cancellationToken)
    {
        return await _dbContext.TakimFormlari
            .AsNoTracking()
            .Where(x =>
                x.TakimId == takimId &&
                (ligId == null || x.LigId == ligId))
            .OrderByDescending(x => x.HesaplamaTarihi)
            .FirstOrDefaultAsync(cancellationToken);
    }

    private async Task<List<GecmisMacOzetiDto>> SonMaclariGetirAsync(
        int takimId,
        int haricMacId,
        int adet,
        CancellationToken cancellationToken)
    {
        return await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x =>
                x.Id != haricMacId &&
                x.MacTarihi < DateTime.UtcNow &&
                (x.EvSahibiTakimId == takimId ||
                 x.DeplasmanTakimId == takimId) &&
                x.EvSahibiSkor != null &&
                x.DeplasmanSkor != null)
            .OrderByDescending(x => x.MacTarihi)
            .Take(adet)
            .Select(x => new GecmisMacOzetiDto
            {
                MacId = x.Id,
                MacTarihi = x.MacTarihi,
                EvSahibi = x.EvSahibiTakim.Ad,
                Deplasman = x.DeplasmanTakim.Ad,
                EvSahibiSkor = x.EvSahibiSkor,
                DeplasmanSkor = x.DeplasmanSkor,
                Durum = x.Durum
            })
            .ToListAsync(cancellationToken);
    }

    private async Task<List<GecmisMacOzetiDto>> IkiliRekabetGetirAsync(
        int takim1Id,
        int takim2Id,
        int haricMacId,
        int adet,
        CancellationToken cancellationToken)
    {
        return await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x =>
                x.Id != haricMacId &&
                x.EvSahibiSkor != null &&
                x.DeplasmanSkor != null &&
                (
                    (x.EvSahibiTakimId == takim1Id &&
                     x.DeplasmanTakimId == takim2Id)
                    ||
                    (x.EvSahibiTakimId == takim2Id &&
                     x.DeplasmanTakimId == takim1Id)
                ))
            .OrderByDescending(x => x.MacTarihi)
            .Take(adet)
            .Select(x => new GecmisMacOzetiDto
            {
                MacId = x.Id,
                MacTarihi = x.MacTarihi,
                EvSahibi = x.EvSahibiTakim.Ad,
                Deplasman = x.DeplasmanTakim.Ad,
                EvSahibiSkor = x.EvSahibiSkor,
                DeplasmanSkor = x.DeplasmanSkor,
                Durum = x.Durum
            })
            .ToListAsync(cancellationToken);
    }

    private static TakimAnalizOzetiDto TakimFormunuDonustur(
        Takim takim,
        TakimFormu? form)
    {
        return new TakimAnalizOzetiDto
        {
            TakimId = takim.Id,
            TakimAdi = takim.Ad,
            SonMacSayisi = form?.SonMacSayisi ?? 0,
            Galibiyet = form?.Galibiyet ?? 0,
            Beraberlik = form?.Beraberlik ?? 0,
            Maglubiyet = form?.Maglubiyet ?? 0,
            AttigiGol = form?.AttigiGol ?? 0,
            YedigiGol = form?.YedigiGol ?? 0,
            MacBasinaGolOrtalamasi =
                form?.MacBasinaGolOrtalamasi ?? 0,
            MacBasinaYenilenGolOrtalamasi =
                form?.MacBasinaYenilenGolOrtalamasi ?? 0,
            IkiBucukUstYuzdesi =
                form?.IkiBucukUstYuzdesi ?? 0,
            KarsilikliGolYuzdesi =
                form?.KarsilikliGolYuzdesi ?? 0
        };
    }

    private static void TakimFormunuYaz(
        StringBuilder metin,
        string baslik,
        TakimAnalizOzetiDto form)
    {
        metin.AppendLine(baslik);
        metin.AppendLine($"Takım: {form.TakimAdi}");
        metin.AppendLine($"Son maç sayısı: {form.SonMacSayisi}");
        metin.AppendLine(
            $"Galibiyet/Beraberlik/Mağlubiyet: " +
            $"{form.Galibiyet}/{form.Beraberlik}/{form.Maglubiyet}");
        metin.AppendLine(
            $"Attığı/Yediği gol: {form.AttigiGol}/{form.YedigiGol}");
        metin.AppendLine(
            $"Maç başına gol: {form.MacBasinaGolOrtalamasi:0.00}");
        metin.AppendLine(
            $"Maç başına yenilen gol: " +
            $"{form.MacBasinaYenilenGolOrtalamasi:0.00}");
        metin.AppendLine(
            $"2.5 üst yüzdesi: %{form.IkiBucukUstYuzdesi:0.00}");
        metin.AppendLine(
            $"Karşılıklı gol yüzdesi: " +
            $"%{form.KarsilikliGolYuzdesi:0.00}");
        metin.AppendLine();
    }

    private static void MacListesiniYaz(
        StringBuilder metin,
        string baslik,
        IReadOnlyCollection<GecmisMacOzetiDto> maclar)
    {
        metin.AppendLine(baslik);

        if (maclar.Count == 0)
        {
            metin.AppendLine("Kayıt bulunamadı.");
            metin.AppendLine();
            return;
        }

        foreach (var mac in maclar)
        {
            metin.AppendLine(
                $"{mac.MacTarihi:yyyy-MM-dd} | " +
                $"{mac.EvSahibi} {mac.EvSahibiSkor} - " +
                $"{mac.DeplasmanSkor} {mac.Deplasman}");
        }

        metin.AppendLine();
    }
}
