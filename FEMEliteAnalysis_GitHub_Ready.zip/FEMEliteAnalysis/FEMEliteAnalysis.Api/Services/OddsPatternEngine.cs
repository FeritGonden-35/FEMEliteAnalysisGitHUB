using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

/// <summary>
/// V5.1 odds-pattern motoru. İnternette dolaşan oran tablolarını "gerçek" kabul etmez;
/// yalnız hipotez olarak tutar ve FEM veritabanındaki bitmiş maçlarla backtest eder.
/// </summary>
public class OddsPatternEngine : IOddsPatternEngine
{
    private readonly FemDbContext _db;
    public OddsPatternEngine(FemDbContext db) => _db = db;

    private sealed record Pattern(int No, decimal O1, decimal OX, decimal O2, bool Simetrik, string[] Adaylar);

    private static readonly Pattern[] Patterns =
    {
        new(1, 2.00m, 3.20m, 2.60m, true,  new[]{"MSX","X2","1/X","2/X"}),
        new(2, 2.20m, 3.20m, 2.30m, true,  new[]{"MSX","X2","1/X","2/X"}),
        new(3, 2.10m, 3.20m, 2.50m, true,  new[]{"KG VAR","2.5 ÜST","1/2","2/1"}),
        new(4, 2.10m, 3.20m, 2.60m, true,  new[]{"X2","MS2"}),
        new(5, 1.50m, 3.30m, 4.30m, true,  new[]{"KG VAR","2/1","1/X","2/X"}),
        new(6, 1.45m, 3.40m, 4.60m, true,  new[]{"2.5 ÜST","X2","2/1"}),
        new(7, 1.80m, 3.10m, 3.10m, true,  new[]{"MSX","X/X","1/X","2/X"}),
        new(8, 1.35m, 3.60m, 5.50m, true,  new[]{"KG VAR","1/X","2/X"}),
        new(9, 1.70m, 3.10m, 3.50m, true,  new[]{"MS1","MS1 + 1.5 ÜST","MS1 + 3.5 ALT"}),
        new(10,2.50m, 3.10m, 2.10m, false, new[]{"İY X","X/1","X/2"}),
        new(11,1.85m, 3.20m, 2.90m, true,  new[]{"MSX","KG VAR","1/X","2/X"}),
        new(14,1.85m, 2.90m, 3.20m, true,  new[]{"MSX","X/X","İY X"}),
    };

    public async Task<ServiceResult<OddsPatternSonucDto>> AnalizEtAsync(int macId, CancellationToken ct)
    {
        var r = await HizliAnalizAsync(macId, ct);
        return r is null
            ? ServiceResult<OddsPatternSonucDto>.BasarisizSonuc("Bu maçta MS1/MSX/MS2 gerçek oran üçlüsü bulunamadı veya pattern benzerliği düşük.")
            : ServiceResult<OddsPatternSonucDto>.BasariliSonuc(r);
    }

    public async Task<OddsPatternSonucDto?> HizliAnalizAsync(int macId, CancellationToken ct)
    {
        var current = await SonOranUclusu(macId, ct);
        if (current is null) return null;

        Pattern? best = null; decimal bestSim = 0; bool mirrored = false;
        foreach (var p in Patterns)
        {
            var sim = Similarity(current.Value.o1, current.Value.ox, current.Value.o2, p.O1, p.OX, p.O2);
            if (sim > bestSim) { best = p; bestSim = sim; mirrored = false; }
            if (p.Simetrik)
            {
                var rev = Similarity(current.Value.o1, current.Value.ox, current.Value.o2, p.O2, p.OX, p.O1);
                if (rev > bestSim) { best = p; bestSim = rev; mirrored = true; }
            }
        }
        if (best is null || bestSim < 0.72m) return null;

        var finished = await _db.Maclar.AsNoTracking()
            .Where(x => x.Id != macId && x.EvSahibiSkor != null && x.DeplasmanSkor != null)
            .OrderByDescending(x => x.MacTarihi)
            .Take(1800)
            .Select(x => new { x.Id, x.EvSahibiSkor, x.DeplasmanSkor, x.IlkYariEvSahibiSkor, x.IlkYariDeplasmanSkor })
            .ToListAsync(ct);
        var ids = finished.Select(x => x.Id).ToList();
        var odds = await _db.BahisOranlari.AsNoTracking()
            .Where(x => ids.Contains(x.MacId) && (x.MarketKodu == "MS1" || x.MarketKodu == "MSX" || x.MarketKodu == "MS2"))
            .OrderByDescending(x => x.AlinmaTarihi)
            .ToListAsync(ct);
        var grouped = odds.GroupBy(x => x.MacId).ToDictionary(g => g.Key, g => g.GroupBy(x => x.MarketKodu).ToDictionary(z => z.Key, z => z.First().Oran, StringComparer.OrdinalIgnoreCase));

        var hits = new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
        foreach (var a in best.Adaylar) hits[a] = 0;
        var sample = 0;
        foreach (var m in finished)
        {
            if (!grouped.TryGetValue(m.Id, out var d) || !d.TryGetValue("MS1", out var o1) || !d.TryGetValue("MSX", out var ox) || !d.TryGetValue("MS2", out var o2)) continue;
            var sim = Similarity(o1, ox, o2, best.O1, best.OX, best.O2);
            if (best.Simetrik) sim = Math.Max(sim, Similarity(o1, ox, o2, best.O2, best.OX, best.O1));
            if (sim < 0.78m) continue;
            sample++;
            foreach (var a in best.Adaylar) if (Gerceklesti(a, m.EvSahibiSkor!.Value, m.DeplasmanSkor!.Value, m.IlkYariEvSahibiSkor, m.IlkYariDeplasmanSkor)) hits[a]++;
        }

        var dto = new OddsPatternSonucDto
        {
            PatternNo = best.No,
            Referans = $"{best.O1:0.00} / {best.OX:0.00} / {best.O2:0.00}" + (mirrored ? " (ters eşleşme)" : ""),
            Benzerlik = Math.Round(bestSim * 100m, 1),
            Simetrik = best.Simetrik,
            Orneklem = sample
        };
        foreach (var kv in hits)
            dto.BasariOranlari[kv.Key] = sample == 0 ? 0 : Math.Round(kv.Value * 100m / sample, 1);
        if (dto.BasariOranlari.Count > 0)
        {
            var top = dto.BasariOranlari.OrderByDescending(x => x.Value).First();
            dto.EnGucluSinyal = top.Key;
            dto.EnGucluSinyalYuzdesi = top.Value;
        }
        dto.Durum = sample < 25 ? "Veri yetersiz" : dto.EnGucluSinyalYuzdesi >= 68 ? "Güçlü pattern" : dto.EnGucluSinyalYuzdesi >= 58 ? "Destekleyici pattern" : "Zayıf pattern";
        return dto;
    }

    private async Task<(decimal o1,decimal ox,decimal o2)?> SonOranUclusu(int macId, CancellationToken ct)
    {
        var rows = await _db.BahisOranlari.AsNoTracking().Where(x => x.MacId == macId && (x.MarketKodu == "MS1" || x.MarketKodu == "MSX" || x.MarketKodu == "MS2"))
            .OrderByDescending(x => x.AlinmaTarihi).ToListAsync(ct);
        decimal? F(string k) => rows.FirstOrDefault(x => x.MarketKodu.Equals(k,StringComparison.OrdinalIgnoreCase))?.Oran;
        var a=F("MS1"); var b=F("MSX"); var c=F("MS2");
        return a.HasValue&&b.HasValue&&c.HasValue ? (a.Value,b.Value,c.Value) : null;
    }

    private static decimal Similarity(decimal a, decimal b, decimal c, decimal x, decimal y, decimal z)
    {
        static decimal One(decimal q, decimal t)
        {
            var rel = Math.Abs(q-t) / Math.Max(1m,t);
            return Math.Clamp(1m-rel/0.22m,0m,1m);
        }
        return One(a,x)*0.4m + One(b,y)*0.25m + One(c,z)*0.35m;
    }

    private static bool Gerceklesti(string market, int ev, int dep, int? iyEv, int? iyDep)
    {
        var m = market.ToUpperInvariant().Replace('İ','I').Replace('Ü','U');
        var ms = ev>dep?"1":ev<dep?"2":"X";
        var iy = iyEv.HasValue&&iyDep.HasValue ? (iyEv>iyDep?"1":iyEv<iyDep?"2":"X") : "?";
        var tg=ev+dep; var kg=ev>0&&dep>0;
        if (m=="MS1") return ms=="1"; if(m=="MS2") return ms=="2"; if(m is "MSX" or "X") return ms=="X";
        if(m=="X2") return ms!="1"; if(m=="1X") return ms!="2"; if(m=="KG VAR") return kg; if(m=="2.5 UST") return tg>2;
        if(m=="IY X") return iy=="X";
        if(m.Contains('/')) { var p=m.Split('/'); return p.Length==2 && iy==p[0] && ms==p[1]; }
        if(m.StartsWith("MS1 +")) return ms=="1" && Gerceklesti(m[6..].Trim(),ev,dep,iyEv,iyDep);
        if(m.StartsWith("MS2 +")) return ms=="2" && Gerceklesti(m[6..].Trim(),ev,dep,iyEv,iyDep);
        if(m=="1.5 UST") return tg>1; if(m=="3.5 ALT") return tg<4;
        return false;
    }
}
