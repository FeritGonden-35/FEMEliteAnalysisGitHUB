using FEMEliteAnalysis.Api.Dtos.Historical;

namespace FEMEliteAnalysis.Api.Services;

public class HistoricalPoolStatusStore
{
    private readonly object _kilit = new();
    private HistoricalPoolStatusDto _durum = new();

    public HistoricalPoolStatusDto Getir()
    {
        lock (_kilit)
        {
            return Kopyala(_durum);
        }
    }

    public bool Baslat(string baslangic, string bitis, int toplamSezon, int toplamLig)
    {
        lock (_kilit)
        {
            if (_durum.CalisiyorMu) return false;
            _durum = new HistoricalPoolStatusDto
            {
                CalisiyorMu = true,
                BaslamaZamani = DateTime.UtcNow,
                BaslangicSezonu = baslangic,
                BitisSezonu = bitis,
                ToplamSezon = toplamSezon,
                ToplamLig = toplamLig,
                SonIslem = "Tarihsel veri havuzu aktarımı başlatıldı."
            };
            return true;
        }
    }

    public void Guncelle(string sezon, int basarili, int basarisiz, long eklenen, long guncellenen, string? hata)
    {
        lock (_kilit)
        {
            _durum.IslenenSezon++;
            _durum.BasariliAktarim += basarili;
            _durum.BasarisizAktarim += basarisiz;
            _durum.EklenenMac += eklenen;
            _durum.GuncellenenMac += guncellenen;
            _durum.SonIslem = $"{sezon} sezonu işlendi.";
            if (!string.IsNullOrWhiteSpace(hata)) _durum.SonHata = hata;
        }
    }

    public void Bitir(string mesaj, string? hata = null)
    {
        lock (_kilit)
        {
            _durum.CalisiyorMu = false;
            _durum.BitisZamani = DateTime.UtcNow;
            _durum.SonIslem = mesaj;
            if (!string.IsNullOrWhiteSpace(hata)) _durum.SonHata = hata;
        }
    }

    private static HistoricalPoolStatusDto Kopyala(HistoricalPoolStatusDto x) => new()
    {
        CalisiyorMu = x.CalisiyorMu,
        BaslamaZamani = x.BaslamaZamani,
        BitisZamani = x.BitisZamani,
        BaslangicSezonu = x.BaslangicSezonu,
        BitisSezonu = x.BitisSezonu,
        ToplamSezon = x.ToplamSezon,
        IslenenSezon = x.IslenenSezon,
        ToplamLig = x.ToplamLig,
        BasariliAktarim = x.BasariliAktarim,
        BasarisizAktarim = x.BasarisizAktarim,
        EklenenMac = x.EklenenMac,
        GuncellenenMac = x.GuncellenenMac,
        SonIslem = x.SonIslem,
        SonHata = x.SonHata
    };
}
