using System.Globalization;
using System.Net.Http.Json;
using System.Text.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Dtos.TheSportsDb;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class UygunMacService : IUygunMacService
{
    private const int KaynakIdCarpani = -10;
    private readonly HttpClient _httpClient;
    private readonly FemDbContext _dbContext;
    private readonly ISqlTakimFormService _formService;
    private readonly ITakimSaglayiciKimlikService _kimlikService;
    private readonly TheSportsDbOptions _options;
    private readonly ILogger<UygunMacService> _logger;

    public UygunMacService(
        HttpClient httpClient,
        FemDbContext dbContext,
        ISqlTakimFormService formService,
        ITakimSaglayiciKimlikService kimlikService,
        IOptions<TheSportsDbOptions> options,
        ILogger<UygunMacService> logger)
    {
        _httpClient = httpClient;
        _dbContext = dbContext;
        _formService = formService;
        _kimlikService = kimlikService;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<ServiceResult<List<UygunMacDto>>> UygunMaclariGetirAsync(
        int gunSayisi,
        int limit,
        CancellationToken cancellationToken)
    {
        var gun = Math.Clamp(gunSayisi, 1, 14);
        var tz = TimeZoneInfo.FindSystemTimeZoneById(
            "Turkey Standard Time");
        var simdiUtc = DateTime.UtcNow;
        var simdiYerel = TimeZoneInfo.ConvertTimeFromUtc(
            simdiUtc, tz);

        // /uygunmaclar 1 = Türkiye saatine göre bugünün tamamı.
        // Önceki sürüm komutun yazıldığı andan sonrasını aradığı için
        // gün içinde daha önce başlayan maçları tamamen eliyordu.
        var baslangicYerel = simdiYerel.Date;
        var bitisYerel = baslangicYerel.AddDays(gun);

        var baslangicUtc = TimeZoneInfo.ConvertTimeToUtc(
            baslangicYerel, tz);
        var bitisUtc = TimeZoneInfo.ConvertTimeToUtc(
            bitisYerel, tz);

        // /uygunmaclar artık yalnızca appsettings'teki 20 çekirdek lig ile sınırlı değil.
        // /synclig ile elle eklenen (pozitif kaynak ID) ligler ve TheSportsDB provider'ın
        // eklediği (negatif normalize ID) ligler birlikte değerlendirilir.
        // Böylece veritabanında veri kalitesi oluşmuş tüm aktif futbol ligleri aday havuzuna girer.
        var uygunLigIdleri = await _dbContext.Ligler
            .AsNoTracking()
            .Where(x => x.AktifMi)
            .Select(x => x.Id)
            .ToHashSetAsync(cancellationToken);

        var adaylar = await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x =>
                x.MacTarihi >= baslangicUtc &&
                x.MacTarihi < bitisUtc &&
                x.LigId.HasValue &&
                uygunLigIdleri.Contains(x.LigId.Value) &&
                x.EvSahibiTakimId > 0 &&
                x.DeplasmanTakimId > 0)
            .OrderBy(x => x.MacTarihi)
            .Take(1500)
            .ToListAsync(cancellationToken);

        adaylar = adaylar
            .Where(x => !IstenmeyenMacMi(
                x.Lig?.Ad,
                x.EvSahibiTakim.Ad,
                x.DeplasmanTakim.Ad))
            .ToList();

        var sonuc = new List<UygunMacDto>();

        foreach (var mac in adaylar)
        {
            var veri = await _formService.MacKuponVerisiOlusturAsync(
                mac.Id, cancellationToken);

            if (!veri.Basarili || veri.Veri is null)
                continue;

            var v = veri.Veri;
            var puan = AnalizSkoruHesapla(
                v.EvSahibiGenelForm.ToplamMac,
                v.EvSahibiIcSahaForm.ToplamMac,
                v.DeplasmanGenelForm.ToplamMac,
                v.DeplasmanDisSahaForm.ToplamMac,
                v.H2H.ToplamMac);

            // V4.2: listeyi düşük/verimsiz maçlarla doldurma.
            // Genel veri tabanı sağlam olmalı ve en az bir ana market ailesinde güçlü veri kapsaması bulunmalı.
            var enIyiAnaMarketKalitesi = new[]
            {
                v.MacSonucuVeriKalitesi,
                v.GolMarketVeriKalitesi,
                v.IlkYariVeriKalitesi
            }.Max();

            if (puan < 60 || v.VeriKalitesiPuani < 60 || enIyiAnaMarketKalitesi < 65)
                continue;

            sonuc.Add(new UygunMacDto
            {
                MacId = mac.Id,
                MacTarihi = mac.MacTarihi,
                Lig = mac.Lig?.Ad ?? "Bilinmeyen Lig",
                EvSahibi = mac.EvSahibiTakim.Ad,
                Deplasman = mac.DeplasmanTakim.Ad,
                EvGenelMac = v.EvSahibiGenelForm.ToplamMac,
                EvIcSahaMac = v.EvSahibiIcSahaForm.ToplamMac,
                DepGenelMac = v.DeplasmanGenelForm.ToplamMac,
                DepDisSahaMac = v.DeplasmanDisSahaForm.ToplamMac,
                H2HMac = v.H2H.ToplamMac,
                VeriGuvenPuani = puan,
                Yildiz = YildizHesapla(puan),
                Rozet = RozetHesapla(puan)
            });
        }

        // V5: Aynı gerçek fikstür birden fazla provider/sezon kaydıyla geldiyse kullanıcıya tek kez göster.
        // MacId yerine takım adları + yerel maç saati üzerinden tekilleştiriyoruz.
        var tekilSonuc = sonuc
            .GroupBy(x => $"{NormalizeMacAnahtari(x.EvSahibi)}|{NormalizeMacAnahtari(x.Deplasman)}|{x.MacTarihi:yyyyMMddHHmm}")
            .Select(g => g.OrderByDescending(x => x.VeriGuvenPuani)
                .ThenByDescending(x => x.EvGenelMac + x.DepGenelMac + x.EvIcSahaMac + x.DepDisSahaMac)
                .First())
            .ToList();

        var sirali = tekilSonuc
            .OrderByDescending(x => x.VeriGuvenPuani)
            .ThenByDescending(x =>
                x.EvGenelMac + x.DepGenelMac +
                x.EvIcSahaMac + x.DepDisSahaMac)
            .ThenByDescending(x => x.H2HMac)
            .ThenBy(x => x.MacTarihi)
            .Take(Math.Clamp(limit, 1, 100))
            .ToList();

        var mesaj = sirali.Count > 0
            ? $"{sirali.Count} maç filtreyi geçti (Analiz Skoru ≥60, genel veri ≥60, ana market verisi ≥65)."
            : adaylar.Count == 0
                ? $"Önümüzdeki {gun} takvim gününde aktif lig havuzunda uygun fikstür bulunamadı."
                : $"{adaylar.Count} fikstür bulundu fakat yeterli form verisi üretilemedi.";

        return ServiceResult<List<UygunMacDto>>.BasariliSonuc(
            sirali, mesaj);
    }

    public async Task<ServiceResult<SeciliMacVeriCekSonucDto>> SeciliMacVerisiniCekAsync(
        int macId,
        CancellationToken cancellationToken)
    {
        if (!_options.Aktif || (string.IsNullOrWhiteSpace(_options.ApiKey) && string.IsNullOrWhiteSpace(_options.V1ApiKey)))
            return ServiceResult<SeciliMacVeriCekSonucDto>.BasarisizSonuc(
                "TheSportsDB aktif değil veya API anahtarı tanımlı değil.");

        var mac = await _dbContext.Maclar
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(x => x.Id == macId, cancellationToken);
        if (mac is null)
            return ServiceResult<SeciliMacVeriCekSonucDto>.BasarisizSonuc("Maç bulunamadı.");

        var once = await _formService.MacKuponVerisiOlusturAsync(macId, cancellationToken);
        var oncePuan = once.Veri?.VeriKalitesiPuani ?? 0;
        var sonuc = new SeciliMacVeriCekSonucDto
        {
            MacId = macId,
            MacAdi = $"{mac.EvSahibiTakim.Ad} - {mac.DeplasmanTakim.Ad}",
            VeriKalitesiOnce = oncePuan
        };

        var evSource = await _kimlikService.TheSportsDbIdGetirAsync(
            mac.EvSahibiTakimId,
            cancellationToken);
        var depSource = await _kimlikService.TheSportsDbIdGetirAsync(
            mac.DeplasmanTakimId,
            cancellationToken);

        if (!evSource.HasValue || !depSource.HasValue)
        {
            return ServiceResult<SeciliMacVeriCekSonucDto>.BasarisizSonuc(
                "Seçilen maçın takımlarından en az biri TheSportsDB ile eşleştirilemedi. " +
                "Takım adını /takim komutuyla kontrol edin veya V2 API anahtarını doğrulayın.");
        }

        var events = new Dictionary<string, TheSportsDbEventDto>();

        // eventslast.php Premium'da dahi takım başına sınırlı bir son maç listesi döndürebilir.
        // eventsh2h.php ise güncel V1 dokümantasyonunda yer almıyor ve bazı hesaplarda 404/boş dönüyor.
        // Bu nedenle takım geçmişi + H2H'yi sezon fikstürlerinden türetiyoruz.
        await EndpointTakimMaclariniEkleAsync($"eventslast.php?id={evSource.Value}", evSource.Value, depSource.Value, events, sonuc.Uyarilar, cancellationToken);
        await EndpointTakimMaclariniEkleAsync($"eventslast.php?id={depSource.Value}", evSource.Value, depSource.Value, events, sonuc.Uyarilar, cancellationToken);

        // V4.4: Avrupa kupası maçında yalnızca UEFA turnuvasını çekmek formu eksik bırakıyordu.
        // Takımların DB geçmişinden oynadıkları ana/yerel ligleri de bulup son sezonları beraber çekiyoruz.
        var ligKaynakIdleri = new HashSet<int>();
        var mevcutLigSourceId = KaynakLigIdOku(mac.Lig?.HariciLigId);
        if (mevcutLigSourceId.HasValue) ligKaynakIdleri.Add(mevcutLigSourceId.Value);

        var evAliasIdleri = await TakimAliasIdleriniBulAsync(mac.EvSahibiTakimId, evSource.Value, cancellationToken);
        var depAliasIdleri = await TakimAliasIdleriniBulAsync(mac.DeplasmanTakimId, depSource.Value, cancellationToken);

        var evYerelLigler = await TakiminAnaLigKaynakIdleriniBulAsync(evAliasIdleri, mac.LigId, mac.MacTarihi, cancellationToken);
        var depYerelLigler = await TakiminAnaLigKaynakIdleriniBulAsync(depAliasIdleri, mac.LigId, mac.MacTarihi, cancellationToken);
        foreach (var id in evYerelLigler) ligKaynakIdleri.Add(id);
        foreach (var id in depYerelLigler) ligKaynakIdleri.Add(id);

        if (evYerelLigler.Count > 0) sonuc.Bilgiler.Add($"{mac.EvSahibiTakim.Ad}: yerel lig geçmişi dahil ({string.Join(", ", evYerelLigler)}).");
        if (depYerelLigler.Count > 0) sonuc.Bilgiler.Add($"{mac.DeplasmanTakim.Ad}: yerel lig geçmişi dahil ({string.Join(", ", depYerelLigler)}).");

        var sezonlar = _options.Sezonlar
            .Append(_options.VarsayilanSezon)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(4)
            .ToList();

        foreach (var ligSourceId in ligKaynakIdleri.Take(6))
        {
            foreach (var sezon in sezonlar)
            {
                await EndpointTakimMaclariniEkleAsync(
                    $"eventsseason.php?id={ligSourceId}&s={Uri.EscapeDataString(sezon)}",
                    evSource.Value, depSource.Value, events, sonuc.Uyarilar, cancellationToken);

                var tekYil = SezonBaslangicYili(sezon);
                if (!string.IsNullOrWhiteSpace(tekYil) && !string.Equals(tekYil, sezon, StringComparison.OrdinalIgnoreCase))
                {
                    await EndpointTakimMaclariniEkleAsync(
                        $"eventsseason.php?id={ligSourceId}&s={Uri.EscapeDataString(tekYil)}",
                        evSource.Value, depSource.Value, events, sonuc.Uyarilar, cancellationToken);
                }
            }
        }

        if (ligKaynakIdleri.Count == 0)
            sonuc.Uyarilar.Add("Takımlar için sezon bazlı lig kaynağı bulunamadı; yalnızca son maç endpointleri kullanıldı.");

        var seciliEvents = events.Values
            .OrderByDescending(x => TarihOku(x) ?? DateTime.MinValue)
            .Take(120)
            .ToList();

        sonuc.ApiKayitSayisi = seciliEvents.Count;
        foreach (var dto in seciliEvents)
        {
            var durum = await KaydetAsync(dto, cancellationToken);
            if (durum == 1) sonuc.EklenenMacSayisi++;
            else if (durum == 2) sonuc.GuncellenenMacSayisi++;
        }

        // Korner/kart/şut marketleri için seçilen en yeni geçmiş maçları event stats ile zenginleştir.
        var statsAdaylari = seciliEvents
            .Where(x => NullableInt(x.HomeScore).HasValue && NullableInt(x.AwayScore).HasValue)
            .Take(24)
            .ToList();
        foreach (var dto in statsAdaylari)
            await EventIstatistikleriniKaydetAsync(dto, sonuc.Uyarilar, cancellationToken);

        var sonra = await _formService.MacKuponVerisiOlusturAsync(macId, cancellationToken);
        sonuc.VeriKalitesiSonra = sonra.Veri?.VeriKalitesiPuani ?? oncePuan;

        return ServiceResult<SeciliMacVeriCekSonucDto>.BasariliSonuc(
            sonuc, "Seçili maçın özel geçmiş verileri güncellendi.");
    }

    private async Task<List<int>> TakimAliasIdleriniBulAsync(
        int takimId, int theSportsDbId, CancellationToken cancellationToken)
    {
        return await _dbContext.Takimlar
            .AsNoTracking()
            .Where(x => x.Id == takimId ||
                        x.TheSportsDbTakimId == theSportsDbId ||
                        x.HariciTakimId == theSportsDbId)
            .Select(x => x.Id)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    private async Task<List<int>> TakiminAnaLigKaynakIdleriniBulAsync(
        IReadOnlyCollection<int> takimIdleri,
        int? mevcutLigId,
        DateTime analizMacTarihi,
        CancellationToken cancellationToken)
    {
        if (takimIdleri.Count == 0) return new List<int>();

        var ucSezonOnce = analizMacTarihi.AddYears(-3).AddMonths(-2);
        var ligSayilari = await _dbContext.Maclar
            .AsNoTracking()
            .Where(x => x.LigId.HasValue &&
                        x.LigId != mevcutLigId &&
                        x.MacTarihi >= ucSezonOnce &&
                        x.MacTarihi < analizMacTarihi &&
                        x.EvSahibiSkor.HasValue && x.DeplasmanSkor.HasValue &&
                        (takimIdleri.Contains(x.EvSahibiTakimId) || takimIdleri.Contains(x.DeplasmanTakimId)))
            .GroupBy(x => x.LigId!.Value)
            .Select(g => new { LigId = g.Key, MacSayisi = g.Count() })
            .OrderByDescending(x => x.MacSayisi)
            .Take(5)
            .ToListAsync(cancellationToken);

        var ligIds = ligSayilari.Select(x => x.LigId).ToList();
        if (ligIds.Count == 0) return new List<int>();

        var ligler = await _dbContext.Ligler
            .AsNoTracking()
            .Where(x => ligIds.Contains(x.Id) && x.HariciLigId.HasValue)
            .ToListAsync(cancellationToken);

        return ligSayilari
            .Select(x => ligler.FirstOrDefault(l => l.Id == x.LigId))
            .Where(x => x is not null && !AvrupaVeyaHazirlikLigiMi(x.Ad))
            .Select(x => KaynakLigIdOku(x!.HariciLigId))
            .Where(x => x.HasValue)
            .Select(x => x!.Value)
            .Distinct()
            .Take(2)
            .ToList();
    }

    private static bool AvrupaVeyaHazirlikLigiMi(string? ligAdi)
    {
        if (string.IsNullOrWhiteSpace(ligAdi)) return false;
        var a = ligAdi.ToLowerInvariant();
        return a.Contains("champions league") ||
               a.Contains("europa league") ||
               a.Contains("conference league") ||
               a.Contains("uefa") ||
               a.Contains("friendly") ||
               a.Contains("club friend");
    }

    private async Task EndpointTakimMaclariniEkleAsync(
        string endpoint,
        int evSourceId,
        int depSourceId,
        Dictionary<string, TheSportsDbEventDto> hedef,
        List<string> uyarilar,
        CancellationToken cancellationToken)
    {
        try
        {
            using var httpResponse = await _httpClient.GetAsync(endpoint, cancellationToken);
            var body = await httpResponse.Content.ReadAsStringAsync(cancellationToken);
            if (!httpResponse.IsSuccessStatusCode)
            {
                var kisa = body.Length > 180 ? body[..180] : body;
                _logger.LogWarning("TheSportsDB endpoint HTTP {Status}: {Endpoint} Body: {Body}",
                    (int)httpResponse.StatusCode, endpoint, kisa);
                uyarilar.Add($"{endpoint.Split('?')[0]} HTTP {(int)httpResponse.StatusCode}");
                return;
            }

            var response = JsonSerializer.Deserialize<TheSportsDbEventsResponse>(body);
            var gelen = response?.Results ?? response?.Events;
            if (gelen is null) return;

            foreach (var item in gelen)
            {
                if (string.IsNullOrWhiteSpace(item.EventId)) continue;
                if (!PozitifInt(item.HomeTeamId, out var h) || !PozitifInt(item.AwayTeamId, out var a)) continue;

                var ilgili = h == evSourceId || a == evSourceId || h == depSourceId || a == depSourceId;
                if (ilgili) hedef[item.EventId] = item;
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Seçili maç endpointi okunamadı: {Endpoint}", endpoint);
            uyarilar.Add($"Endpoint okunamadı: {endpoint.Split('?')[0]} ({ex.GetType().Name})");
        }
    }

    private async Task EventIstatistikleriniKaydetAsync(
        TheSportsDbEventDto dto,
        List<string> uyarilar,
        CancellationToken ct)
    {
        if (!PozitifInt(dto.EventId, out var sourceEventId) ||
            !PozitifInt(dto.HomeTeamId, out var homeSourceId) ||
            !PozitifInt(dto.AwayTeamId, out var awaySourceId))
            return;

        try
        {
            using var response = await _httpClient.GetAsync($"lookupeventstats.php?id={sourceEventId}", ct);
            if (!response.IsSuccessStatusCode) return;
            var body = await response.Content.ReadAsStringAsync(ct);
            using var doc = JsonDocument.Parse(body);
            if (!doc.RootElement.TryGetProperty("eventstats", out var stats) || stats.ValueKind != JsonValueKind.Array)
                return;

            var macHariciAdaylari = new[] { KaynakId(sourceEventId), sourceEventId };
            var mac = await _dbContext.Maclar
                .FirstOrDefaultAsync(x => x.HariciMacId.HasValue && macHariciAdaylari.Contains(x.HariciMacId.Value), ct);
            if (mac is null) return;

            var homeTeam = await TheSportsDbTakiminiBulAsync(homeSourceId, ct);
            var awayTeam = await TheSportsDbTakiminiBulAsync(awaySourceId, ct);
            if (homeTeam is null || awayTeam is null) return;

            var homeValues = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var awayValues = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (var stat in stats.EnumerateArray())
            {
                var name = JsonString(stat, "strStat", "strStatistic", "name");
                if (string.IsNullOrWhiteSpace(name)) continue;
                var key = NormalizeStat(name);
                var hv = JsonInt(stat, "intHome", "strHome", "home");
                var av = JsonInt(stat, "intAway", "strAway", "away");
                if (hv.HasValue) homeValues[key] = hv.Value;
                if (av.HasValue) awayValues[key] = av.Value;
            }

            await UpsertIstatistikAsync(mac.Id, homeTeam.Id, homeValues, ct);
            await UpsertIstatistikAsync(mac.Id, awayTeam.Id, awayValues, ct);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Event stats alınamadı. EventId: {EventId}", sourceEventId);
        }
    }

    private async Task<Takim?> TheSportsDbTakiminiBulAsync(int sourceId, CancellationToken ct)
    {
        var normalized = KaynakId(sourceId);
        return await _dbContext.Takimlar.FirstOrDefaultAsync(x =>
            x.TheSportsDbTakimId == sourceId ||
            x.HariciTakimId == sourceId ||
            x.HariciTakimId == normalized, ct);
    }

    private async Task UpsertIstatistikAsync(int macId, int takimId, Dictionary<string, int> v, CancellationToken ct)
    {
        var row = await _dbContext.MacIstatistikleri.FirstOrDefaultAsync(x => x.MacId == macId && x.TakimId == takimId, ct);
        if (row is null)
        {
            row = new MacIstatistigi { MacId = macId, TakimId = takimId, KayitTarihi = DateTime.UtcNow };
            _dbContext.MacIstatistikleri.Add(row);
        }

        row.Sut = GetStat(v, "totalshots", "shots");
        row.IsabetliSut = GetStat(v, "shotsongoal", "shotsontarget");
        row.Korner = GetStat(v, "cornerkicks", "corners");
        row.Faul = GetStat(v, "fouls", "foulscommitted");
        row.SariKart = GetStat(v, "yellowcards");
        row.KirmiziKart = GetStat(v, "redcards");
        row.Ofsayt = GetStat(v, "offsides", "offside");
        await _dbContext.SaveChangesAsync(ct);
    }

    private static int? GetStat(Dictionary<string, int> values, params string[] keys)
    {
        foreach (var key in keys)
            if (values.TryGetValue(key, out var value)) return value;
        return null;
    }

    private static string NormalizeStat(string value) =>
        new string(value.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

    private static string? JsonString(JsonElement e, params string[] names)
    {
        foreach (var name in names)
            if (e.TryGetProperty(name, out var p) && p.ValueKind != JsonValueKind.Null)
                return p.ToString();
        return null;
    }

    private static int? JsonInt(JsonElement e, params string[] names)
    {
        var s = JsonString(e, names);
        if (string.IsNullOrWhiteSpace(s)) return null;
        var temiz = new string(s.Where(c => char.IsDigit(c) || c == '-').ToArray());
        return int.TryParse(temiz, out var x) ? x : null;
    }

    private async Task<int> KaydetAsync(TheSportsDbEventDto dto, CancellationToken cancellationToken)
    {
        if (!PozitifInt(dto.EventId, out var eventId) ||
            !PozitifInt(dto.LeagueId, out var leagueId) ||
            !PozitifInt(dto.HomeTeamId, out var homeId) ||
            !PozitifInt(dto.AwayTeamId, out var awayId)) return 0;
        var tarih = TarihOku(dto); if (!tarih.HasValue) return 0;

        var lig = await LigGetirAsync(leagueId, dto, cancellationToken);
        var ev = await TakimGetirAsync(homeId, dto.HomeTeamName, lig.Id, dto.Country, cancellationToken);
        var dep = await TakimGetirAsync(awayId, dto.AwayTeamName, lig.Id, dto.Country, cancellationToken);
        var hariciId = KaynakId(eventId);
        // /synclig pozitif TheSportsDB event ID'sini, eski uygun-mac sağlayıcısı ise -10
        // kodlamasını kullanabiliyor. İkisini aynı kayıt kabul ederek mükerrer maçı engelle.
        var kayit = await _dbContext.Maclar.FirstOrDefaultAsync(
            x => x.HariciMacId == eventId || x.HariciMacId == hariciId, cancellationToken);
        var yeni = kayit is null;
        if (kayit is null)
        {
            kayit = new Mac { HariciMacId = hariciId, OlusturmaTarihi = DateTime.UtcNow };
            _dbContext.Maclar.Add(kayit);
        }
        kayit.LigId = lig.Id; kayit.EvSahibiTakimId = ev.Id; kayit.DeplasmanTakimId = dep.Id;
        kayit.MacTarihi = tarih.Value; kayit.Durum = DurumOku(dto);
        kayit.EvSahibiSkor = NullableInt(dto.HomeScore); kayit.DeplasmanSkor = NullableInt(dto.AwayScore);
        kayit.IlkYariEvSahibiSkor = NullableInt(dto.HomeHalfTimeScore);
        kayit.IlkYariDeplasmanSkor = NullableInt(dto.AwayHalfTimeScore);
        kayit.Stadyum = dto.Venue; kayit.GuncellemeTarihi = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);
        return yeni ? 1 : 2;
    }

    private async Task<Lig> LigGetirAsync(int sourceId, TheSportsDbEventDto dto, CancellationToken ct)
    {
        var hid = KaynakId(sourceId);
        var sezon = string.IsNullOrWhiteSpace(dto.Season) ? _options.VarsayilanSezon : dto.Season.Trim();
        var lig = await _dbContext.Ligler.FirstOrDefaultAsync(
            x => (x.HariciLigId == sourceId || x.HariciLigId == hid) && x.Sezon == sezon, ct);

        // Aynı TheSportsDB ligi takvim-yılı / çapraz-sezon etiketi yüzünden bulunamadıysa
        // en yakın aktif kaydı tekrar kullan. Böylece /synclig ve /macvericek ayrı lig açmaz.
        lig ??= await _dbContext.Ligler
            .Where(x => x.HariciLigId == sourceId || x.HariciLigId == hid)
            .OrderByDescending(x => x.AktifMi)
            .ThenByDescending(x => x.Id)
            .FirstOrDefaultAsync(ct);

        if (lig is not null)
        {
            lig.AktifMi = true;
            if (!string.IsNullOrWhiteSpace(dto.LeagueName)) lig.Ad = dto.LeagueName.Trim();
            if (!string.IsNullOrWhiteSpace(dto.Country)) lig.Ulke = dto.Country;
            await _dbContext.SaveChangesAsync(ct);
            return lig;
        }

        lig = new Lig
        {
            HariciLigId = hid,
            Ad = dto.LeagueName?.Trim() ?? $"Lig {sourceId}",
            Ulke = dto.Country,
            Sezon = sezon,
            AktifMi = true
        };
        _dbContext.Ligler.Add(lig);
        await _dbContext.SaveChangesAsync(ct);
        return lig;
    }

    private async Task<Takim> TakimGetirAsync(int sourceId, string? ad, int ligId, string? ulke, CancellationToken ct)
    {
        var hid = KaynakId(sourceId);
        var t = await _dbContext.Takimlar.FirstOrDefaultAsync(x =>
            x.TheSportsDbTakimId == sourceId ||
            x.HariciTakimId == sourceId ||
            x.HariciTakimId == hid, ct);

        if (t is null)
        {
            t = new Takim
            {
                HariciTakimId = hid,
                TheSportsDbTakimId = sourceId,
                LigId = ligId,
                Ad = string.IsNullOrWhiteSpace(ad) ? $"Takım {sourceId}" : ad.Trim(),
                Ulke = ulke,
                AktifMi = true
            };
            _dbContext.Takimlar.Add(t);
        }
        else
        {
            t.LigId = ligId;
            t.TheSportsDbTakimId ??= sourceId;
            t.AktifMi = true;
            if (!string.IsNullOrWhiteSpace(ad)) t.Ad = ad.Trim();
            if (!string.IsNullOrWhiteSpace(ulke)) t.Ulke = ulke;
        }

        await _dbContext.SaveChangesAsync(ct);
        return t;
    }

    private static string? SezonBaslangicYili(string? sezon)
    {
        if (string.IsNullOrWhiteSpace(sezon)) return null;
        var ilk = sezon.Trim().Split('-', '/', '–', '—')[0].Trim();
        return ilk.Length == 4 && int.TryParse(ilk, out _) ? ilk : null;
    }

    private static int? SourceIdOku(int? hariciId) => hariciId.HasValue && hariciId.Value < 0 && Math.Abs(hariciId.Value) % 10 == 0 ? Math.Abs(hariciId.Value) / 10 : null;
    private static int? KaynakLigIdOku(int? hariciId)
    {
        if (!hariciId.HasValue || hariciId.Value == 0) return null;
        if (hariciId.Value > 0) return hariciId.Value;
        return SourceIdOku(hariciId);
    }
    private static int KaynakId(int id) { checked { return id * KaynakIdCarpani; } }
    private static bool PozitifInt(string? s, out int i) => int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out i) && i > 0;
    private static int? NullableInt(string? s) => int.TryParse(s, out var i) ? i : null;
    private static DateTime? TarihOku(TheSportsDbEventDto d)
    {
        if (!string.IsNullOrWhiteSpace(d.Timestamp) && DateTimeOffset.TryParse(d.Timestamp, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var ts)) return ts.UtcDateTime;
        if (string.IsNullOrWhiteSpace(d.DateEvent)) return null;
        var text = string.IsNullOrWhiteSpace(d.Time) ? d.DateEvent : $"{d.DateEvent} {d.Time}";
        return DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var dt) ? dt : null;
    }
    private static string DurumOku(TheSportsDbEventDto d) => d.Postponed == "yes" ? "postponed" : (!string.IsNullOrWhiteSpace(d.Status) ? d.Status.Trim() : (NullableInt(d.HomeScore).HasValue && NullableInt(d.AwayScore).HasValue ? "finished" : "scheduled"));

    public static int GuvenPuaniHesapla(
        int evGenel,
        int evSaha,
        int depGenel,
        int depSaha,
        int h2h)
    {
        return AnalizSkoruHesapla(
            evGenel, evSaha, depGenel, depSaha, h2h);
    }

    private static int AnalizSkoruHesapla(
        int evGenel,
        int evSaha,
        int depGenel,
        int depSaha,
        int h2h)
    {
        static decimal Oran(int mevcut, int hedef) =>
            Math.Min(mevcut / (decimal)hedef, 1m);

        // Form ana ağırlıktır. H2H yokluğu maçı kullanılmaz hale getirmez.
        var puan =
            Oran(evGenel, 20) * 25m +
            Oran(depGenel, 20) * 25m +
            Oran(evSaha, 10) * 17.5m +
            Oran(depSaha, 10) * 17.5m;

        // İki takımın da minimum genel formu varsa temel güncellik puanı.
        if (evGenel >= 10 && depGenel >= 10)
            puan += 10m;
        else if (evGenel >= 5 && depGenel >= 5)
            puan += 5m;

        puan += h2h > 0
            ? Oran(h2h, 10) * 5m
            : 2m;

        return Math.Clamp(
            (int)Math.Round(puan),
            0,
            100);
    }

    private static bool IstenmeyenMacMi(
        string? lig,
        string? evSahibi,
        string? deplasman)
    {
        var metin = $"{lig} {evSahibi} {deplasman}"
            .ToLowerInvariant();

        string[] engelli =
        {
            "friendly", "friendlies", "hazırlık", "hazirlik",
            "women", "woman", "kadın", "kadin",
            "u19", "u20", "u21", "u23", "youth",
            "reserve", "reserves", "academy"
        };

        return engelli.Any(metin.Contains);
    }

    private static int YildizHesapla(int p) => p >= 90 ? 5 : p >= 75 ? 4 : p >= 60 ? 3 : p >= 40 ? 2 : 1;
    private static string RozetHesapla(int p) => p >= 90 ? "🟢 Premium Analiz" : p >= 75 ? "🟢 Güvenilir" : p >= 60 ? "🟡 İncelenebilir" : p >= 40 ? "🟠 Riskli" : "🔴 Önerilmez";

    private static string NormalizeMacAnahtari(string value)
    {
        var chars = value.Trim().ToUpperInvariant()
            .Replace("İ", "I").Replace("Ü", "U").Replace("Ö", "O")
            .Replace("Ş", "S").Replace("Ğ", "G").Replace("Ç", "C")
            .Where(char.IsLetterOrDigit);
        return new string(chars.ToArray());
    }

}

