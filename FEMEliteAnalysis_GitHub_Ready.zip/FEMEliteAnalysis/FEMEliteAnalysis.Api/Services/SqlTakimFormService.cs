using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Globalization;
using System.Text;

namespace FEMEliteAnalysis.Api.Services;

public class SqlTakimFormService : ISqlTakimFormService
{
    private readonly FemDbContext _dbContext;
    private readonly MacAnalizOptions _options;

    public SqlTakimFormService(
        FemDbContext dbContext,
        IOptions<MacAnalizOptions> options)
    {
        _dbContext = dbContext;
        _options = options.Value;
    }

    public async Task<ServiceResult<MacKuponVerisiDto>>
        MacKuponVerisiOlusturAsync(
            int macId,
            CancellationToken cancellationToken)
    {
        var mac = await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == macId,
                cancellationToken);

        if (mac is null)
        {
            return ServiceResult<MacKuponVerisiDto>.BasarisizSonuc(
                "Analiz edilecek maç bulunamadı.");
        }

        var genelAdet = Math.Max(
            5,
            _options.GenelFormMacSayisi);

        var sahaAdet = Math.Max(
            5,
            _options.IcDisSahaMacSayisi);

        var h2hAdet = Math.Max(
            3,
            _options.H2HMacSayisi);

        // Esas takım her zaman pozitif TheSportsDB HariciTakimId taşıyan
        // canonical kayıttır. Maç eski/geçici takım kaydına bağlı olsa bile
        // aynı kulübün canonical + alias ID'leri birlikte sorgulanır.
        var evTakimGrubu = await CanonicalTakimGrubuGetirAsync(
            mac.EvSahibiTakim,
            cancellationToken);

        var depTakimGrubu = await CanonicalTakimGrubuGetirAsync(
            mac.DeplasmanTakim,
            cancellationToken);

        var evGenelMaclar = await TakimMaclariniGetirAsync(
            evTakimGrubu.TakimIdleri,
            mac.MacTarihi,
            genelAdet,
            null,
            cancellationToken);

        var evIcSahaMaclar = await TakimMaclariniGetirAsync(
            evTakimGrubu.TakimIdleri,
            mac.MacTarihi,
            sahaAdet,
            true,
            cancellationToken);

        var depGenelMaclar = await TakimMaclariniGetirAsync(
            depTakimGrubu.TakimIdleri,
            mac.MacTarihi,
            genelAdet,
            null,
            cancellationToken);

        var depDisSahaMaclar = await TakimMaclariniGetirAsync(
            depTakimGrubu.TakimIdleri,
            mac.MacTarihi,
            sahaAdet,
            false,
            cancellationToken);

        var h2hMaclar = await H2HMaclariniGetirAsync(
            evTakimGrubu.TakimIdleri,
            depTakimGrubu.TakimIdleri,
            mac.MacTarihi,
            h2hAdet,
            cancellationToken);

        var dto = new MacKuponVerisiDto
        {
            MacId = mac.Id,
            HariciMacId = mac.HariciMacId ?? 0,
            Lig = mac.Lig?.Ad ?? "Bilinmeyen Lig",
            MacTarihi = mac.MacTarihi,
            EvSahibi = evTakimGrubu.CanonicalTakim.Ad,
            Deplasman = depTakimGrubu.CanonicalTakim.Ad,

            EvSahibiGenelForm = TakimOzetiniOlustur(
                evTakimGrubu.CanonicalTakim,
                evTakimGrubu.TakimIdleri,
                evGenelMaclar),

            EvSahibiIcSahaForm = TakimOzetiniOlustur(
                evTakimGrubu.CanonicalTakim,
                evTakimGrubu.TakimIdleri,
                evIcSahaMaclar),

            DeplasmanGenelForm = TakimOzetiniOlustur(
                depTakimGrubu.CanonicalTakim,
                depTakimGrubu.TakimIdleri,
                depGenelMaclar),

            DeplasmanDisSahaForm = TakimOzetiniOlustur(
                depTakimGrubu.CanonicalTakim,
                depTakimGrubu.TakimIdleri,
                depDisSahaMaclar),

            H2H = H2HOzetOlustur(
                evTakimGrubu.CanonicalTakim,
                evTakimGrubu.TakimIdleri,
                depTakimGrubu.CanonicalTakim,
                depTakimGrubu.TakimIdleri,
                h2hMaclar)
        };

        dto.EvSahibiIstatistik = await TakimMarketIstatistikleriniGetirAsync(
            evTakimGrubu.TakimIdleri,
            evGenelMaclar.Select(x => x.Id),
            cancellationToken);

        dto.DeplasmanIstatistik = await TakimMarketIstatistikleriniGetirAsync(
            depTakimGrubu.TakimIdleri,
            depGenelMaclar.Select(x => x.Id),
            cancellationToken);

        dto.VeriEksikleri = VeriEksikleriniOlustur(dto);
        dto.VeriKalitesiPuani = VeriKalitesiHesapla(dto);
        MarketVeriKaliteleriniHesapla(dto);

        return ServiceResult<MacKuponVerisiDto>.BasariliSonuc(
            dto,
            $"SQL kupon verisi hazırlandı. Veri kalitesi: " +
            $"%{dto.VeriKalitesiPuani}");
    }

    private async Task<List<Mac>> TakimMaclariniGetirAsync(
        IReadOnlyCollection<int> takimIdleri,
        DateTime analizMacTarihi,
        int adet,
        bool? evSahibiFiltresi,
        CancellationToken cancellationToken)
    {
        var aktifSezonBaslangici = AktifUcSezonBaslangici(analizMacTarihi);

        var query = _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x =>
                x.HariciMacId.HasValue &&
                x.MacTarihi >= aktifSezonBaslangici &&
                x.MacTarihi < analizMacTarihi &&
                x.EvSahibiSkor.HasValue &&
                x.DeplasmanSkor.HasValue &&
                (
                    takimIdleri.Contains(x.EvSahibiTakimId) ||
                    takimIdleri.Contains(x.DeplasmanTakimId)
                ));

        if (evSahibiFiltresi == true)
        {
            query = query.Where(
                x => takimIdleri.Contains(x.EvSahibiTakimId));
        }
        else if (evSahibiFiltresi == false)
        {
            query = query.Where(
                x => takimIdleri.Contains(x.DeplasmanTakimId));
        }

        return await query
            .OrderByDescending(x => x.MacTarihi)
            .Take(Math.Clamp(adet, 1, 20))
            .ToListAsync(cancellationToken);
    }

    private async Task<List<Mac>> H2HMaclariniGetirAsync(
        IReadOnlyCollection<int> takim1Idleri,
        IReadOnlyCollection<int> takim2Idleri,
        DateTime analizMacTarihi,
        int adet,
        CancellationToken cancellationToken)
    {
        var aktifSezonBaslangici = AktifUcSezonBaslangici(analizMacTarihi);
        return await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.Lig)
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .Where(x =>
                x.HariciMacId.HasValue &&
                x.MacTarihi >= aktifSezonBaslangici &&
                x.MacTarihi < analizMacTarihi &&
                x.EvSahibiSkor.HasValue &&
                x.DeplasmanSkor.HasValue &&
                (
                    (
                        takim1Idleri.Contains(x.EvSahibiTakimId) &&
                        takim2Idleri.Contains(x.DeplasmanTakimId)
                    ) ||
                    (
                        takim2Idleri.Contains(x.EvSahibiTakimId) &&
                        takim1Idleri.Contains(x.DeplasmanTakimId)
                    )
                ))
            .OrderByDescending(x => x.MacTarihi)
            .Take(Math.Clamp(adet, 1, 20))
            .ToListAsync(cancellationToken);
    }

    private async Task<CanonicalTakimGrubu> CanonicalTakimGrubuGetirAsync(
        Takim gelenTakim,
        CancellationToken cancellationToken)
    {
        var anahtar = NormalizeKulupAdi(gelenTakim.Ad);

        var tumTakimlar = await _dbContext.Takimlar
            .AsNoTracking()
            .ToListAsync(cancellationToken);

        var ayniKulup = tumTakimlar
            .Where(x =>
                NormalizeKulupAdi(x.Ad) == anahtar ||
                (gelenTakim.TheSportsDbTakimId.HasValue &&
                 x.TheSportsDbTakimId == gelenTakim.TheSportsDbTakimId) ||
                (gelenTakim.ApiFootballTakimId.HasValue &&
                 x.ApiFootballTakimId == gelenTakim.ApiFootballTakimId))
            .ToList();

        if (ayniKulup.All(x => x.Id != gelenTakim.Id))
            ayniKulup.Add(gelenTakim);

        // Canonical seçiminde vazgeçilmez kural:
        // HariciTakimId pozitif olmalı. Negatif/geçici ve NULL kayıtlar
        // yalnızca alias olarak kullanılabilir.
        var canonicalAdaylar = ayniKulup
            .Where(x =>
                x.AktifMi &&
                (x.ApiFootballTakimId.HasValue ||
                 x.TheSportsDbTakimId.HasValue ||
                 (x.HariciTakimId.HasValue && x.HariciTakimId.Value > 0)))
            .ToList();

        Takim canonical;
        if (canonicalAdaylar.Count == 0)
        {
            // TheSportsDB kaydı henüz yoksa veriyi kaybetmemek için mevcut
            // kayıt geçici olarak kullanılır; ancak canonical kabul edilmez.
            canonical = gelenTakim;
        }
        else
        {
            // Birden fazla pozitif harici kimlik varsa lig/ülke yakınlığı ve
            // maç sayısı tercih edilir. Aynı normalize ada sahip farklı
            // TheSportsDB takımlarını körlemesine birleştirmeyiz.
            var adayIdleri = canonicalAdaylar.Select(x => x.Id).ToList();
            var macSayilari = await _dbContext.Maclar
                .AsNoTracking()
                .Where(x => adayIdleri.Contains(x.EvSahibiTakimId) ||
                            adayIdleri.Contains(x.DeplasmanTakimId))
                .Select(x => new { x.EvSahibiTakimId, x.DeplasmanTakimId })
                .ToListAsync(cancellationToken);

            canonical = canonicalAdaylar
                .OrderByDescending(x =>
                    gelenTakim.Ulke != null && x.Ulke == gelenTakim.Ulke)
                .ThenByDescending(x =>
                    gelenTakim.LigId.HasValue && x.LigId == gelenTakim.LigId)
                .ThenByDescending(x => macSayilari.Count(m =>
                    m.EvSahibiTakimId == x.Id || m.DeplasmanTakimId == x.Id))
                .First();
        }

        var takimIdleri = ayniKulup
            .Select(x => x.Id)
            .Append(canonical.Id)
            .Distinct()
            .ToArray();

        return new CanonicalTakimGrubu(canonical, takimIdleri);
    }

    private static string NormalizeKulupAdi(string ad)
    {
        if (string.IsNullOrWhiteSpace(ad))
            return string.Empty;

        var normalized = ad.Trim().ToLowerInvariant().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var ch in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark)
                sb.Append(char.IsLetterOrDigit(ch) ? ch : ' ');
        }

        var kelimeler = sb.ToString()
            .Normalize(NormalizationForm.FormC)
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .ToList();

        // Yaş/rezerv/kadın takımı belirteçleri korunur; bunlar ana kulüple
        // eşleşmemelidir.
        var korunan = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "u19", "u21", "u23", "ii", "iii", "b", "reserve",
            "reserves", "women", "woman", "kadin"
        };

        var kulupEkleri = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "fc", "cf", "sc", "ac", "afc", "fk", "sk", "jk",
            "club", "clube", "football", "futbol", "spor", "kulubu",
            "as", "anonim", "sirketi"
        };

        kelimeler = kelimeler
            .Where(x => korunan.Contains(x) || !kulupEkleri.Contains(x))
            .ToList();

        // Türkiye kaynaklarında şehir eki sıkça kulüp adının sonuna ekleniyor.
        if (kelimeler.Count > 1 && kelimeler[^1] == "istanbul")
            kelimeler.RemoveAt(kelimeler.Count - 1);

        return string.Join(' ', kelimeler);
    }

    private sealed record CanonicalTakimGrubu(
        Takim CanonicalTakim,
        IReadOnlyCollection<int> TakimIdleri);

    private static DateTime AktifUcSezonBaslangici(DateTime analizMacTarihi)
    {
        // Futbol sezonu Temmuz ayında başlar kabul edilir.
        // Örnek: Ağustos 2026 maçı için aktif havuz 01.07.2024 tarihinden başlar.
        var mevcutSezonBaslangicYili = analizMacTarihi.Month >= 7
            ? analizMacTarihi.Year
            : analizMacTarihi.Year - 1;

        return new DateTime(
            mevcutSezonBaslangicYili - 2,
            7,
            1,
            0,
            0,
            0,
            DateTimeKind.Utc);
    }

    private static TakimGecmisVerisiDto TakimOzetiniOlustur(
        Takim takim,
        IReadOnlyCollection<int> takimIdleri,
        IReadOnlyCollection<Mac> maclar)
    {
        var dtoMaclar = maclar
            .Select(x => MacDtoOlustur(x, takimIdleri))
            .ToList();

        var toplam = dtoMaclar.Count;

        var attigiGol = dtoMaclar.Sum(x =>
            x.TakimEvSahibiMi
                ? x.EvSahibiGol
                : x.DeplasmanGol);

        var yedigiGol = dtoMaclar.Sum(x =>
            x.TakimEvSahibiMi
                ? x.DeplasmanGol
                : x.EvSahibiGol);

        return new TakimGecmisVerisiDto
        {
            TakimId = takim.Id,
            HariciTakimId = takim.HariciTakimId ?? 0,
            TakimAdi = takim.Ad,
            ToplamMac = toplam,
            Galibiyet = dtoMaclar.Count(x => x.KazandiMi),
            Beraberlik = dtoMaclar.Count(x => x.BerabereMi),
            Maglubiyet = dtoMaclar.Count(x => x.KaybettiMi),
            AttigiGol = attigiGol,
            YedigiGol = yedigiGol,
            MacBasinaGol = Ortalama(attigiGol, toplam),
            MacBasinaYenilenGol = Ortalama(yedigiGol, toplam),
            BirBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.BirBucukUstMu), toplam),
            IkiBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.IkiBucukUstMu), toplam),
            UcBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.UcBucukUstMu), toplam),
            KarsilikliGolYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.KarsilikliGolVarMi), toplam),
            GolYemedenBitirmeYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.GolYemedenBitirdiMi), toplam),
            IlkYariGolYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.IlkYaridaGolVarMi), toplam),
            IlkYariBirBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.IlkYariBirBucukUstMu), toplam),
            IlkYariKarsilikliGolYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.IlkYariKarsilikliGolVarMi), toplam),
            Maclar = dtoMaclar
        };
    }

    private static H2HOzetDto H2HOzetOlustur(
        Takim takim1,
        IReadOnlyCollection<int> takim1Idleri,
        Takim takim2,
        IReadOnlyCollection<int> takim2Idleri,
        IReadOnlyCollection<Mac> maclar)
    {
        var dtoMaclar = maclar
            .Select(x => MacDtoOlustur(x, takim1Idleri))
            .ToList();

        var takim1Galibiyet = 0;
        var takim2Galibiyet = 0;
        var beraberlik = 0;

        foreach (var mac in maclar)
        {
            if (mac.EvSahibiSkor == mac.DeplasmanSkor)
            {
                beraberlik++;
                continue;
            }

            var kazananTakimId =
                mac.EvSahibiSkor > mac.DeplasmanSkor
                    ? mac.EvSahibiTakimId
                    : mac.DeplasmanTakimId;

            if (takim1Idleri.Contains(kazananTakimId))
                takim1Galibiyet++;
            else if (takim2Idleri.Contains(kazananTakimId))
                takim2Galibiyet++;
        }

        var toplam = dtoMaclar.Count;
        var toplamGol = dtoMaclar.Sum(
            x => x.EvSahibiGol + x.DeplasmanGol);

        return new H2HOzetDto
        {
            Takim1Id = takim1.Id,
            Takim1Adi = takim1.Ad,
            Takim2Id = takim2.Id,
            Takim2Adi = takim2.Ad,
            ToplamMac = toplam,
            Takim1Galibiyet = takim1Galibiyet,
            Beraberlik = beraberlik,
            Takim2Galibiyet = takim2Galibiyet,
            OrtalamaToplamGol = Ortalama(toplamGol, toplam),
            BirBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.BirBucukUstMu), toplam),
            IkiBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.IkiBucukUstMu), toplam),
            UcBucukUstYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.UcBucukUstMu), toplam),
            KarsilikliGolYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.KarsilikliGolVarMi), toplam),
            IlkYariGolYuzdesi =
                Yuzde(dtoMaclar.Count(x => x.IlkYaridaGolVarMi), toplam),
            Maclar = dtoMaclar
        };
    }

    private static TakimGecmisMacDto MacDtoOlustur(
        Mac mac,
        IReadOnlyCollection<int> incelenenTakimIdleri)
    {
        var evGol = mac.EvSahibiSkor ?? 0;
        var depGol = mac.DeplasmanSkor ?? 0;

        var takimEvSahibiMi =
            incelenenTakimIdleri.Contains(mac.EvSahibiTakimId);

        var takimGol = takimEvSahibiMi ? evGol : depGol;
        var rakipGol = takimEvSahibiMi ? depGol : evGol;
        var toplamGol = evGol + depGol;

        var ilkYariToplam =
            (mac.IlkYariEvSahibiSkor ?? 0) +
            (mac.IlkYariDeplasmanSkor ?? 0);

        return new TakimGecmisMacDto
        {
            MacId = mac.Id,
            HariciMacId = mac.HariciMacId ?? 0,
            MacTarihi = mac.MacTarihi,
            LigId = mac.LigId ?? 0,
            LigAdi = mac.Lig?.Ad ?? string.Empty,
            EvSahibiTakimId = mac.EvSahibiTakimId,
            EvSahibiTakim = mac.EvSahibiTakim?.Ad ?? string.Empty,
            DeplasmanTakimId = mac.DeplasmanTakimId,
            DeplasmanTakim = mac.DeplasmanTakim?.Ad ?? string.Empty,
            EvSahibiGol = evGol,
            DeplasmanGol = depGol,
            IlkYariEvSahibiGol = mac.IlkYariEvSahibiSkor,
            IlkYariDeplasmanGol = mac.IlkYariDeplasmanSkor,
            TakimEvSahibiMi = takimEvSahibiMi,
            KazandiMi = takimGol > rakipGol,
            BerabereMi = takimGol == rakipGol,
            KaybettiMi = takimGol < rakipGol,
            BirBucukUstMu = toplamGol >= 2,
            IkiBucukUstMu = toplamGol >= 3,
            UcBucukUstMu = toplamGol >= 4,
            KarsilikliGolVarMi = evGol > 0 && depGol > 0,
            GolYemedenBitirdiMi = rakipGol == 0,
            IlkYaridaGolVarMi = ilkYariToplam > 0,
            IlkYariBirBucukUstMu = ilkYariToplam >= 2,
            IlkYariKarsilikliGolVarMi =
                (mac.IlkYariEvSahibiSkor ?? 0) > 0 &&
                (mac.IlkYariDeplasmanSkor ?? 0) > 0,
            IlkYariSonucu = (mac.IlkYariEvSahibiSkor ?? 0) == (mac.IlkYariDeplasmanSkor ?? 0)
                ? 0
                : (mac.IlkYariEvSahibiSkor ?? 0) > (mac.IlkYariDeplasmanSkor ?? 0) ? 1 : 2,
            MacSonucu = evGol == depGol ? 0 : evGol > depGol ? 1 : 2
        };
    }

    private async Task<TakimMarketIstatistikDto> TakimMarketIstatistikleriniGetirAsync(
        IReadOnlyCollection<int> takimIdleri,
        IEnumerable<int> macIdleri,
        CancellationToken cancellationToken)
    {
        var ids = macIdleri.Distinct().ToList();
        if (ids.Count == 0)
            return new TakimMarketIstatistikDto();

        var tumVeriler = await _dbContext.MacIstatistikleri
            .AsNoTracking()
            .Where(x => ids.Contains(x.MacId))
            .OrderByDescending(x => x.Mac.MacTarihi)
            .ToListAsync(cancellationToken);

        var veriler = tumVeriler
            .Where(x => takimIdleri.Contains(x.TakimId))
            .ToList();

        if (veriler.Count == 0)
            return new TakimMarketIstatistikDto();

        var rakipVeriler = tumVeriler
            .Where(x => !takimIdleri.Contains(x.TakimId))
            .ToList();

        static List<int> Kullanilabilir(IEnumerable<int?> values) =>
            values.Where(x => x.HasValue).Select(x => x!.Value).ToList();

        static decimal Ort(IEnumerable<int> values)
        {
            var usable = values.ToList();
            return usable.Count == 0 ? 0m : Math.Round((decimal)usable.Average(), 2);
        }

        static decimal Medyan(IEnumerable<int> values)
        {
            var a = values.OrderBy(x => x).ToList();
            if (a.Count == 0) return 0m;
            var mid = a.Count / 2;
            return a.Count % 2 == 1
                ? a[mid]
                : Math.Round((a[mid - 1] + a[mid]) / 2m, 2);
        }

        static decimal Std(IEnumerable<int> values)
        {
            var a = values.Select(x => (decimal)x).ToList();
            if (a.Count < 2) return 0m;
            var ort = a.Average();
            var varyans = a.Sum(x => (x - ort) * (x - ort)) / a.Count;
            return Math.Round((decimal)Math.Sqrt((double)varyans), 2);
        }

        var kornerler = Kullanilabilir(veriler.Select(x => x.Korner));
        var rakipKornerler = Kullanilabilir(rakipVeriler.Select(x => x.Korner));
        var kartlar = veriler
            .Where(x => x.SariKart.HasValue || x.KirmiziKart.HasValue)
            .Select(x => (x.SariKart ?? 0) + (x.KirmiziKart ?? 0) * 2)
            .ToList();

        return new TakimMarketIstatistikDto
        {
            KayitSayisi = veriler.Count,
            KornerKayitSayisi = kornerler.Count,
            KartKayitSayisi = kartlar.Count,
            OrtalamaKorner = Ort(kornerler),
            MedyanKorner = Medyan(kornerler),
            Son5OrtalamaKorner = Ort(kornerler.Take(5)),
            KornerStandartSapma = Std(kornerler),
            OrtalamaRakipKorner = Ort(rakipKornerler),
            MedyanRakipKorner = Medyan(rakipKornerler),
            OrtalamaKart = Ort(kartlar),
            MedyanKart = Medyan(kartlar),
            OrtalamaSut = Ort(Kullanilabilir(veriler.Select(x => x.Sut))),
            OrtalamaIsabetliSut = Ort(Kullanilabilir(veriler.Select(x => x.IsabetliSut))),
            OrtalamaFaul = Ort(Kullanilabilir(veriler.Select(x => x.Faul))),
            KornerDegerleri = kornerler,
            RakipKornerDegerleri = rakipKornerler,
            KartDegerleri = kartlar
        };
    }

    private int VeriKalitesiHesapla(
        MacKuponVerisiDto veri)
    {
        static decimal Oran(int mevcut, int hedef) =>
            hedef <= 0 ? 0m : Math.Min(mevcut / (decimal)hedef, 1m);

        var puan =
            Oran(veri.EvSahibiGenelForm.ToplamMac, _options.GenelFormMacSayisi) * 30m +
            Oran(veri.DeplasmanGenelForm.ToplamMac, _options.GenelFormMacSayisi) * 30m +
            Oran(veri.EvSahibiIcSahaForm.ToplamMac, _options.IcDisSahaMacSayisi) * 17.5m +
            Oran(veri.DeplasmanDisSahaForm.ToplamMac, _options.IcDisSahaMacSayisi) * 17.5m;

        // H2H her maçta bulunmaz. Varsa bonus verir, yoksa ana formu cezalandırmaz.
        puan += veri.H2H.ToplamMac > 0
            ? Oran(veri.H2H.ToplamMac, _options.H2HMacSayisi) * 5m
            : 3m;

        return Math.Clamp((int)Math.Round(puan), 0, 100);
    }

    private static List<string> VeriEksikleriniOlustur(
        MacKuponVerisiDto veri)
    {
        var eksikler = new List<string>();

        if (veri.EvSahibiGenelForm.ToplamMac < 5)
            eksikler.Add("Ev sahibi genel form verisi yetersiz.");

        if (veri.EvSahibiIcSahaForm.ToplamMac < 3)
            eksikler.Add("Ev sahibi iç saha verisi yetersiz.");

        if (veri.DeplasmanGenelForm.ToplamMac < 5)
            eksikler.Add("Deplasman genel form verisi yetersiz.");

        if (veri.DeplasmanDisSahaForm.ToplamMac < 3)
            eksikler.Add("Deplasman dış saha verisi yetersiz.");

        if (veri.H2H.ToplamMac == 0)
            eksikler.Add("H2H bulunamadı; analiz takım formu ve saha performansına dayanır.");
        else if (veri.H2H.ToplamMac < 3)
            eksikler.Add($"H2H örneklemi sınırlı: {veri.H2H.ToplamMac} maç.");

        return eksikler;
    }

    private void MarketVeriKaliteleriniHesapla(MacKuponVerisiDto veri)
    {
        static decimal Oran(int mevcut, int hedef) =>
            hedef <= 0 ? 0m : Math.Min(mevcut / (decimal)hedef, 1m);

        var genelHedef = _options.GenelFormMacSayisi;
        var sahaHedef = _options.IcDisSahaMacSayisi;
        var h2hHedef = _options.H2HMacSayisi;

        var temel =
            Oran(veri.EvSahibiGenelForm.ToplamMac, genelHedef) * 30m +
            Oran(veri.DeplasmanGenelForm.ToplamMac, genelHedef) * 30m +
            Oran(veri.EvSahibiIcSahaForm.ToplamMac, sahaHedef) * 20m +
            Oran(veri.DeplasmanDisSahaForm.ToplamMac, sahaHedef) * 20m;

        veri.MacSonucuVeriKalitesi = Math.Clamp((int)Math.Round(temel), 0, 100);

        // Gol ve ilk yarı marketleri temel form verisiyle güçlü biçimde çalışabilir.
        // H2H varsa küçük bir bonus sağlar; yokluğu ana marketi cezalandırmaz.
        var h2hBonus = veri.H2H.ToplamMac > 0 ? Oran(veri.H2H.ToplamMac, h2hHedef) * 5m : 2m;
        veri.GolMarketVeriKalitesi = Math.Clamp((int)Math.Round(temel * .95m + h2hBonus), 0, 100);
        veri.IlkYariVeriKalitesi = Math.Clamp((int)Math.Round(temel * .90m + h2hBonus), 0, 100);

        veri.H2HVeriKalitesi = Math.Clamp((int)Math.Round(Oran(veri.H2H.ToplamMac, h2hHedef) * 100m), 0, 100);

        // Korner/kart kalitesi yalnızca gerçekten mevcut event-stats örneklemine bağlıdır.
        // Bir tarafın verisi azsa market güveni de otomatik olarak düşer.
        var kornerOrneklem = Math.Min(veri.EvSahibiIstatistik.KornerKayitSayisi, veri.DeplasmanIstatistik.KornerKayitSayisi);
        var kartOrneklem = Math.Min(veri.EvSahibiIstatistik.KartKayitSayisi, veri.DeplasmanIstatistik.KartKayitSayisi);
        veri.KornerVeriKalitesi = Math.Clamp((int)Math.Round(Oran(kornerOrneklem, 20) * 100m), 0, 100);
        veri.KartVeriKalitesi = Math.Clamp((int)Math.Round(Oran(kartOrneklem, 20) * 100m), 0, 100);
    }

    private static int VeriAdediPuani(
        int mevcut,
        int hedef,
        int maksimumPuan)
    {
        if (hedef <= 0)
            return 0;

        var oran = Math.Min(
            mevcut / (decimal)hedef,
            1m);

        return (int)Math.Round(
            oran * maksimumPuan);
    }

    private static decimal Ortalama(
        int toplam,
        int adet)
    {
        return adet == 0
            ? 0
            : Math.Round(
                toplam / (decimal)adet,
                2);
    }

    private static decimal Yuzde(
        int uygunAdet,
        int toplamAdet)
    {
        return toplamAdet == 0
            ? 0
            : Math.Round(
                uygunAdet / (decimal)toplamAdet * 100m,
                2);
    }
}
