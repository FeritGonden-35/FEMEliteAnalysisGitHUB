using System.Text;
using System.Text.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class AnalizService : IAnalizService
{
    private readonly FemDbContext _dbContext;
    private readonly ISqlTakimFormService _sqlTakimFormService;
    private readonly IAnalizMotoruV2 _analizMotoruV2;
    private readonly ILogger<AnalizService> _logger;

    public AnalizService(
        FemDbContext dbContext,
        ISqlTakimFormService sqlTakimFormService,
        IAnalizMotoruV2 analizMotoruV2,
        ILogger<AnalizService> logger)
    {
        _dbContext = dbContext;
        _sqlTakimFormService = sqlTakimFormService;
        _analizMotoruV2 = analizMotoruV2;
        _logger = logger;
    }

    public async Task<ServiceResult<int>> AnalizOlusturAsync(
        AnalizOlusturRequest request,
        CancellationToken cancellationToken)
    {
        var mevcutTaslak = await _dbContext.Analizler
            .AsNoTracking()
            .Where(x =>
                x.MacId == request.MacId &&
                x.Durum == AnalizDurumu.Taslak)
            .OrderByDescending(x => x.OlusturmaTarihi)
            .FirstOrDefaultAsync(cancellationToken);

        if (mevcutTaslak is not null)
        {
            var yeniGercekOranVar = await _dbContext.BahisOranlari.AsNoTracking()
                .AnyAsync(x => x.MacId == request.MacId && x.AlinmaTarihi > mevcutTaslak.OlusturmaTarihi &&
                               x.Kaynak != null && x.Kaynak.StartsWith("PulseScore"), cancellationToken);
            if (!yeniGercekOranVar)
            {
                return ServiceResult<int>.BasariliSonuc(
                    mevcutTaslak.Id,
                    "Bu maç için daha önce oluşturulmuş güncel taslak analiz var.");
            }

            // Oran analizden sonra geldiyse yeni bir taslak oluştur; eski analiz kupon geçmişinde referanslanıyor olabilir.
        }

        var veriSonucu =
            await _sqlTakimFormService.MacKuponVerisiOlusturAsync(
                request.MacId,
                cancellationToken);

        if (!veriSonucu.Basarili ||
            veriSonucu.Veri is null)
        {
            return ServiceResult<int>.BasarisizSonuc(
                veriSonucu.Mesaj);
        }

        AnalizMotoruV2SonucDto motorSonucu;

        try
        {
            motorSonucu = _analizMotoruV2.AnalizEt(
                veriSonucu.Veri);
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Analiz Motoru V2 çalışırken hata oluştu. MacId: {MacId}",
                request.MacId);

            return ServiceResult<int>.BasarisizSonuc(
                "Gelişmiş maç analizi oluşturulurken hata oluştu.");
        }

        await PiyasaOranlariniUygulaAsync(motorSonucu, request.MacId, cancellationToken);
        await V5KilitMarketKalibrasyonuAsync(motorSonucu, cancellationToken);

        var ms1 = MarketBul(
            motorSonucu,
            "MS1");

        var msx = MarketBul(
            motorSonucu,
            "MSX");

        var ms2 = MarketBul(
            motorSonucu,
            "MS2");

        var analizMetni = AnalizMetniOlustur(
            veriSonucu.Veri,
            motorSonucu);

        var anaFaktorler = AnaFaktorleriOlustur(
            motorSonucu);

        var analiz = new Analiz
        {
            MacId = request.MacId,
            AnalizTuru = "FEM Analiz Motoru V2",
            Tahmin = string.IsNullOrWhiteSpace(
                request.KullaniciTahmini)
                ? "Admin değerlendirmesi bekleniyor"
                : request.KullaniciTahmini.Trim(),
            GuvenPuani = motorSonucu.GenelGuvenPuani,
            RiskSeviyesi = RiskSeviyesiniDonustur(
                motorSonucu.GenelRiskSeviyesi),
            YapayZekaAnalizi = analizMetni,
            AnaFaktorlerJson = JsonSerializer.Serialize(
                anaFaktorler),
            EvSahibiKazanmaOlasiligi =
                ms1?.GuvenPuani ?? 0,
            BeraberlikOlasiligi =
                msx?.GuvenPuani ?? 0,
            DeplasmanKazanmaOlasiligi =
                ms2?.GuvenPuani ?? 0,
            Durum = AnalizDurumu.Taslak,
            Sonuc = AnalizSonucu.Bekliyor,
            OlusturmaTarihi = DateTime.UtcNow
        };

        _dbContext.Analizler.Add(analiz);
        await _dbContext.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Analiz Motoru V2 sonucu kaydedildi. AnalizId: {AnalizId}, MacId: {MacId}, Güven: {Guven}, VeriKalitesi: {VeriKalitesi}",
            analiz.Id,
            analiz.MacId,
            motorSonucu.GenelGuvenPuani,
            motorSonucu.VeriKalitesiPuani);

        return ServiceResult<int>.BasariliSonuc(
            analiz.Id,
            "FEM Analiz Motoru V2 taslağı oluşturuldu.");
    }

    private async Task PiyasaOranlariniUygulaAsync(
        AnalizMotoruV2SonucDto sonuc,
        int macId,
        CancellationToken ct)
    {
        var esik = DateTime.UtcNow.AddHours(-4);
        var oranlar = await _dbContext.BahisOranlari.AsNoTracking()
            .Where(x => x.MacId == macId && x.AlinmaTarihi >= esik && x.Oran > 1.01m)
            .OrderByDescending(x => x.AlinmaTarihi)
            .ToListAsync(ct);

        if (oranlar.Count == 0) return;

        foreach (var market in sonuc.Marketler)
        {
            var eslesen = oranlar
                .Where(x => MarketKodEsit(x.MarketKodu, market.Kod))
                .OrderByDescending(x => x.Oran)
                .FirstOrDefault();
            if (eslesen is null) continue;

            market.Oran = eslesen.Oran;
            market.PiyasaOlasiligi = Math.Round(1m / eslesen.Oran, 4);
            market.EdgeYuzdesi = Math.Round((market.ModelOlasiligi - market.PiyasaOlasiligi.Value) * 100m, 2);
            market.BeklenenDeger = Math.Round(market.ModelOlasiligi * eslesen.Oran - 1m, 4);
            market.DegerliBahisMi = market.BeklenenDeger > 0.03m && market.EdgeYuzdesi > 2m;
            market.Gerekceler.Insert(0, $"Gerçek piyasa oranı @{eslesen.Oran:0.00} ({eslesen.Kaynak}).");
        }

        sonuc.EnGucluAdaylar = sonuc.Marketler
            .Where(x => !x.UzakDurMu && x.OneriliyorMu)
            .OrderByDescending(x => (x.DegerliBahisMi ? 18 : 0) + x.GuvenPuani + (int)Math.Clamp(x.EdgeYuzdesi ?? 0, -10, 15))
            .ThenByDescending(x => x.OrneklemSayisi)
            .Take(8)
            .ToList();
    }

    /// <summary>
    /// V5 kilit seçim katmanı. Modelin kendi geçmiş tahmin performansını gerçek piyasa
    /// oranı/value ile birleştirir. Amaç çok sayıda düşük oranlı seçim yerine az sayıda,
    /// gerçek oranı bulunan ve geçmişte kalibre olmuş yüksek-değer marketi öne çıkarmaktır.
    /// </summary>
    private async Task V5KilitMarketKalibrasyonuAsync(AnalizMotoruV2SonucDto sonuc, CancellationToken ct)
    {
        var kodlar = sonuc.Marketler.Select(x => x.Kod).Distinct().ToList();
        // V5.1: gerçek sonuçlanmış kupon seçimlerinden kalibrasyon yap.
        // TahminKayitlari eski kurulumlarda boş kalabildiği için KuponMaclari güvenilir kaynak olarak kullanılır.
        var gecmis = await _dbContext.KuponMaclari.AsNoTracking()
            .Where(x => x.Sonuc == "Kazandi" || x.Sonuc == "Kaybetti")
            .Select(x => new { x.SecilenMarket, x.Sonuc })
            .ToListAsync(ct);
        var gecmisGruplu = gecmis
            .GroupBy(x => MarketKoduTemizle(x.SecilenMarket), StringComparer.OrdinalIgnoreCase)
            .Select(g => new { Kod = g.Key, Toplam = g.Count(), Basarili = g.Count(x => x.Sonuc == "Kazandi") })
            .ToList();

        var perf = gecmisGruplu.ToDictionary(x => x.Kod, StringComparer.OrdinalIgnoreCase);
        foreach (var m in sonuc.Marketler)
        {
            if (perf.TryGetValue(m.Kod, out var p) && p.Toplam >= 10)
            {
                var hit = p.Basarili / (decimal)p.Toplam;
                // Bayesian benzeri shrinkage: geçmiş hit-rate'i modele tamamen ezdirmeden %35 ağırlıkla uygula.
                var kalibre = m.ModelOlasiligi * 0.65m + hit * 0.35m;
                m.ModelOlasiligi = Math.Round(Math.Clamp(kalibre, 0.05m, 0.95m), 4);
                m.GuvenPuani = (int)Math.Round(m.ModelOlasiligi * 100m);
                m.Gerekceler.Add($"FEM geçmiş performansı: {p.Basarili}/{p.Toplam} (%{hit * 100m:0.0}); V5 kalibrasyonu uygulandı.");

                if (m.Oran.HasValue)
                {
                    m.PiyasaOlasiligi = Math.Round(1m / m.Oran.Value, 4);
                    m.EdgeYuzdesi = Math.Round((m.ModelOlasiligi - m.PiyasaOlasiligi.Value) * 100m, 2);
                    m.BeklenenDeger = Math.Round(m.ModelOlasiligi * m.Oran.Value - 1m, 4);
                    m.DegerliBahisMi = m.BeklenenDeger >= 0.04m && m.EdgeYuzdesi >= 4m;
                }
            }
        }

        // Kilit liste: gerçek oranı ve anlamlı value'su olan 1.55-5.00 bandına öncelik.
        // Aynı maçın analizinde 1.10-1.30 tipi marketlerin güven puanıyla listeyi işgal etmesini engeller.
        var kilit = sonuc.Marketler
            .Where(x => !x.UzakDurMu && x.OneriliyorMu && x.Oran is >= 1.55m and <= 5.00m)
            .Where(x => x.GuvenPuani >= 60 && x.OrneklemSayisi >= 8)
            .Where(x => x.DegerliBahisMi || (x.EdgeYuzdesi ?? 0m) >= 4m)
            .OrderByDescending(V5KilitSkoru)
            .Take(4)
            .ToList();

        // Gerçek oran var fakat value filtresi çok sert kaldıysa yine düşük oran yerine yüksek-değer profilini koru.
        if (kilit.Count == 0)
        {
            kilit = sonuc.Marketler
                .Where(x => !x.UzakDurMu && x.OneriliyorMu && x.Oran is >= 1.55m and <= 5.00m)
                .Where(x => x.GuvenPuani >= 64 && x.OrneklemSayisi >= 8)
                .OrderByDescending(V5KilitSkoru)
                .Take(3)
                .ToList();
        }

        if (kilit.Count > 0)
            sonuc.EnGucluAdaylar = kilit;
    }

    private static decimal V5KilitSkoru(KuponMarketSkoruDto x)
    {
        var oranBonusu = x.Oran switch
        {
            >= 1.80m and <= 3.20m => 10m,
            > 3.20m and <= 5.00m => 6m,
            _ => 2m
        };
        var kombineBonusu = x.Kategori.Equals("Kombine", StringComparison.OrdinalIgnoreCase) ? 7m : 0m;
        return x.GuvenPuani + Math.Clamp(x.EdgeYuzdesi ?? 0m, -15m, 20m) + oranBonusu + kombineBonusu;
    }

    private static string MarketKoduTemizle(string x)
    {
        if (string.IsNullOrWhiteSpace(x)) return string.Empty;
        var at = x.IndexOf('@');
        if (at >= 0) x = x[..at];
        return x.Trim();
    }

    private static bool MarketKodEsit(string a, string b)
    {
        static string N(string x) => x.ToUpperInvariant()
            .Replace(" ", string.Empty)
            .Replace("İ", "I")
            .Replace("Ü", "U")
            .Replace("+", string.Empty)
            .Replace("&", string.Empty)
            .Replace("MSX", "X");
        return N(a) == N(b);
    }

    private static string AnalizMetniOlustur(
        Dtos.Mac.MacKuponVerisiDto veri,
        AnalizMotoruV2SonucDto sonuc)
    {
        var metin = new StringBuilder();

        metin.AppendLine("🏆 FEM ELITE MAÇ ANALİZİ");
        metin.AppendLine($"⚽ {veri.EvSahibi} - {veri.Deplasman}");
        metin.AppendLine($"🏟 {veri.Lig} | {veri.MacTarihi:dd.MM.yyyy HH:mm}");
        metin.AppendLine();

        metin.AppendLine("🧠 ANALİZ ÖZETİ");
        metin.AppendLine(MacOzetiniOlustur(veri, sonuc));
        metin.AppendLine();

        metin.AppendLine(
            $"📦 Genel veri kalitesi: {Yildizlar(sonuc.VeriKalitesiPuani)} %{sonuc.VeriKalitesiPuani}");
        metin.AppendLine(
            $"🎯 Tahmin güveni: {Yildizlar(sonuc.GenelGuvenPuani)} %{sonuc.GenelGuvenPuani} — {GuvenEtiketi(sonuc.GenelGuvenPuani)}");
        metin.AppendLine(
            $"🧪 Market veri kalitesi: MS %{veri.MacSonucuVeriKalitesi} | Gol %{veri.GolMarketVeriKalitesi} | İY %{veri.IlkYariVeriKalitesi} | 🚩 %{veri.KornerVeriKalitesi} | 🟨 %{veri.KartVeriKalitesi} | H2H %{veri.H2HVeriKalitesi}");
        metin.AppendLine($"🎭 Maç profili: {sonuc.MacProfili}");
        metin.AppendLine($"🛡 Risk seviyesi: {sonuc.GenelRiskSeviyesi}");

        metin.AppendLine($"⚖️ Güç dengesi: {veri.EvSahibi} {sonuc.EvSahibiGucPuani}/100 — {veri.Deplasman} {sonuc.DeplasmanGucPuani}/100");
        metin.AppendLine($"📈 Form ivmesi: {sonuc.EvSahibiFormTrendi.Trend} / {sonuc.DeplasmanFormTrendi.Trend}");

        if (sonuc.GuvenDagilimi.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("🧩 GÜVEN PUANI DAĞILIMI");
            foreach (var bilesen in sonuc.GuvenDagilimi)
                metin.AppendLine($"• {bilesen.Ad}: {bilesen.Puan}/{bilesen.Maksimum}");
        }

        metin.AppendLine();
        metin.AppendLine("🔥 EN GÜÇLÜ MARKETLER");

        if (sonuc.EnGucluAdaylar.Count == 0)
        {
            metin.AppendLine("• Güçlü eşik üzerinde güvenilir market bulunamadı.");
        }
        else
        {
            var sira = 1;
            foreach (var aday in sonuc.EnGucluAdaylar.Take(3))
            {
                var oranMetni = aday.Oran.HasValue
                    ? $" | 💰 @{aday.Oran.Value:0.00}" + (aday.EdgeYuzdesi.HasValue ? $" | Edge %{aday.EdgeYuzdesi.Value:0.0}" : string.Empty)
                    : string.Empty;
                metin.AppendLine(
                    $"{sira}. {Yildizlar(aday.GuvenPuani)} {aday.Kod} — %{aday.GuvenPuani}{oranMetni}");

                foreach (var gerekce in aday.Gerekceler.Take(2))
                    metin.AppendLine($"   • {gerekce}");

                sira++;
            }
        }

        var banko = BankoMarketiniSec(sonuc);
        var orta = OrtaRiskMarketiniSec(sonuc, banko?.Kod);
        var surpriz = SurprizMarketiniSec(sonuc);

        metin.AppendLine();
        metin.AppendLine("🎟️ 3 RİSK SEVİYESİNDE KUPON");
        metin.AppendLine();

        KuponSatiriEkle(metin, "🟢 BANKO", banko,
            "En dengeli ve en yüksek güvenli tercih");
        KuponSatiriEkle(metin, "🟠 ORTA RİSK", orta,
            "Daha yüksek getiri için kontrollü seçenek");
        KuponSatiriEkle(metin, "🔴 SÜRPRİZ", surpriz,
            "Yüksek oran ihtimali; düşük tutarla değerlendirilir");

        var iyMsPatternleri = sonuc.Marketler
            .Where(x => x.Kategori.Equals("İY/MS", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu &&
                        x.GuvenPuani >= 30 &&
                        YeterliOrneklemMi(x, 8))
            .OrderByDescending(x => x.GuvenPuani + SurprizUyumBonusu(x.Kod))
            .ThenByDescending(x => x.OrneklemSayisi)
            .Take(3)
            .ToList();

        metin.AppendLine();
        metin.AppendLine("🔥 İY/MS PATTERNLERİ");
        if (iyMsPatternleri.Count == 0)
        {
            metin.AppendLine("• Yeterli örneklem gücünde İY/MS paterni bulunamadı.");
        }
        else
        {
            foreach (var p in iyMsPatternleri)
            {
                metin.AppendLine($"• {p.Kod} — %{p.GuvenPuani} | örneklem {p.OrneklemSayisi}");
                foreach (var g in p.Gerekceler.Take(2))
                    metin.AppendLine($"  ↳ {g}");
            }
        }

        metin.AppendLine();
        metin.AppendLine("📈 FORM ÖZETİ");
        metin.AppendLine(
            $"🏠 {veri.EvSahibi} genel: {FormMetni(veri.EvSahibiGenelForm)}");
        metin.AppendLine(
            $"🏟 İç saha: {FormMetni(veri.EvSahibiIcSahaForm)}");
        metin.AppendLine(
            $"✈️ {veri.Deplasman} genel: {FormMetni(veri.DeplasmanGenelForm)}");
        metin.AppendLine(
            $"🛣 Dış saha: {FormMetni(veri.DeplasmanDisSahaForm)}");

        metin.AppendLine();
        metin.AppendLine("⚽ GOL EĞİLİMLERİ");
        metin.AppendLine(
            $"• Ev iç saha gol ort.: {veri.EvSahibiIcSahaForm.MacBasinaGol:0.00}");
        metin.AppendLine(
            $"• Dep dış saha gol ort.: {veri.DeplasmanDisSahaForm.MacBasinaGol:0.00}");
        metin.AppendLine(
            $"• KG Var: ev %{veri.EvSahibiIcSahaForm.KarsilikliGolYuzdesi:0.#} | dep %{veri.DeplasmanDisSahaForm.KarsilikliGolYuzdesi:0.#}");
        metin.AppendLine(
            $"• 2.5 Üst: ev %{veri.EvSahibiIcSahaForm.IkiBucukUstYuzdesi:0.#} | dep %{veri.DeplasmanDisSahaForm.IkiBucukUstYuzdesi:0.#}");

        metin.AppendLine();
        metin.AppendLine("🤝 H2H");
        if (veri.H2H.ToplamMac == 0)
        {
            metin.AppendLine("• H2H verisi bulunamadı; karar takım formlarına dayanıyor.");
        }
        else
        {
            metin.AppendLine(
                $"• Son {veri.H2H.ToplamMac}: {veri.EvSahibi} {veri.H2H.Takim1Galibiyet}G, " +
                $"{veri.H2H.Beraberlik}B, {veri.Deplasman} {veri.H2H.Takim2Galibiyet}G");
            metin.AppendLine(
                $"• Gol ort.: {veri.H2H.OrtalamaToplamGol:0.00} | KG Var %{veri.H2H.KarsilikliGolYuzdesi:0.#} | 2.5 Üst %{veri.H2H.IkiBucukUstYuzdesi:0.#}");
        }

        if (sonuc.RiskFaktorleri.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("⚠️ KARŞI ARGÜMANLAR / RİSKLER");
            foreach (var faktor in sonuc.RiskFaktorleri.Take(3))
                metin.AppendLine($"• {faktor}");
        }

        if (sonuc.PozitifFaktorler.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("✅ TAHMİNİ DESTEKLEYEN SİNYALLER");
            foreach (var faktor in sonuc.PozitifFaktorler.Take(4))
                metin.AppendLine($"• {faktor}");
        }

        var ilkYariAdaylari = sonuc.Marketler
            .Where(x => x.Kategori.Equals("İlk Yarı", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu && x.GuvenPuani >= 55 &&
                        x.Kod is not "İY 2.5 ALT")
            .OrderByDescending(x => x.GuvenPuani)
            .Take(5)
            .ToList();
        if (ilkYariAdaylari.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("⏱ İLK YARI MARKETLERİ");
            foreach (var aday in ilkYariAdaylari)
                metin.AppendLine($"• {aday.Kod} — %{aday.GuvenPuani} | {aday.RiskSeviyesi}");
        }

        var ikinciYariAdaylari = sonuc.Marketler
            .Where(x => x.Kategori.Equals("İkinci Yarı", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu && x.GuvenPuani >= 55)
            .OrderByDescending(x => x.GuvenPuani)
            .Take(4)
            .ToList();
        if (ikinciYariAdaylari.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("⏱ İKİNCİ YARI MARKETLERİ");
            foreach (var aday in ikinciYariAdaylari)
                metin.AppendLine($"• {aday.Kod} — %{aday.GuvenPuani} | {aday.RiskSeviyesi}");
        }

        var toplamGolAdaylari = sonuc.Marketler
            .Where(x => x.Kategori.Equals("Toplam Gol", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu && x.GuvenPuani >= 50)
            .OrderByDescending(x => x.GuvenPuani)
            .Take(4)
            .ToList();
        if (toplamGolAdaylari.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("🎯 TOPLAM GOL / TEK-ÇİFT");
            foreach (var aday in toplamGolAdaylari)
                metin.AppendLine($"• {aday.Kod} — %{aday.GuvenPuani}");
        }

        var kornerAdaylari = sonuc.Marketler
            .Where(x => x.Kategori.Equals("Korner", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu && x.GuvenPuani >= 52 && x.OrneklemSayisi >= 6)
            .OrderByDescending(x => x.GuvenPuani)
            .Take(4)
            .ToList();
        var kartAdaylari = sonuc.Marketler
            .Where(x => x.Kategori.Equals("Kart", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu && x.GuvenPuani >= 52 && x.OrneklemSayisi >= 6)
            .OrderByDescending(x => x.GuvenPuani)
            .Take(4)
            .ToList();
        metin.AppendLine();
        metin.AppendLine("🚩 KORNER / 🟨 KART VERİ DURUMU");
        metin.AppendLine($"• Korner veri kalitesi: %{veri.KornerVeriKalitesi} | örneklem ev {veri.EvSahibiIstatistik.KornerKayitSayisi}, dep {veri.DeplasmanIstatistik.KornerKayitSayisi}");
        metin.AppendLine($"• Kart veri kalitesi: %{veri.KartVeriKalitesi} | örneklem ev {veri.EvSahibiIstatistik.KartKayitSayisi}, dep {veri.DeplasmanIstatistik.KartKayitSayisi}");
        if (kornerAdaylari.Count == 0) metin.AppendLine("• 🚩 Oynanabilir eşik üzerinde korner marketi yok; veri yetersiz veya güven düşük.");
        if (kartAdaylari.Count == 0) metin.AppendLine("• 🟨 Oynanabilir eşik üzerinde kart marketi yok; veri yetersiz veya güven düşük.");

        if (kornerAdaylari.Count > 0 || kartAdaylari.Count > 0)
        {
            metin.AppendLine("🚩 KORNER / 🟨 KART MARKETLERİ");

            if (kornerAdaylari.Count > 0)
            {
                var evStat = veri.EvSahibiIstatistik;
                var depStat = veri.DeplasmanIstatistik;
                metin.AppendLine($"🚩 {veri.EvSahibi}: {evStat.OrtalamaKorner:0.00} korner | medyan {evStat.MedyanKorner:0.00} | rakibe verdiği {evStat.OrtalamaRakipKorner:0.00}");
                metin.AppendLine($"🚩 {veri.Deplasman}: {depStat.OrtalamaKorner:0.00} korner | medyan {depStat.MedyanKorner:0.00} | rakibe verdiği {depStat.OrtalamaRakipKorner:0.00}");
                foreach (var aday in kornerAdaylari)
                {
                    metin.AppendLine($"• 🚩 {aday.Kod} — %{aday.GuvenPuani} | örneklem {aday.OrneklemSayisi}");
                    foreach (var gerekce in aday.Gerekceler.Take(2))
                        metin.AppendLine($"   ↳ {gerekce}");
                }
            }

            if (kartAdaylari.Count > 0)
            {
                metin.AppendLine($"🟨 Kart ort.: {veri.EvSahibi} {veri.EvSahibiIstatistik.OrtalamaKart:0.00} | {veri.Deplasman} {veri.DeplasmanIstatistik.OrtalamaKart:0.00}");
                foreach (var aday in kartAdaylari)
                {
                    metin.AppendLine($"• 🟨 {aday.Kod} — %{aday.GuvenPuani} | örneklem {aday.OrneklemSayisi}");
                    foreach (var gerekce in aday.Gerekceler.Take(1))
                        metin.AppendLine($"   ↳ {gerekce}");
                }
            }
        }

        var kombineAdaylar = sonuc.Marketler
            .Where(x => x.Kategori.Equals("Kombine", StringComparison.OrdinalIgnoreCase) &&
                        !x.UzakDurMu && x.GuvenPuani >= 50)
            .OrderByDescending(x => x.GuvenPuani)
            .Take(5)
            .ToList();
        if (kombineAdaylar.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("🧪 ORAN YÜKSELTEN KOMBİNE MARKETLER");
            foreach (var aday in kombineAdaylar)
                metin.AppendLine($"• {aday.Kod} — model güveni %{aday.GuvenPuani}");
        }

        metin.AppendLine();
        metin.AppendLine("💡 Değer filtresi: EV/DEP 0.5 ÜST ve benzeri çok düşük oran üretme eğilimindeki marketler ana 'banko' seçiminden otomatik çıkarılır.");

        if (sonuc.AlternatifAdaylar.Count > 0)
        {
            metin.AppendLine();
            metin.AppendLine("⭐ ALTERNATİF MARKETLER");
            foreach (var aday in sonuc.AlternatifAdaylar.Take(4))
                metin.AppendLine($"• {aday.Kod} — %{aday.GuvenPuani}");
        }

        metin.AppendLine();
        metin.AppendLine("ℹ️ Analiz istatistiksel olasılıktır; kesin sonuç garantisi değildir.");

        return metin.ToString().Trim();
    }

    private static KuponMarketSkoruDto? BankoMarketiniSec(
        AnalizMotoruV2SonucDto sonuc)
    {
        var izinliKodlar = new[]
        {
            "1.5 ÜST",
            "İY 0.5 ÜST",
            "KG VAR",
            "KG YOK",
            "1X",
            "X2",
            "2.5 ALT",
            "2.5 ÜST",
            "3.5 ALT",
            "İY 1.5 ALT"
        };

        return sonuc.Marketler
            .Where(x =>
                !x.UzakDurMu &&
                !x.SurprizMi &&
                x.GuvenPuani >= 66 &&
                izinliKodlar.Contains(x.Kod, StringComparer.OrdinalIgnoreCase) &&
                YeterliOrneklemMi(x, 8))
            .OrderByDescending(x =>
                x.GuvenPuani + BankoUyumBonusu(x.Kod))
            .ThenByDescending(x => x.OrneklemSayisi)
            .FirstOrDefault();
    }

    private static KuponMarketSkoruDto? OrtaRiskMarketiniSec(
        AnalizMotoruV2SonucDto sonuc,
        string? bankoKod)
    {
        var izinliKodlar = new[]
        {
            "MS1", "MS2", "12", "KG VAR", "2.5 ÜST", "3.5 ALT",
            "MS1 + KG VAR", "MS2 + KG VAR",
            "MS1 + 2.5 ÜST", "MS2 + 2.5 ÜST",
            "MS1 + 4.5 ALT", "MS2 + 4.5 ALT",
            "MS1 + 1.5 ÜST", "MS2 + 1.5 ÜST"
        };

        return sonuc.Marketler
            .Where(x =>
                !x.UzakDurMu &&
                x.GuvenPuani >= 52 &&
                !x.Kod.Equals(bankoKod, StringComparison.OrdinalIgnoreCase) &&
                izinliKodlar.Contains(x.Kod, StringComparer.OrdinalIgnoreCase) &&
                YeterliOrneklemMi(x, 8))
            .OrderByDescending(x =>
                x.GuvenPuani + OrtaRiskUyumBonusu(x.Kod))
            .ThenByDescending(x => x.OrneklemSayisi)
            .FirstOrDefault();
    }

    private static KuponMarketSkoruDto? SurprizMarketiniSec(
        AnalizMotoruV2SonucDto sonuc)
    {
        var izinliKodlar = new[]
        {
            "1/1", "1/X", "1/2",
            "X/1", "X/X", "X/2",
            "2/1", "2/X", "2/2",
            "4.5 ÜST", "5.5 ÜST", "6.5 ÜST", "İY KG VAR"
        };

        return sonuc.Marketler
            .Where(x =>
                !x.UzakDurMu &&
                x.GuvenPuani >= 32 &&
                izinliKodlar.Contains(x.Kod, StringComparer.OrdinalIgnoreCase) &&
                YeterliOrneklemMi(x, 10))
            .OrderByDescending(x =>
                x.GuvenPuani + SurprizUyumBonusu(x.Kod))
            .ThenByDescending(x => x.OrneklemSayisi)
            .FirstOrDefault();
    }

    private static bool YeterliOrneklemMi(
        KuponMarketSkoruDto market,
        int minimum)
    {
        // Bazı yüzde tabanlı ana marketlerde örneklem DTO'ya yazılmıyor.
        // Bu marketler veri kalitesi filtresinden geçtiği için kabul edilir.
        return market.OrneklemSayisi == 0 ||
               market.OrneklemSayisi >= minimum;
    }

    private static int BankoUyumBonusu(string kod) => kod switch
    {
        "1.5 ÜST" => 8,
        "İY 0.5 ÜST" => 7,
        "1X" or "X2" => 6,
        "KG VAR" or "KG YOK" => 5,
        "2.5 ALT" or "2.5 ÜST" => 4,
        "3.5 ALT" => 3,
        "İY 1.5 ALT" => 2,
        _ => 0
    };

    private static int OrtaRiskUyumBonusu(string kod)
    {
        if (kod.Contains(" + ", StringComparison.Ordinal))
            return 8;

        return kod switch
        {
            "MS1" or "MS2" => 6,
            "KG VAR" or "2.5 ÜST" => 4,
            "3.5 ALT" or "12" => 3,
            _ => 0
        };
    }

    private static int SurprizUyumBonusu(string kod)
    {
        if (kod is "1/2" or "2/1" or "X/1" or "X/2")
            return 10;

        if (kod is "1/X" or "2/X")
            return 7;

        if (kod is "1/1" or "2/2")
            return 4;

        if (kod is "X/X")
            return 3;

        if (kod is "6.5 ÜST" or "5.5 ÜST")
            return 5;

        return 0;
    }

    private static void KuponSatiriEkle(
        StringBuilder metin,
        string baslik,
        KuponMarketSkoruDto? market,
        string aciklama)
    {
        metin.AppendLine(baslik);
        if (market is null)
        {
            metin.AppendLine("• Bu risk seviyesinde yeterli sinyal bulunamadı.");
        }
        else
        {
            metin.AppendLine(
                $"• {market.Kod} — {Yildizlar(market.GuvenPuani)} %{market.GuvenPuani}");
            metin.AppendLine($"• {aciklama}");
            foreach (var gerekce in market.Gerekceler.Take(2))
                metin.AppendLine($"  ↳ {gerekce}");
        }
        metin.AppendLine();
    }

    private static string MacOzetiniOlustur(
        Dtos.Mac.MacKuponVerisiDto veri,
        AnalizMotoruV2SonucDto sonuc)
    {
        var formKategori = sonuc.Kategoriler
            .FirstOrDefault(x => x.Kod == "FORM");
        var sahaKategori = sonuc.Kategoriler
            .FirstOrDefault(x => x.Kod == "SAHA");

        var evPuan = (formKategori?.EvSahibiPuani ?? 50) +
                     (sahaKategori?.EvSahibiPuani ?? 50);
        var depPuan = (formKategori?.DeplasmanPuani ?? 50) +
                      (sahaKategori?.DeplasmanPuani ?? 50);

        var tarafMetni = Math.Abs(evPuan - depPuan) < 18
            ? "Takımların form gücü birbirine yakın; tek taraflı sonuç marketlerinde temkinli olunmalı."
            : evPuan > depPuan
                ? $"{veri.EvSahibi}, genel form ve iç saha performansında daha güçlü görünüyor."
                : $"{veri.Deplasman}, genel form ve dış saha performansında öne çıkıyor.";

        var toplamGolEgilimi =
            veri.EvSahibiIcSahaForm.MacBasinaGol +
            veri.DeplasmanDisSahaForm.MacBasinaGol;

        var golMetni = toplamGolEgilimi switch
        {
            >= 3.0m => "Maç yüksek gol potansiyeli taşıyor.",
            >= 2.1m => "Gol marketleri için dengeli bir görünüm var.",
            _ => "Maçın düşük tempolu ve kontrollü geçme ihtimali yüksek."
        };

        return tarafMetni + " " + golMetni;
    }

    private static string Yildizlar(int puan) => puan switch
    {
        >= 88 => "⭐⭐⭐⭐⭐",
        >= 75 => "⭐⭐⭐⭐☆",
        >= 62 => "⭐⭐⭐☆☆",
        >= 48 => "⭐⭐☆☆☆",
        _ => "⭐☆☆☆☆"
    };

    private static string GuvenEtiketi(int puan) => puan switch
    {
        >= 88 => "Çok güçlü",
        >= 75 => "Güçlü",
        >= 62 => "Analiz edilebilir",
        >= 48 => "Temkinli",
        _ => "Zayıf"
    };

    private static List<string> AnaFaktorleriOlustur(
        AnalizMotoruV2SonucDto sonuc)
    {
        var faktorler = new List<string>
        {
            $"Maç profili: {sonuc.MacProfili}",
            $"Veri kalitesi: %{sonuc.VeriKalitesiPuani}",
            $"Genel güven: %{sonuc.GenelGuvenPuani}",
            $"Genel risk: {sonuc.GenelRiskSeviyesi}"
        };

        foreach (var aday in sonuc.EnGucluAdaylar.Take(2))
        {
            faktorler.Add(
                $"{aday.Kod}: %{aday.GuvenPuani}");
        }

        faktorler.AddRange(
            sonuc.RiskFaktorleri.Take(2));

        return faktorler
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(8)
            .ToList();
    }

    private static KuponMarketSkoruDto? MarketBul(
        AnalizMotoruV2SonucDto sonuc,
        string kod)
    {
        return sonuc.Marketler.FirstOrDefault(
            x => x.Kod.Equals(
                kod,
                StringComparison.OrdinalIgnoreCase));
    }

    private static bool SurprizMarketMi(string kod)
    {
        return kod is "1/2" or "2/1" or "X/1" or "X/2" or "1/1" or "2/2";
    }

    private static string FormMetni(
        Dtos.Mac.TakimGecmisVerisiDto form)
    {
        return
            $"{form.ToplamMac} maç | " +
            $"{form.Galibiyet}G " +
            $"{form.Beraberlik}B " +
            $"{form.Maglubiyet}M | " +
            $"{form.AttigiGol}-{form.YedigiGol} gol";
    }

    private static RiskSeviyesi RiskSeviyesiniDonustur(
        string? risk)
    {
        return risk?.Trim().ToLowerInvariant() switch
        {
            "düşük" or "dusuk" => RiskSeviyesi.Dusuk,
            "orta" => RiskSeviyesi.Orta,
            "yüksek" or "yuksek" or
            "çok yüksek" or "cok yuksek" => RiskSeviyesi.Yuksek,
            _ => RiskSeviyesi.Orta
        };
    }
}
