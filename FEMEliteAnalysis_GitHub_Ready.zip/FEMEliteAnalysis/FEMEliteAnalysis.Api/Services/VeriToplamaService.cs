using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.VeriToplama;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class VeriToplamaService : IVeriToplamaService
{
    private readonly IVeriSaglayiciFactory _factory;
    private readonly IVeriToplamaDurumStore _durumStore;
    private readonly ILogger<VeriToplamaService> _logger;

    private static readonly SemaphoreSlim Kilit = new(1, 1);

    public VeriToplamaService(
        IVeriSaglayiciFactory factory,
        IVeriToplamaDurumStore durumStore,
        ILogger<VeriToplamaService> logger)
    {
        _factory = factory;
        _durumStore = durumStore;
        _logger = logger;
    }

    public bool CalisiyorMu => _durumStore.CalisiyorMu;
    public DateTime? SonBaslamaZamani => _durumStore.SonBaslamaZamani;
    public DateTime? SonBitisZamani => _durumStore.SonBitisZamani;

    public async Task<ServiceResult<VeriToplamaSonucDto>> CalistirAsync(
        VeriToplamaIstekDto istek,
        CancellationToken cancellationToken)
    {
        if (!await Kilit.WaitAsync(0, cancellationToken))
        {
            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                "Başka bir veri toplama işlemi zaten çalışıyor.");
        }

        _durumStore.Basladi();

        try
        {
            var saglayici = _factory.Getir(
                istek.SaglayiciTuru);

            if (!saglayici.AktifMi)
            {
                var mesaj =
                    $"{saglayici.Ad} veri sağlayıcısı aktif değil.";

                _durumStore.Basarisiz(mesaj);

                return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                    mesaj);
            }

            _logger.LogInformation(
                "Veri toplama başladı. Sağlayıcı: {Saglayici}, Başlangıç: {Baslangic}, Bitiş: {Bitis}",
                saglayici.Ad,
                istek.BaslangicTarihi,
                istek.BitisTarihi);

            var sonuc = await saglayici.VeriToplaAsync(
                istek,
                cancellationToken);

            if (sonuc.Basarili)
            {
                _durumStore.Tamamlandi(sonuc.Mesaj);
            }
            else
            {
                _durumStore.Basarisiz(sonuc.Mesaj);
            }

            _logger.LogInformation(
                "Veri toplama tamamlandı. Sağlayıcı: {Saglayici}, Başarılı: {Basarili}, Mesaj: {Mesaj}",
                saglayici.Ad,
                sonuc.Basarili,
                sonuc.Mesaj);

            return sonuc;
        }
        catch (Exception ex)
        {
            const string mesaj =
                "Veri toplama işleminde beklenmeyen hata oluştu.";

            _durumStore.Basarisiz(mesaj);

            _logger.LogError(
                ex,
                "Veri toplama işleminde beklenmeyen hata oluştu. Sağlayıcı: {Saglayici}",
                istek.SaglayiciTuru);

            return ServiceResult<VeriToplamaSonucDto>.BasarisizSonuc(
                mesaj);
        }
        finally
        {
            Kilit.Release();
        }
    }

    public async Task<ServiceResult<List<VeriToplamaSonucDto>>>
        TumAktifSaglayicilariCalistirAsync(
            DateOnly baslangicTarihi,
            DateOnly bitisTarihi,
            CancellationToken cancellationToken)
    {
        var saglayicilar = _factory.AktifSaglayicilariGetir();

        if (saglayicilar.Count == 0)
        {
            return ServiceResult<List<VeriToplamaSonucDto>>.BasarisizSonuc(
                "Aktif veri sağlayıcısı bulunmuyor.");
        }

        var sonuclar = new List<VeriToplamaSonucDto>();

        foreach (var saglayici in saglayicilar)
        {
            var sonuc = await CalistirAsync(
                new VeriToplamaIstekDto
                {
                    SaglayiciTuru = saglayici.Tur,
                    BaslangicTarihi = baslangicTarihi,
                    BitisTarihi = bitisTarihi,
                    // Normal /sync hızlı çalışır: sezon arşivi ve takım bazlı
                    // geçmiş endpointleri tekrar çağrılmaz.
                    GecmisFormuGetir = false
                },
                cancellationToken);

            if (sonuc.Veri is not null)
            {
                sonuclar.Add(sonuc.Veri);
            }
            else
            {
                sonuclar.Add(new VeriToplamaSonucDto
                {
                    SaglayiciTuru = saglayici.Tur,
                    BaslamaZamani = DateTime.UtcNow,
                    BitisZamani = DateTime.UtcNow,
                    Basarili = false,
                    Mesaj = sonuc.Mesaj
                });
            }
        }

        return ServiceResult<List<VeriToplamaSonucDto>>.BasariliSonuc(
            sonuclar,
            $"{sonuclar.Count} veri sağlayıcısı çalıştırıldı.");
    }
}
