using System.Globalization;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class KuponPerformansService : IKuponPerformansService
{
    private readonly FemDbContext _db;
    public KuponPerformansService(FemDbContext db) => _db = db;

    public async Task<ServiceResult<int>> SonuclariGuncelleAsync(long adminTelegramId, CancellationToken cancellationToken)
    {
        var kuponlar = await _db.Kuponlar
            .Include(x => x.Maclar).ThenInclude(x => x.Mac).ThenInclude(x => x.Istatistikler)
            .Where(x => x.AdminTelegramId == adminTelegramId && x.YayinlanmaTarihi != null && x.Maclar.Any(m => m.Sonuc == "Bekliyor"))
            .ToListAsync(cancellationToken);

        var degisen = 0;
        foreach (var kupon in kuponlar)
        {
            foreach (var secim in kupon.Maclar.Where(x => x.Sonuc == "Bekliyor"))
            {
                var mac = secim.Mac;
                if (!mac.EvSahibiSkor.HasValue || !mac.DeplasmanSkor.HasValue || mac.MacTarihi > DateTime.UtcNow.AddMinutes(30))
                    continue;

                var sonuc = MarketDegerlendir(secim.SecilenMarket, mac);
                if (sonuc is null) continue;

                secim.Sonuc = sonuc.Value ? "Kazandi" : "Kaybetti";
                secim.SonuclandirmaTarihi = DateTime.UtcNow;
                degisen++;
            }

            var tumu = kupon.Maclar.ToList();
            if (tumu.Any(x => x.Sonuc == "Kaybetti"))
            {
                kupon.Sonuc = "Kaybetti";
                kupon.SonuclandirmaTarihi = DateTime.UtcNow;
            }
            else if (tumu.Count > 0 && tumu.All(x => x.Sonuc == "Kazandi"))
            {
                kupon.Sonuc = "Kazandi";
                kupon.SonuclandirmaTarihi = DateTime.UtcNow;
            }
        }

        await _db.SaveChangesAsync(cancellationToken);
        return ServiceResult<int>.BasariliSonuc(degisen, $"{degisen} kupon seçimi sonuçlandırıldı.");
    }

    public async Task<ServiceResult<KuponPerformansDto>> GetirAsync(long adminTelegramId, int gun, CancellationToken cancellationToken)
    {
        await SonuclariGuncelleAsync(adminTelegramId, cancellationToken);
        gun = Math.Clamp(gun, 1, 3650);
        var baslangic = DateTime.UtcNow.AddDays(-gun);

        var kuponlar = await _db.Kuponlar.AsNoTracking().Include(x => x.Maclar)
            .Where(x => x.AdminTelegramId == adminTelegramId && x.YayinlanmaTarihi >= baslangic)
            .ToListAsync(cancellationToken);

        var dto = new KuponPerformansDto
        {
            ToplamKupon = kuponlar.Count,
            KazananKupon = kuponlar.Count(x => x.Sonuc == "Kazandi"),
            KaybedenKupon = kuponlar.Count(x => x.Sonuc == "Kaybetti"),
            BekleyenKupon = kuponlar.Count(x => x.Sonuc == "Bekliyor")
        };
        var settledKupon = dto.KazananKupon + dto.KaybedenKupon;
        dto.KuponBasariYuzdesi = settledKupon == 0 ? 0 : Math.Round(dto.KazananKupon * 100m / settledKupon, 1);

        var secimler = kuponlar.SelectMany(x => x.Maclar).ToList();
        dto.ToplamSecim = secimler.Count;
        dto.KazananSecim = secimler.Count(x => x.Sonuc == "Kazandi");
        dto.KaybedenSecim = secimler.Count(x => x.Sonuc == "Kaybetti");
        dto.BekleyenSecim = secimler.Count(x => x.Sonuc == "Bekliyor");
        var settled = dto.KazananSecim + dto.KaybedenSecim;
        dto.SecimBasariYuzdesi = settled == 0 ? 0 : Math.Round(dto.KazananSecim * 100m / settled, 1);

        dto.Marketler = secimler.Where(x => x.Sonuc != "Bekliyor")
            .GroupBy(x => MarketGrubu(x.SecilenMarket))
            .Select(g => new MarketPerformansDto
            {
                Market = g.Key,
                Toplam = g.Count(),
                Kazanan = g.Count(x => x.Sonuc == "Kazandi"),
                Kaybeden = g.Count(x => x.Sonuc == "Kaybetti"),
                BasariYuzdesi = Math.Round(g.Count(x => x.Sonuc == "Kazandi") * 100m / Math.Max(1, g.Count()), 1)
            })
            .OrderByDescending(x => x.Toplam).ThenByDescending(x => x.BasariYuzdesi).ToList();

        dto.SonKuponlar = kuponlar.OrderByDescending(x => x.YayinlanmaTarihi).Take(12)
            .Select(x => new KuponSonucOzetDto
            {
                KuponId = x.Id, Baslik = x.Baslik, ToplamOran = x.ToplamOran, Sonuc = x.Sonuc,
                KazananSecim = x.Maclar.Count(m => m.Sonuc == "Kazandi"),
                KaybedenSecim = x.Maclar.Count(m => m.Sonuc == "Kaybetti"),
                BekleyenSecim = x.Maclar.Count(m => m.Sonuc == "Bekliyor"),
                YayinlanmaTarihi = x.YayinlanmaTarihi
            }).ToList();

        dto.OranBantlari = kuponlar.Where(x => x.Sonuc != "Bekliyor" && x.ToplamOran.HasValue)
            .GroupBy(x => OranBandi(x.ToplamOran!.Value))
            .Select(g => new OranBandPerformansDto
            {
                Bant = g.Key,
                Toplam = g.Count(),
                Kazanan = g.Count(x => x.Sonuc == "Kazandi"),
                Kaybeden = g.Count(x => x.Sonuc == "Kaybetti"),
                BasariYuzdesi = Math.Round(g.Count(x => x.Sonuc == "Kazandi") * 100m / Math.Max(1, g.Count()), 1)
            }).OrderBy(x => x.Bant).ToList();

        return ServiceResult<KuponPerformansDto>.BasariliSonuc(dto, $"Son {gun} günlük performans hazırlandı.");
    }

    private static string OranBandi(decimal oran) => oran switch
    {
        < 3m => "1-3",
        < 6m => "3-6",
        < 10m => "6-10",
        _ => "10+"
    };

    private static string MarketGrubu(string market)
    {
        var m = Normalize(market);
        if (m.Contains("KORNER")) return "Korner";
        if (m.Contains("KART")) return "Kart";
        if (m.Contains("KG")) return m.StartsWith("İY") ? "İY KG" : "KG";
        if (m.StartsWith("İY") || m.Contains('/')) return "İlk Yarı";
        if (m.StartsWith("MS") || m is "1" or "X" or "2" or "1X" or "X2" or "12") return "Maç Sonucu";
        if (m.Contains("ÜST") || m.Contains("ALT") || m.StartsWith("TG")) return "Gol";
        return "Diğer";
    }

    private static bool? MarketDegerlendir(string market, Mac mac)
    {
        var m = Normalize(market);
        var parts = Regex.Split(m, @"\s+\+\s+").Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();
        if (parts.Length > 1)
        {
            var sonuc = parts.Select(x => TekMarket(x, mac)).ToList();
            if (sonuc.Any(x => x is null)) return null;
            return sonuc.All(x => x == true);
        }
        return TekMarket(m, mac);
    }

    private static bool? TekMarket(string m, Mac mac)
    {
        var ev = mac.EvSahibiSkor!.Value;
        var dep = mac.DeplasmanSkor!.Value;
        var toplam = ev + dep;
        var iyEv = mac.IlkYariEvSahibiSkor;
        var iyDep = mac.IlkYariDeplasmanSkor;

        if (m is "MS1" or "1") return ev > dep;
        if (m is "MSX" or "X") return ev == dep;
        if (m is "MS2" or "2") return ev < dep;
        if (m == "1X") return ev >= dep;
        if (m == "X2") return ev <= dep;
        if (m == "12") return ev != dep;
        if (m == "KG VAR") return ev > 0 && dep > 0;
        if (m == "KG YOK") return ev == 0 || dep == 0;

        var iyms = Regex.Match(m, @"^(1|X|2)/(1|X|2)$");
        if (iyms.Success && iyEv.HasValue && iyDep.HasValue)
            return SonucKod(iyEv.Value, iyDep.Value) == iyms.Groups[1].Value && SonucKod(ev, dep) == iyms.Groups[2].Value;

        if (m is "İY 1" or "İY X" or "İY 2")
        {
            if (!iyEv.HasValue || !iyDep.HasValue) return null;
            return SonucKod(iyEv.Value, iyDep.Value) == m[3..].Trim();
        }
        if (m == "İY KG VAR" || m == "İY KG YOK")
        {
            if (!iyEv.HasValue || !iyDep.HasValue) return null;
            var varMi = iyEv.Value > 0 && iyDep.Value > 0;
            return m.EndsWith("VAR") ? varMi : !varMi;
        }

        var iyGol = Regex.Match(m, @"^İY\s+(\d+[\.,]5)\s+(ÜST|ALT)$");
        if (iyGol.Success)
        {
            if (!iyEv.HasValue || !iyDep.HasValue) return null;
            var esik = Parse(iyGol.Groups[1].Value);
            var t = iyEv.Value + iyDep.Value;
            return iyGol.Groups[2].Value == "ÜST" ? t > esik : t < esik;
        }

        var teamGol = Regex.Match(m, @"^(EV|DEP)\s+(\d+[\.,]5)\s+(ÜST|ALT)$");
        if (teamGol.Success)
        {
            var goal = teamGol.Groups[1].Value == "EV" ? ev : dep;
            var esik = Parse(teamGol.Groups[2].Value);
            return teamGol.Groups[3].Value == "ÜST" ? goal > esik : goal < esik;
        }

        var gol = Regex.Match(m, @"^(\d+[\.,]5)\s+(ÜST|ALT)$");
        if (gol.Success)
        {
            var esik = Parse(gol.Groups[1].Value);
            return gol.Groups[2].Value == "ÜST" ? toplam > esik : toplam < esik;
        }

        if (m == "TG TEK") return toplam % 2 == 1;
        if (m == "TG ÇİFT") return toplam % 2 == 0;
        var tg = Regex.Match(m, @"^TG\s+(\d+)-(\d+)$");
        if (tg.Success) return toplam >= int.Parse(tg.Groups[1].Value) && toplam <= int.Parse(tg.Groups[2].Value);
        if (m is "TG 6+" or "6+ GOL") return toplam >= 6;

        var korner = Regex.Match(m, @"^(?:(EV|DEP)\s+)?KORNER\s+(\d+[\.,]5)\s+(ÜST|ALT)$|^(\d+[\.,]5)\s+KORNER\s+(ÜST|ALT)$");
        if (korner.Success)
        {
            var taraf = korner.Groups[1].Success ? korner.Groups[1].Value : string.Empty;
            var esikText = korner.Groups[2].Success ? korner.Groups[2].Value : korner.Groups[4].Value;
            var yon = korner.Groups[3].Success ? korner.Groups[3].Value : korner.Groups[5].Value;
            var evStat = mac.Istatistikler.FirstOrDefault(x => x.TakimId == mac.EvSahibiTakimId)?.Korner;
            var depStat = mac.Istatistikler.FirstOrDefault(x => x.TakimId == mac.DeplasmanTakimId)?.Korner;
            if (!evStat.HasValue || !depStat.HasValue) return null;
            var deger = taraf == "EV" ? evStat.Value : taraf == "DEP" ? depStat.Value : evStat.Value + depStat.Value;
            var esik = Parse(esikText);
            return yon == "ÜST" ? deger > esik : deger < esik;
        }

        var kart = Regex.Match(m, @"^(\d+[\.,]5)\s+KART\s+(ÜST|ALT)$");
        if (kart.Success)
        {
            var stats = mac.Istatistikler.ToList();
            if (stats.Count < 2) return null;
            var kartSayisi = stats.Sum(x => (x.SariKart ?? 0) + (x.KirmiziKart ?? 0));
            var esik = Parse(kart.Groups[1].Value);
            return kart.Groups[2].Value == "ÜST" ? kartSayisi > esik : kartSayisi < esik;
        }
        return null;
    }

    private static string SonucKod(int ev, int dep) => ev > dep ? "1" : ev < dep ? "2" : "X";
    private static decimal Parse(string x) => decimal.Parse(x.Replace(',', '.'), CultureInfo.InvariantCulture);
    private static string Normalize(string x)
    {
        var temiz = Regex.Replace(x, @"\s*@\s*\d+(?:[\.,]\d+)?\s*$", string.Empty);
        return Regex.Replace(temiz.Trim().ToUpperInvariant().Replace("İLK YARI", "İY").Replace("MAÇ SONUCU", "MS"), @"\s+", " ");
    }
}
