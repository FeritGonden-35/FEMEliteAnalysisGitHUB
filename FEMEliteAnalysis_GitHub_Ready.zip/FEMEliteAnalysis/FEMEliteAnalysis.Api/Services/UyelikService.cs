using FEMEliteAnalysis.Api.Common.Constants;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Uyelik;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class UyelikService : IUyelikService
{
    private readonly FemDbContext _dbContext;
    private readonly ICacheService _cacheService;

    public UyelikService(
        FemDbContext dbContext,
        ICacheService cacheService)
    {
        _dbContext = dbContext;
        _cacheService = cacheService;
    }

    public async Task<ServiceResult<DateTime>> UyeEkleVeyaUzatAsync(
        UyelikEkleRequest request,
        long olusturanTelegramKullaniciId,
        CancellationToken cancellationToken)
    {
        if (request.Gun <= 0 || request.Gun > 3650)
        {
            return ServiceResult<DateTime>.BasarisizSonuc(
                "Gün değeri geçersiz.");
        }

        var kullanici = await _dbContext.Kullanicilar
            .FirstOrDefaultAsync(
                x => x.TelegramKullaniciId == request.TelegramKullaniciId,
                cancellationToken);

        if (kullanici is null)
        {
            return ServiceResult<DateTime>.BasarisizSonuc(
                "Kullanıcı önce bota /start yazmalıdır.");
        }

        var simdi = DateTime.UtcNow;

        var aktifUyelik = await _dbContext.Uyelikler
            .Where(x =>
                x.KullaniciId == kullanici.Id &&
                x.Durum == UyelikDurumu.Aktif &&
                x.BitisTarihi > simdi)
            .OrderByDescending(x => x.BitisTarihi)
            .FirstOrDefaultAsync(cancellationToken);

        DateTime bitisTarihi;

        if (aktifUyelik is null)
        {
            bitisTarihi = simdi.AddDays(request.Gun);

            _dbContext.Uyelikler.Add(new Uyelik
            {
                KullaniciId = kullanici.Id,
                BaslangicTarihi = simdi,
                BitisTarihi = bitisTarihi,
                Durum = UyelikDurumu.Aktif,
                Aciklama = request.Aciklama,
                OlusturanTelegramKullaniciId =
                    olusturanTelegramKullaniciId,
                OlusturmaTarihi = simdi
            });
        }
        else
        {
            aktifUyelik.BitisTarihi =
                aktifUyelik.BitisTarihi.AddDays(request.Gun);

            aktifUyelik.GuncellemeTarihi = simdi;
            bitisTarihi = aktifUyelik.BitisTarihi;
        }

        await _dbContext.SaveChangesAsync(cancellationToken);

        _cacheService.Remove(CacheAnahtarlari.AktifVipUyeler);

        return ServiceResult<DateTime>.BasariliSonuc(
            bitisTarihi,
            "Üyelik başarıyla tanımlandı.");
    }

    public async Task<DateTime?> AktifUyelikBitisTarihiGetirAsync(
        int kullaniciId,
        CancellationToken cancellationToken)
    {
        var simdi = DateTime.UtcNow;

        return await _dbContext.Uyelikler
            .Where(x =>
                x.KullaniciId == kullaniciId &&
                x.Durum == UyelikDurumu.Aktif &&
                x.BaslangicTarihi <= simdi &&
                x.BitisTarihi > simdi)
            .OrderByDescending(x => x.BitisTarihi)
            .Select(x => (DateTime?)x.BitisTarihi)
            .FirstOrDefaultAsync(cancellationToken);
    }
}
