using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class FemAnalizMotoru : IFemAnalizMotoru
{
    public YapayZekaAnalizResult AnalizEt(MacAnalizVerisiDto veri)
    {
        ArgumentNullException.ThrowIfNull(veri);

        var evPuani = 38m;
        var beraberlikPuani = 28m;
        var depPuani = 34m;

        var faktorler = new List<string>();

        FormPuaniniUygula(
            veri.EvSahibiFormu,
            veri.DeplasmanFormu,
            ref evPuani,
            ref beraberlikPuani,
            ref depPuani,
            faktorler);

        GolEgiliminiUygula(
            veri.EvSahibiFormu,
            veri.DeplasmanFormu,
            ref beraberlikPuani,
            faktorler);

        IkiliRekabetiUygula(
            veri,
            ref evPuani,
            ref beraberlikPuani,
            ref depPuani,
            faktorler);

        EvSahibiAvantajiniUygula(
            ref evPuani,
            ref depPuani,
            faktorler);

        OlasiliklariNormalizeEt(
            ref evPuani,
            ref beraberlikPuani,
            ref depPuani);

        var veriYeterlilikPuani = VeriYeterlilikPuaniHesapla(veri);
        var fark = Math.Abs(evPuani - depPuani);

        var guvenPuani = (int)Math.Round(
            Math.Clamp(
                45m +
                veriYeterlilikPuani * 0.35m +
                Math.Min(fark, 25m) * 0.8m,
                40m,
                92m));

        var risk = guvenPuani switch
        {
            >= 78 => "Dusuk",
            >= 62 => "Orta",
            _ => "Yuksek"
        };

        if (faktorler.Count == 0)
        {
            faktorler.Add(
                "Geçmiş veri miktarı sınırlı olduğu için analiz temkinli oluşturuldu.");
        }

        var ozet = OzetOlustur(
            veri,
            evPuani,
            beraberlikPuani,
            depPuani,
            guvenPuani);

        return new YapayZekaAnalizResult
        {
            Ozet = ozet,
            GuvenPuani = guvenPuani,
            RiskSeviyesi = risk,
            EvSahibiKazanmaOlasiligi = Math.Round(evPuani, 2),
            BeraberlikOlasiligi = Math.Round(beraberlikPuani, 2),
            DeplasmanKazanmaOlasiligi = Math.Round(depPuani, 2),
            AnaFaktorler = faktorler
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Take(8)
                .ToList()
        };
    }

    private static void FormPuaniniUygula(
        TakimAnalizOzetiDto ev,
        TakimAnalizOzetiDto dep,
        ref decimal evPuani,
        ref decimal beraberlikPuani,
        ref decimal depPuani,
        List<string> faktorler)
    {
        var evForm = FormSkoru(ev);
        var depForm = FormSkoru(dep);
        var fark = evForm - depForm;

        if (Math.Abs(fark) < 0.75m)
        {
            beraberlikPuani += 3;
            faktorler.Add(
                "Takımların yakın dönem form seviyeleri birbirine yakın.");
            return;
        }

        var etki = Math.Min(Math.Abs(fark) * 2.2m, 12m);

        if (fark > 0)
        {
            evPuani += etki;
            depPuani -= etki * 0.65m;
            faktorler.Add(
                $"{ev.TakimAdi} yakın dönem formunda rakibine göre daha güçlü görünüyor.");
        }
        else
        {
            depPuani += etki;
            evPuani -= etki * 0.65m;
            faktorler.Add(
                $"{dep.TakimAdi} yakın dönem formunda rakibine göre daha güçlü görünüyor.");
        }

        if (ev.SonMacSayisi > 0)
        {
            faktorler.Add(
                $"{ev.TakimAdi}: {ev.Galibiyet}G {ev.Beraberlik}B {ev.Maglubiyet}M.");
        }

        if (dep.SonMacSayisi > 0)
        {
            faktorler.Add(
                $"{dep.TakimAdi}: {dep.Galibiyet}G {dep.Beraberlik}B {dep.Maglubiyet}M.");
        }
    }

    private static void GolEgiliminiUygula(
        TakimAnalizOzetiDto ev,
        TakimAnalizOzetiDto dep,
        ref decimal beraberlikPuani,
        List<string> faktorler)
    {
        var ortalamaGol =
            ev.MacBasinaGolOrtalamasi +
            dep.MacBasinaGolOrtalamasi;

        var ortalamaYenilen =
            ev.MacBasinaYenilenGolOrtalamasi +
            dep.MacBasinaYenilenGolOrtalamasi;

        var ustYuzdesi =
            (ev.IkiBucukUstYuzdesi + dep.IkiBucukUstYuzdesi) / 2m;

        var kgYuzdesi =
            (ev.KarsilikliGolYuzdesi + dep.KarsilikliGolYuzdesi) / 2m;

        if (ortalamaGol >= 2.6m || ustYuzdesi >= 60)
        {
            beraberlikPuani -= 2;
            faktorler.Add(
                "Gol üretim ve 2.5 üst göstergeleri açık oyuna işaret ediyor.");
        }

        if (kgYuzdesi >= 60)
        {
            faktorler.Add(
                "Karşılıklı gol eğilimi istatistiksel olarak dikkat çekiyor.");
        }

        if (ortalamaYenilen >= 2.5m)
        {
            faktorler.Add(
                "İki takımın savunma verileri maçta gol ihtimalini yükseltiyor.");
        }

        if (ortalamaGol > 0 && ortalamaGol < 1.6m)
        {
            beraberlikPuani += 4;
            faktorler.Add(
                "Düşük gol üretimi beraberlik ve kontrollü oyun ihtimalini artırıyor.");
        }
    }

    private static void IkiliRekabetiUygula(
        MacAnalizVerisiDto veri,
        ref decimal evPuani,
        ref decimal beraberlikPuani,
        ref decimal depPuani,
        List<string> faktorler)
    {
        if (veri.IkiliRekabet.Count == 0)
            return;

        var evGalibiyet = 0;
        var depGalibiyet = 0;
        var beraberlik = 0;

        foreach (var mac in veri.IkiliRekabet)
        {
            if (!mac.EvSahibiSkor.HasValue ||
                !mac.DeplasmanSkor.HasValue)
            {
                continue;
            }

            if (mac.EvSahibiSkor == mac.DeplasmanSkor)
            {
                beraberlik++;
                continue;
            }

            var kazanan = mac.EvSahibiSkor > mac.DeplasmanSkor
                ? mac.EvSahibi
                : mac.Deplasman;

            if (kazanan.Equals(
                    veri.EvSahibi,
                    StringComparison.OrdinalIgnoreCase))
            {
                evGalibiyet++;
            }
            else if (kazanan.Equals(
                         veri.Deplasman,
                         StringComparison.OrdinalIgnoreCase))
            {
                depGalibiyet++;
            }
        }

        evPuani += evGalibiyet * 1.5m;
        depPuani += depGalibiyet * 1.5m;
        beraberlikPuani += beraberlik;

        faktorler.Add(
            $"Son ikili rekabet: {veri.EvSahibi} {evGalibiyet} galibiyet, " +
            $"{veri.Deplasman} {depGalibiyet} galibiyet, {beraberlik} beraberlik.");
    }

    private static void EvSahibiAvantajiniUygula(
        ref decimal evPuani,
        ref decimal depPuani,
        List<string> faktorler)
    {
        evPuani += 4;
        depPuani -= 1;

        faktorler.Add(
            "Standart ev sahibi avantajı olasılık hesabına dahil edildi.");
    }

    private static decimal FormSkoru(TakimAnalizOzetiDto takim)
    {
        if (takim.SonMacSayisi <= 0)
            return 0;

        var puan =
            takim.Galibiyet * 3m +
            takim.Beraberlik;

        var puanOrtalamasi = puan / takim.SonMacSayisi;
        var averajEtkisi =
            (takim.AttigiGol - takim.YedigiGol) /
            (decimal)takim.SonMacSayisi * 0.35m;

        return puanOrtalamasi + averajEtkisi;
    }

    private static decimal VeriYeterlilikPuaniHesapla(
        MacAnalizVerisiDto veri)
    {
        var skor = 0m;

        skor += Math.Min(
            veri.EvSahibiFormu.SonMacSayisi,
            5) * 6;

        skor += Math.Min(
            veri.DeplasmanFormu.SonMacSayisi,
            5) * 6;

        skor += Math.Min(
            veri.EvSahibiSonMaclar.Count,
            5) * 3;

        skor += Math.Min(
            veri.DeplasmanSonMaclar.Count,
            5) * 3;

        skor += Math.Min(
            veri.IkiliRekabet.Count,
            5) * 2;

        return Math.Min(skor, 100);
    }

    private static void OlasiliklariNormalizeEt(
        ref decimal ev,
        ref decimal beraberlik,
        ref decimal dep)
    {
        ev = Math.Max(ev, 5);
        beraberlik = Math.Max(beraberlik, 8);
        dep = Math.Max(dep, 5);

        var toplam = ev + beraberlik + dep;

        ev = ev / toplam * 100m;
        beraberlik = beraberlik / toplam * 100m;
        dep = 100m - ev - beraberlik;
    }

    private static string OzetOlustur(
        MacAnalizVerisiDto veri,
        decimal ev,
        decimal beraberlik,
        decimal dep,
        int guven)
    {
        var enYuksek = Math.Max(ev, Math.Max(beraberlik, dep));

        string egilim;

        if (enYuksek == ev)
        {
            egilim =
                $"{veri.EvSahibi} tarafı istatistiksel olarak bir adım önde.";
        }
        else if (enYuksek == dep)
        {
            egilim =
                $"{veri.Deplasman} tarafı istatistiksel olarak bir adım önde.";
        }
        else
        {
            egilim =
                "İstatistikler dengeli bir maç ve beraberlik ihtimaline işaret ediyor.";
        }

        var veriNotu =
            veri.EvSahibiFormu.SonMacSayisi == 0 ||
            veri.DeplasmanFormu.SonMacSayisi == 0
                ? " Geçmiş form verisi sınırlı olduğundan değerlendirme temkinlidir."
                : string.Empty;

        return
            $"{veri.EvSahibi} - {veri.Deplasman} karşılaşmasında " +
            $"{egilim} Hesaplanan güven puanı {guven}/100 seviyesindedir." +
            veriNotu;
    }
}
