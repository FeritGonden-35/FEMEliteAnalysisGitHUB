using System.Text.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Prompts;
using Microsoft.Extensions.Options;
using OpenAI.Chat;

namespace FEMEliteAnalysis.Api.Services;

public class YapayZekaService : IYapayZekaService
{
    private readonly OpenAIOptions _options;
    private readonly ILogger<YapayZekaService> _logger;

    public YapayZekaService(
        IOptions<OpenAIOptions> options,
        ILogger<YapayZekaService> logger)
    {
        _options = options.Value;
        _logger = logger;
    }

    public async Task<ServiceResult<YapayZekaAnalizResult>> MacAnaliziOlusturAsync(
        string veriMetni,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            return ServiceResult<YapayZekaAnalizResult>.BasarisizSonuc(
                "OpenAI API anahtarı tanımlanmamış.");
        }

        if (string.IsNullOrWhiteSpace(veriMetni))
        {
            return ServiceResult<YapayZekaAnalizResult>.BasarisizSonuc(
                "Analiz edilecek maç verisi boş.");
        }

        try
        {
            var client = new ChatClient(
                model: _options.Model,
                apiKey: _options.ApiKey);

            List<ChatMessage> messages =
            [
                new SystemChatMessage(FutbolAnalizPromptu.SistemPromptu),
                new UserChatMessage(
                    "Aşağıdaki futbol maçını yalnızca verilen verilere göre analiz et.\n\n" +
                    veriMetni)
            ];

            ChatCompletionOptions completionOptions = new()
            {
                ResponseFormat = ChatResponseFormat.CreateJsonSchemaFormat(
                    jsonSchemaFormatName: "fem_futbol_analizi",
                    jsonSchema: BinaryData.FromBytes("""
                    {
                      "type": "object",
                      "properties": {
                        "ozet": {
                          "type": "string"
                        },
                        "guvenPuani": {
                          "type": "integer",
                          "minimum": 0,
                          "maximum": 100
                        },
                        "riskSeviyesi": {
                          "type": "string",
                          "enum": ["Dusuk", "Orta", "Yuksek"]
                        },
                        "evSahibiKazanmaOlasiligi": {
                          "type": "number",
                          "minimum": 0,
                          "maximum": 100
                        },
                        "beraberlikOlasiligi": {
                          "type": "number",
                          "minimum": 0,
                          "maximum": 100
                        },
                        "deplasmanKazanmaOlasiligi": {
                          "type": "number",
                          "minimum": 0,
                          "maximum": 100
                        },
                        "anaFaktorler": {
                          "type": "array",
                          "items": {
                            "type": "string"
                          }
                        }
                      },
                      "required": [
                        "ozet",
                        "guvenPuani",
                        "riskSeviyesi",
                        "evSahibiKazanmaOlasiligi",
                        "beraberlikOlasiligi",
                        "deplasmanKazanmaOlasiligi",
                        "anaFaktorler"
                      ],
                      "additionalProperties": false
                    }
                    """u8.ToArray()),
                    jsonSchemaIsStrict: true)
            };

            ChatCompletion completion = await client.CompleteChatAsync(
                messages,
                completionOptions,
                cancellationToken);

            var json = completion.Content.FirstOrDefault()?.Text;

            if (string.IsNullOrWhiteSpace(json))
            {
                return ServiceResult<YapayZekaAnalizResult>.BasarisizSonuc(
                    "OpenAI boş analiz döndürdü.");
            }

            var sonuc = JsonSerializer.Deserialize<YapayZekaAnalizResult>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            if (sonuc is null)
            {
                return ServiceResult<YapayZekaAnalizResult>.BasarisizSonuc(
                    "OpenAI analiz cevabı okunamadı.");
            }

            OlasiliklariDogrula(sonuc);

            _logger.LogInformation(
                "OpenAI maç analizi üretildi. Model: {Model}, Güven: {Guven}",
                _options.Model,
                sonuc.GuvenPuani);

            return ServiceResult<YapayZekaAnalizResult>.BasariliSonuc(
                sonuc,
                "Yapay zekâ analizi oluşturuldu.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "OpenAI maç analizi oluşturulurken hata oluştu.");

            return ServiceResult<YapayZekaAnalizResult>.BasarisizSonuc(
                "Yapay zekâ analizi oluşturulurken hata oluştu.");
        }
    }

    private static void OlasiliklariDogrula(YapayZekaAnalizResult sonuc)
    {
        sonuc.GuvenPuani = Math.Clamp(sonuc.GuvenPuani, 0, 100);

        sonuc.EvSahibiKazanmaOlasiligi =
            Math.Clamp(sonuc.EvSahibiKazanmaOlasiligi, 0, 100);

        sonuc.BeraberlikOlasiligi =
            Math.Clamp(sonuc.BeraberlikOlasiligi, 0, 100);

        sonuc.DeplasmanKazanmaOlasiligi =
            Math.Clamp(sonuc.DeplasmanKazanmaOlasiligi, 0, 100);

        var toplam =
            sonuc.EvSahibiKazanmaOlasiligi +
            sonuc.BeraberlikOlasiligi +
            sonuc.DeplasmanKazanmaOlasiligi;

        if (toplam <= 0)
        {
            sonuc.EvSahibiKazanmaOlasiligi = 34;
            sonuc.BeraberlikOlasiligi = 33;
            sonuc.DeplasmanKazanmaOlasiligi = 33;
            return;
        }

        if (Math.Abs(toplam - 100) <= 0.1m)
            return;

        sonuc.EvSahibiKazanmaOlasiligi =
            Math.Round(
                sonuc.EvSahibiKazanmaOlasiligi / toplam * 100,
                2);

        sonuc.BeraberlikOlasiligi =
            Math.Round(
                sonuc.BeraberlikOlasiligi / toplam * 100,
                2);

        sonuc.DeplasmanKazanmaOlasiligi =
            100 -
            sonuc.EvSahibiKazanmaOlasiligi -
            sonuc.BeraberlikOlasiligi;
    }
}
