namespace FEMEliteAnalysis.Api.Services;

public sealed class IstatistikSyncDurumStore
{
    private readonly object _kilit = new();
    private bool _istekVar;

    public bool CalisiyorMu { get; private set; }
    public long ChatId { get; private set; }
    public DateTime? BaslamaZamani { get; private set; }
    public DateTime? BitisZamani { get; private set; }
    public int ToplamHedef { get; private set; }
    public int KontrolEdilen { get; private set; }
    public int KornerBulunan { get; private set; }
    public int KartBulunan { get; private set; }
    public int StatsBulunamayan { get; private set; }
    public int ZatenDolu { get; private set; }
    public int Hata { get; private set; }
    public string SonMesaj { get; private set; } = "Henüz çalışmadı.";

    public bool Baslat(long chatId)
    {
        lock (_kilit)
        {
            if (CalisiyorMu || _istekVar) return false;
            _istekVar = true;
            ChatId = chatId;
            SonMesaj = "İstatistik senkronizasyonu sıraya alındı.";
            return true;
        }
    }

    public bool IstegiAl(out long chatId)
    {
        lock (_kilit)
        {
            if (!_istekVar)
            {
                chatId = 0;
                return false;
            }

            _istekVar = false;
            CalisiyorMu = true;
            BaslamaZamani = DateTime.UtcNow;
            BitisZamani = null;
            ToplamHedef = KontrolEdilen = KornerBulunan = KartBulunan = StatsBulunamayan = ZatenDolu = Hata = 0;
            SonMesaj = "Çalışıyor.";
            chatId = ChatId;
            return true;
        }
    }

    public void Ilerle(IstatistikSyncIlerleme x)
    {
        lock (_kilit)
        {
            ToplamHedef = x.ToplamHedef;
            KontrolEdilen = x.KontrolEdilen;
            KornerBulunan = x.KornerBulunan;
            KartBulunan = x.KartBulunan;
            StatsBulunamayan = x.StatsBulunamayan;
            ZatenDolu = x.ZatenDolu;
            Hata = x.Hata;
            SonMesaj = x.Mesaj;
        }
    }

    public void Tamamla(string mesaj)
    {
        lock (_kilit)
        {
            CalisiyorMu = false;
            BitisZamani = DateTime.UtcNow;
            SonMesaj = mesaj;
        }
    }
}

public sealed class IstatistikSyncIlerleme
{
    public int ToplamHedef { get; init; }
    public int KontrolEdilen { get; init; }
    public int KornerBulunan { get; init; }
    public int KartBulunan { get; init; }
    public int SutBulunan { get; init; }
    public int StatsBulunamayan { get; init; }
    public int ZatenDolu { get; init; }
    public int Hata { get; init; }
    public int CursorMacId { get; init; }
    public string Mesaj { get; init; } = string.Empty;
}

public sealed class IstatistikSyncSonuc
{
    public int ToplamHedef { get; set; }
    public int KontrolEdilen { get; set; }
    public int KornerBulunan { get; set; }
    public int KartBulunan { get; set; }
    public int SutBulunan { get; set; }
    public int StatsBulunamayan { get; set; }
    public int ZatenDolu { get; set; }
    public int Hata { get; set; }
    public int BaslangicCursor { get; set; }
    public int BitisCursor { get; set; }
}
