using System.Text;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Debug;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class DebugService : IDebugService
{
    private readonly FemDbContext _dbContext;
    private readonly ISqlTakimFormService _sqlTakimFormService;
    private readonly IAnalizMotoruV2 _analizMotoruV2;

    public DebugService(
        FemDbContext dbContext,
        ISqlTakimFormService sqlTakimFormService,
        IAnalizMotoruV2 analizMotoruV2)
    {
        _dbContext = dbContext;
        _sqlTakimFormService = sqlTakimFormService;
        _analizMotoruV2 = analizMotoruV2;
    }

    public async Task<ServiceResult<MacDebugDto>> MacDebugGetirAsync(
        int macId,
        CancellationToken cancellationToken)
    {
        var mac = await _dbContext.Maclar
            .AsNoTracking()
            .Include(x => x.EvSahibiTakim)
            .Include(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == macId,
                cancellationToken);

        if (mac is null)
        {
            return ServiceResult<MacDebugDto>.BasarisizSonuc(
                "Maç bulunamadı.");
        }

        var veriSonucu =
            await _sqlTakimFormService.MacKuponVerisiOlusturAsync(
                macId,
                cancellationToken);

        if (!veriSonucu.Basarili || veriSonucu.Veri is null)
        {
            return ServiceResult<MacDebugDto>.BasarisizSonuc(
                veriSonucu.Mesaj);
        }

        var veri = veriSonucu.Veri;

        var dto = new MacDebugDto
        {
            MacId = mac.Id,
            MacAdi =
                $"{mac.EvSahibiTakim.Ad} - {mac.DeplasmanTakim.Ad}",
            MacTarihi = mac.MacTarihi,

            EvTakimId = veri.EvSahibiGenelForm.TakimId,
            EvTakimAdi = veri.EvSahibiGenelForm.TakimAdi,
            EvHariciTakimId = veri.EvSahibiGenelForm.HariciTakimId,
            EvGenelMacSayisi =
                veri.EvSahibiGenelForm.ToplamMac,
            EvIcSahaMacSayisi =
                veri.EvSahibiIcSahaForm.ToplamMac,
            EvSonMacTarihi =
                veri.EvSahibiGenelForm.Maclar
                    .OrderByDescending(x => x.MacTarihi)
                    .Select(x => (DateTime?)x.MacTarihi)
                    .FirstOrDefault(),

            DepTakimId = veri.DeplasmanGenelForm.TakimId,
            DepTakimAdi = veri.DeplasmanGenelForm.TakimAdi,
            DepHariciTakimId = veri.DeplasmanGenelForm.HariciTakimId,
            DepGenelMacSayisi =
                veri.DeplasmanGenelForm.ToplamMac,
            DepDisSahaMacSayisi =
                veri.DeplasmanDisSahaForm.ToplamMac,
            DepSonMacTarihi =
                veri.DeplasmanGenelForm.Maclar
                    .OrderByDescending(x => x.MacTarihi)
                    .Select(x => (DateTime?)x.MacTarihi)
                    .FirstOrDefault(),

            H2HMacSayisi = veri.H2H.ToplamMac,
            VeriKalitesiPuani = veri.VeriKalitesiPuani,
            Uyarilar = veri.VeriEksikleri
        };

        return ServiceResult<MacDebugDto>.BasariliSonuc(
            dto,
            "Maç debug bilgisi hazırlandı.");
    }

    public async Task<ServiceResult<string>> TakimDebugGetirAsync(
        string takimAdi,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(takimAdi))
        {
            return ServiceResult<string>.BasarisizSonuc(
                "Takım adı boş olamaz.");
        }

        var aranan = takimAdi.Trim();

        var takimlar = await _dbContext.Takimlar
            .AsNoTracking()
            .Where(x => x.Ad.Contains(aranan))
            .OrderBy(x => x.Ad)
            .Take(10)
            .ToListAsync(cancellationToken);

        if (takimlar.Count == 0)
        {
            return ServiceResult<string>.BasarisizSonuc(
                "Takım bulunamadı.");
        }

        var metin = new StringBuilder();

        foreach (var takim in takimlar)
        {
            var bitmisMacSayisi = await _dbContext.Maclar
                .AsNoTracking()
                .CountAsync(
                    x =>
                        (
                            x.EvSahibiTakimId == takim.Id ||
                            x.DeplasmanTakimId == takim.Id
                        ) &&
                        x.EvSahibiSkor.HasValue &&
                        x.DeplasmanSkor.HasValue,
                    cancellationToken);

            var sonMac = await _dbContext.Maclar
                .AsNoTracking()
                .Include(x => x.EvSahibiTakim)
                .Include(x => x.DeplasmanTakim)
                .Where(x =>
                    (
                        x.EvSahibiTakimId == takim.Id ||
                        x.DeplasmanTakimId == takim.Id
                    ) &&
                    x.EvSahibiSkor.HasValue &&
                    x.DeplasmanSkor.HasValue)
                .OrderByDescending(x => x.MacTarihi)
                .FirstOrDefaultAsync(cancellationToken);

            metin.AppendLine($"⚽ {takim.Ad}");
            metin.AppendLine($"Takım ID: {takim.Id}");
            metin.AppendLine(
                $"Eski Harici ID: {takim.HariciTakimId?.ToString() ?? "NULL"}");
            metin.AppendLine(
                $"TheSportsDB ID: {takim.TheSportsDbTakimId?.ToString() ?? "NULL"}");
            metin.AppendLine(
                $"API-Football ID: {takim.ApiFootballTakimId?.ToString() ?? "NULL"}");
            metin.AppendLine($"Bitmiş maç: {bitmisMacSayisi}");

            if (sonMac is not null)
            {
                metin.AppendLine(
                    $"Son maç: {sonMac.EvSahibiTakim.Ad} " +
                    $"{sonMac.EvSahibiSkor}-" +
                    $"{sonMac.DeplasmanSkor} " +
                    $"{sonMac.DeplasmanTakim.Ad}");

                metin.AppendLine(
                    $"Son maç tarihi: " +
                    $"{sonMac.MacTarihi.ToLocalTime():dd.MM.yyyy HH:mm}");
            }

            metin.AppendLine("────────────");
        }

        return ServiceResult<string>.BasariliSonuc(
            metin.ToString().Trim(),
            "Takım debug bilgisi hazırlandı.");
    }

    public async Task<ServiceResult<string>> H2HDebugGetirAsync(
        int macId,
        CancellationToken cancellationToken)
    {
        var veriSonucu =
            await _sqlTakimFormService.MacKuponVerisiOlusturAsync(
                macId,
                cancellationToken);

        if (!veriSonucu.Basarili || veriSonucu.Veri is null)
        {
            return ServiceResult<string>.BasarisizSonuc(
                veriSonucu.Mesaj);
        }

        var veri = veriSonucu.Veri;
        var h2h = veri.H2H;

        var metin =
            $"🤝 H2H DEBUG\n\n" +
            $"{veri.EvSahibi} - {veri.Deplasman}\n\n" +
            $"Bulunan maç: {h2h.ToplamMac}\n" +
            $"{veri.EvSahibi} galibiyet: {h2h.Takim1Galibiyet}\n" +
            $"Beraberlik: {h2h.Beraberlik}\n" +
            $"{veri.Deplasman} galibiyet: {h2h.Takim2Galibiyet}\n" +
            $"Ortalama gol: {h2h.OrtalamaToplamGol:0.00}\n" +
            $"KG Var: %{h2h.KarsilikliGolYuzdesi:0.##}\n" +
            $"2.5 Üst: %{h2h.IkiBucukUstYuzdesi:0.##}";

        return ServiceResult<string>.BasariliSonuc(
            metin,
            "H2H debug bilgisi hazırlandı.");
    }

    public async Task<ServiceResult<AnalizMotoruV2SonucDto>>
        MarketDebugGetirAsync(
            int macId,
            CancellationToken cancellationToken)
    {
        var veriSonucu =
            await _sqlTakimFormService.MacKuponVerisiOlusturAsync(
                macId,
                cancellationToken);

        if (!veriSonucu.Basarili || veriSonucu.Veri is null)
        {
            return ServiceResult<AnalizMotoruV2SonucDto>.BasarisizSonuc(
                veriSonucu.Mesaj);
        }

        var sonuc = _analizMotoruV2.AnalizEt(
            veriSonucu.Veri);

        return ServiceResult<AnalizMotoruV2SonucDto>.BasariliSonuc(
            sonuc,
            "Market debug bilgisi hazırlandı.");
    }
}
