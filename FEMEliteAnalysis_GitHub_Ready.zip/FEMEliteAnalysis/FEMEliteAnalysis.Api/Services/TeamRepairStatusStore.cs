using FEMEliteAnalysis.Api.Dtos.TeamRepair;

namespace FEMEliteAnalysis.Api.Services;

public sealed class TeamRepairStatusStore
{
    private readonly object _lock = new();
    private TeamRepairStatusDto _status = new();
    private List<TeamMergeCandidateDto> _plan = [];

    public TeamRepairStatusDto Get()
    {
        lock (_lock)
            return Kopyala(_status);
    }

    public IReadOnlyList<TeamMergeCandidateDto> PlanGetir()
    {
        lock (_lock)
            return _plan.ToList();
    }

    public void PlanAyarla(int takimSayisi, List<TeamMergeCandidateDto> plan)
    {
        lock (_lock)
        {
            _plan = plan;
            _status = new TeamRepairStatusDto
            {
                IncelenenTakim = takimSayisi,
                AdayGrup = plan.Count,
                SonBitis = DateTime.UtcNow,
                SonMesaj = $"{takimSayisi} takım incelendi; {plan.Count} güvenli birleştirme grubu bulundu."
            };
        }
    }

    public void Baslat()
    {
        lock (_lock)
        {
            _status.CalisiyorMu = true;
            _status.SonBaslangic = DateTime.UtcNow;
            _status.SonMesaj = "Takım birleştirme işlemi başladı.";
        }
    }

    public void Bitir(TeamRepairStatusDto sonuc)
    {
        lock (_lock)
        {
            sonuc.CalisiyorMu = false;
            sonuc.SonBitis = DateTime.UtcNow;
            _status = sonuc;
        }
    }

    private static TeamRepairStatusDto Kopyala(TeamRepairStatusDto x) => new()
    {
        CalisiyorMu=x.CalisiyorMu, SonBaslangic=x.SonBaslangic, SonBitis=x.SonBitis,
        IncelenenTakim=x.IncelenenTakim, AdayGrup=x.AdayGrup, BirlesenTakim=x.BirlesenTakim,
        GuncellenenMacBaglantisi=x.GuncellenenMacBaglantisi, GuncellenenIstatistik=x.GuncellenenIstatistik,
        GuncellenenForm=x.GuncellenenForm, SonMesaj=x.SonMesaj
    };
}
