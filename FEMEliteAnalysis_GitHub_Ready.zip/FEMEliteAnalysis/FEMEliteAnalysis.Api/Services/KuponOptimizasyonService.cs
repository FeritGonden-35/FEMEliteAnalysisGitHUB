using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public class KuponOptimizasyonService : IKuponOptimizasyonService
{
    private readonly ICokluKuponTaslakService _taslakService;
    private readonly FemDbContext _dbContext;

    public KuponOptimizasyonService(
        ICokluKuponTaslakService taslakService,
        FemDbContext dbContext)
    {
        _taslakService = taslakService;
        _dbContext = dbContext;
    }

    public async Task<ServiceResult<KuponOptimizasyonSonucDto>> OptimizeEtAsync(
        long adminTelegramId,
        int? hedefMacSayisi,
        CancellationToken cancellationToken)
    {
        var taslakSonucu = _taslakService.TaslagiGetir(adminTelegramId);

        if (!taslakSonucu.Basarili ||
            taslakSonucu.Veri is null ||
            taslakSonucu.Veri.Maclar.Count == 0)
        {
            return ServiceResult<KuponOptimizasyonSonucDto>.BasarisizSonuc(
                "Optimize edilecek kupon taslağı bulunmuyor.");
        }

        var taslak = taslakSonucu.Veri;
        var analizIdleri = taslak.Maclar.Select(x => x.AnalizId).ToList();

        var analizler = await _dbContext.Analizler
            .AsNoTracking()
            .Include(x => x.Mac)
                .ThenInclude(x => x.Lig)
            .Include(x => x.Mac)
                .ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac)
                .ThenInclude(x => x.DeplasmanTakim)
            .Where(x => analizIdleri.Contains(x.Id))
            .ToListAsync(cancellationToken);

        var maclar = new List<KuponOptimizasyonMacDto>();

        foreach (var secim in taslak.Maclar)
        {
            var analiz = analizler.FirstOrDefault(x => x.Id == secim.AnalizId);
            if (analiz is null)
                continue;

            var uyarilar = new List<string>();
            var duzenlenmis = secim.GuvenPuani;

            if (secim.GuvenPuani < 50)
            {
                duzenlenmis -= 14;
                uyarilar.Add("Güven puanı %50 altında.");
            }
            else if (secim.GuvenPuani < 65)
            {
                duzenlenmis -= 7;
                uyarilar.Add("Güven puanı orta-alt seviyede.");
            }

            var risk = analiz.RiskSeviyesi.ToString();
            if (risk.Equals("Yuksek", StringComparison.OrdinalIgnoreCase))
            {
                duzenlenmis -= 8;
                uyarilar.Add("Analiz risk seviyesi yüksek.");
            }

            if (MarketAnalizle(secim.SecilenMarket, analiz, out var marketUyarisi, out var marketFarki))
            {
                duzenlenmis += marketFarki;
                if (!string.IsNullOrWhiteSpace(marketUyarisi))
                    uyarilar.Add(marketUyarisi);
            }

            maclar.Add(new KuponOptimizasyonMacDto
            {
                AnalizId = secim.AnalizId,
                MacId = secim.MacId,
                EvSahibi = secim.EvSahibi,
                Deplasman = secim.Deplasman,
                Market = secim.SecilenMarket,
                HamGuvenPuani = secim.GuvenPuani,
                DuzenlenmisGuvenPuani = Math.Clamp(duzenlenmis, 0, 100),
                Lig = analiz.Mac.Lig?.Ad ?? "Bilinmeyen Lig",
                MacTarihi = analiz.Mac.MacTarihi,
                RiskSeviyesi = risk,
                Uyarilar = uyarilar
            });
        }

        if (maclar.Count == 0)
        {
            return ServiceResult<KuponOptimizasyonSonucDto>.BasarisizSonuc(
                "Kupon seçimlerinin analiz kayıtları bulunamadı.");
        }

        var hedefler = hedefMacSayisi.HasValue
            ? new[] { Math.Clamp(hedefMacSayisi.Value, 1, maclar.Count) }
            : Enumerable.Range(1, maclar.Count).ToArray();

        var kombinasyonlar = new List<KuponKombinasyonDto>();
        foreach (var hedef in hedefler)
        {
            foreach (var kombinasyon in KombinasyonUret(maclar, hedef))
                kombinasyonlar.Add(KombinasyonuPuanla(kombinasyon));
        }

        var sirali = kombinasyonlar
            .OrderByDescending(x => x.OptimizasyonPuani)
            .ThenByDescending(x => x.OrtalamaGuven)
            .ThenBy(x => x.Maclar.Count)
            .ToList();

        for (var i = 0; i < sirali.Count; i++)
            sirali[i].Sira = i + 1;

        var mevcut = KombinasyonuPuanla(maclar);
        var onerilen = sirali.FirstOrDefault();

        var sonuc = new KuponOptimizasyonSonucDto
        {
            MevcutMacSayisi = mevcut.Maclar.Count,
            MevcutOrtalamaGuven = mevcut.OrtalamaGuven,
            MevcutOptimizasyonPuani = mevcut.OptimizasyonPuani,
            MevcutRiskSeviyesi = mevcut.RiskSeviyesi,
            TumMaclar = maclar.OrderByDescending(x => x.DuzenlenmisGuvenPuani).ToList(),
            OnerilenKupon = onerilen,
            Alternatifler = sirali.Skip(1).Take(3).ToList(),
            EnZayifSecim = maclar.OrderBy(x => x.DuzenlenmisGuvenPuani).FirstOrDefault(),
            Kritikler = KritikOlustur(mevcut, onerilen)
        };

        return ServiceResult<KuponOptimizasyonSonucDto>.BasariliSonuc(
            sonuc,
            "Kupon optimizasyonu tamamlandı.");
    }

    public async Task<ServiceResult<CokluKuponTaslakDto>> OnerilenKuponuUygulaAsync(
        long adminTelegramId,
        int hedefMacSayisi,
        CancellationToken cancellationToken)
    {
        var optimizasyon = await OptimizeEtAsync(
            adminTelegramId,
            hedefMacSayisi,
            cancellationToken);

        if (!optimizasyon.Basarili ||
            optimizasyon.Veri?.OnerilenKupon is null)
        {
            return ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                optimizasyon.Mesaj);
        }

        _taslakService.Temizle(adminTelegramId);
        ServiceResult<CokluKuponTaslakDto>? sonSonuc = null;

        foreach (var mac in optimizasyon.Veri.OnerilenKupon.Maclar)
        {
            sonSonuc = _taslakService.MacEkle(
                adminTelegramId,
                new CokluKuponMacSecimiDto
                {
                    AnalizId = mac.AnalizId,
                    MacId = mac.MacId,
                    EvSahibi = mac.EvSahibi,
                    Deplasman = mac.Deplasman,
                    SecilenMarket = mac.Market,
                    GuvenPuani = mac.HamGuvenPuani,
                    AktifMi = true
                });
        }

        return sonSonuc is null
            ? ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                "Önerilen kupon uygulanamadı.")
            : ServiceResult<CokluKuponTaslakDto>.BasariliSonuc(
                sonSonuc.Veri!,
                $"En iyi {hedefMacSayisi} maçlık kombinasyon kupon taslağına uygulandı.");
    }

    private static bool MarketAnalizle(
        string market,
        FEMEliteAnalysis.Api.Models.Analiz analiz,
        out string uyari,
        out int puanFarki)
    {
        uyari = string.Empty;
        puanFarki = 0;
        var m = market.ToUpperInvariant();

        decimal? olasilik = null;
        if (m.Contains("MS1") || m == "1")
            olasilik = analiz.EvSahibiKazanmaOlasiligi;
        else if (m.Contains("MS2") || m == "2")
            olasilik = analiz.DeplasmanKazanmaOlasiligi;
        else if (m.Contains("MSX") || m == "X")
            olasilik = analiz.BeraberlikOlasiligi;

        if (!olasilik.HasValue)
            return false;

        if (olasilik.Value >= 65)
        {
            puanFarki = 4;
            uyari = "Seçilen maç sonucu marketi analiz olasılığıyla uyumlu.";
        }
        else if (olasilik.Value < 45)
        {
            puanFarki = -10;
            uyari = $"Seçilen maç sonucu marketinin analiz puanı düşük: %{olasilik.Value:0}.";
        }

        return true;
    }

    private static IEnumerable<List<KuponOptimizasyonMacDto>> KombinasyonUret(
        IReadOnlyList<KuponOptimizasyonMacDto> kaynak,
        int adet)
    {
        var sonuc = new List<List<KuponOptimizasyonMacDto>>();

        void Uret(int baslangic, List<KuponOptimizasyonMacDto> secilen)
        {
            if (secilen.Count == adet)
            {
                sonuc.Add(secilen.ToList());
                return;
            }

            for (var i = baslangic; i <= kaynak.Count - (adet - secilen.Count); i++)
            {
                secilen.Add(kaynak[i]);
                Uret(i + 1, secilen);
                secilen.RemoveAt(secilen.Count - 1);
            }
        }

        Uret(0, new List<KuponOptimizasyonMacDto>());
        return sonuc;
    }

    private static KuponKombinasyonDto KombinasyonuPuanla(
        IReadOnlyCollection<KuponOptimizasyonMacDto> maclar)
    {
        var liste = maclar.ToList();
        var ortalama = liste.Count == 0
            ? 0
            : (int)Math.Round(liste.Average(x => x.DuzenlenmisGuvenPuani));

        var uyarilar = new List<string>();
        var ceza = 0;

        var dusukSayisi = liste.Count(x => x.DuzenlenmisGuvenPuani < 50);
        if (dusukSayisi > 0)
        {
            ceza += dusukSayisi * 8;
            uyarilar.Add($"{dusukSayisi} seçim optimize edilmiş %50 güvenin altında.");
        }

        var ayniLigFazlasi = liste
            .GroupBy(x => x.Lig, StringComparer.OrdinalIgnoreCase)
            .Sum(g => Math.Max(0, g.Count() - 1));

        if (ayniLigFazlasi > 0)
        {
            ceza += ayniLigFazlasi * 3;
            uyarilar.Add("Aynı ligden birden fazla seçim kupon çeşitliliğini azaltıyor.");
        }

        var ayniSaatFazlasi = liste
            .GroupBy(x => new
            {
                x.MacTarihi.Date,
                x.MacTarihi.Hour
            })
            .Sum(g => Math.Max(0, g.Count() - 1));

        if (ayniSaatFazlasi > 0)
        {
            ceza += ayniSaatFazlasi * 2;
            uyarilar.Add("Aynı saat diliminde yoğunlaşan maçlar bulunuyor.");
        }

        var adetCezasi = liste.Count switch
        {
            <= 2 => 0,
            3 => 2,
            4 => 5,
            _ => 9
        };
        ceza += adetCezasi;

        if (adetCezasi > 0)
            uyarilar.Add($"{liste.Count} maçlık kupon için kombinasyon riski uygulandı.");

        var minGuven = liste.Select(x => x.DuzenlenmisGuvenPuani).DefaultIfEmpty(0).Min();
        var puan = Math.Clamp(
            (int)Math.Round(ortalama * 0.75m + minGuven * 0.25m) - ceza,
            0,
            100);

        return new KuponKombinasyonDto
        {
            Maclar = liste.OrderByDescending(x => x.DuzenlenmisGuvenPuani).ToList(),
            OrtalamaGuven = ortalama,
            OptimizasyonPuani = puan,
            RiskSeviyesi = puan switch
            {
                >= 78 => "Düşük",
                >= 62 => "Orta",
                >= 45 => "Yüksek",
                _ => "Çok Yüksek"
            },
            Uyarilar = uyarilar
        };
    }

    private static List<string> KritikOlustur(
        KuponKombinasyonDto mevcut,
        KuponKombinasyonDto? onerilen)
    {
        var kritikler = new List<string>();

        if (mevcut.Maclar.Count > 3)
            kritikler.Add("Maç sayısını 2 veya 3'e indirmek toplam kupon riskini azaltabilir.");

        var enZayif = mevcut.Maclar.OrderBy(x => x.DuzenlenmisGuvenPuani).FirstOrDefault();
        if (enZayif is not null && enZayif.DuzenlenmisGuvenPuani < 60)
        {
            kritikler.Add(
                $"En zayıf seçim: {enZayif.EvSahibi} - {enZayif.Deplasman}, " +
                $"{enZayif.Market}, optimize güven %{enZayif.DuzenlenmisGuvenPuani}.");
        }

        if (onerilen is not null && onerilen.OptimizasyonPuani > mevcut.OptimizasyonPuani)
        {
            kritikler.Add(
                $"Önerilen kombinasyon kupon puanını %{mevcut.OptimizasyonPuani}'dan " +
                $"%{onerilen.OptimizasyonPuani}'a çıkarıyor.");
        }

        kritikler.AddRange(mevcut.Uyarilar);

        return kritikler
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(6)
            .ToList();
    }
}
