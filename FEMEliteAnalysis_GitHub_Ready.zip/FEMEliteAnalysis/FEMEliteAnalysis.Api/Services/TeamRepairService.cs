using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.TeamRepair;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public sealed class TeamRepairService : ITeamRepairService
{
    private readonly FemDbContext _db;
    private readonly TeamRepairStatusStore _store;
    private readonly ILogger<TeamRepairService> _logger;

    private static readonly string[] KulupEkleri =
    [
        "futbol kulubu", "spor kulubu", "football club", "football clube",
        "futbol club", "soccer club", "sporting club", "sports club",
        "istanbul anonim sirketi", "istanbul as", "istanbul a s",
        "istanbul sk", "anonim sirketi", "a s", "sk", "fk", "fc",
        "cf", "sc", "ac", "afc"
    ];

    // Kaynaklar arasında sık görülen gerçek kulüp yazım farklılıkları.
    // Buradaki eşlemeler sadece aynı kulübün bilinen adlarıdır.
    private static readonly Dictionary<string, string> BilinenAliaslar =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["galatasaray istanbul"] = "galatasaray",
            ["galatasaray istanbul as"] = "galatasaray",
            ["fenerbahce istanbul"] = "fenerbahce",
            ["fenerbahce istanbul sk"] = "fenerbahce",
            ["besiktas istanbul"] = "besiktas",
            ["besiktas jk"] = "besiktas",
            ["istanbul basaksehir"] = "basaksehir",
            ["medipol basaksehir"] = "basaksehir",
            ["man utd"] = "manchester united",
            ["man united"] = "manchester united",
            ["man city"] = "manchester city",
            ["inter milan"] = "internazionale",
            ["inter"] = "internazionale",
            ["fc internazionale milano"] = "internazionale",
            ["psg"] = "paris saint germain",
            ["paris sg"] = "paris saint germain",
            ["bayern munich"] = "bayern munchen",
            ["borussia monchengladbach"] = "borussia m gladbach",
            ["ath madrid"] = "atletico madrid",
            ["atletico de madrid"] = "atletico madrid",
            ["ath bilbao"] = "athletic bilbao",
            ["real betis balompie"] = "real betis",
            ["deportivo la coruna"] = "deportivo coruna",
            ["sporting gijon"] = "sporting de gijon",
            ["us boulogne"] = "boulogne",
            ["boulogne sur mer"] = "boulogne"
        };

    private static readonly HashSet<string> KorunacakFarkliKulupEkleri =
        new(StringComparer.OrdinalIgnoreCase)
        {
            "tula", "sarandi", "ceska lipa", "kyiv", "kiev", "minsk",
            "kharkiv", "london", "women", "u21", "u23", "ii", "b"
        };

    public TeamRepairService(
        FemDbContext db,
        TeamRepairStatusStore store,
        ILogger<TeamRepairService> logger)
    {
        _db = db;
        _store = store;
        _logger = logger;
    }

    public TeamRepairStatusDto DurumGetir() => _store.Get();

    public IReadOnlyList<TeamMergeCandidateDto> SonPlanGetir() =>
        _store.PlanGetir();

    public async Task<ServiceResult<List<TeamMergeCandidateDto>>> TaraAsync(
        CancellationToken cancellationToken)
    {
        var takimlar = await _db.Takimlar
            .AsNoTracking()
            .Where(x => x.AktifMi)
            .ToListAsync(cancellationToken);

        var evSahibiSayilari = await _db.Maclar
            .AsNoTracking()
            .GroupBy(x => x.EvSahibiTakimId)
            .Select(g => new { TakimId = g.Key, Adet = g.Count() })
            .ToListAsync(cancellationToken);

        var deplasmanSayilari = await _db.Maclar
            .AsNoTracking()
            .GroupBy(x => x.DeplasmanTakimId)
            .Select(g => new { TakimId = g.Key, Adet = g.Count() })
            .ToListAsync(cancellationToken);

        var macSayilari = evSahibiSayilari
            .Concat(deplasmanSayilari)
            .GroupBy(x => x.TakimId)
            .ToDictionary(g => g.Key, g => g.Sum(x => x.Adet));

        var union = new UnionFind(takimlar.Select(x => x.Id));
        var bilgiler = takimlar.ToDictionary(
            x => x.Id,
            x => TakimBilgisiOlustur(x));

        // 1) Kesin normalize/alias eşleşmeleri.
        foreach (var grup in takimlar
                     .GroupBy(x => bilgiler[x.Id].Anahtar)
                     .Where(g => !string.IsNullOrWhiteSpace(g.Key) && g.Count() > 1))
        {
            BirlikteBirlestir(union, grup.Select(x => x.Id));
        }

        // 2) Yüksek güvenli benzerlik eşleşmeleri.
        // İlk karaktere göre kovalanarak gereksiz tüm çift karşılaştırmaları azaltılır.
        foreach (var bucket in takimlar
                     .Where(x => bilgiler[x.Id].Anahtar.Length >= 4)
                     .GroupBy(x => bilgiler[x.Id].Anahtar[0]))
        {
            var liste = bucket.ToList();

            for (var i = 0; i < liste.Count; i++)
            {
                for (var j = i + 1; j < liste.Count; j++)
                {
                    var sol = liste[i];
                    var sag = liste[j];

                    if (!UlkelerUyumlu(sol, sag))
                        continue;

                    if (AyniKulupGuvenliMi(
                            bilgiler[sol.Id],
                            bilgiler[sag.Id]))
                    {
                        union.Union(sol.Id, sag.Id);
                    }
                }
            }
        }

        var plan = union
            .Gruplar()
            .Where(g => g.Count > 1)
            .Select(ids => ids
                .Select(id => takimlar.First(x => x.Id == id))
                .ToList())
            .Select(grup => AdayOlustur(grup, macSayilari))
            .Where(x => x is not null)
            .Cast<TeamMergeCandidateDto>()
            .OrderByDescending(x => x.ToplamTasinacakMacBaglantisi)
            .ToList();

        _store.PlanAyarla(takimlar.Count, plan);

        return ServiceResult<List<TeamMergeCandidateDto>>
            .BasariliSonuc(
                plan,
                $"{takimlar.Count} takım incelendi; " +
                $"{plan.Count} güvenli grup ve " +
                $"{plan.Sum(x => x.BirlesecekTakimlar.Count)} tekrar kayıt bulundu.");
    }

    public async Task<ServiceResult<TeamRepairStatusDto>> UygulaAsync(
        CancellationToken cancellationToken)
    {
        if (_store.Get().CalisiyorMu)
        {
            return ServiceResult<TeamRepairStatusDto>
                .BasarisizSonuc("Birleştirme zaten çalışıyor.");
        }

        var plan = _store.PlanGetir().ToList();

        if (plan.Count == 0)
        {
            var tarama = await TaraAsync(cancellationToken);

            if (!tarama.Basarili ||
                tarama.Veri is null ||
                tarama.Veri.Count == 0)
            {
                return ServiceResult<TeamRepairStatusDto>
                    .BasarisizSonuc(
                        "Uygulanacak güvenli birleştirme planı bulunamadı.");
            }

            plan = tarama.Veri;
        }

        _store.Baslat();

        try
        {
            var executionStrategy = _db.Database.CreateExecutionStrategy();

            var sonuc = await executionStrategy.ExecuteAsync(async () =>
            {
                // Retry olursa sayaçlar sıfırdan hesaplanır.
                var status = _store.Get();
                status.AdayGrup = plan.Count;
                status.BirlesenTakim = 0;
                status.GuncellenenMacBaglantisi = 0;
                status.GuncellenenIstatistik = 0;
                status.GuncellenenForm = 0;

                await using var tx = await _db.Database
                    .BeginTransactionAsync(cancellationToken);

                try
                {
                    foreach (var grup in plan)
                    {
                        foreach (var uye in grup.BirlesecekTakimlar)
                        {
                            var eskiId = uye.TakimId;
                            var anaId = grup.AnaTakimId;

                            status.GuncellenenMacBaglantisi +=
                                await _db.Maclar
                                    .Where(x => x.EvSahibiTakimId == eskiId)
                                    .ExecuteUpdateAsync(
                                        s => s.SetProperty(
                                            x => x.EvSahibiTakimId,
                                            anaId),
                                        cancellationToken);

                            status.GuncellenenMacBaglantisi +=
                                await _db.Maclar
                                    .Where(x => x.DeplasmanTakimId == eskiId)
                                    .ExecuteUpdateAsync(
                                        s => s.SetProperty(
                                            x => x.DeplasmanTakimId,
                                            anaId),
                                        cancellationToken);

                            // Aynı maç için ana takım istatistiği zaten varsa
                            // eski takımın çakışan istatistiğini kaldır.
                            await _db.MacIstatistikleri
                                .Where(x =>
                                    x.TakimId == eskiId &&
                                    _db.MacIstatistikleri.Any(y =>
                                        y.MacId == x.MacId &&
                                        y.TakimId == anaId))
                                .ExecuteDeleteAsync(cancellationToken);

                            status.GuncellenenIstatistik +=
                                await _db.MacIstatistikleri
                                    .Where(x => x.TakimId == eskiId)
                                    .ExecuteUpdateAsync(
                                        s => s.SetProperty(
                                            x => x.TakimId,
                                            anaId),
                                        cancellationToken);

                            status.GuncellenenForm +=
                                await _db.TakimFormlari
                                    .Where(x => x.TakimId == eskiId)
                                    .ExecuteUpdateAsync(
                                        s => s.SetProperty(
                                            x => x.TakimId,
                                            anaId),
                                        cancellationToken);

                            await _db.Takimlar
                                .Where(x => x.Id == eskiId)
                                .ExecuteUpdateAsync(
                                    s => s.SetProperty(
                                        x => x.AktifMi,
                                        false),
                                    cancellationToken);

                            status.BirlesenTakim++;
                        }
                    }

                    await tx.CommitAsync(cancellationToken);
                    return status;
                }
                catch
                {
                    await tx.RollbackAsync(cancellationToken);
                    throw;
                }
            });

            sonuc.SonMesaj =
                $"{sonuc.BirlesenTakim} takım kaydı birleştirildi; " +
                $"{sonuc.GuncellenenMacBaglantisi} maç bağlantısı, " +
                $"{sonuc.GuncellenenIstatistik} istatistik ve " +
                $"{sonuc.GuncellenenForm} form kaydı güncellendi.";

            _store.Bitir(sonuc);

            return ServiceResult<TeamRepairStatusDto>
                .BasariliSonuc(_store.Get(), sonuc.SonMesaj);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Takım birleştirme hatası");

            var status = _store.Get();
            status.SonMesaj = "Birleştirme geri alındı: " + ex.Message;
            _store.Bitir(status);

            return ServiceResult<TeamRepairStatusDto>
                .BasarisizSonuc(status.SonMesaj);
        }
    }

    private static TeamMergeCandidateDto? AdayOlustur(
        List<Takim> takimlar,
        Dictionary<int, int> macSayilari)
    {
        var ulkeler = takimlar
            .Select(x => NormalizeBasit(x.Ulke ?? string.Empty))
            .Where(x => x.Length > 0)
            .Distinct()
            .ToList();

        if (ulkeler.Count > 1)
            return null;

        // Ana takım yalnızca TheSportsDB'den gelen pozitif HariciTakimId
        // taşıyan kayıt olabilir. Negatif/geçici veya NULL kayıt hiçbir zaman
        // canonical seçilmez.
        var theSportsDbAdaylari = takimlar
            .Where(x => x.HariciTakimId.HasValue && x.HariciTakimId.Value > 0)
            .ToList();

        if (theSportsDbAdaylari.Count == 0)
            return null;

        // Aynı normalize grupta birden fazla farklı pozitif TheSportsDB ID
        // varsa otomatik birleştirmek güvenli değildir.
        if (theSportsDbAdaylari
            .Select(x => x.HariciTakimId!.Value)
            .Distinct()
            .Count() > 1)
        {
            return null;
        }

        var ana = theSportsDbAdaylari
            .OrderByDescending(x => macSayilari.GetValueOrDefault(x.Id))
            .ThenBy(x => x.Ad.Length)
            .First();

        var diger = takimlar
            .Where(x => x.Id != ana.Id)
            .ToList();

        if (diger.Count == 0)
            return null;

        return new TeamMergeCandidateDto
        {
            NormalizeAnahtari = NormalizeKulupAdi(ana.Ad),
            AnaTakimId = ana.Id,
            AnaTakimAdi = ana.Ad,
            AnaTakimMacSayisi = macSayilari.GetValueOrDefault(ana.Id),
            BirlesecekTakimlar = diger
                .Select(x => new TeamMergeMemberDto
                {
                    TakimId = x.Id,
                    TakimAdi = x.Ad,
                    HariciTakimId = x.HariciTakimId,
                    LigId = x.LigId,
                    Ulke = x.Ulke,
                    MacSayisi = macSayilari.GetValueOrDefault(x.Id)
                })
                .ToList()
        };
    }

    private static TakimEslesmeBilgisi TakimBilgisiOlustur(Takim takim)
    {
        var basit = NormalizeBasit(takim.Ad);
        var anahtar = NormalizeKulupAdi(takim.Ad);

        if (BilinenAliaslar.TryGetValue(basit, out var alias))
            anahtar = alias;

        return new TakimEslesmeBilgisi(
            anahtar,
            anahtar.Split(
                ' ',
                StringSplitOptions.RemoveEmptyEntries));
    }

    private static bool AyniKulupGuvenliMi(
        TakimEslesmeBilgisi sol,
        TakimEslesmeBilgisi sag)
    {
        if (sol.Anahtar == sag.Anahtar)
            return true;

        if (sol.Anahtar.Length < 4 || sag.Anahtar.Length < 4)
            return false;

        if (FarkliKulupIsaretiVar(sol, sag))
            return false;

        // Çok yüksek yazım benzerliği: Fenerbahce / Fenerbahçe vb.
        var benzerlik = BenzerlikOrani(sol.Anahtar, sag.Anahtar);

        if (benzerlik >= 0.94)
            return true;

        // Bir ad diğerini tamamen içeriyorsa yalnızca kalan kelimeler
        // zararsız kulüp/şehir ekleriyse birleştir.
        var kisa = sol.Anahtar.Length <= sag.Anahtar.Length ? sol : sag;
        var uzun = ReferenceEquals(kisa, sol) ? sag : sol;

        if (uzun.Anahtar.StartsWith(kisa.Anahtar + " ",
                StringComparison.OrdinalIgnoreCase))
        {
            var kalan = uzun.Anahtar[(kisa.Anahtar.Length + 1)..]
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);

            return kalan.All(x =>
                x is "istanbul" or "as" or "sk" or "fk" or "fc");
        }

        return false;
    }

    private static bool FarkliKulupIsaretiVar(
        TakimEslesmeBilgisi sol,
        TakimEslesmeBilgisi sag)
    {
        var fark = sol.Kelimeler
            .Except(sag.Kelimeler, StringComparer.OrdinalIgnoreCase)
            .Concat(sag.Kelimeler.Except(
                sol.Kelimeler,
                StringComparer.OrdinalIgnoreCase));

        return fark.Any(x => KorunacakFarkliKulupEkleri.Contains(x));
    }

    private static bool UlkelerUyumlu(Takim sol, Takim sag)
    {
        var solUlke = NormalizeBasit(sol.Ulke ?? string.Empty);
        var sagUlke = NormalizeBasit(sag.Ulke ?? string.Empty);

        return solUlke.Length == 0 ||
               sagUlke.Length == 0 ||
               solUlke == sagUlke;
    }

    private static void BirlikteBirlestir(
        UnionFind union,
        IEnumerable<int> ids)
    {
        var liste = ids.ToList();

        if (liste.Count < 2)
            return;

        for (var i = 1; i < liste.Count; i++)
            union.Union(liste[0], liste[i]);
    }

    private static string NormalizeKulupAdi(string value)
    {
        var basit = NormalizeBasit(value);

        if (BilinenAliaslar.TryGetValue(basit, out var alias))
            return alias;

        var sonuc = basit;

        foreach (var ek in KulupEkleri.OrderByDescending(x => x.Length))
        {
            sonuc = Regex.Replace(
                sonuc,
                $@"\b{Regex.Escape(ek)}\b",
                " ");
        }

        sonuc = Regex.Replace(
            sonuc,
            @"\b(istanbul|anonim sirketi|as|a s)\b$",
            " ");

        sonuc = Regex.Replace(sonuc, @"\s+", " ").Trim();

        return BilinenAliaslar.TryGetValue(sonuc, out alias)
            ? alias
            : sonuc;
    }

    private static string NormalizeBasit(string value)
    {
        var d = (value ?? string.Empty)
            .ToLowerInvariant()
            .Replace('ı', 'i')
            .Normalize(NormalizationForm.FormD);

        var sb = new StringBuilder();

        foreach (var c in d)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) ==
                UnicodeCategory.NonSpacingMark)
            {
                continue;
            }

            sb.Append(char.IsLetterOrDigit(c) ? c : ' ');
        }

        return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
    }

    private static double BenzerlikOrani(string left, string right)
    {
        if (left == right)
            return 1;

        var distance = Levenshtein(left, right);
        var max = Math.Max(left.Length, right.Length);

        return max == 0 ? 1 : 1d - ((double)distance / max);
    }

    private static int Levenshtein(string left, string right)
    {
        var previous = new int[right.Length + 1];
        var current = new int[right.Length + 1];

        for (var j = 0; j <= right.Length; j++)
            previous[j] = j;

        for (var i = 1; i <= left.Length; i++)
        {
            current[0] = i;

            for (var j = 1; j <= right.Length; j++)
            {
                var cost = left[i - 1] == right[j - 1] ? 0 : 1;

                current[j] = Math.Min(
                    Math.Min(current[j - 1] + 1, previous[j] + 1),
                    previous[j - 1] + cost);
            }

            (previous, current) = (current, previous);
        }

        return previous[right.Length];
    }

    private sealed record TakimEslesmeBilgisi(
        string Anahtar,
        string[] Kelimeler);

    private sealed class UnionFind
    {
        private readonly Dictionary<int, int> _parent;

        public UnionFind(IEnumerable<int> ids)
        {
            _parent = ids.ToDictionary(x => x, x => x);
        }

        public int Find(int id)
        {
            if (_parent[id] != id)
                _parent[id] = Find(_parent[id]);

            return _parent[id];
        }

        public void Union(int left, int right)
        {
            var leftRoot = Find(left);
            var rightRoot = Find(right);

            if (leftRoot != rightRoot)
                _parent[rightRoot] = leftRoot;
        }

        public IEnumerable<List<int>> Gruplar()
        {
            return _parent.Keys
                .GroupBy(Find)
                .Select(g => g.ToList());
        }
    }
}
