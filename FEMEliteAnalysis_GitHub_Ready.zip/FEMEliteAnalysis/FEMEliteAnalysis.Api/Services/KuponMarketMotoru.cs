using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Dtos.Mac;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class KuponMarketMotoru : IKuponMarketMotoru
{
    public KuponMarketAnaliziDto AnalizEt(
        MacKuponVerisiDto veri)
    {
        ArgumentNullException.ThrowIfNull(veri);

        var marketler = new List<KuponMarketSkoruDto>
        {
            MacSonucuEvSahibi(veri),
            MacSonucuBeraberlik(veri),
            MacSonucuDeplasman(veri),

            CifteSans1X(veri),
            CifteSansX2(veri),
            CifteSans12(veri),

            BirBucukUst(veri),
            IkiBucukUst(veri),
            IkiBucukAlt(veri),
            UcBucukUst(veri),
            GolAlt(veri, 3.5m),
            GolAlt(veri, 4.5m),
            GolUst(veri, 4.5m),
            GolUst(veri, 5.5m),
            GolUst(veri, 6.5m),

            KarsilikliGolVar(veri),
            KarsilikliGolYok(veri),

            IlkYariYarimUst(veri),
            IlkYariYarimAlt(veri),
            IlkYariBirBucukUst(veri),
            IlkYariBirBucukAlt(veri),
            IlkYariIkiBucukUst(veri),
            IlkYariIkiBucukAlt(veri),
            IlkYariKgVar(veri),
            IlkYariKgYok(veri),
            IlkYariEvSahibi(veri),
            IlkYariBeraberlik(veri),
            IlkYariDeplasman(veri),

            IkinciYariGol(veri, 0.5m, true),
            IkinciYariGol(veri, 0.5m, false),
            IkinciYariGol(veri, 1.5m, true),
            IkinciYariGol(veri, 1.5m, false),
            IkinciYariKg(veri, true),
            IkinciYariKg(veri, false),
            IkinciYariSonuc(veri, 1, "2Y 1", "İkinci Yarı Ev Sahibi"),
            IkinciYariSonuc(veri, 0, "2Y X", "İkinci Yarı Beraberlik"),
            IkinciYariSonuc(veri, 2, "2Y 2", "İkinci Yarı Deplasman"),

            ToplamGolAralik(veri, 0, 1, "TG 0-1"),
            ToplamGolAralik(veri, 2, 3, "TG 2-3"),
            ToplamGolAralik(veri, 4, 5, "TG 4-5"),
            ToplamGolAralik(veri, 6, 99, "TG 6+", true),
            ToplamGolTekCift(veri, true),
            ToplamGolTekCift(veri, false),

            IyMs(veri, 1, 1, "1/1"),
            IyMs(veri, 1, 0, "1/X", true),
            IyMs(veri, 1, 2, "1/2", true),
            IyMs(veri, 0, 1, "X/1", true),
            IyMs(veri, 0, 0, "X/X"),
            IyMs(veri, 0, 2, "X/2", true),
            IyMs(veri, 2, 1, "2/1", true),
            IyMs(veri, 2, 0, "2/X", true),
            IyMs(veri, 2, 2, "2/2"),

            TakimGol(veri, true, 1),
            TakimGol(veri, true, 2),
            TakimGol(veri, true, 3),
            TakimGol(veri, false, 1),
            TakimGol(veri, false, 2),
            TakimGol(veri, false, 3),
            TakimGolAlt(veri, true, 1.5m),
            TakimGolAlt(veri, true, 2.5m),
            TakimGolAlt(veri, false, 1.5m),
            TakimGolAlt(veri, false, 2.5m),

            // V4.6: İddaa tipi birleşik marketler.
            // Güven puanı artık iki ayrı market puanının ortalamasından değil,
            // aynı senaryonun iç/dış saha geçmişinde GERÇEKTEN birlikte gerçekleşmesinden hesaplanır.
            KombineRolBazli(veri, "MS1 + 1.5 ÜST", x => x.MacSonucu == 1 && ToplamGol(x) > 1.5m),
            KombineRolBazli(veri, "MS1 + 2.5 ÜST", x => x.MacSonucu == 1 && ToplamGol(x) > 2.5m),
            KombineRolBazli(veri, "MS1 + 2.5 ALT", x => x.MacSonucu == 1 && ToplamGol(x) < 2.5m),
            KombineRolBazli(veri, "MS1 + 3.5 ALT", x => x.MacSonucu == 1 && ToplamGol(x) < 3.5m),
            KombineRolBazli(veri, "MS1 + 4.5 ALT", x => x.MacSonucu == 1 && ToplamGol(x) < 4.5m),

            KombineRolBazli(veri, "MS2 + 1.5 ÜST", x => x.MacSonucu == 2 && ToplamGol(x) > 1.5m),
            KombineRolBazli(veri, "MS2 + 2.5 ÜST", x => x.MacSonucu == 2 && ToplamGol(x) > 2.5m),
            KombineRolBazli(veri, "MS2 + 2.5 ALT", x => x.MacSonucu == 2 && ToplamGol(x) < 2.5m),
            KombineRolBazli(veri, "MS2 + 3.5 ALT", x => x.MacSonucu == 2 && ToplamGol(x) < 3.5m),
            KombineRolBazli(veri, "MS2 + 4.5 ALT", x => x.MacSonucu == 2 && ToplamGol(x) < 4.5m),

            KombineRolBazli(veri, "MS1 + KG VAR", x => x.MacSonucu == 1 && x.KarsilikliGolVarMi),
            KombineRolBazli(veri, "MS1 + KG YOK", x => x.MacSonucu == 1 && !x.KarsilikliGolVarMi),
            KombineRolBazli(veri, "MS2 + KG VAR", x => x.MacSonucu == 2 && x.KarsilikliGolVarMi),
            KombineRolBazli(veri, "MS2 + KG YOK", x => x.MacSonucu == 2 && !x.KarsilikliGolVarMi),

            KombineRolBazli(veri, "X + KG VAR", x => x.MacSonucu == 0 && x.KarsilikliGolVarMi, surprizMi: true),
            KombineRolBazli(veri, "X + KG YOK", x => x.MacSonucu == 0 && !x.KarsilikliGolVarMi, surprizMi: true),
            KombineRolBazli(veri, "X + 1.5 ÜST", x => x.MacSonucu == 0 && ToplamGol(x) > 1.5m, surprizMi: true),
            KombineRolBazli(veri, "X + 2.5 ÜST", x => x.MacSonucu == 0 && ToplamGol(x) > 2.5m, surprizMi: true),
            KombineRolBazli(veri, "X + 3.5 ALT", x => x.MacSonucu == 0 && ToplamGol(x) < 3.5m, surprizMi: true),
            KombineRolBazli(veri, "X + 4.5 ALT", x => x.MacSonucu == 0 && ToplamGol(x) < 4.5m, surprizMi: true),

            KombineRolBazli(veri, "1X + 1.5 ÜST", x => x.MacSonucu != 2 && ToplamGol(x) > 1.5m),
            KombineRolBazli(veri, "1X + 2.5 ÜST", x => x.MacSonucu != 2 && ToplamGol(x) > 2.5m),
            KombineRolBazli(veri, "1X + 3.5 ALT", x => x.MacSonucu != 2 && ToplamGol(x) < 3.5m),
            KombineRolBazli(veri, "X2 + 1.5 ÜST", x => x.MacSonucu != 1 && ToplamGol(x) > 1.5m),
            KombineRolBazli(veri, "X2 + 2.5 ÜST", x => x.MacSonucu != 1 && ToplamGol(x) > 2.5m),
            KombineRolBazli(veri, "X2 + 3.5 ALT", x => x.MacSonucu != 1 && ToplamGol(x) < 3.5m),

            KombineRolBazli(veri, "KG VAR + 2.5 ÜST", x => x.KarsilikliGolVarMi && ToplamGol(x) > 2.5m),
            KombineRolBazli(veri, "KG YOK + 3.5 ALT", x => !x.KarsilikliGolVarMi && ToplamGol(x) < 3.5m),

            IlkYariKombine(veri, "İY1 + 0.5 ÜST", 1, 0.5m, true),
            IlkYariKombine(veri, "İY1 + 1.5 ÜST", 1, 1.5m, true),
            IlkYariKombine(veri, "İY1 + 1.5 ALT", 1, 1.5m, false),
            IlkYariKombine(veri, "İY X + 1.5 ALT", 0, 1.5m, false),
            IlkYariKombine(veri, "İY X + 1.5 ÜST", 0, 1.5m, true, surprizMi: true),
            IlkYariKombine(veri, "İY2 + 0.5 ÜST", 2, 0.5m, true),
            IlkYariKombine(veri, "İY2 + 1.5 ÜST", 2, 1.5m, true),
            IlkYariKombine(veri, "İY2 + 1.5 ALT", 2, 1.5m, false),

            KornerAlt(veri, 6.5m), KornerUst(veri, 6.5m),
            KornerAlt(veri, 7.5m), KornerUst(veri, 7.5m),
            KornerAlt(veri, 8.5m), KornerUst(veri, 8.5m),
            KornerAlt(veri, 9.5m), KornerUst(veri, 9.5m),
            KornerAlt(veri, 10.5m), KornerUst(veri, 10.5m),
            KornerAlt(veri, 11.5m), KornerUst(veri, 11.5m),
            KornerAlt(veri, 12.5m), KornerUst(veri, 12.5m),
            TakimKorner(veri, true, 2.5m, true), TakimKorner(veri, true, 2.5m, false),
            TakimKorner(veri, true, 3.5m, true), TakimKorner(veri, true, 3.5m, false),
            TakimKorner(veri, true, 4.5m, true), TakimKorner(veri, true, 4.5m, false),
            TakimKorner(veri, true, 5.5m, true), TakimKorner(veri, true, 5.5m, false),
            TakimKorner(veri, true, 6.5m, true), TakimKorner(veri, true, 6.5m, false),
            TakimKorner(veri, false, 2.5m, true), TakimKorner(veri, false, 2.5m, false),
            TakimKorner(veri, false, 3.5m, true), TakimKorner(veri, false, 3.5m, false),
            TakimKorner(veri, false, 4.5m, true), TakimKorner(veri, false, 4.5m, false),
            TakimKorner(veri, false, 5.5m, true), TakimKorner(veri, false, 5.5m, false),
            TakimKorner(veri, false, 6.5m, true), TakimKorner(veri, false, 6.5m, false),
            KartAlt(veri, 2.5m),
            KartUst(veri, 2.5m),
            KartAlt(veri, 3.5m),
            KartUst(veri, 3.5m),
            KartAlt(veri, 4.5m),
            KartUst(veri, 4.5m),
            KartAlt(veri, 5.5m),
            KartUst(veri, 5.5m)
        };

        foreach (var market in marketler)
        {
            // V4.2: her market kendi veri yeterliliğiyle düzeltilir.
            // Korner verisi eksik diye gol/MS tahmini cezalandırılmaz; aynı şekilde
            // güçlü genel form, zayıf korner örneklemini yapay biçimde yükseltmez.
            var marketVeriKalitesi = MarketVeriKalitesiSec(veri, market);

            market.GuvenPuani = VeriKalitesineGoreDuzelt(
                market.GuvenPuani,
                marketVeriKalitesi);

            market.RiskSeviyesi = RiskBelirle(
                market.GuvenPuani);

            var minimumVeriKalitesi = market.Kategori switch
            {
                "Korner" => 40,
                "Kart" => 40,
                _ => 60
            };

            market.OneriliyorMu =
                marketVeriKalitesi >= minimumVeriKalitesi &&
                market.GuvenPuani >= (market.SurprizMi ? 52 : 68) &&
                !DusukOranProfilMi(market.Kod);

            market.UzakDurMu =
                marketVeriKalitesi < 30 ||
                market.GuvenPuani <= 42;
        }

        var enGucluAdaylar = marketler
            .Where(x => x.OneriliyorMu)
            .OrderByDescending(x => x.GuvenPuani +
                (x.Kategori.Equals("Kombine", StringComparison.OrdinalIgnoreCase) ? 6 : 0))
            .Take(3)
            .ToList();

        var uzakDurulacaklar = marketler
            .Where(x => x.UzakDurMu)
            .OrderBy(x => x.GuvenPuani)
            .Take(3)
            .ToList();

        return new KuponMarketAnaliziDto
        {
            MacId = veri.MacId,
            EvSahibi = veri.EvSahibi,
            Deplasman = veri.Deplasman,
            VeriKalitesiPuani = veri.VeriKalitesiPuani,
            GenelRiskSeviyesi = GenelRiskBelirle(
                veri.VeriKalitesiPuani,
                enGucluAdaylar),
            Marketler = marketler
                .OrderByDescending(x => x.GuvenPuani)
                .ToList(),
            EnGucluAdaylar = enGucluAdaylar,
            UzakDurulacaklar = uzakDurulacaklar,
            VeriEksikleri = veri.VeriEksikleri
        };
    }

    private static KuponMarketSkoruDto MacSonucuEvSahibi(
        MacKuponVerisiDto veri)
    {
        var puan = 50;

        var evGenel = FormPuani(
            veri.EvSahibiGenelForm);

        var evIc = FormPuani(
            veri.EvSahibiIcSahaForm);

        var depGenel = FormPuani(
            veri.DeplasmanGenelForm);

        var depDis = FormPuani(
            veri.DeplasmanDisSahaForm);

        var fark =
            (evGenel * 0.35m + evIc * 0.65m) -
            (depGenel * 0.35m + depDis * 0.65m);

        puan += (int)Math.Round(
            Math.Clamp(fark * 6m, -25m, 25m));

        puan += 5;

        var gerekceler = new List<string>
        {
            $"Ev sahibi genel form: {FormMetni(veri.EvSahibiGenelForm)}",
            $"Ev sahibi iç saha formu: {FormMetni(veri.EvSahibiIcSahaForm)}",
            $"Deplasman dış saha formu: {FormMetni(veri.DeplasmanDisSahaForm)}"
        };

        if (veri.H2H.ToplamMac > 0)
        {
            puan += (veri.H2H.Takim1Galibiyet -
                     veri.H2H.Takim2Galibiyet) * 2;

            gerekceler.Add(
                $"H2H: {veri.EvSahibi} {veri.H2H.Takim1Galibiyet} galibiyet, " +
                $"{veri.Deplasman} {veri.H2H.Takim2Galibiyet} galibiyet.");
        }

        return Market(
            "MS1",
            "Maç Sonucu Ev Sahibi",
            puan,
            gerekceler);
    }

    private static KuponMarketSkoruDto MacSonucuBeraberlik(
        MacKuponVerisiDto veri)
    {
        var puan = 42;

        var ev = veri.EvSahibiGenelForm;
        var dep = veri.DeplasmanGenelForm;

        var formFarki = Math.Abs(
            FormPuani(ev) -
            FormPuani(dep));

        if (formFarki <= 0.35m)
            puan += 12;
        else if (formFarki <= 0.75m)
            puan += 6;
        else
            puan -= 8;

        var toplamGolOrtalamasi =
            ev.MacBasinaGol +
            dep.MacBasinaGol;

        if (toplamGolOrtalamasi < 2.1m)
            puan += 8;

        if (veri.H2H.ToplamMac > 0)
        {
            puan += (int)Math.Round(
                veri.H2H.Beraberlik /
                (decimal)veri.H2H.ToplamMac * 20m);
        }

        return Market(
            "MSX",
            "Maç Sonucu Beraberlik",
            puan,
            new[]
            {
                "Takımların form farkı beraberlik ihtimali için karşılaştırıldı.",
                $"Toplam gol üretim ortalaması: {toplamGolOrtalamasi:0.00}",
                $"H2H beraberlik sayısı: {veri.H2H.Beraberlik}"
            });
    }

    private static KuponMarketSkoruDto MacSonucuDeplasman(
        MacKuponVerisiDto veri)
    {
        var puan = 45;

        var evGenel = FormPuani(
            veri.EvSahibiGenelForm);

        var evIc = FormPuani(
            veri.EvSahibiIcSahaForm);

        var depGenel = FormPuani(
            veri.DeplasmanGenelForm);

        var depDis = FormPuani(
            veri.DeplasmanDisSahaForm);

        var fark =
            (depGenel * 0.35m + depDis * 0.65m) -
            (evGenel * 0.35m + evIc * 0.65m);

        puan += (int)Math.Round(
            Math.Clamp(fark * 6m, -25m, 25m));

        puan -= 4;

        if (veri.H2H.ToplamMac > 0)
        {
            puan += (veri.H2H.Takim2Galibiyet -
                     veri.H2H.Takim1Galibiyet) * 2;
        }

        return Market(
            "MS2",
            "Maç Sonucu Deplasman",
            puan,
            new[]
            {
                $"Deplasman genel formu: {FormMetni(veri.DeplasmanGenelForm)}",
                $"Deplasman dış saha formu: {FormMetni(veri.DeplasmanDisSahaForm)}",
                "Standart ev sahibi avantajı deplasman puanından düşürüldü."
            });
    }

    private static KuponMarketSkoruDto CifteSans1X(
        MacKuponVerisiDto veri)
    {
        var ms1 = MacSonucuEvSahibi(veri).GuvenPuani;
        var msx = MacSonucuBeraberlik(veri).GuvenPuani;

        var puan = Math.Clamp(
            Math.Max(ms1, msx) +
            Math.Min(ms1, msx) / 3,
            0,
            96);

        return Market(
            "1X",
            "Çifte Şans 1X",
            puan,
            new[]
            {
                "Ev sahibi kazanma ve beraberlik ihtimalleri birlikte değerlendirildi.",
                "Ev sahibi saha avantajı hesaba katıldı."
            });
    }

    private static KuponMarketSkoruDto CifteSansX2(
        MacKuponVerisiDto veri)
    {
        var ms2 = MacSonucuDeplasman(veri).GuvenPuani;
        var msx = MacSonucuBeraberlik(veri).GuvenPuani;

        var puan = Math.Clamp(
            Math.Max(ms2, msx) +
            Math.Min(ms2, msx) / 3,
            0,
            94);

        return Market(
            "X2",
            "Çifte Şans X2",
            puan,
            new[]
            {
                "Deplasman kazanma ve beraberlik ihtimalleri birlikte değerlendirildi.",
                "Deplasman dış saha performansı belirleyici olarak kullanıldı."
            });
    }

    private static KuponMarketSkoruDto CifteSans12(
        MacKuponVerisiDto veri)
    {
        var beraberlik = MacSonucuBeraberlik(veri).GuvenPuani;

        var puan = Math.Clamp(
            100 - beraberlik + 10,
            0,
            92);

        return Market(
            "12",
            "Çifte Şans 12",
            puan,
            new[]
            {
                "Beraberlik ihtimalinin ters puanı kullanıldı.",
                "Gol eğilimleri maçın kazanan üretme ihtimalini etkiledi."
            });
    }

    private static KuponMarketSkoruDto BirBucukUst(
        MacKuponVerisiDto veri)
    {
        var oran = Ortalama(
            veri.EvSahibiGenelForm.BirBucukUstYuzdesi,
            veri.EvSahibiIcSahaForm.BirBucukUstYuzdesi,
            veri.DeplasmanGenelForm.BirBucukUstYuzdesi,
            veri.DeplasmanDisSahaForm.BirBucukUstYuzdesi,
            veri.H2H.BirBucukUstYuzdesi);

        var puan = (int)Math.Round(
            oran * 0.82m + 12m);

        return Market(
            "1.5 ÜST",
            "Toplam Gol 1.5 Üst",
            puan,
            new[]
            {
                $"Birleşik 1.5 üst eğilimi: %{oran:0.00}",
                $"H2H 1.5 üst oranı: %{veri.H2H.BirBucukUstYuzdesi:0.00}"
            });
    }

    private static KuponMarketSkoruDto IkiBucukUst(
        MacKuponVerisiDto veri)
    {
        var oran = Ortalama(
            veri.EvSahibiGenelForm.IkiBucukUstYuzdesi,
            veri.EvSahibiIcSahaForm.IkiBucukUstYuzdesi,
            veri.DeplasmanGenelForm.IkiBucukUstYuzdesi,
            veri.DeplasmanDisSahaForm.IkiBucukUstYuzdesi,
            veri.H2H.IkiBucukUstYuzdesi);

        var golOrtalamasi =
            Ortalama(
                veri.EvSahibiGenelForm.MacBasinaGol,
                veri.EvSahibiIcSahaForm.MacBasinaGol,
                veri.DeplasmanGenelForm.MacBasinaGol,
                veri.DeplasmanDisSahaForm.MacBasinaGol);

        var puan = (int)Math.Round(
            oran * 0.72m +
            Math.Min(golOrtalamasi * 7m, 18m));

        return Market(
            "2.5 ÜST",
            "Toplam Gol 2.5 Üst",
            puan,
            new[]
            {
                $"Birleşik 2.5 üst eğilimi: %{oran:0.00}",
                $"Takımların ortalama gol üretimi: {golOrtalamasi:0.00}"
            });
    }

    private static KuponMarketSkoruDto IkiBucukAlt(
        MacKuponVerisiDto veri)
    {
        var ust = IkiBucukUst(veri).GuvenPuani;

        return Market(
            "2.5 ALT",
            "Toplam Gol 2.5 Alt",
            Math.Clamp(100 - ust + 8, 0, 94),
            new[]
            {
                "2.5 üst puanının ters eğilimi kullanıldı.",
                "Düşük gol ortalamaları alt marketini destekler."
            });
    }

    private static KuponMarketSkoruDto UcBucukUst(
        MacKuponVerisiDto veri)
    {
        var oran = Ortalama(
            veri.EvSahibiGenelForm.UcBucukUstYuzdesi,
            veri.EvSahibiIcSahaForm.UcBucukUstYuzdesi,
            veri.DeplasmanGenelForm.UcBucukUstYuzdesi,
            veri.DeplasmanDisSahaForm.UcBucukUstYuzdesi,
            veri.H2H.UcBucukUstYuzdesi);

        return Market(
            "3.5 ÜST",
            "Toplam Gol 3.5 Üst",
            (int)Math.Round(oran * 0.9m),
            new[]
            {
                $"Birleşik 3.5 üst eğilimi: %{oran:0.00}",
                "Yüksek skorlu maç geçmişi esas alındı."
            });
    }

    private static KuponMarketSkoruDto GolAlt(
        MacKuponVerisiDto veri,
        decimal esik)
    {
        var maclar = veri.EvSahibiGenelForm.Maclar
            .Concat(veri.EvSahibiIcSahaForm.Maclar)
            .Concat(veri.DeplasmanGenelForm.Maclar)
            .Concat(veri.DeplasmanDisSahaForm.Maclar)
            .GroupBy(x => x.MacId)
            .Select(x => x.First())
            .ToList();

        var altAdet = maclar.Count(x =>
            x.EvSahibiGol + x.DeplasmanGol < esik);

        var oran = Yuzde(altAdet, maclar.Count);
        var puan = (int)Math.Round(
            oran * 0.88m +
            (esik >= 4.5m ? 8m : 3m));

        return Market(
            $"{esik:0.0} ALT",
            $"Toplam Gol {esik:0.0} Alt",
            puan,
            new[]
            {
                $"Geçmiş maçlarda {altAdet}/{maclar.Count} kez {esik:0.0} alt (%{oran:0.##}).",
                $"Örneklem: {maclar.Count} maç."
            },
            "Gol",
            orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto GolUst(
        MacKuponVerisiDto veri,
        decimal esik)
    {
        var maclar = veri.EvSahibiGenelForm.Maclar
            .Concat(veri.EvSahibiIcSahaForm.Maclar)
            .Concat(veri.DeplasmanGenelForm.Maclar)
            .Concat(veri.DeplasmanDisSahaForm.Maclar)
            .GroupBy(x => x.MacId)
            .Select(x => x.First())
            .ToList();

        var ustAdet = maclar.Count(x =>
            x.EvSahibiGol + x.DeplasmanGol > esik);

        var oran = Yuzde(ustAdet, maclar.Count);
        var taban = esik switch
        {
            >= 6.5m => 18m,
            >= 5.5m => 14m,
            _ => 8m
        };

        var puan = (int)Math.Round(oran * 1.10m + taban);

        return Market(
            $"{esik:0.0} ÜST",
            $"Toplam Gol {esik:0.0} Üst",
            puan,
            new[]
            {
                $"Geçmiş maçlarda {ustAdet}/{maclar.Count} kez {esik:0.0} üst (%{oran:0.##}).",
                "Yüksek oranlı gol senaryosudur; düşük tutarla değerlendirilmelidir."
            },
            "Gol",
            surprizMi: esik >= 4.5m,
            orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto KarsilikliGolVar(
        MacKuponVerisiDto veri)
    {
        var oran = Ortalama(
            veri.EvSahibiGenelForm.KarsilikliGolYuzdesi,
            veri.EvSahibiIcSahaForm.KarsilikliGolYuzdesi,
            veri.DeplasmanGenelForm.KarsilikliGolYuzdesi,
            veri.DeplasmanDisSahaForm.KarsilikliGolYuzdesi,
            veri.H2H.KarsilikliGolYuzdesi);

        var ikiTakimGolOrt =
            veri.EvSahibiIcSahaForm.MacBasinaGol +
            veri.DeplasmanDisSahaForm.MacBasinaGol;

        var puan = (int)Math.Round(
            oran * 0.78m +
            Math.Min(ikiTakimGolOrt * 5m, 15m));

        return Market(
            "KG VAR",
            "Karşılıklı Gol Var",
            puan,
            new[]
            {
                $"Birleşik KG Var eğilimi: %{oran:0.00}",
                $"Ev iç saha + deplasman dış saha gol ortalaması: {ikiTakimGolOrt:0.00}"
            });
    }

    private static KuponMarketSkoruDto KarsilikliGolYok(
        MacKuponVerisiDto veri)
    {
        var kgVar = KarsilikliGolVar(veri).GuvenPuani;

        var cleanSheet = Ortalama(
            veri.EvSahibiIcSahaForm.GolYemedenBitirmeYuzdesi,
            veri.DeplasmanDisSahaForm.GolYemedenBitirmeYuzdesi);

        var puan = Math.Clamp(
            100 - kgVar +
            (int)Math.Round(cleanSheet * 0.15m),
            0,
            94);

        return Market(
            "KG YOK",
            "Karşılıklı Gol Yok",
            puan,
            new[]
            {
                "KG Var puanının ters eğilimi kullanıldı.",
                $"Birleşik clean sheet oranı: %{cleanSheet:0.00}"
            });
    }

    private static KuponMarketSkoruDto IlkYariYarimUst(
        MacKuponVerisiDto veri)
    {
        var oran = Ortalama(
            veri.EvSahibiGenelForm.IlkYariGolYuzdesi,
            veri.EvSahibiIcSahaForm.IlkYariGolYuzdesi,
            veri.DeplasmanGenelForm.IlkYariGolYuzdesi,
            veri.DeplasmanDisSahaForm.IlkYariGolYuzdesi,
            veri.H2H.IlkYariGolYuzdesi);

        return Market(
            "İY 0.5 ÜST",
            "İlk Yarı 0.5 Üst",
            (int)Math.Round(oran * 0.88m + 7m),
            new[]
            {
                $"Birleşik ilk yarı gol eğilimi: %{oran:0.00}",
                "Son maçlar ve H2H ilk yarı skorları değerlendirildi."
            });
    }

    private static KuponMarketSkoruDto IlkYariYarimAlt(MacKuponVerisiDto veri)
    {
        var ust = IlkYariYarimUst(veri).GuvenPuani;
        return Market("İY 0.5 ALT", "İlk Yarı 0.5 Alt", Math.Clamp(100 - ust + 3, 0, 94),
            new[] { "İlk yarıda gol çıkmama eğilimi, İY 0.5 Üst modelinin tersiyle hesaplandı." }, "İlk Yarı");
    }

    private static KuponMarketSkoruDto IlkYariBirBucukUst(MacKuponVerisiDto veri)
    {
        var oran = Ortalama(
            veri.EvSahibiGenelForm.IlkYariBirBucukUstYuzdesi,
            veri.EvSahibiIcSahaForm.IlkYariBirBucukUstYuzdesi,
            veri.DeplasmanGenelForm.IlkYariBirBucukUstYuzdesi,
            veri.DeplasmanDisSahaForm.IlkYariBirBucukUstYuzdesi);
        return Market("İY 1.5 ÜST", "İlk Yarı 1.5 Üst", (int)Math.Round(oran * .92m),
            new[] { $"Birleşik İY 1.5 üst oranı: %{oran:0.##}", "Yalnızca ilk yarı skoru bulunan maçlar değerlendirilir." }, "İlk Yarı");
    }

    private static KuponMarketSkoruDto IlkYariBirBucukAlt(MacKuponVerisiDto veri)
    {
        var ust = IlkYariBirBucukUst(veri).GuvenPuani;
        return Market("İY 1.5 ALT", "İlk Yarı 1.5 Alt", Math.Clamp(100 - ust + 5, 0, 94),
            new[] { "İY 1.5 üst eğiliminin tersi kullanıldı." }, "İlk Yarı");
    }

    private static KuponMarketSkoruDto IlkYariIkiBucukUst(MacKuponVerisiDto veri)
    {
        var maclar = TumFormMaclari(veri).Where(x => x.IlkYariEvSahibiGol.HasValue && x.IlkYariDeplasmanGol.HasValue).ToList();
        var adet = maclar.Count(x => (x.IlkYariEvSahibiGol ?? 0) + (x.IlkYariDeplasmanGol ?? 0) >= 3);
        var oran = Yuzde(adet, maclar.Count);
        return Market("İY 2.5 ÜST", "İlk Yarı 2.5 Üst", (int)Math.Round(oran * .96m),
            new[] { $"Geçmişte {adet}/{maclar.Count} maçta ilk yarıda 3+ gol (%{oran:0.##})." }, "İlk Yarı", surprizMi: true, orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto IlkYariIkiBucukAlt(MacKuponVerisiDto veri)
    {
        var ust = IlkYariIkiBucukUst(veri);
        return Market("İY 2.5 ALT", "İlk Yarı 2.5 Alt", Math.Clamp(100 - ust.GuvenPuani + 4, 0, 94),
            new[] { "İlk yarı 2.5 üst gerçekleşmelerinin tersi kullanıldı.", $"Örneklem: {ust.OrneklemSayisi} maç." }, "İlk Yarı", orneklem: ust.OrneklemSayisi);
    }

    private static KuponMarketSkoruDto IlkYariKgVar(MacKuponVerisiDto veri)
    {
        var oran = Ortalama(veri.EvSahibiGenelForm.IlkYariKarsilikliGolYuzdesi,
            veri.EvSahibiIcSahaForm.IlkYariKarsilikliGolYuzdesi,
            veri.DeplasmanGenelForm.IlkYariKarsilikliGolYuzdesi,
            veri.DeplasmanDisSahaForm.IlkYariKarsilikliGolYuzdesi);
        return Market("İY KG VAR", "İlk Yarı Karşılıklı Gol", (int)Math.Round(oran * .92m),
            new[] { $"Birleşik İY KG Var oranı: %{oran:0.##}" }, "İlk Yarı", surprizMi: true);
    }

    private static KuponMarketSkoruDto IlkYariKgYok(MacKuponVerisiDto veri)
    {
        var kg = IlkYariKgVar(veri);
        return Market("İY KG YOK", "İlk Yarı Karşılıklı Gol Yok", Math.Clamp(100 - kg.GuvenPuani + 3, 0, 94),
            new[] { "İlk yarı KG Var eğiliminin tersi kullanıldı." }, "İlk Yarı", orneklem: kg.OrneklemSayisi);
    }

    private static KuponMarketSkoruDto IlkYariEvSahibi(MacKuponVerisiDto veri) =>
        IlkYariSonuc(veri, 1, "İY 1", "İlk Yarı Ev Sahibi");
    private static KuponMarketSkoruDto IlkYariBeraberlik(MacKuponVerisiDto veri) =>
        IlkYariSonuc(veri, 0, "İY X", "İlk Yarı Beraberlik");
    private static KuponMarketSkoruDto IlkYariDeplasman(MacKuponVerisiDto veri) =>
        IlkYariSonuc(veri, 2, "İY 2", "İlk Yarı Deplasman");

    private static KuponMarketSkoruDto IlkYariSonuc(MacKuponVerisiDto veri, int sonuc, string kod, string ad)
    {
        var maclar = veri.EvSahibiIcSahaForm.Maclar.Concat(veri.DeplasmanDisSahaForm.Maclar).ToList();
        var oran = Yuzde(maclar.Count(x => x.IlkYariSonucu == sonuc), maclar.Count);
        return Market(kod, ad, (int)Math.Round(oran * .88m + 5),
            new[] { $"Saha odaklı geçmişte gerçekleşme: %{oran:0.##}", $"Örneklem: {maclar.Count} maç" }, "İlk Yarı", orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto IkinciYariGol(MacKuponVerisiDto veri, decimal esik, bool ust)
    {
        var maclar = TumFormMaclari(veri)
            .Where(x => x.IlkYariEvSahibiGol.HasValue && x.IlkYariDeplasmanGol.HasValue)
            .ToList();
        var adet = maclar.Count(x =>
        {
            var ikinciYari = (x.EvSahibiGol - (x.IlkYariEvSahibiGol ?? 0)) +
                             (x.DeplasmanGol - (x.IlkYariDeplasmanGol ?? 0));
            return ust ? ikinciYari > esik : ikinciYari < esik;
        });
        var oran = Yuzde(adet, maclar.Count);
        var kod = $"2Y {esik:0.0} {(ust ? "ÜST" : "ALT")}";
        return Market(kod, $"İkinci Yarı {esik:0.0} {(ust ? "Üst" : "Alt")}",
            (int)Math.Round(oran * .9m + 4),
            new[] { $"Geçmişte {adet}/{maclar.Count} kez gerçekleşti (%{oran:0.##})." },
            "İkinci Yarı", orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto IkinciYariKg(MacKuponVerisiDto veri, bool varMi)
    {
        var maclar = TumFormMaclari(veri)
            .Where(x => x.IlkYariEvSahibiGol.HasValue && x.IlkYariDeplasmanGol.HasValue)
            .ToList();
        var adet = maclar.Count(x =>
        {
            var ev2 = x.EvSahibiGol - (x.IlkYariEvSahibiGol ?? 0);
            var dep2 = x.DeplasmanGol - (x.IlkYariDeplasmanGol ?? 0);
            var kg = ev2 > 0 && dep2 > 0;
            return kg == varMi;
        });
        var oran = Yuzde(adet, maclar.Count);
        return Market(varMi ? "2Y KG VAR" : "2Y KG YOK",
            varMi ? "İkinci Yarı Karşılıklı Gol Var" : "İkinci Yarı Karşılıklı Gol Yok",
            (int)Math.Round(oran * .9m + 3),
            new[] { $"İkinci yarı KG senaryosu {adet}/{maclar.Count} maçta gerçekleşti (%{oran:0.##})." },
            "İkinci Yarı", surprizMi: varMi, orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto IkinciYariSonuc(MacKuponVerisiDto veri, int sonuc, string kod, string ad)
    {
        var maclar = TumFormMaclari(veri)
            .Where(x => x.IlkYariEvSahibiGol.HasValue && x.IlkYariDeplasmanGol.HasValue)
            .ToList();
        var adet = maclar.Count(x =>
        {
            var ev = x.EvSahibiGol - (x.IlkYariEvSahibiGol ?? 0);
            var dep = x.DeplasmanGol - (x.IlkYariDeplasmanGol ?? 0);
            var r = ev == dep ? 0 : ev > dep ? 1 : 2;
            return r == sonuc;
        });
        var oran = Yuzde(adet, maclar.Count);
        return Market(kod, ad, (int)Math.Round(oran * .88m + 5),
            new[] { $"İkinci yarı sonucu geçmişte {adet}/{maclar.Count} kez gerçekleşti (%{oran:0.##})." },
            "İkinci Yarı", orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto ToplamGolAralik(MacKuponVerisiDto veri, int min, int max, string kod, bool surpriz = false)
    {
        var maclar = TumFormMaclari(veri);
        var adet = maclar.Count(x =>
        {
            var toplam = x.EvSahibiGol + x.DeplasmanGol;
            return toplam >= min && toplam <= max;
        });
        var oran = Yuzde(adet, maclar.Count);
        return Market(kod, $"Toplam Gol {kod.Replace("TG ", string.Empty)}", (int)Math.Round(oran * 1.02m + 7),
            new[] { $"Geçmişte {adet}/{maclar.Count} maç bu gol aralığında bitti (%{oran:0.##})." },
            "Toplam Gol", surprizMi: surpriz, orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto ToplamGolTekCift(MacKuponVerisiDto veri, bool tek)
    {
        var maclar = TumFormMaclari(veri);
        var adet = maclar.Count(x => ((x.EvSahibiGol + x.DeplasmanGol) % 2 == 1) == tek);
        var oran = Yuzde(adet, maclar.Count);
        return Market(tek ? "TG TEK" : "TG ÇİFT", tek ? "Toplam Gol Tek" : "Toplam Gol Çift",
            (int)Math.Round(oran * .9m + 4),
            new[] { $"Geçmiş gerçekleşme: {adet}/{maclar.Count} (%{oran:0.##})." },
            "Toplam Gol", orneklem: maclar.Count);
    }

    private static KuponMarketSkoruDto IyMs(MacKuponVerisiDto veri, int iy, int ms, string kod, bool surpriz = false)
    {
        // Bugünkü roller korunur: ev sahibi yalnız iç saha, deplasman yalnız dış saha geçmişiyle ölçülür.
        // Böylece örneğin X/1 için ev takımının X->galibiyet ve deplasman takımının X->mağlubiyet profili aynı notasyonda karşılaştırılır.
        var evMaclar = veri.EvSahibiIcSahaForm.Maclar
            .Where(x => x.IlkYariEvSahibiGol.HasValue && x.IlkYariDeplasmanGol.HasValue)
            .Take(40).ToList();
        var depMaclar = veri.DeplasmanDisSahaForm.Maclar
            .Where(x => x.IlkYariEvSahibiGol.HasValue && x.IlkYariDeplasmanGol.HasValue)
            .Take(40).ToList();

        var evAdet = evMaclar.Count(x => x.IlkYariSonucu == iy && x.MacSonucu == ms);
        var depAdet = depMaclar.Count(x => x.IlkYariSonucu == iy && x.MacSonucu == ms);
        var evOran = Yuzde(evAdet, evMaclar.Count);
        var depOran = Yuzde(depAdet, depMaclar.Count);

        var ev10 = evMaclar.Take(10).ToList();
        var dep10 = depMaclar.Take(10).ToList();
        var ev10Oran = Yuzde(ev10.Count(x => x.IlkYariSonucu == iy && x.MacSonucu == ms), ev10.Count);
        var dep10Oran = Yuzde(dep10.Count(x => x.IlkYariSonucu == iy && x.MacSonucu == ms), dep10.Count);

        var uzun = evOran * .52m + depOran * .48m;
        var yakin = ev10Oran * .52m + dep10Oran * .48m;
        var uyumCezasi = Math.Abs(evOran - depOran) * .12m;
        var taban = surpriz ? 18m : 12m;
        var puan = (int)Math.Round((uzun * .70m + yakin * .30m - uyumCezasi) * (surpriz ? 1.12m : 1.02m) + taban);
        var orneklem = Math.Min(evMaclar.Count, depMaclar.Count);

        if (orneklem < 8)
            puan = Math.Min(puan, 34);

        return Market(kod, $"İlk Yarı / Maç Sonucu {kod}", puan,
            new[]
            {
                $"{veri.EvSahibi} iç saha: {evAdet}/{evMaclar.Count} (%{evOran:0.##})",
                $"{veri.Deplasman} dış saha: {depAdet}/{depMaclar.Count} (%{depOran:0.##})",
                $"Son 10 trendi: EV %{ev10Oran:0.##} | DEP %{dep10Oran:0.##}"
            },
            "İY/MS", surpriz, orneklem);
    }

    private static KuponMarketSkoruDto TakimGol(MacKuponVerisiDto veri, bool ev, int esik)
    {
        var form = ev ? veri.EvSahibiIcSahaForm : veri.DeplasmanDisSahaForm;
        var adet = form.Maclar.Count(x => (x.TakimEvSahibiMi ? x.EvSahibiGol : x.DeplasmanGol) >= esik);
        var oran = Yuzde(adet, form.Maclar.Count);
        var taraf = ev ? veri.EvSahibi : veri.Deplasman;
        return Market(ev ? $"EV {esik - .5:0.0} ÜST" : $"DEP {esik - .5:0.0} ÜST",
            $"{taraf} Takım Golü {esik - .5:0.0} Üst", (int)Math.Round(oran * .9m + 5),
            new[] { $"{taraf} ilgili saha maçlarında {adet}/{form.Maclar.Count} kez yaptı (%{oran:0.##})." },
            "Takım Golü", orneklem: form.Maclar.Count);
    }

    private static KuponMarketSkoruDto TakimGolAlt(MacKuponVerisiDto veri, bool ev, decimal esik)
    {
        var form = ev ? veri.EvSahibiIcSahaForm : veri.DeplasmanDisSahaForm;
        var adet = form.Maclar.Count(x => (x.TakimEvSahibiMi ? x.EvSahibiGol : x.DeplasmanGol) < esik);
        var oran = Yuzde(adet, form.Maclar.Count);
        var taraf = ev ? veri.EvSahibi : veri.Deplasman;
        return Market(ev ? $"EV {esik:0.0} ALT" : $"DEP {esik:0.0} ALT",
            $"{taraf} Takım Golü {esik:0.0} Alt", (int)Math.Round(oran * .9m + 4),
            new[] { $"{taraf} ilgili saha maçlarında {adet}/{form.Maclar.Count} kez {esik:0.0} altında kaldı (%{oran:0.##})." },
            "Takım Golü", orneklem: form.Maclar.Count);
    }

    private static KuponMarketSkoruDto KombineRolBazli(
        MacKuponVerisiDto veri,
        string kod,
        Func<TakimGecmisMacDto, bool> kosul,
        bool surprizMi = false)
    {
        var evMaclar = veri.EvSahibiIcSahaForm.Maclar
            .OrderByDescending(x => x.MacTarihi)
            .Take(20)
            .ToList();

        var depMaclar = veri.DeplasmanDisSahaForm.Maclar
            .OrderByDescending(x => x.MacTarihi)
            .Take(20)
            .ToList();

        if (evMaclar.Count == 0 || depMaclar.Count == 0)
            return Market(kod, kod, 0,
                new[] { "Birleşik market için iç/dış saha örneklemi yetersiz." },
                "Kombine", surprizMi, 0);

        var evAdet = evMaclar.Count(kosul);
        var depAdet = depMaclar.Count(kosul);
        var evOran = Yuzde(evAdet, evMaclar.Count);
        var depOran = Yuzde(depAdet, depMaclar.Count);

        var evSon10 = evMaclar.Take(10).ToList();
        var depSon10 = depMaclar.Take(10).ToList();
        var evSon10Oran = Yuzde(evSon10.Count(kosul), evSon10.Count);
        var depSon10Oran = Yuzde(depSon10.Count(kosul), depSon10.Count);

        var uzunDonem = evOran * .52m + depOran * .48m;
        var yakinTrend = evSon10Oran * .52m + depSon10Oran * .48m;
        var zayifTaraf = Math.Min(evOran, depOran);
        var ham = uzunDonem * .70m + yakinTrend * .30m;
        var uyumBonusu = Math.Max(0m, zayifTaraf - 40m) * .12m;
        var puan = (int)Math.Round(ham + uyumBonusu + 5m);

        var orneklem = Math.Min(evMaclar.Count, depMaclar.Count);
        if (orneklem < 8)
            puan = Math.Min(puan, 55);

        return Market(kod, kod, puan,
            new[]
            {
                $"{veri.EvSahibi} iç saha: {evAdet}/{evMaclar.Count} (%{evOran:0.##})",
                $"{veri.Deplasman} dış saha: {depAdet}/{depMaclar.Count} (%{depOran:0.##})",
                $"Son 10 trendi: EV %{evSon10Oran:0.##} | DEP %{depSon10Oran:0.##}",
                "Skor, birleşik senaryonun gerçek geçmiş maçlarda birlikte gerçekleşme sıklığından hesaplandı."
            },
            "Kombine", surprizMi, orneklem);
    }

    private static KuponMarketSkoruDto IlkYariKombine(
        MacKuponVerisiDto veri,
        string kod,
        int ilkYariSonucu,
        decimal golEsigi,
        bool ust,
        bool surprizMi = false)
    {
        return KombineRolBazli(veri, kod, x =>
        {
            if (!x.IlkYariEvSahibiGol.HasValue || !x.IlkYariDeplasmanGol.HasValue)
                return false;

            var iyGol = x.IlkYariEvSahibiGol.Value + x.IlkYariDeplasmanGol.Value;
            return x.IlkYariSonucu == ilkYariSonucu &&
                   (ust ? iyGol > golEsigi : iyGol < golEsigi);
        }, surprizMi);
    }

    private static decimal ToplamGol(TakimGecmisMacDto x) =>
        x.EvSahibiGol + x.DeplasmanGol;

    private static KuponMarketSkoruDto KornerAlt(MacKuponVerisiDto veri, decimal esik)
    {
        var ev = veri.EvSahibiIstatistik;
        var dep = veri.DeplasmanIstatistik;
        var toplamKayit = Math.Min(ev.KornerKayitSayisi, dep.KornerKayitSayisi);
        if (toplamKayit < 6)
            return Market($"{esik:0.0} KORNER ALT", $"Toplam Korner {esik:0.0} Alt", 0,
                new[] { "Korner örneklemi yetersiz." }, "Korner", orneklem: toplamKayit);

        var evBeklenen = BeklenenTakimKorner(ev, dep);
        var depBeklenen = BeklenenTakimKorner(dep, ev);
        var beklenen = evBeklenen + depBeklenen;
        var medyanToplam = ev.MedyanKorner + dep.MedyanKorner;
        var hit = SentetikToplamGerceklesme(ev.KornerDegerleri, dep.KornerDegerleri, esik, false);
        var mesafePuan = 50 + (int)Math.Round((esik - beklenen) * 10m);
        var puan = Math.Clamp((int)Math.Round(mesafePuan * .45m + hit * .55m), 0, 96);

        return Market($"{esik:0.0} KORNER ALT", $"Toplam Korner {esik:0.0} Alt", puan,
            new[]
            {
                $"Beklenen toplam korner: {beklenen:0.00} (EV {evBeklenen:0.00} + DEP {depBeklenen:0.00})",
                $"Ortalamalar: {veri.EvSahibi} {ev.OrtalamaKorner:0.00} | {veri.Deplasman} {dep.OrtalamaKorner:0.00}",
                $"Rakibe verilen: {veri.EvSahibi} {ev.OrtalamaRakipKorner:0.00} | {veri.Deplasman} {dep.OrtalamaRakipKorner:0.00}",
                $"Medyan toplam: {medyanToplam:0.00} | sentetik gerçekleşme: %{hit:0}"
            }, "Korner", orneklem: toplamKayit);
    }

    private static KuponMarketSkoruDto TakimKorner(MacKuponVerisiDto veri, bool evMi, decimal esik, bool ust)
    {
        var stat = evMi ? veri.EvSahibiIstatistik : veri.DeplasmanIstatistik;
        var rakip = evMi ? veri.DeplasmanIstatistik : veri.EvSahibiIstatistik;
        var taraf = evMi ? "EV" : "DEP";
        var takim = evMi ? veri.EvSahibi : veri.Deplasman;
        var rakipAdi = evMi ? veri.Deplasman : veri.EvSahibi;
        if (stat.KornerKayitSayisi < 5)
            return Market($"{taraf} KORNER {esik:0.0} {(ust ? "ÜST" : "ALT")}", $"{takim} Korner {esik:0.0} {(ust ? "Üst" : "Alt")}", 0,
                new[] { "Takım korner örneklemi yetersiz." }, "Korner", orneklem: stat.KornerKayitSayisi);

        var beklenen = BeklenenTakimKorner(stat, rakip);
        var kendiHit = Gerceklesme(stat.KornerDegerleri, esik, ust);
        var rakipVermeHit = Gerceklesme(rakip.RakipKornerDegerleri, esik, ust);
        var hit = rakip.RakipKornerDegerleri.Count >= 5
            ? kendiHit * .6m + rakipVermeHit * .4m
            : kendiHit;
        var mesafe = ust ? beklenen - esik : esik - beklenen;
        var mesafePuan = 50 + (int)Math.Round(mesafe * 11m);
        var puan = Math.Clamp((int)Math.Round(mesafePuan * .4m + hit * .6m), 0, 96);

        return Market($"{taraf} KORNER {esik:0.0} {(ust ? "ÜST" : "ALT")}", $"{takim} Korner {esik:0.0} {(ust ? "Üst" : "Alt")}", puan,
            new[]
            {
                $"İki takım korner ort.: {veri.EvSahibi} {veri.EvSahibiIstatistik.OrtalamaKorner:0.00} | {veri.Deplasman} {veri.DeplasmanIstatistik.OrtalamaKorner:0.00}",
                $"{takim} medyan: {stat.MedyanKorner:0.00} | son 5: {stat.Son5OrtalamaKorner:0.00} | {rakipAdi} rakibe verdiği: {rakip.OrtalamaRakipKorner:0.00}",
                $"Model beklenen takım korneri: {beklenen:0.00}",
                $"Gerçekleşme: takım %{kendiHit:0}" + (rakip.RakipKornerDegerleri.Count >= 5 ? $" | rakibin verme profili %{rakipVermeHit:0}" : string.Empty)
            }, "Korner", orneklem: stat.KornerKayitSayisi);
    }

    private static KuponMarketSkoruDto KornerUst(MacKuponVerisiDto veri, decimal esik)
    {
        var ev = veri.EvSahibiIstatistik;
        var dep = veri.DeplasmanIstatistik;
        var toplamKayit = Math.Min(ev.KornerKayitSayisi, dep.KornerKayitSayisi);
        if (toplamKayit < 6)
            return Market($"{esik:0.0} KORNER ÜST", $"Toplam Korner {esik:0.0} Üst", 0,
                new[] { "Korner örneklemi yetersiz." }, "Korner", orneklem: toplamKayit);

        var evBeklenen = BeklenenTakimKorner(ev, dep);
        var depBeklenen = BeklenenTakimKorner(dep, ev);
        var beklenen = evBeklenen + depBeklenen;
        var medyanToplam = ev.MedyanKorner + dep.MedyanKorner;
        var hit = SentetikToplamGerceklesme(ev.KornerDegerleri, dep.KornerDegerleri, esik, true);
        var mesafePuan = 50 + (int)Math.Round((beklenen - esik) * 10m);
        var puan = Math.Clamp((int)Math.Round(mesafePuan * .45m + hit * .55m), 0, 96);

        return Market($"{esik:0.0} KORNER ÜST", $"Toplam Korner {esik:0.0} Üst", puan,
            new[]
            {
                $"Beklenen toplam korner: {beklenen:0.00} (EV {evBeklenen:0.00} + DEP {depBeklenen:0.00})",
                $"Ortalamalar: {veri.EvSahibi} {ev.OrtalamaKorner:0.00} | {veri.Deplasman} {dep.OrtalamaKorner:0.00}",
                $"Rakibe verilen: {veri.EvSahibi} {ev.OrtalamaRakipKorner:0.00} | {veri.Deplasman} {dep.OrtalamaRakipKorner:0.00}",
                $"Medyan toplam: {medyanToplam:0.00} | sentetik gerçekleşme: %{hit:0}"
            }, "Korner", orneklem: toplamKayit);
    }

    private static decimal BeklenenTakimKorner(TakimMarketIstatistikDto takim, TakimMarketIstatistikDto rakip)
    {
        if (rakip.OrtalamaRakipKorner > 0)
            return Math.Round(takim.OrtalamaKorner * .58m + rakip.OrtalamaRakipKorner * .42m, 2);
        return takim.OrtalamaKorner;
    }

    private static decimal Gerceklesme(IReadOnlyCollection<int> values, decimal esik, bool ust)
    {
        if (values.Count == 0) return 0m;
        var adet = values.Count(x => ust ? x > esik : x < esik);
        return Math.Round(adet * 100m / values.Count, 1);
    }

    private static decimal SentetikToplamGerceklesme(IReadOnlyList<int> a, IReadOnlyList<int> b, decimal esik, bool ust)
    {
        var n = Math.Min(a.Count, b.Count);
        if (n == 0) return 0m;
        var adet = 0;
        for (var i = 0; i < n; i++)
        {
            var toplam = a[i] + b[i];
            if (ust ? toplam > esik : toplam < esik) adet++;
        }
        return Math.Round(adet * 100m / n, 1);
    }

    private static KuponMarketSkoruDto KartAlt(MacKuponVerisiDto veri, decimal esik)
    {
        var ev = veri.EvSahibiIstatistik; var dep = veri.DeplasmanIstatistik;
        var toplamKayit = Math.Min(ev.KartKayitSayisi, dep.KartKayitSayisi);
        if (toplamKayit < 6) return Market($"{esik:0.0} KART ALT", $"Toplam Kart {esik:0.0} Alt", 0, new[] { "Kart örneklemi yetersiz." }, "Kart", orneklem: toplamKayit);
        var beklenen = ev.OrtalamaKart + dep.OrtalamaKart;
        var puan = 48 + (int)Math.Round((esik - beklenen) * 12m);
        return Market($"{esik:0.0} KART ALT", $"Toplam Kart {esik:0.0} Alt", puan,
            new[] { $"Kart ortalamaları: {veri.EvSahibi} {ev.OrtalamaKart:0.00} | {veri.Deplasman} {dep.OrtalamaKart:0.00}", $"Medyanlar: {ev.MedyanKart:0.00} + {dep.MedyanKart:0.00}", $"Beklenen toplam kart: {beklenen:0.00}", $"İstatistik örneklemi: {toplamKayit}" }, "Kart", orneklem: toplamKayit);
    }

    private static KuponMarketSkoruDto KartUst(MacKuponVerisiDto veri, decimal esik)
    {
        var ev = veri.EvSahibiIstatistik; var dep = veri.DeplasmanIstatistik;
        var toplamKayit = Math.Min(ev.KartKayitSayisi, dep.KartKayitSayisi);
        if (toplamKayit < 6) return Market($"{esik:0.0} KART ÜST", $"Toplam Kart {esik:0.0} Üst", 0, new[] { "Kart örneklemi yetersiz." }, "Kart", orneklem: toplamKayit);
        var beklenen = ev.OrtalamaKart + dep.OrtalamaKart;
        var puan = 45 + (int)Math.Round((beklenen - esik) * 13m);
        return Market($"{esik:0.0} KART ÜST", $"Toplam Kart {esik:0.0} Üst", puan,
            new[] { $"Kart ortalamaları: {veri.EvSahibi} {ev.OrtalamaKart:0.00} | {veri.Deplasman} {dep.OrtalamaKart:0.00}", $"Medyanlar: {ev.MedyanKart:0.00} + {dep.MedyanKart:0.00}", $"Beklenen toplam kart: {beklenen:0.00}", $"İstatistik örneklemi: {toplamKayit}" }, "Kart", orneklem: toplamKayit);
    }

    private static List<TakimGecmisMacDto> TumFormMaclari(MacKuponVerisiDto veri) =>
        veri.EvSahibiGenelForm.Maclar
            .Concat(veri.EvSahibiIcSahaForm.Maclar)
            .Concat(veri.DeplasmanGenelForm.Maclar)
            .Concat(veri.DeplasmanDisSahaForm.Maclar)
            .GroupBy(x => x.MacId)
            .Select(x => x.First())
            .ToList();

    private static bool DusukOranProfilMi(string kod) => kod is
        "EV 0.5 ÜST" or "DEP 0.5 ÜST" or "4.5 ALT" or "İY 2.5 ALT";

    private static decimal Yuzde(int adet, int toplam) => toplam <= 0 ? 0m : Math.Round(adet * 100m / toplam, 2);

    private static KuponMarketSkoruDto Market(
        string kod,
        string ad,
        int puan,
        IEnumerable<string> gerekceler,
        string kategori = "Genel",
        bool surprizMi = false,
        int orneklem = 0)
    {
        return new KuponMarketSkoruDto
        {
            Kod = kod,
            Ad = ad,
            Kategori = kategori,
            SurprizMi = surprizMi,
            OrneklemSayisi = orneklem,
            GuvenPuani = Math.Clamp(puan, 0, 96),
            Gerekceler = gerekceler
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Take(4)
                .ToList()
        };
    }

    private static decimal FormPuani(
        TakimGecmisVerisiDto form)
    {
        if (form.ToplamMac <= 0)
            return 0;

        var puanOrtalamasi =
            (form.Galibiyet * 3m + form.Beraberlik) /
            form.ToplamMac;

        var golFarki =
            (form.AttigiGol - form.YedigiGol) /
            (decimal)form.ToplamMac;

        return puanOrtalamasi +
               golFarki * 0.30m;
    }

    private static string FormMetni(
        TakimGecmisVerisiDto form)
    {
        return
            $"{form.Galibiyet}G " +
            $"{form.Beraberlik}B " +
            $"{form.Maglubiyet}M";
    }

    private static int MarketVeriKalitesiSec(MacKuponVerisiDto veri, KuponMarketSkoruDto market)
    {
        if (market.Kategori.Equals("Korner", StringComparison.OrdinalIgnoreCase))
            return veri.KornerVeriKalitesi;

        if (market.Kategori.Equals("Kart", StringComparison.OrdinalIgnoreCase))
            return veri.KartVeriKalitesi;

        if (market.Kategori.Contains("İlk Yarı", StringComparison.OrdinalIgnoreCase) ||
            market.Kod.StartsWith("İY", StringComparison.OrdinalIgnoreCase))
            return veri.IlkYariVeriKalitesi;

        if (market.Kategori.Equals("Kombine", StringComparison.OrdinalIgnoreCase))
            return Math.Min(veri.MacSonucuVeriKalitesi, veri.GolMarketVeriKalitesi);

        if (market.Kategori.Contains("Gol", StringComparison.OrdinalIgnoreCase) ||
            market.Kategori.Equals("Takım Golü", StringComparison.OrdinalIgnoreCase) ||
            market.Kod.Contains("ÜST", StringComparison.OrdinalIgnoreCase) ||
            market.Kod.Contains("ALT", StringComparison.OrdinalIgnoreCase) ||
            market.Kod.Contains("KG", StringComparison.OrdinalIgnoreCase))
            return veri.GolMarketVeriKalitesi;

        return veri.MacSonucuVeriKalitesi > 0
            ? veri.MacSonucuVeriKalitesi
            : veri.VeriKalitesiPuani;
    }

    private static int VeriKalitesineGoreDuzelt(
        int puan,
        int veriKalitesi)
    {
        var faktor = veriKalitesi switch
        {
            >= 85 => 1.00m,
            >= 70 => 0.94m,
            >= 55 => 0.86m,
            >= 40 => 0.76m,
            _ => 0.62m
        };

        return Math.Clamp(
            (int)Math.Round(puan * faktor),
            0,
            96);
    }

    private static string RiskBelirle(int guven)
    {
        return guven switch
        {
            >= 80 => "Düşük",
            >= 65 => "Orta",
            _ => "Yüksek"
        };
    }

    private static string GenelRiskBelirle(
        int veriKalitesi,
        IReadOnlyCollection<KuponMarketSkoruDto> adaylar)
    {
        if (veriKalitesi < 45)
            return "Çok Yüksek";

        if (adaylar.Count == 0)
            return "Yüksek";

        var enGuclu = adaylar.Max(x => x.GuvenPuani);

        return enGuclu switch
        {
            >= 82 when veriKalitesi >= 75 => "Düşük",
            >= 70 => "Orta",
            _ => "Yüksek"
        };
    }

    private static decimal Ortalama(
        params decimal[] degerler)
    {
        var kullanilabilir = degerler
            .Where(x => x > 0)
            .ToArray();

        return kullanilabilir.Length == 0
            ? 0
            : kullanilabilir.Average();
    }
}
