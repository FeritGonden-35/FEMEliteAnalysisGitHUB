using System.Collections.Concurrent;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class CokluKuponTaslakService : ICokluKuponTaslakService
{
    private readonly ConcurrentDictionary<long, CokluKuponTaslakDto>
        _taslaklar = new();

    public ServiceResult<CokluKuponTaslakDto> MacEkle(
        long adminTelegramId,
        CokluKuponMacSecimiDto secim)
    {
        if (secim.AnalizId <= 0 || secim.MacId <= 0)
        {
            return ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                "Geçerli analiz ve maç ID değerleri gereklidir.");
        }

        if (string.IsNullOrWhiteSpace(secim.SecilenMarket))
        {
            return ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                "Kupona eklenecek market boş olamaz.");
        }

        var taslak = _taslaklar.GetOrAdd(
            adminTelegramId,
            id => new CokluKuponTaslakDto
            {
                AdminTelegramId = id
            });

        lock (taslak)
        {
            var ayniMac = taslak.Maclar.FirstOrDefault(x => x.MacId == secim.MacId && x.AnalizId != secim.AnalizId);
            if (ayniMac is not null)
            {
                return ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                    "Aynı maç kupona iki kez eklenemez.");
            }

            var mevcut = taslak.Maclar.FirstOrDefault(
                x => x.AnalizId == secim.AnalizId);

            if (mevcut is not null)
            {
                mevcut.SecilenMarket = secim.SecilenMarket.Trim();
                mevcut.GuvenPuani = secim.GuvenPuani;
                mevcut.AktifMi = true;

                return ServiceResult<CokluKuponTaslakDto>.BasariliSonuc(
                    taslak,
                    "Maç kupon taslağında güncellendi.");
            }

            if (taslak.Maclar.Count >= 5)
            {
                return ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                    "Bir kupona en fazla 5 maç ekleyebilirsiniz.");
            }

            secim.SecilenMarket = secim.SecilenMarket.Trim();
            taslak.Maclar.Add(secim);

            return ServiceResult<CokluKuponTaslakDto>.BasariliSonuc(
                taslak,
                "Maç kupon taslağına eklendi.");
        }
    }

    public ServiceResult<CokluKuponTaslakDto> MacCikar(
        long adminTelegramId,
        int analizId)
    {
        if (!_taslaklar.TryGetValue(
                adminTelegramId,
                out var taslak))
        {
            return ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                "Aktif kupon taslağı bulunmuyor.");
        }

        lock (taslak)
        {
            var silinen = taslak.Maclar.RemoveAll(
                x => x.AnalizId == analizId);

            return silinen == 0
                ? ServiceResult<CokluKuponTaslakDto>.BasarisizSonuc(
                    "Kupon taslağında bu analiz bulunamadı.")
                : ServiceResult<CokluKuponTaslakDto>.BasariliSonuc(
                    taslak,
                    "Maç kupon taslağından çıkarıldı.");
        }
    }

    public ServiceResult<CokluKuponTaslakDto> TaslagiGetir(
        long adminTelegramId)
    {
        if (!_taslaklar.TryGetValue(
                adminTelegramId,
                out var taslak))
        {
            taslak = new CokluKuponTaslakDto
            {
                AdminTelegramId = adminTelegramId
            };
        }

        return ServiceResult<CokluKuponTaslakDto>.BasariliSonuc(
            taslak,
            "Kupon taslağı getirildi.");
    }

    public ServiceResult<bool> Temizle(
        long adminTelegramId)
    {
        _taslaklar.TryRemove(
            adminTelegramId,
            out _);

        return ServiceResult<bool>.BasariliSonuc(
            true,
            "Kupon taslağı temizlendi.");
    }
}
