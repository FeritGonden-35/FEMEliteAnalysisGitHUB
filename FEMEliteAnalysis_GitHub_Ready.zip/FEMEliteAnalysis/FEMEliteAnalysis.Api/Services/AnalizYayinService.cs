using System.Text.Json;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Enums;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Services;

public class AnalizYayinService : IAnalizYayinService
{
    private readonly FemDbContext _dbContext;
    private readonly ITelegramBotClient _botClient;
    private readonly TelegramOptions _telegramOptions;
    private readonly ILogger<AnalizYayinService> _logger;

    public AnalizYayinService(
        FemDbContext dbContext,
        ITelegramBotClient botClient,
        IOptions<TelegramOptions> telegramOptions,
        ILogger<AnalizYayinService> logger)
    {
        _dbContext = dbContext;
        _botClient = botClient;
        _telegramOptions = telegramOptions.Value;
        _logger = logger;
    }

    public async Task<ServiceResult<long>> VipKanalinaYayinlaAsync(
        int analizId,
        CancellationToken cancellationToken)
    {
        if (!_telegramOptions.VipChannelId.HasValue)
        {
            return ServiceResult<long>.BasarisizSonuc(
                "Telegram VIP kanal ID değeri tanımlanmamış.");
        }

        var analiz = await _dbContext.Analizler
            .Include(x => x.Mac)
                .ThenInclude(x => x.Lig)
            .Include(x => x.Mac)
                .ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac)
                .ThenInclude(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == analizId,
                cancellationToken);

        if (analiz is null)
        {
            return ServiceResult<long>.BasarisizSonuc(
                "Yayınlanacak analiz bulunamadı.");
        }

        if (analiz.Durum == AnalizDurumu.Yayinlandi)
        {
            return ServiceResult<long>.BasarisizSonuc(
                "Bu analiz daha önce yayınlanmış.");
        }

        if (analiz.Durum != AnalizDurumu.Taslak)
        {
            return ServiceResult<long>.BasarisizSonuc(
                "Yalnızca taslak durumundaki analizler yayınlanabilir.");
        }

        var mesajMetni = AnalizMesajiOlustur(analiz);

        try
        {
            var gonderilenMesaj = await _botClient.SendMessage(
                chatId: _telegramOptions.VipChannelId.Value,
                text: mesajMetni,
                cancellationToken: cancellationToken);

            analiz.Durum = AnalizDurumu.Yayinlandi;
            analiz.TelegramMesajId = gonderilenMesaj.MessageId;
            analiz.YayinlananKanalId = _telegramOptions.VipChannelId.Value;
            analiz.YayinlanmaTarihi = DateTime.UtcNow;

            await _dbContext.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "Analiz VIP kanalına yayınlandı. AnalizId: {AnalizId}, MesajId: {MesajId}",
                analiz.Id,
                gonderilenMesaj.MessageId);

            return ServiceResult<long>.BasariliSonuc(
                gonderilenMesaj.MessageId,
                "Analiz VIP kanalına yayınlandı.");
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Analiz VIP kanalına yayınlanırken hata oluştu. AnalizId: {AnalizId}",
                analizId);

            return ServiceResult<long>.BasarisizSonuc(
                "Analiz VIP kanalına gönderilemedi.");
        }
    }

    public async Task<ServiceResult<string>> YayinOnizlemesiOlusturAsync(
        int analizId,
        CancellationToken cancellationToken)
    {
        var analiz = await _dbContext.Analizler
            .AsNoTracking()
            .Include(x => x.Mac)
                .ThenInclude(x => x.Lig)
            .Include(x => x.Mac)
                .ThenInclude(x => x.EvSahibiTakim)
            .Include(x => x.Mac)
                .ThenInclude(x => x.DeplasmanTakim)
            .FirstOrDefaultAsync(
                x => x.Id == analizId,
                cancellationToken);

        if (analiz is null)
        {
            return ServiceResult<string>.BasarisizSonuc(
                "Analiz bulunamadı.");
        }

        return ServiceResult<string>.BasariliSonuc(
            AnalizMesajiOlustur(analiz),
            "Yayın ön izlemesi oluşturuldu.");
    }

    private static string AnalizMesajiOlustur(
        Models.Analiz analiz)
    {
        List<string> faktorler;

        try
        {
            faktorler = JsonSerializer.Deserialize<List<string>>(
                analiz.AnaFaktorlerJson ?? "[]")
                ?? new List<string>();
        }
        catch
        {
            faktorler = new List<string>();
        }

        var faktorMetni = faktorler.Count == 0
            ? "• Ek faktör bulunmuyor."
            : string.Join(
                "\n",
                faktorler.Take(6).Select(x => $"• {x}"));

        var macSaati = IstanbulSaati(analiz.Mac.MacTarihi);

        return
            "⚽ FEM ELITE ANALYSIS\n\n" +
            $"🏆 {analiz.Mac.Lig?.Ad ?? "Bilinmeyen Lig"}\n" +
            $"📅 {macSaati:dd.MM.yyyy HH:mm}\n\n" +
            $"🔥 {analiz.Mac.EvSahibiTakim.Ad} - " +
            $"{analiz.Mac.DeplasmanTakim.Ad}\n\n" +
            $"📝 ANALİZ\n{analiz.YapayZekaAnalizi}\n\n" +
            $"📊 MAÇ SONU OLASILIKLARI\n" +
            $"Ev sahibi: %{analiz.EvSahibiKazanmaOlasiligi:0.##}\n" +
            $"Beraberlik: %{analiz.BeraberlikOlasiligi:0.##}\n" +
            $"Deplasman: %{analiz.DeplasmanKazanmaOlasiligi:0.##}\n\n" +
            $"🎯 Güven puanı: {analiz.GuvenPuani}/100\n" +
            $"⚠️ Risk seviyesi: {analiz.RiskSeviyesi}\n\n" +
            $"📌 ANA FAKTÖRLER\n{faktorMetni}\n\n" +
            "⚠️ Bu içerik istatistiksel analizdir; kesin sonuç garantisi içermez.";
    }

    private static DateTime IstanbulSaati(DateTime utcTarih)
    {
        var tarih = utcTarih.Kind == DateTimeKind.Utc
            ? utcTarih
            : DateTime.SpecifyKind(utcTarih, DateTimeKind.Utc);

        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
            tarih,
            "Turkey Standard Time");
    }
}
