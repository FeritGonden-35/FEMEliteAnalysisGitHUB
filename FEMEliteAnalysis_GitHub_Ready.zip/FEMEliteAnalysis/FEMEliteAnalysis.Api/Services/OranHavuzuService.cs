using System.Collections.Concurrent;
using FEMEliteAnalysis.Api.Dtos.Oran;
using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class OranHavuzuService : IOranHavuzuService
{
    private const int MaksimumMac = 5;
    private readonly ConcurrentDictionary<long, List<OranHavuzuMacDto>> _havuzlar = new();
    private readonly object _kilit = new();

    public bool Ekle(long telegramId, OranHavuzuMacDto mac, out string mesaj)
    {
        lock (_kilit)
        {
            var liste = _havuzlar.GetOrAdd(telegramId, _ => new List<OranHavuzuMacDto>());
            if (liste.Any(x => x.MacId == mac.MacId))
            {
                mesaj = "Maç zaten oran havuzunda.";
                return false;
            }
            if (liste.Count >= MaksimumMac)
            {
                mesaj = $"Oran havuzu en fazla {MaksimumMac} maç kabul eder.";
                return false;
            }
            liste.Add(mac);
            mesaj = "Maç oran havuzuna eklendi.";
            return true;
        }
    }

    public bool Cikar(long telegramId, int macId)
    {
        lock (_kilit)
        {
            if (!_havuzlar.TryGetValue(telegramId, out var liste)) return false;
            return liste.RemoveAll(x => x.MacId == macId) > 0;
        }
    }

    public void Temizle(long telegramId) => _havuzlar.TryRemove(telegramId, out _);

    public IReadOnlyList<OranHavuzuMacDto> Listele(long telegramId)
    {
        lock (_kilit)
        {
            return _havuzlar.TryGetValue(telegramId, out var liste)
                ? liste.Select(x => new OranHavuzuMacDto { MacId = x.MacId, EvSahibi = x.EvSahibi, Deplasman = x.Deplasman, MacTarihi = x.MacTarihi }).ToList()
                : Array.Empty<OranHavuzuMacDto>();
        }
    }

    public bool Iceriyor(long telegramId, int macId) => Listele(telegramId).Any(x => x.MacId == macId);
}
