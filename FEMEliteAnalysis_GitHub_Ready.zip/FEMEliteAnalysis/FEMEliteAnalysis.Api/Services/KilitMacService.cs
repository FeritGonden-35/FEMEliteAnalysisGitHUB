using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Analiz;
using FEMEliteAnalysis.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

/// <summary>
/// V5.1: "her maça tahmin" yerine az sayıda yüksek-değerli kilit seçim bulur.
/// Yerel veride shortlist -> PulseScore gerçek oran -> model + gerçek market performansı + odds pattern -> final skor.
/// </summary>
public class KilitMacService : IKilitMacService
{
    private readonly FemDbContext _db;
    private readonly IUygunMacService _uygun;
    private readonly ISqlTakimFormService _form;
    private readonly IAnalizMotoruV2 _motor;
    private readonly IOddsApiService _odds;
    private readonly IOddsPatternEngine _pattern;

    public KilitMacService(FemDbContext db, IUygunMacService uygun, ISqlTakimFormService form, IAnalizMotoruV2 motor, IOddsApiService odds, IOddsPatternEngine pattern)
    { _db=db; _uygun=uygun; _form=form; _motor=motor; _odds=odds; _pattern=pattern; }

    public async Task<ServiceResult<KilitMaclarSonucDto>> GetirAsync(int adet, bool yuksekDeger, CancellationToken ct)
    {
        adet=Math.Clamp(adet,1,10);
        var ur=await _uygun.UygunMaclariGetirAsync(3,120,ct);
        if(!ur.Basarili||ur.Veri is null||ur.Veri.Count==0) return ServiceResult<KilitMaclarSonucDto>.BasarisizSonuc("Uygun maç bulunamadı.");

        // Provider/season tekrarlarını gerçek fikstür anahtarıyla tekilleştir.
        var uniq=ur.Veri.GroupBy(x=>$"{N(x.EvSahibi)}|{N(x.Deplasman)}|{x.MacTarihi:yyyyMMddHH}")
            .Select(g=>g.OrderByDescending(x=>x.VeriGuvenPuani).First()).ToList();

        var locals=new List<(int id,int score,string lig,string ev,string dep,DateTime tarih)>();
        foreach(var m in uniq)
        {
            var vr=await _form.MacKuponVerisiOlusturAsync(m.MacId,ct); if(!vr.Basarili||vr.Veri is null) continue;
            try
            {
                var a=_motor.AnalizEt(vr.Veri);
                var top=a.Marketler.Where(x=>!x.UzakDurMu && x.OrneklemSayisi>=6).OrderByDescending(x=>x.GuvenPuani+(x.Kategori=="Kombine"?7:0)).FirstOrDefault();
                if(top is null||a.VeriKalitesiPuani<65||a.GenelGuvenPuani<58) continue;
                locals.Add((m.MacId,a.GenelGuvenPuani*2+a.VeriKalitesiPuani+top.GuvenPuani+m.VeriGuvenPuani,m.Lig,m.EvSahibi,m.Deplasman,m.MacTarihi));
            } catch { }
        }
        if(locals.Count==0) return ServiceResult<KilitMaclarSonucDto>.BasarisizSonuc("Kilit seçim için yerel shortlist oluşmadı.");

        var shortlist=locals.OrderByDescending(x=>x.score).Take(12).ToList();
        var sync=await _odds.HavuzOranlariniCekAsync(shortlist.Select(x=>x.id),ct);
        var oddsRows=await _db.BahisOranlari.AsNoTracking().Where(x=>shortlist.Select(s=>s.id).Contains(x.MacId) && x.Oran>1.01m)
            .OrderByDescending(x=>x.AlinmaTarihi).ToListAsync(ct);

        // Gerçek kupon sonuçlarından market kalibrasyonu. Tahmin tablosu boş olsa bile çalışır.
        var perfRows=await _db.KuponMaclari.AsNoTracking().Where(x=>x.Sonuc=="Kazandi"||x.Sonuc=="Kaybetti").ToListAsync(ct);
        var perf=perfRows.GroupBy(x=>MarketBase(x.SecilenMarket),StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g=>g.Key,g=>(top:g.Count(),win:g.Count(x=>x.Sonuc=="Kazandi")),StringComparer.OrdinalIgnoreCase);

        var candidates=new List<KilitMacSecimDto>();
        foreach(var s in shortlist)
        {
            var vr=await _form.MacKuponVerisiOlusturAsync(s.id,ct); if(!vr.Basarili||vr.Veri is null) continue;
            FEMEliteAnalysis.Api.Dtos.Analiz.AnalizMotoruV2SonucDto a; try{a=_motor.AnalizEt(vr.Veri);}catch{continue;}
            var row=oddsRows.Where(x=>x.MacId==s.id).GroupBy(x=>N(x.MarketKodu)).ToDictionary(g=>g.Key,g=>g.First(),StringComparer.OrdinalIgnoreCase);
            foreach(var m in a.Marketler.Where(x=>!x.UzakDurMu && x.OrneklemSayisi>=8 && x.GuvenPuani>=58))
            {
                if(!row.TryGetValue(N(m.Kod),out var odd)) continue;
                var minOdd=yuksekDeger?1.75m:1.55m; var maxOdd=yuksekDeger?5.50m:4.00m;
                if(odd.Oran<minOdd||odd.Oran>maxOdd) continue;
                var model=Math.Clamp(m.GuvenPuani/100m,0.05m,0.95m);
                decimal? hit=null; int hitN=0;
                if(perf.TryGetValue(MarketBase(m.Kod),out var p)&&p.top>=5){hitN=p.top;hit=p.win*100m/p.top;model=model*0.7m+(hit.Value/100m)*0.3m;}
                var marketProb=1m/odd.Oran; var edge=(model-marketProb)*100m; var ev=model*odd.Oran-1m;
                if(edge<3m||ev<0.025m) continue;
                var comb=m.Kategori.Equals("Kombine",StringComparison.OrdinalIgnoreCase)||m.Kod.Contains('+');
                var oddBonus=odd.Oran is >=1.80m and <=3.50m?10m:6m;
                var score=model*100m+Math.Clamp(edge,-10m,20m)+(comb?9m:0m)+oddBonus+(m.OrneklemSayisi>=15?4m:0m)+(hitN>=10?4m:0m);
                candidates.Add(new KilitMacSecimDto{MacId=s.id,MacTarihi=s.tarih,Lig=s.lig,EvSahibi=s.ev,Deplasman=s.dep,Market=m.Kod,Oran=odd.Oran,ModelGuven=(int)Math.Round(model*100m),Edge=Math.Round(edge,1),BeklenenDeger=Math.Round(ev,3),MarketOrneklem=m.OrneklemSayisi,GecmisMarketBasari=hit,GecmisMarketOrneklem=hitN,FinalSkor=Math.Round(score,1),Nedenler=m.Gerekceler.Take(3).ToList()});
            }
        }

        // Aynı maçtan tek seçim: yüksek oran hedefinde bile bir maçın dört marketi listeyi doldurmasın.
        var bestPerMatch=candidates.GroupBy(x=>x.MacId).Select(g=>g.OrderByDescending(x=>x.FinalSkor).First()).OrderByDescending(x=>x.FinalSkor).Take(Math.Max(adet*2,6)).ToList();
        foreach(var c in bestPerMatch.Take(8))
        {
            var p=await _pattern.HizliAnalizAsync(c.MacId,ct);
            if(p is null) continue;
            c.PatternSkoru=p.EnGucluSinyalYuzdesi;
            c.PatternBilgisi=$"#{p.PatternNo} %{p.Benzerlik:0.0} benzer | {p.EnGucluSinyal} %{p.EnGucluSinyalYuzdesi:0.0} | n={p.Orneklem}";
            if(p.BasariOranlari.TryGetValue(c.Market,out var direct)) c.FinalSkor+=Math.Clamp((direct-50m)/3m,-6m,10m);
            else if(p.Durum=="Güçlü pattern") c.FinalSkor+=4m;
        }

        var final=bestPerMatch.OrderByDescending(x=>x.FinalSkor).Take(adet).ToList();
        if(final.Count==0) return ServiceResult<KilitMaclarSonucDto>.BasarisizSonuc("Gerçek oran + edge + kalite filtresini geçen kilit seçim bulunamadı. Zayıf seçim üretilmedi.");
        return ServiceResult<KilitMaclarSonucDto>.BasariliSonuc(new KilitMaclarSonucDto{IncelenenMac=uniq.Count,Shortlist=shortlist.Count,ApiIstek=sync.Sum(x=>x.ApiIstekSayisi),Secimler=final},$"{final.Count} kilit seçim bulundu.");
    }

    private static string MarketBase(string x)
    {
        var at=x.IndexOf('@'); if(at>=0)x=x[..at]; return N(x);
    }
    private static string N(string x)=>string.Join(' ',(x??"").ToUpperInvariant().Replace('İ','I').Replace('Ü','U').Replace('Ş','S').Replace('Ğ','G').Replace('Ö','O').Replace('Ç','C').Split(' ',StringSplitOptions.RemoveEmptyEntries));
}
