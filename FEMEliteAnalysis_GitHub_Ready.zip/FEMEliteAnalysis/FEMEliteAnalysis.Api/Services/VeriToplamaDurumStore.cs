using FEMEliteAnalysis.Api.Interfaces;

namespace FEMEliteAnalysis.Api.Services;

public class VeriToplamaDurumStore : IVeriToplamaDurumStore
{
    private readonly object _kilit = new();

    public bool CalisiyorMu { get; private set; }
    public DateTime? SonBaslamaZamani { get; private set; }
    public DateTime? SonBitisZamani { get; private set; }
    public string? SonMesaj { get; private set; }

    public void Basladi()
    {
        lock (_kilit)
        {
            CalisiyorMu = true;
            SonBaslamaZamani = DateTime.UtcNow;
            SonBitisZamani = null;
            SonMesaj = "Veri toplama çalışıyor.";
        }
    }

    public void Tamamlandi(string mesaj)
    {
        lock (_kilit)
        {
            CalisiyorMu = false;
            SonBitisZamani = DateTime.UtcNow;
            SonMesaj = mesaj;
        }
    }

    public void Basarisiz(string mesaj)
    {
        lock (_kilit)
        {
            CalisiyorMu = false;
            SonBitisZamani = DateTime.UtcNow;
            SonMesaj = mesaj;
        }
    }
}
