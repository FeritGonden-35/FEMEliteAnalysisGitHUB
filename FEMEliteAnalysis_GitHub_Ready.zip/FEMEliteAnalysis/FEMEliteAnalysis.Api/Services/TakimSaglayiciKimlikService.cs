using System.Globalization;
using System.Text;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Providers.TheSportsDb;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Services;

public sealed class TakimSaglayiciKimlikService : ITakimSaglayiciKimlikService
{
    public const string ApiFootball = "ApiFootball";
    public const string TheSportsDb = "TheSportsDB";

    private readonly FemDbContext _db;
    private readonly TheSportsDbV2Client _v2Client;
    private readonly ILogger<TakimSaglayiciKimlikService> _logger;

    public TakimSaglayiciKimlikService(
        FemDbContext db,
        TheSportsDbV2Client v2Client,
        ILogger<TakimSaglayiciKimlikService> logger)
    {
        _db = db;
        _v2Client = v2Client;
        _logger = logger;
    }

    public async Task<TakimSaglayiciKimlikSonucu> TumKimlikleriGetirAsync(
        int takimId,
        CancellationToken ct)
    {
        var apiFootball = await ApiFootballIdGetirAsync(takimId, ct);
        var sportsDb = await TheSportsDbIdGetirAsync(takimId, ct);

        return new TakimSaglayiciKimlikSonucu
        {
            TakimId = takimId,
            ApiFootballId = apiFootball,
            TheSportsDbId = sportsDb
        };
    }

    public async Task<int?> ApiFootballIdGetirAsync(int takimId, CancellationToken ct)
    {
        var mevcut = await KimlikOkuAsync(takimId, ApiFootball, ct);
        if (mevcut.HasValue)
            return mevcut;

        var takim = await _db.Takimlar.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == takimId, ct);
        if (takim is null)
            return null;

        // Eski kayıtlarda pozitif HariciTakimId API-Football olabilir; /synclig ile
        // eklenen yeni kayıtlarda ise aynı alan TheSportsDB ID'si olabilir. TheSportsDbTakimId
        // ile aynı pozitif değeri API-Football sanma.
        if (takim.HariciTakimId is > 0 &&
            (!takim.TheSportsDbTakimId.HasValue || takim.TheSportsDbTakimId.Value != takim.HariciTakimId.Value))
        {
            await KimlikKaydetAsync(takim.Id, ApiFootball, takim.HariciTakimId.Value, takim.Ad, ct);
            return takim.HariciTakimId.Value;
        }

        // Aynı kulübün eski/yeni veya farklı sağlayıcıdan oluşmuş mükerrer kaydını ara.
        var adaylar = await _db.Takimlar.AsNoTracking()
            .Where(x => x.Id != takimId && x.HariciTakimId.HasValue && x.HariciTakimId.Value > 0 &&
                        (!x.TheSportsDbTakimId.HasValue || x.TheSportsDbTakimId.Value != x.HariciTakimId.Value))
            .Select(x => new { x.Id, x.Ad, x.HariciTakimId })
            .ToListAsync(ct);

        var hedefNorm = Normalize(takim.Ad);
        var aday = adaylar
            .Where(x => Normalize(x.Ad) == hedefNorm)
            .OrderBy(x => x.Ad.Length)
            .FirstOrDefault();

        if (aday?.HariciTakimId is > 0)
        {
            await KimlikKaydetAsync(takim.Id, ApiFootball, aday.HariciTakimId.Value, aday.Ad, ct);
            return aday.HariciTakimId.Value;
        }

        // V2 takım araması aynı cevapta idAPIfootball alanını da döndürüyor.
        var bulunan = await _v2Client.TakimAraAsync(takim.Ad, 0, ct);
        if (bulunan?.ApiFootballId is > 0)
        {
            await KimlikKaydetAsync(takim.Id, ApiFootball, bulunan.ApiFootballId.Value, bulunan.Ad, ct);
            if (bulunan.Id > 0)
                await KimlikKaydetAsync(takim.Id, TheSportsDb, bulunan.Id, bulunan.Ad, ct);
            return bulunan.ApiFootballId.Value;
        }

        return null;
    }

    public async Task<int?> TheSportsDbIdGetirAsync(int takimId, CancellationToken ct)
    {
        var mevcut = await KimlikOkuAsync(takimId, TheSportsDb, ct);
        if (mevcut.HasValue)
            return mevcut;

        var takim = await _db.Takimlar.AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == takimId, ct);
        if (takim is null)
            return null;

        // /synclig ile eklenen kayıtlarda TheSportsDbTakimId doğrudan saklanır.
        if (takim.TheSportsDbTakimId is > 0)
        {
            await KimlikKaydetAsync(takim.Id, TheSportsDb, takim.TheSportsDbTakimId.Value, takim.Ad, ct);
            return takim.TheSportsDbTakimId.Value;
        }

        // Negatif -10 kodlaması TheSportsDB kaynak kimliğini temsil eder.
        if (takim.HariciTakimId is < 0 && Math.Abs(takim.HariciTakimId.Value) % 10 == 0)
        {
            var sourceId = Math.Abs(takim.HariciTakimId.Value) / 10;
            await KimlikKaydetAsync(takim.Id, TheSportsDb, sourceId, takim.Ad, ct);
            return sourceId;
        }

        var bulunan = await _v2Client.TakimAraAsync(takim.Ad, 0, ct);
        if (bulunan is null || bulunan.Id <= 0)
            return null;

        await KimlikKaydetAsync(takim.Id, TheSportsDb, bulunan.Id, bulunan.Ad, ct);
        if (bulunan.ApiFootballId is > 0)
            await KimlikKaydetAsync(takim.Id, ApiFootball, bulunan.ApiFootballId.Value, bulunan.Ad, ct);

        return bulunan.Id;
    }

    private async Task<int?> KimlikOkuAsync(int takimId, string saglayici, CancellationToken ct)
    {
        return await _db.TakimSaglayiciKimlikleri.AsNoTracking()
            .Where(x => x.TakimId == takimId && x.Saglayici == saglayici)
            .Select(x => (int?)x.SaglayiciTakimId)
            .FirstOrDefaultAsync(ct);
    }

    private async Task KimlikKaydetAsync(
        int takimId,
        string saglayici,
        int saglayiciTakimId,
        string? saglayiciTakimAdi,
        CancellationToken ct)
    {
        if (saglayiciTakimId <= 0)
            return;

        try
        {
            var kayit = await _db.TakimSaglayiciKimlikleri
                .FirstOrDefaultAsync(x => x.TakimId == takimId && x.Saglayici == saglayici, ct);

            if (kayit is null)
            {
                kayit = new TakimSaglayiciKimligi
                {
                    TakimId = takimId,
                    Saglayici = saglayici,
                    SaglayiciTakimId = saglayiciTakimId,
                    SaglayiciTakimAdi = saglayiciTakimAdi,
                    KayitTarihi = DateTime.UtcNow
                };
                _db.TakimSaglayiciKimlikleri.Add(kayit);
            }
            else
            {
                kayit.SaglayiciTakimId = saglayiciTakimId;
                kayit.SaglayiciTakimAdi = saglayiciTakimAdi;
                kayit.GuncellemeTarihi = DateTime.UtcNow;
            }

            await _db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex)
        {
            // Paralel istek aynı eşleşmeyi eklemiş olabilir; sonraki okumada kayıt bulunur.
            _logger.LogDebug(ex,
                "Takım sağlayıcı kimliği eklenirken eşzamanlı kayıt oluştu. TakimId: {TakimId}, Sağlayıcı: {Saglayici}",
                takimId, saglayici);
            _db.ChangeTracker.Clear();
        }
    }

    private static string Normalize(string value)
    {
        var text = value.Trim().ToLower(new CultureInfo("tr-TR"));
        text = text
            .Replace("ı", "i", StringComparison.Ordinal)
            .Replace("ş", "s", StringComparison.Ordinal)
            .Replace("ğ", "g", StringComparison.Ordinal)
            .Replace("ü", "u", StringComparison.Ordinal)
            .Replace("ö", "o", StringComparison.Ordinal)
            .Replace("ç", "c", StringComparison.Ordinal);

        var sb = new StringBuilder(text.Length);
        foreach (var ch in text)
            if (char.IsLetterOrDigit(ch))
                sb.Append(ch);

        var sonuc = sb.ToString();
        foreach (var ek in new[] { "footballclub", "futbolkulubu", "club", "fk", "fc", "sc", "ac" })
        {
            if (sonuc.EndsWith(ek, StringComparison.Ordinal) && sonuc.Length > ek.Length + 2)
                sonuc = sonuc[..^ek.Length];
        }

        return sonuc;
    }
}
