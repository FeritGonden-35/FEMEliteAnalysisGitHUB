using System.Text;
using FEMEliteAnalysis.Api.Common.Results;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Dtos.Kupon;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Services;

public class KuponYayinService : IKuponYayinService
{
    private readonly FemDbContext _db;
    private readonly TelegramOptions _telegramOptions;

    public KuponYayinService(
        FemDbContext db,
        IOptions<TelegramOptions> telegramOptions)
    {
        _db = db;
        _telegramOptions = telegramOptions.Value;
    }

    public async Task<ServiceResult<KuponYayinOnizlemeDto>> OnizlemeGetirAsync(
        int kuponId,
        long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var kupon = await KuponGetirAsync(
            kuponId,
            adminTelegramId,
            tracking: false,
            cancellationToken);

        if (kupon is null)
        {
            return ServiceResult<KuponYayinOnizlemeDto>.BasarisizSonuc(
                "Kupon bulunamadı veya bu kuponu yayınlama yetkiniz yok.");
        }

        if (kupon.Maclar.Count is < 1 or > 5)
        {
            return ServiceResult<KuponYayinOnizlemeDto>.BasarisizSonuc(
                "Yayınlanacak kupon 1 ile 5 maç arasında olmalıdır.");
        }

        return ServiceResult<KuponYayinOnizlemeDto>.BasariliSonuc(
            OnizlemeOlustur(kupon),
            "Kupon yayın önizlemesi hazırlandı.");
    }

    public async Task<ServiceResult<KuponYayinOnizlemeDto>> YayinlandiOlarakIsaretleAsync(
        int kuponId,
        long adminTelegramId,
        CancellationToken cancellationToken)
    {
        var kupon = await KuponGetirAsync(
            kuponId,
            adminTelegramId,
            tracking: true,
            cancellationToken);

        if (kupon is null)
        {
            return ServiceResult<KuponYayinOnizlemeDto>.BasarisizSonuc(
                "Kupon bulunamadı veya bu kuponu yayınlama yetkiniz yok.");
        }

        if (YayinlandiMi(kupon))
        {
            return ServiceResult<KuponYayinOnizlemeDto>.BasarisizSonuc(
                $"Bu kupon daha önce {IstanbulSaati(kupon.YayinlanmaTarihi!.Value):dd.MM.yyyy HH:mm} tarihinde yayınlandı.");
        }

        var onizleme = OnizlemeOlustur(kupon);

        kupon.Durum = "Yayinlandi";
        kupon.YayinMetni = onizleme.VipMetni;
        kupon.YayinlanmaTarihi = DateTime.UtcNow;
        kupon.GuncellemeTarihi = DateTime.UtcNow;

        await _db.SaveChangesAsync(cancellationToken);

        onizleme.DahaOnceYayinlandiMi = true;
        onizleme.YayinlanmaTarihi = kupon.YayinlanmaTarihi;

        return ServiceResult<KuponYayinOnizlemeDto>.BasariliSonuc(
            onizleme,
            "Kupon yayınlandı olarak işaretlendi.");
    }

    private async Task<Kupon?> KuponGetirAsync(
        int kuponId,
        long adminTelegramId,
        bool tracking,
        CancellationToken cancellationToken)
    {
        IQueryable<Kupon> query = _db.Kuponlar
            .Include(x => x.Maclar);

        if (!tracking)
        {
            query = query.AsNoTracking();
        }

        return await query.FirstOrDefaultAsync(
            x => x.Id == kuponId &&
                 x.AdminTelegramId == adminTelegramId,
            cancellationToken);
    }

    private KuponYayinOnizlemeDto OnizlemeOlustur(Kupon kupon)
    {
        return new KuponYayinOnizlemeDto
        {
            KuponId = kupon.Id,
            Baslik = kupon.Baslik,
            VipMetni = VipMetniOlustur(kupon),
            UcretsizKanalMetni = UcretsizKanalMetniOlustur(kupon),
            TwitterMetni = TwitterMetniOlustur(kupon),
            DahaOnceYayinlandiMi = YayinlandiMi(kupon),
            YayinlanmaTarihi = kupon.YayinlanmaTarihi
        };
    }

    private string VipMetniOlustur(Kupon kupon)
    {
        var sb = new StringBuilder();
        var marka = MarkaAdi();

        sb.AppendLine("💎 VIP KUPON");
        sb.AppendLine($"🔥 {marka}");
        sb.AppendLine();
        sb.AppendLine($"🎫 {kupon.Baslik}");
        sb.AppendLine();

        foreach (var mac in kupon.Maclar.OrderBy(x => x.Sira))
        {
            sb.AppendLine($"{SiraEmojisi(mac.Sira)} {mac.EvSahibi} - {mac.Deplasman}");
            sb.AppendLine($"🎯 {mac.SecilenMarket}{(mac.Oran.HasValue ? $" ({mac.Oran:0.00})" : string.Empty)}");
            sb.AppendLine($"📊 Güven: %{mac.GuvenPuani}");
            sb.AppendLine();
        }

        sb.AppendLine($"📦 Toplam seçim: {kupon.Maclar.Count}");
        sb.AppendLine($"🎯 Ortalama güven: %{kupon.OrtalamaGuvenPuani}");
        sb.AppendLine($"🛡️ Risk: {kupon.RiskSeviyesi}");
        if (kupon.ToplamOran.HasValue) sb.AppendLine($"💰 Toplam oran: {kupon.ToplamOran:0.00}");
        sb.AppendLine();
        sb.AppendLine("⚠️ Bahis finansal risk içerir. Bu paylaşım kesin sonuç garantisi değildir.");

        return sb.ToString().Trim();
    }

    private string UcretsizKanalMetniOlustur(Kupon kupon)
    {
        var sb = new StringBuilder();
        sb.AppendLine("🔥 YENİ VIP KUPON HAZIR");
        sb.AppendLine();
        sb.AppendLine($"🎫 {kupon.Baslik}");
        sb.AppendLine($"📦 {kupon.Maclar.Count} seçim");
        sb.AppendLine($"🎯 Ortalama güven: %{kupon.OrtalamaGuvenPuani}");
        sb.AppendLine($"🛡️ Risk: {kupon.RiskSeviyesi}");

        if (!string.IsNullOrWhiteSpace(_telegramOptions.KanalKullaniciAdi))
        {
            var kullaniciAdi = _telegramOptions.KanalKullaniciAdi.Trim();
            if (!kullaniciAdi.StartsWith('@'))
                kullaniciAdi = "@" + kullaniciAdi;

            sb.AppendLine();
            sb.AppendLine($"💎 Detaylı seçimler VIP kanalda: {kullaniciAdi}");
        }
        else
        {
            sb.AppendLine();
            sb.AppendLine("💎 Detaylı seçimler VIP kanalda paylaşıldı.");
        }

        return sb.ToString().Trim();
    }

    private string TwitterMetniOlustur(Kupon kupon)
    {
        var secimler = kupon.Maclar
            .OrderBy(x => x.Sira)
            .Select(x => $"{x.EvSahibi}-{x.Deplasman}: {x.SecilenMarket}")
            .ToList();

        var metin =
            $"⚽ {kupon.Baslik}\n\n" +
            string.Join("\n", secimler.Select((x, i) => $"{i + 1}. {x}")) +
            $"\n\nGüven: %{kupon.OrtalamaGuvenPuani} | Risk: {kupon.RiskSeviyesi}" +
            "\n\n#Futbol #Kupon #FEMElite";

        const int hedefUzunluk = 275;
        return metin.Length <= hedefUzunluk
            ? metin
            : metin[..hedefUzunluk].TrimEnd() + "…";
    }

    private string MarkaAdi()
    {
        return string.IsNullOrWhiteSpace(_telegramOptions.MarkaAdi)
            ? "FEM Elite Analysis"
            : _telegramOptions.MarkaAdi.Trim();
    }

    private static bool YayinlandiMi(Kupon kupon)
    {
        return kupon.YayinlanmaTarihi.HasValue ||
               kupon.Durum.Equals(
                   "Yayinlandi",
                   StringComparison.OrdinalIgnoreCase) ||
               kupon.Durum.Equals(
                   "Yayınlandı",
                   StringComparison.OrdinalIgnoreCase);
    }

    private static DateTime IstanbulSaati(DateTime utc)
    {
        var utcTarih = utc.Kind == DateTimeKind.Utc
            ? utc
            : DateTime.SpecifyKind(utc, DateTimeKind.Utc);

        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(
            utcTarih,
            "Turkey Standard Time");
    }

    private static string SiraEmojisi(int sira)
    {
        return sira switch
        {
            1 => "1️⃣",
            2 => "2️⃣",
            3 => "3️⃣",
            4 => "4️⃣",
            5 => "5️⃣",
            _ => $"{sira}."
        };
    }
}
