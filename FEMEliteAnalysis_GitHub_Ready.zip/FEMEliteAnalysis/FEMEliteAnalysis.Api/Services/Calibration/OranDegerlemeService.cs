namespace FEMEliteAnalysis.Api.Services.Calibration;

public static class OranDegerlemeService
{
    public static decimal PiyasaOlasiligi(decimal oran) => oran > 1m ? Math.Round(1m / oran, 4) : 0m;
    public static decimal EdgeYuzdesi(decimal modelOlasiligi, decimal oran) =>
        Math.Round((modelOlasiligi - PiyasaOlasiligi(oran)) * 100m, 2);
    public static decimal BeklenenDeger(decimal modelOlasiligi, decimal oran) =>
        Math.Round(modelOlasiligi * oran - 1m, 4);
}
