using FEMEliteAnalysis.Api.Dtos.Kullanici;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Models;
using FEMEliteAnalysis.Api.Repositories;
using Telegram.Bot.Types;

namespace FEMEliteAnalysis.Api.Services;

public class KullaniciService : IKullaniciService
{
    private readonly KullaniciRepository _repository;
    private readonly IUyelikService _uyelikService;

    public KullaniciService(
        KullaniciRepository repository,
        IUyelikService uyelikService)
    {
        _repository = repository;
        _uyelikService = uyelikService;
    }

    public async Task<KullaniciDto> KaydetVeyaGuncelleAsync(
        User telegramKullanicisi,
        CancellationToken cancellationToken)
    {
        var kullanici = await _repository.TelegramIdIleGetirAsync(
            telegramKullanicisi.Id,
            cancellationToken);

        if (kullanici is null)
        {
            kullanici = new Kullanici
            {
                TelegramKullaniciId = telegramKullanicisi.Id,
                KullaniciAdi = telegramKullanicisi.Username,
                Ad = telegramKullanicisi.FirstName,
                Soyad = telegramKullanicisi.LastName,
                BotMu = telegramKullanicisi.IsBot,
                KayitTarihi = DateTime.UtcNow,
                SonGorulmeTarihi = DateTime.UtcNow
            };

            await _repository.EkleAsync(kullanici, cancellationToken);
        }
        else
        {
            kullanici.KullaniciAdi = telegramKullanicisi.Username;
            kullanici.Ad = telegramKullanicisi.FirstName;
            kullanici.Soyad = telegramKullanicisi.LastName;
            kullanici.SonGorulmeTarihi = DateTime.UtcNow;

            await _repository.KaydetAsync(cancellationToken);
        }

        var bitis = await _uyelikService.AktifUyelikBitisTarihiGetirAsync(
            kullanici.Id,
            cancellationToken);

        return new KullaniciDto
        {
            Id = kullanici.Id,
            TelegramKullaniciId = kullanici.TelegramKullaniciId,
            KullaniciAdi = kullanici.KullaniciAdi,
            AdSoyad = $"{kullanici.Ad} {kullanici.Soyad}".Trim(),
            AdminMi = kullanici.AdminMi,
            EngellendiMi = kullanici.EngellendiMi,
            AktifVipMi = bitis.HasValue,
            UyelikBitisTarihi = bitis
        };
    }

    public async Task<KullaniciDto?> TelegramIdIleGetirAsync(
        long telegramKullaniciId,
        CancellationToken cancellationToken)
    {
        var kullanici = await _repository.TelegramIdIleGetirAsync(
            telegramKullaniciId,
            cancellationToken);

        if (kullanici is null)
            return null;

        var bitis = await _uyelikService.AktifUyelikBitisTarihiGetirAsync(
            kullanici.Id,
            cancellationToken);

        return new KullaniciDto
        {
            Id = kullanici.Id,
            TelegramKullaniciId = kullanici.TelegramKullaniciId,
            KullaniciAdi = kullanici.KullaniciAdi,
            AdSoyad = $"{kullanici.Ad} {kullanici.Soyad}".Trim(),
            AdminMi = kullanici.AdminMi,
            EngellendiMi = kullanici.EngellendiMi,
            AktifVipMi = bitis.HasValue,
            UyelikBitisTarihi = bitis
        };
    }
}
