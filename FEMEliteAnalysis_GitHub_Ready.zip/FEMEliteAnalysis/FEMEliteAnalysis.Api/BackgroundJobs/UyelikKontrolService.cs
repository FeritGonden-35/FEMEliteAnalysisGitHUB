using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Enums;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.BackgroundJobs;

public class UyelikKontrolService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<UyelikKontrolService> _logger;

    public UyelikKontrolService(
        IServiceScopeFactory scopeFactory,
        ILogger<UyelikKontrolService> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var dbContext = scope.ServiceProvider.GetRequiredService<FemDbContext>();

                var simdi = DateTime.UtcNow;

                var suresiDolanlar = await dbContext.Uyelikler
                    .Where(x =>
                        x.Durum == UyelikDurumu.Aktif &&
                        x.BitisTarihi <= simdi)
                    .ToListAsync(stoppingToken);

                foreach (var uyelik in suresiDolanlar)
                    uyelik.Durum = UyelikDurumu.SuresiDoldu;

                if (suresiDolanlar.Count > 0)
                    await dbContext.SaveChangesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Üyelik kontrol servisinde hata oluştu.");
            }

            await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
        }
    }
}
