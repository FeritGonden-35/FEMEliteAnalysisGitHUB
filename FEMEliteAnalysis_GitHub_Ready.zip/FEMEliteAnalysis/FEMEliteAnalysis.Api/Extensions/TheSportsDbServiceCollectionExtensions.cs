using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Providers.TheSportsDb;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Extensions;

public static class TheSportsDbServiceCollectionExtensions
{
    public static IServiceCollection AddFemTheSportsDb(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<TheSportsDbOptions>(
            configuration.GetSection(TheSportsDbOptions.SectionName));

        services.AddHttpClient<TheSportsDbV2Client>(
            (serviceProvider, client) =>
            {
                var options = serviceProvider
                    .GetRequiredService<IOptions<TheSportsDbOptions>>()
                    .Value;

                var baseUrl = string.IsNullOrWhiteSpace(options.V2BaseUrl)
                    ? "https://www.thesportsdb.com/api/v2/json/"
                    : options.V2BaseUrl.TrimEnd('/') + "/";

                client.BaseAddress = new Uri(baseUrl);
                client.Timeout = TimeSpan.FromSeconds(45);
                client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
                client.DefaultRequestHeaders.UserAgent.ParseAdd("FEMEliteAnalysis/2.0");

                if (!string.IsNullOrWhiteSpace(options.V2ApiKey))
                    client.DefaultRequestHeaders.Add(
                        "X-API-KEY",
                        options.V2ApiKey.Trim());
            });

        services.AddHttpClient<IVeriSaglayici, TheSportsDbVeriSaglayici>(
            (serviceProvider, client) =>
            {
                var options = serviceProvider
                    .GetRequiredService<IOptions<TheSportsDbOptions>>()
                    .Value;

                var baseUrl = string.IsNullOrWhiteSpace(options.BaseUrl)
                    ? "https://www.thesportsdb.com/api/v1/json/"
                    : options.BaseUrl.TrimEnd('/') + "/";

                var apiKey = !string.IsNullOrWhiteSpace(options.V1ApiKey)
                    ? options.V1ApiKey.Trim()
                    : !string.IsNullOrWhiteSpace(options.ApiKey)
                        ? options.ApiKey.Trim()
                        : "3";

                client.BaseAddress = new Uri($"{baseUrl}{apiKey}/");
                client.Timeout = TimeSpan.FromSeconds(90);
                client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
                client.DefaultRequestHeaders.UserAgent.ParseAdd("FEMEliteAnalysis/2.0");
            });

        return services;
    }
}
