using FEMEliteAnalysis.Api.Bot.Handlers;
using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Services;

namespace FEMEliteAnalysis.Api.Extensions;

public static class DebugServiceCollectionExtensions
{
    public static IServiceCollection AddFemDebugMode(
        this IServiceCollection services)
    {
        services.AddScoped<IDebugService, DebugService>();
        services.AddScoped<DebugTelegramService>();
        services.AddSingleton<TelegramDebugCommandHandler>();

        return services;
    }
}
