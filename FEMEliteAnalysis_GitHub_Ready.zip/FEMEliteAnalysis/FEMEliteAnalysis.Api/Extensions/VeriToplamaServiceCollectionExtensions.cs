using FEMEliteAnalysis.Api.BackgroundServices;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Services;

namespace FEMEliteAnalysis.Api.Extensions;

public static class VeriToplamaServiceCollectionExtensions
{
    public static IServiceCollection AddFemVeriToplama(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<VeriToplamaOptions>(
            configuration.GetSection(
                VeriToplamaOptions.SectionName));

        services.AddSingleton<
            IVeriToplamaDurumStore,
            VeriToplamaDurumStore>();

        services.AddScoped<
            IVeriSaglayiciFactory,
            VeriSaglayiciFactory>();

        services.AddScoped<
            IVeriToplamaService,
            VeriToplamaService>();

        services.AddHostedService<
            VeriToplamaBackgroundService>();

        return services;
    }
}
