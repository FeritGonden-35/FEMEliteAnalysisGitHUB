using FEMEliteAnalysis.Api.Bot.Handlers;
using FEMEliteAnalysis.Api.Bot.Services;
using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Repositories;
using FEMEliteAnalysis.Api.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Options;
using Telegram.Bot;

namespace FEMEliteAnalysis.Api.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddFemOptions(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<TelegramOptions>(
            configuration.GetSection(TelegramOptions.SectionName));

        services.Configure<OpenAIOptions>(
            configuration.GetSection(OpenAIOptions.SectionName));

        services.Configure<MacApiOptions>(
            configuration.GetSection(MacApiOptions.SectionName));

        services.Configure<CacheOptions>(
            configuration.GetSection(CacheOptions.SectionName));

        services.Configure<MacAnalizOptions>(
            configuration.GetSection(MacAnalizOptions.SectionName));

        services.Configure<ModerasyonOptions>(
            configuration.GetSection(ModerasyonOptions.SectionName));

        services.Configure<HistoricalDataOptions>(
            configuration.GetSection(HistoricalDataOptions.SectionName));

        services.Configure<AnalizMotoruOptions>(
            configuration.GetSection(AnalizMotoruOptions.SectionName));

        services.Configure<OddsApiOptions>(
            configuration.GetSection(OddsApiOptions.SectionName));

        services.Configure<TelegramJoinVerificationOptions>(
            configuration.GetSection(TelegramJoinVerificationOptions.SectionName));

        return services;
    }

    public static IServiceCollection AddFemDatabase(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionString =
            configuration.GetConnectionString("FemDatabase")
            ?? throw new InvalidOperationException(
                "ConnectionStrings:FemDatabase ayarı bulunamadı.");

        services.AddDbContext<FemDbContext>(options =>
        {
            options.UseSqlServer(
                connectionString,
                sqlServerOptions =>
                {
                    sqlServerOptions.EnableRetryOnFailure();
                    sqlServerOptions.CommandTimeout(60);
                    sqlServerOptions.MigrationsHistoryTable(
                        "__EFMigrationsHistory",
                        "fem");
                });

            // Feature 14 kupon tabloları FemDbInitializer içinde güvenli SQL ile
            // oluşturuluyor. Bu nedenle yalnızca pending-model uyarısını bastırıyoruz.
            options.ConfigureWarnings(warnings =>
                warnings.Ignore(
                    RelationalEventId.PendingModelChangesWarning));
        });

        return services;
    }

    public static IServiceCollection AddFemServices(
        this IServiceCollection services)
    {
        services.AddMemoryCache();

        services.AddScoped<KullaniciRepository>();

        services.AddScoped<ICacheService, MemoryCacheService>();
        services.AddScoped<IKullaniciService, KullaniciService>();
        services.AddScoped<IUyelikService, UyelikService>();
        services.AddScoped<IVipYonetimService, VipYonetimService>();
        services.AddScoped<TelegramJoinVerificationService>();

        services.AddScoped<IYapayZekaService, YapayZekaService>();
        services.AddScoped<IFemAnalizMotoru, FemAnalizMotoru>();
        services.AddScoped<IKuponMarketMotoru, KuponMarketMotoru>();
        services.AddScoped<IAnalizMotoruV2, AnalizMotoruV2>();

        services.AddScoped<IMacVeriService, MacVeriService>();
        services.AddScoped<IMacAnalizVerisiService, MacAnalizVerisiService>();
        services.AddScoped<ISqlTakimFormService, SqlTakimFormService>();
        services.AddScoped<ITakimSaglayiciKimlikService, TakimSaglayiciKimlikService>();

        services.AddHttpClient<ILigYonetimService, LigYonetimService>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<IOptions<TheSportsDbOptions>>().Value;
            var key = !string.IsNullOrWhiteSpace(options.V1ApiKey) ? options.V1ApiKey : options.ApiKey;
            var baseUrl = string.IsNullOrWhiteSpace(options.BaseUrl)
                ? "https://www.thesportsdb.com/api/v1/json/"
                : options.BaseUrl.TrimEnd('/') + "/";
            client.BaseAddress = new Uri($"{baseUrl}{key.Trim()}/");
            client.Timeout = TimeSpan.FromSeconds(90);
            client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FEMEliteAnalysis/1.0");
        });

        services.AddScoped<IAnalizService, AnalizService>();
        services.AddScoped<IAnalizYayinService, AnalizYayinService>();
        services.AddScoped<IAnalizDuzenlemeService, AnalizDuzenlemeService>();

        services.AddSingleton<
            ICokluKuponTaslakService,
            CokluKuponTaslakService>();

        services.AddScoped<VeriToplamaTelegramService>();
        services.AddScoped<CokluKuponTelegramService>();
        services.AddScoped<IKuponKaliciService, KuponKaliciService>();
        services.AddScoped<IKuponOptimizasyonService, KuponOptimizasyonService>();
        services.AddScoped<KuponOptimizasyonTelegramService>();
        services.AddScoped<IKuponYayinService, KuponYayinService>();
        services.AddScoped<KuponYayinTelegramService>();
        services.AddScoped<IKuponPerformansService, KuponPerformansService>();
        services.AddScoped<KuponPerformansTelegramService>();
        services.AddScoped<IHedefKuponService, HedefKuponService>();
        services.AddScoped<IOtomatikKuponService, OtomatikKuponService>();
        services.AddScoped<IYuksekOranPatternService, YuksekOranPatternService>();
        services.AddScoped<IOddsPatternEngine, OddsPatternEngine>();
        services.AddScoped<IKilitMacService, KilitMacService>();
        services.AddSingleton<IOranHavuzuService, OranHavuzuService>();
        services.AddHttpClient<IOddsApiService, OddsApiService>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<IOptions<OddsApiOptions>>().Value;
            var baseUrl = string.IsNullOrWhiteSpace(options.BaseUrl) ? "https://api.pulsescore.net/api/v3/bet365/" : options.BaseUrl.TrimEnd('/') + "/";
            client.BaseAddress = new Uri(baseUrl);
            client.Timeout = TimeSpan.FromSeconds(45);
            client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FEMEliteAnalysis/1.0");
        });
        services.AddScoped<HedefKuponTelegramService>();
        services.AddSingleton<FEMEliteAnalysis.Api.Bot.Moderation.ModerasyonDurumStore>();
        services.AddSingleton<FEMEliteAnalysis.Api.Bot.Moderation.ModerasyonAnalizService>();
        services.AddScoped<ModerasyonTelegramService>();
        services.AddScoped<UygunMacTelegramService>();
        services.AddSingleton<IstatistikSyncDurumStore>();
        services.AddSingleton<HistoricalImportStatusStore>();
        services.AddScoped<IHistoricalImportService, HistoricalImportService>();
        services.AddScoped<HistoricalImportTelegramService>();
        services.AddScoped<IFootballDataCoUkImportService, FootballDataCoUkImportService>();
        services.AddScoped<FootballDataTelegramService>();
        services.AddSingleton<TeamRepairStatusStore>();
        services.AddScoped<ITeamRepairService, TeamRepairService>();
        services.AddScoped<TeamRepairTelegramService>();


        services.AddHttpClient<IIstatistikSyncService, IstatistikSyncService>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<IOptions<TheSportsDbOptions>>().Value;
            var baseUrl = string.IsNullOrWhiteSpace(options.BaseUrl)
                ? "https://www.thesportsdb.com/api/v1/json/"
                : options.BaseUrl.TrimEnd('/') + "/";
            var apiKey = !string.IsNullOrWhiteSpace(options.V1ApiKey)
                ? options.V1ApiKey.Trim()
                : options.ApiKey.Trim();
            client.BaseAddress = new Uri($"{baseUrl}{apiKey}/");
            client.Timeout = TimeSpan.FromSeconds(60);
            client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FEMEliteAnalysis/1.0");
        });

        services.AddHttpClient<IUygunMacService, UygunMacService>((serviceProvider, client) =>
        {
            var options = serviceProvider.GetRequiredService<IOptions<TheSportsDbOptions>>().Value;
            var baseUrl = string.IsNullOrWhiteSpace(options.BaseUrl)
                ? "https://www.thesportsdb.com/api/v1/json/"
                : options.BaseUrl.TrimEnd('/') + "/";
            var apiKey = !string.IsNullOrWhiteSpace(options.V1ApiKey)
                ? options.V1ApiKey.Trim()
                : options.ApiKey.Trim();
            client.BaseAddress = new Uri($"{baseUrl}{apiKey}/");
            client.Timeout = TimeSpan.FromSeconds(60);
            client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FEMEliteAnalysis/1.0");
        });

        services.AddHttpClient<
            IMacSenkronizasyonService,
            MacSenkronizasyonService>(
            (serviceProvider, client) =>
            {
                MacHttpClientAyarla(
                    serviceProvider,
                    client);
            });

        services.AddHttpClient<
            ITakimGecmisSenkronizasyonService,
            TakimGecmisSenkronizasyonService>(
            (serviceProvider, client) =>
            {
                MacHttpClientAyarla(
                    serviceProvider,
                    client);
            });

        return services;
    }

    public static IServiceCollection AddFemTelegram(
        this IServiceCollection services)
    {
        services.AddSingleton<ITelegramBotClient>(serviceProvider =>
        {
            var options = serviceProvider
                .GetRequiredService<IOptions<TelegramOptions>>()
                .Value;

            if (string.IsNullOrWhiteSpace(options.BotToken))
            {
                throw new InvalidOperationException(
                    "Telegram:BotToken ayarı bulunamadı.");
            }

            return new TelegramBotClient(options.BotToken);
        });

        services.AddSingleton<TelegramCallbackHandler>();
        services.AddSingleton<TelegramTeamRepairCommandHandler>();
        services.AddSingleton<TelegramKuponCommandHandler>();
        services.AddSingleton<TelegramModerasyonCommandHandler>();
        services.AddSingleton<TelegramUygunMacCommandHandler>();
        services.AddSingleton<TelegramHistoricalCommandHandler>();
        services.AddSingleton<TelegramFootballDataCommandHandler>();
        services.AddSingleton<TelegramSearchCommandHandler>();
        services.AddSingleton<TelegramLigCommandHandler>();
        services.AddSingleton<TelegramUpdateHandler>();
        services.AddSingleton<TelegramMesajService>();
        services.AddHostedService<TelegramBotBackgroundService>();
        services.AddHostedService<FEMEliteAnalysis.Api.BackgroundServices.IstatistikSyncBackgroundService>();

        return services;
    }

    private static void MacHttpClientAyarla(
        IServiceProvider serviceProvider,
        HttpClient client)
    {
        var options = serviceProvider
            .GetRequiredService<IOptions<MacApiOptions>>()
            .Value;

        var baseUrl = string.IsNullOrWhiteSpace(options.BaseUrl)
            ? "https://v3.football.api-sports.io/"
            : options.BaseUrl.TrimEnd('/') + "/";

        client.BaseAddress = new Uri(baseUrl);
        client.Timeout = TimeSpan.FromSeconds(60);
    }
}
