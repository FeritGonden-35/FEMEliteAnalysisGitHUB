using FEMEliteAnalysis.Api.Interfaces;
using FEMEliteAnalysis.Api.Options;
using FEMEliteAnalysis.Api.Providers.SofaScore;
using Microsoft.Extensions.Options;

namespace FEMEliteAnalysis.Api.Extensions;

public static class SofaScoreServiceCollectionExtensions
{
    public static IServiceCollection AddFemSofaScore(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<SofaScoreOptions>(
            configuration.GetSection(
                SofaScoreOptions.SectionName));

        services.AddHttpClient<
            IVeriSaglayici,
            SofaScoreVeriSaglayici>(
            (serviceProvider, client) =>
            {
                var options = serviceProvider
                    .GetRequiredService<
                        IOptions<SofaScoreOptions>>()
                    .Value;

                var baseUrl =
                    string.IsNullOrWhiteSpace(options.BaseUrl)
                        ? "https://www.sofascore.com/api/v1/"
                        : options.BaseUrl.TrimEnd('/') + "/";

                client.BaseAddress = new Uri(baseUrl);
                client.Timeout = TimeSpan.FromSeconds(45);

                client.DefaultRequestHeaders.UserAgent.ParseAdd(
                    string.IsNullOrWhiteSpace(options.UserAgent)
                        ? "FEMEliteAnalysis/1.0"
                        : options.UserAgent);

                client.DefaultRequestHeaders.Accept.ParseAdd(
                    "application/json");
            });

        return services;
    }
}
