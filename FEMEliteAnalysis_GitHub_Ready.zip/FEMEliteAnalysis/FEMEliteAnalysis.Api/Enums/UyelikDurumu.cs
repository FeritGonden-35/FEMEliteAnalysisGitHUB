namespace FEMEliteAnalysis.Api.Enums;

public enum UyelikDurumu
{
    Pasif = 0,
    Aktif = 1,
    SuresiDoldu = 2,
    IptalEdildi = 3
}
