namespace FEMEliteAnalysis.Api.Enums;

public enum AnalizDurumu
{
    Taslak = 0,
    Yayinlandi = 1,
    Sonuclandi = 2,
    IptalEdildi = 3
}
