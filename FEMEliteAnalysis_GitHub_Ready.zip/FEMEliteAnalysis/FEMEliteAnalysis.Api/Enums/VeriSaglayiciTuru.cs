namespace FEMEliteAnalysis.Api.Enums;

public enum VeriSaglayiciTuru
{
    Bilinmiyor = 0,
    ApiFootball = 1,
    AcikVeri = 2,
    Crawler = 3,
    TheSportsDb = 4
}
