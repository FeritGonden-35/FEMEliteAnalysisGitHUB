namespace FEMEliteAnalysis.Api.Enums;

public enum AnalizSonucu
{
    Bekliyor = 0,
    Basarili = 1,
    Basarisiz = 2,
    Iade = 3,
    Iptal = 4
}
