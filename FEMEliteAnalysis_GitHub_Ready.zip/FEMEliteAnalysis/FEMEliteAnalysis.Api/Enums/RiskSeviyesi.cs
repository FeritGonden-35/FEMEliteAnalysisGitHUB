namespace FEMEliteAnalysis.Api.Enums;

public enum RiskSeviyesi
{
    Dusuk = 1,
    Orta = 2,
    Yuksek = 3
}
