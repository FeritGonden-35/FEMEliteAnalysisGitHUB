using FEMEliteAnalysis.Api.Data;
using FEMEliteAnalysis.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FEMEliteAnalysis.Api.Repositories;

public class KullaniciRepository
{
    private readonly FemDbContext _dbContext;

    public KullaniciRepository(FemDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Kullanici?> TelegramIdIleGetirAsync(
        long telegramKullaniciId,
        CancellationToken cancellationToken)
    {
        return _dbContext.Kullanicilar
            .FirstOrDefaultAsync(
                x => x.TelegramKullaniciId == telegramKullaniciId,
                cancellationToken);
    }

    public async Task EkleAsync(
        Kullanici kullanici,
        CancellationToken cancellationToken)
    {
        _dbContext.Kullanicilar.Add(kullanici);
        await _dbContext.SaveChangesAsync(cancellationToken);
    }

    public Task KaydetAsync(CancellationToken cancellationToken)
        => _dbContext.SaveChangesAsync(cancellationToken);
}
